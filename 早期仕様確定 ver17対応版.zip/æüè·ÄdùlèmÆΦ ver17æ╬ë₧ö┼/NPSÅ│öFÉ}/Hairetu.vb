﻿Imports BricscadDb

Module Hairetu

    'P_sBlkPathはReadINI.vbにて代入されており、その値は
    '"\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\"

    Public P_HBlkPath As String = P_sBlkPath & "hairetu\"           '配列図用ﾌﾞﾛｯｸの保存場所

    Public P_Hairetu() As String                                    '扉構造
    Private sChkExtHako As String                                   '納入外箱Noかどうかのﾁｪｯｸ結果
    Private Const cP_Gage As String = "ゲージ式"                    'ｹﾞｰｼﾞ式
    '
    '配列図作成
    '
    Public Sub sCreHairetu()
        Dim dInsPnt(2) As Double
        Dim blkObj As AcadBlockReference                                'ﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
        Dim iBanNum As Integer                                          '盤数
        Dim i As Integer ', p As Integer
        'Dim iPage As Integer
        BanNoSK = 0

        'アクティブレイヤーの変更
        '指定したレイヤーをアクティブにする
        Call Tools.SetActiveLayer("自動作成")

        'NPS承認図が選択された場合
        If nps = True Then                                              'NPS承認図が選択された場合
            YDown = NPSDown                                             '表題が少なくなるので、作図位置を少し下げる
        Else
            YDown = 0
        End If

        acadDoc.SendCommand("'_zoom" & vbCrLf & "_e" & vbCr)

        'iPage = 1　つまり一回だけ作成されるものをここに記載
        '構造図と側面図は盤の数に関わらず一個しか作成されないため、
        'ここで作成している

        If iPage = 1 Then

            '扉構造図(配列図左上)
            '------------------------------------
            dInsPnt(0) = SetScale(conZhyX1, p_Scale)                        'ﾌﾞﾛｯｸ挿入位置X設定
            dInsPnt(1) = SetScale(conZhyY1 - YDown, p_Scale)                        'ﾌﾞﾛｯｸ挿入位置Y設定
            dInsPnt(2) = 0.0#                                               'ﾌﾞﾛｯｸ挿入位置Z設定
            blkObj = fInsBlk(dInsPnt, P_HBlkPath & "P_KOZO_TYPE", 1, p_DoorTyp) '扉構造図ﾌﾞﾛｯｸ挿入
            Call sSetDoorKouzo()                                            '扉構造に応じたﾌﾞﾛｯｸ挿入
            iBanNum = UBound(H_D)                                           '盤数取得
            '------------------------------------

            '側面図作成
            'iBanNumは盤の最大数
            Call sCreSideDrw(iBanNum)

            '------------------------------------
        End If


        '配列初期化
        For i = 0 To 10
            For j = 0 To 20
                H_PageHakoNo(i, j) = ""
            Next j
        Next i

        '必要図面枚数の計算
        Call CalNeedPageH()

        '------------------------------------
        '正面図作成
        'iPage = p
        'p = 1 To TL_ZMaisu(必要枚数)

        Call sCreFrontDrw(iBanNum)

        '------------------------------------
        acadDoc.SendCommand("LTSCALE" & vbCrLf & "150" & vbCrLf)    '線種尺度の調整
        acadApp.ZoomAll()
    End Sub



    '-----------------------------------------------
    ' 正面図作成プログラム
    '-----------------------------------------------
    '   iBanNum   : 盤数
    '   pntX      : 正面図の描き始めX座標(ex 90)
    '-----------------------------------------------
    'Private Sub sCreFrontDrw(iBanNum As Integer, dPntX As Double, iPage As Integer)
    Private Sub sCreFrontDrw(ByVal iBanNum As Integer)
        Dim dPntX As Double
        Dim dCFD_MainX As Double                            '基本座標（Ｘ座標）
        Dim iH_IO As Integer
        Dim iBanCnt As Integer                              '盤ｶｳﾝﾀｰ
        Dim sExtChk As String                               '納入外ﾁｪｯｸﾌﾗｸﾞ
        Dim bFstBan As Boolean                                  '最初に表示する盤かどうか
        Dim dCFD_ExtXL As Double, dCFD_ExtXR As Double          '納入外を含まない列番の左端,右端位置
        Dim dH_Val As Double
        Dim blockObj As Object          'ﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
        Dim dimLin As AcadDimAligned    '寸法線
        Dim sT_WakTyp As String         '箱ﾀｲﾌﾟ(Tmp)
        Dim sCFD_Block As String        'ﾌﾞﾛｯｸ名
        Dim sBlkChk() As String         '
        Dim bBlkChkFlg As Boolean       '
        Dim iBlkCnt As Integer          'ﾌﾞﾛｯｸｶｳﾝﾀｰ
        Dim lin_obj As AcadLine         '線
        Dim sBlock As String            'ﾌﾞﾛｯｸ名
        Dim dimRotate As AcadDimRotated

        Dim HyoudaiX As Double         '表題欄用X座標
        'Dim HyoudaiY As Double         '表題欄用Y座標
        Dim Chk As Object
        Dim CB_Block As String          'ブロックスケルトンのブロック名
        Dim i As Integer, j As Integer
        'Dim MString As String
        'Dim BCnt As Integer
        Dim Attribs As Object           'ブロックの要素
        Dim dOrgHigh As Integer

        Cellingflg = False

        If iPage = 1 Then
            H_Cnt = 0
            dPntX = conZhyX2 + Val(H_D(iBanNum)) / p_Scale + conDou10
        Else
            dPntX = conZhyX3
        End If

        'Const cH_Limit = 2500      '16.9.13 吹野氏に確認 by 松本
        'Const cH_Limit = 3150       '←
        dCFD_MainX = dPntX
        If IO = "屋外" Then
            'iH_IO = 150        「O_1000.dwg」を編集したため変更
            iH_IO = 180
        Else
            iH_IO = 0
        End If
        i = 1
        iBanCnt = 1 + H_Cnt
        '箱別データ作図
        sExtChk = "OFF"
        bFstBan = True                                      '最初に表示する盤としておく
        Zencho = 0                                          '全長初期化

        XLen = 0
        YLen = 0

        'iPageはカウンタの値を代入したパブリック変数
        '１からTL_Maisu(必要枚数)の分までの値が入る

        Do Until (H_PageHakoNo(iPage, i) = "")

            If InStr(ExtCubNo(iBanCnt), P_conNoShow) = 0 Then  '納入外（非表示）以外の盤の場合
                dH_Val = Val(H_H(iBanCnt))                  '箱高さ取得 
                'If dH_Val > cH_Limit Then                   '箱高さが制限値より大きい場合    '高さ制限撤廃(17/3/31)
                '    dH_Val = cH_Limit                       '箱高さは制限値とする
                'End If
                If InStr(ExtCubNo(iBanCnt), "納入外") = 0 Then  '納入外でない盤の場合
                    sCFD_Block = "I_" & H_W(iBanCnt)
                    If sExtChk = "ON" Then
                        dCFD_ExtXL = dCFD_MainX                 '左端をｾｯﾄ
                        sExtChk = "OFF"
                    End If
                Else
                    sCFD_Block = "EI_" & H_W(iBanCnt)
                    If sExtChk = "OFF" Then
                        dCFD_ExtXR = dCFD_MainX                 '右端をｾｯﾄ(ﾙｰﾌﾟの度に更新される)
                        sExtChk = "ON"
                    End If
                End If

                'アクティブレイヤーの変更 あとまわし knsknskns
                'Call SetActiveLayer("自動作成")

                'ブロック配置
                'nps承認図の場合、表題は一部のみ使用
                InsPnt(0) = SetScale(dCFD_MainX, p_Scale)
                InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
                InsPnt(2) = 0.0#

                If iBanCnt = 1 Then
                    HyoudaiX = InsPnt(0)
                End If
                S_CUBNO = H_CubNo(iBanCnt)
                S_NP1 = H_NP1(iBanCnt)
                S_NP2 = H_NP2(iBanCnt)
                S_NP3 = H_NP3(iBanCnt)
                S_DRZUBAN = H_DRZuban(iBanCnt)
                S_DOORZUBAN = H_DoorZuban(iBanCnt)
                'S_KATA = H_Kata(iBanCnt)
                S_JYURYO = H_Jyuryo(iBanCnt) & "kg"
                If nps = False Then     '簡略図でないなら(簡略図の場合は上の6項目のみ)
                    'S_DRZUBAN = H_DRZuban(iBanCnt)
                    'S_DOORZUBAN = H_DoorZuban(iBanCnt)
                    S_KATA = H_Kata(iBanCnt)
                    S_HOGO = H_Hogo1(iBanCnt)
                    S_HOGO2 = H_Hogo2(iBanCnt)
                    S_DENATU = H_DenAtu(iBanCnt)
                    S_HZ = H_Hz(iBanCnt)
                    S_ZETUEN = H_Zetuen(iBanCnt)
                    S_TNP = H_TNP(iBanCnt)
                    S_JYOTAI = IO & "形" & H_Jyotai(iBanCnt)     '(屋内or屋外)形(環境条件)
                    S_DOOROPEN = H_DoorOpen(iBanCnt) & "度"      '扉開放角度
                    S_POWERFREQUENCY = H_PowerFreq(iBanCnt)
                    S_LIGHTNINGIMPULSE = H_Impulse(iBanCnt)
                Else
                    'InsPnt(1) = InsPnt(1) - YDown
                End If

                '↓元々の
                'InsPnt(0) = SetScale(dCFD_MainX, p_Scale)
                'InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
                'InsPnt(2) = 0.0#
                'S_CUBNO = H_CubNo(iBanCnt)
                'S_DRZUBAN = H_DRZuban(iBanCnt)
                'S_DOORZUBAN = H_DoorZuban(iBanCnt)
                'S_KATA = H_Kata(iBanCnt)
                'S_HOGO = H_Hogo1(iBanCnt)
                'S_HOGO2 = H_Hogo2(iBanCnt)
                'S_DENATU = H_DenAtu(iBanCnt)
                'S_HZ = H_Hz(iBanCnt)
                'S_ZETUEN = H_Zetuen(iBanCnt)
                'S_TNP = H_TNP(iBanCnt)
                'S_JYOTAI = H_Jyotai(iBanCnt)
                'S_DOOROPEN = H_DoorOpen(iBanCnt)
                'S_JYURYO = H_Jyuryo(iBanCnt)
                'S_NP1 = H_NP1(iBanCnt)
                'S_NP2 = H_NP2(iBanCnt)
                'S_NP3 = H_NP3(iBanCnt)
                'S_POWERFREQUENCY = H_PowerFreq(iBanCnt)
                'S_LIGHTNINGIMPULSE = H_Impulse(iBanCnt)
                '↑
                If InStr(ExtCubNo(iBanCnt), "納入外") = 0 Then  '納入外でない盤の場合
                    blockObj = fVariSize(InsPnt(0), InsPnt(1), "屋内", Val(H_W(iBanCnt)), dH_Val - iH_IO, "", "")
                Else
                    blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外屋内", Val(H_W(iBanCnt)), dH_Val - iH_IO, "", "")
                End If



                ''ブロックスケルトン
                'CB_Block = ""
                CB_Block = P_sBanDat(pc_BlkSKRow, iBanCnt - 1)                                         '↓X方向の尺度(1/2しているのはブロックスケルトンの基点が下線の左端ではなく中点のため)
                'Chk = FunInsertBlock(CB_Block, InsPnt(0) + Val(H_W(iBanCnt)) / 2, InsPnt(1) + 3250, InsPnt(2), (XLen / 2) / (900 / 2), YLen / 2000, 0.0#, "ブロックスケルトン")
                ''                               ↑基準点のX座標+箱幅の半分      　↑基準点のY座標+3250                                ↑Y方向の尺度 ↑回転角度
                ''                                                                       3250(スケルトンの欄の下線のY座標 - 基準点のY座標)  

                'Chk = FunInsertBlock(CB_Block, InsPnt(0) + Val(H_W(iBanCnt)) / 2, InsPnt(1) + 3250, InsPnt(2), 1, 1, 0.0#, "ブロックスケルトン")
                If CB_Block <> "" Then
                    SKname = P_sBanDat(pc_BlkSKRow, iBanCnt - 1)
                    SKCopyPath = SKFullPath(iBanCnt - 1)
                    SKCnt = 0
                    BanNoSK = BanNoSK + 1
                    blockObj = fVariSize(InsPnt(0) + Val(H_W(iBanCnt)) / 2, InsPnt(1) + 3250, "ブロックスケルトン", Val(H_W(iBanCnt)), dH_Val - iH_IO, "", "")
                End If






                'アクティブレイヤーの変更 あとまわし knsknskns
                'Call SetActiveLayer("寸法")
                'アクティブレイヤーの変更
                Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                '線種変更
                Call SetActiveLine("BYLAYER")

                If bFstBan = True Then
                    '高さ寸法表示
                    If IO = "屋内" Then
                        insPntS(0) = SetScale(dCFD_MainX, p_Scale)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dCFD_MainX, p_Scale)
                        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_Val / p_Scale), p_Scale)
                        insPntE(2) = 0.0#
                        InsPnt(0) = SetScale(dCFD_MainX - conDou11, p_Scale) - 300
                        InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_Val / p_Scale) / 2), p_Scale)
                        InsPnt(2) = 0.0#
                        dimLin = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
                        dimLin.TextOverride = H_H(iBanCnt) '表示寸法を書き換える
                    ElseIf IO = "屋外" Then


                        insPntS(0) = SetScale(dCFD_MainX, p_Scale)
                        'insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        'insPntS(2) = 0.0#
                        'insPntE(0) = SetScale(dCFD_MainX, p_Scale)
                        'insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale) + conDou22, p_Scale)
                        'insPntE(2) = 0.0#
                        'InsPnt(0) = SetScale(dCFD_MainX - conDou24, p_Scale)
                        'InsPnt(1) = SetScale(conZhyY2 - YDown + ((((dH_Val - iH_IO) / p_Scale) + conDou22) / 2), p_Scale)
                        'InsPnt(2) = 0.0#
                        insPntS(1) = SetScale(conZhyY2 - YDown - (Val(BaseH) / p_Scale), p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dCFD_MainX, p_Scale)
                        insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale) + conDou23, p_Scale)
                        insPntE(2) = 0.0#
                        InsPnt(0) = SetScale(dCFD_MainX - conDou25, p_Scale) - 350
                        InsPnt(1) = SetScale(conZhyY2 - YDown + ((((dH_Val - iH_IO) / p_Scale) + conDou23) / 2), p_Scale)
                        InsPnt(2) = 0.0#
                        dimLin = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
                        dimLin.TextOverride = H_H(iBanCnt) + Val(BaseH) + conDou26 '表示寸法を書き換える

                        insPntS(0) = SetScale(dCFD_MainX, p_Scale)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dCFD_MainX, p_Scale)
                        insPntE(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val - iH_IO + 180
                        insPntE(2) = 0.0#
                        InsPnt(0) = SetScale(dCFD_MainX, p_Scale) - 600
                        InsPnt(1) = (SetScale(conZhyY2 - YDown, p_Scale) + dH_Val - iH_IO + 180) / 2
                        InsPnt(2) = 0.0#
                        dimLin = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
                        dimLin.TextOverride = H_H(iBanCnt)                           '表示寸法を書き換える
                    End If


                    'If iPage = 1 And nps = False Then       
                    If iPage = 1 Then       '1ページ目の場合、且つ簡略図ではない場合(簡略図の場合は表に角度を表示しないため、この寸法は必要ない)
                        '扉最大開放寸法
                        'ブロック位置
                        InsPnt(0) = SetScale(dCFD_MainX, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val - iH_IO
                        InsPnt(2) = 0.0#


                        sCFD_Block = "O_DOOR_SL"
                        CSD_OD_Sunpo = Val(H_W(iBanCnt)) / 2               '扉最大開放寸法の計算

                        blockObj = fVariSize(InsPnt(0), InsPnt(1), sCFD_Block, Val(H_W(1)), dH_Val - iH_IO, "", "")
                        Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                        Attribs(0).TextString = CSD_OD_Sunpo        '扉最大開放寸法値に書き換え

                    End If


                End If




                '巾寸法表示
                insPntS(0) = SetScale(dCFD_MainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + (dH_Val / p_Scale), p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dCFD_MainX + (Val(H_W(iBanCnt)) / p_Scale), p_Scale)
                insPntE(1) = SetScale(conZhyY2 - YDown + (dH_Val / p_Scale), p_Scale)
                insPntE(2) = 0.0#
                InsPnt(0) = SetScale(dCFD_MainX - ((Val(H_W(iBanCnt)) / p_Scale) / 2), p_Scale)
                'InsPnt(1) = SetScale(conDou3 - ((cH_Limit - dH_Val) / p_Scale), p_Scale)
                InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) + 525    '16.10.28 松本修正
                InsPnt(2) = 0.0#
                dimLin = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)

                'アクティブレイヤーの変更 あとまわし knsknskns
                'Call SetActiveLayer("自動作成")
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")


                'Cub.の属性が空白の場合は線を引く
                If nps = True Then                                                      '簡略図なら(17/01/19追加)
                    If Trim(S_NP1) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 0)
                    If Trim(S_NP2) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 1)
                    If Trim(S_NP3) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 2)
                    'If Trim(S_KATA) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 3)
                    If Trim(S_DRZUBAN) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 3)
                    If Trim(S_DOORZUBAN) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 4)
                    If Trim(S_JYURYO) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 5)
                Else
                    If Trim(S_NP1) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 0)
                    If Trim(S_NP2) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 1)
                    If Trim(S_NP3) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 2)
                    If Trim(S_DRZUBAN) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 3)
                    If Trim(S_DOORZUBAN) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 4)
                    If Trim(S_KATA) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 5)
                    If Trim(S_HOGO) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 6)
                    If Trim(S_HOGO2) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 7)
                    If Trim(S_DENATU) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 8)
                    If Trim(S_HZ) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 9)
                    If Trim(S_POWERFREQUENCY) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 10)
                    If Trim(S_LIGHTNINGIMPULSE) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 11)
                    If Trim(S_ZETUEN) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 12)
                    If Trim(S_TNP) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 13)
                    If Trim(S_JYOTAI) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 14)
                    If Trim(S_DOOROPEN) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 15)
                    If Trim(S_JYURYO) = "" Then Call sWrtNulLin(dCFD_MainX, iBanCnt, 16)
                End If


                '扉形状の作成＆取手ブロックの貼り付け
                sT_WakTyp = Left(H_WakuType(iBanCnt), 2)
                If InStr(ExtCubNo(iBanCnt), "納入外") = 0 Then  '納入外でない盤の場合
                    Call sCreTotte(sT_WakTyp, "", iBanCnt, dCFD_MainX)
                Else
                    Call sCreTotte(sT_WakTyp, "DOT_", iBanCnt, dCFD_MainX)
                End If

                '屋外専用ブロックの配置
                If IO = "屋外" Then
                    Cellingflg = True
                    '屋外用天井板の配置
                    If InStr(ExtCubNo(iBanCnt), "納入外") = 0 Then  '納入外でない盤の場合
                        sCFD_Block = "O_" & H_W(iBanCnt)
                    Else
                        sCFD_Block = "EO_" & H_W(iBanCnt)
                    End If
                    ReDim Preserve sBlkChk(iBanCnt)
                    sBlkChk(iBanCnt) = sCFD_Block
                    InsPnt(0) = SetScale(dCFD_MainX, p_Scale)
                    InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
                    InsPnt(2) = 0.0#
                    '同じブロックを再度variSizeを使い挿入すると既にAutoCAD上にある
                    'ブロック定義を変更してしまいサイズがずれる為、同じブロックは
                    'AutoCAD上のブロック定義を使うようにする
                    bBlkChkFlg = False
                    For iBlkCnt = 0 To iBanCnt - 1
                        If sBlkChk(iBlkCnt) = sCFD_Block Then
                            bBlkChkFlg = True
                        End If
                    Next iBlkCnt
                    If bBlkChkFlg = True Then
                        'blockObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                        blockObj = moSpace.InsertBlock(InsPnt, sCFD_Block, 1, 1, 1, 0.0#)
                    Else
                        If InStr(ExtCubNo(iBanCnt), "納入外") = 0 Then  '納入外でない盤の場合
                            blockObj = fVariSize(InsPnt(0), InsPnt(1), IO, Val(H_W(iBanCnt)), dH_Val, "", "")
                        Else
                            blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外屋外", Val(H_W(iBanCnt)), dH_Val, "", "")
                        End If
                    End If

                    Cellingflg = False


                    '屋外用換気箱
                    If P_sBanDat(pc_KankiRow, iBanCnt - 1) = "天井" Then
                        InsPnt(0) = SetScale(dCFD_MainX, p_Scale) + Val(H_W(iBanCnt)) / 2
                        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val + 30
                        InsPnt(2) = 0.0#
                        If InStr(ExtCubNo(iBanCnt), "納入外") = 0 Then  '納入外でない盤の場合 
                            blockObj = moSpace.InsertBlock(InsPnt, P_HBlkPath & "O_KANKI_FT.dwg", 1, 1, 1, 0.0#)
                        Else
                            blockObj = moSpace.InsertBlock(InsPnt, P_HBlkPath & "EO_KANKI_FT.dwg", 1, 1, 1, 0.0#)
                        End If


                        If iBanCnt = 1 Then
                            'アクティブレイヤーの変更
                            Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                            '線種変更
                            Call SetActiveLine("BYLAYER")

                            '換気箱高さ寸法
                            insPntS(0) = SetScale(dCFD_MainX, p_Scale)
                            insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val - iH_IO + 180
                            insPntS(2) = 0.0#
                            insPntE(0) = InsPnt(0) - 345
                            insPntE(1) = insPntS(1) + 300
                            insPntE(2) = 0.0#
                            InsPnt(0) = SetScale(dCFD_MainX - conDou11, p_Scale) - 300
                            InsPnt(1) = InsPnt(1)
                            InsPnt(2) = 0.0#

                            pnt10 = insPntS(0) & "," & insPntS(1) & "," & insPntS(2)
                            pnt11 = insPntE(0) & "," & insPntE(1) & "," & insPntE(2)
                            pnt12 = InsPnt(0) & "," & InsPnt(1) & "," & InsPnt(2)
                            acadDoc.SendCommand("_dimlinear" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & "V" & vbCrLf & pnt12 & vbCrLf)


                            'FAN点検所要寸法
                            insPntS(0) = insPntE(0)
                            insPntS(1) = insPntE(1)
                            insPntS(2) = 0.0#
                            insPntE(0) = insPntS(0)
                            insPntE(1) = insPntS(1) + 250
                            insPntE(2) = 0.0#
                            InsPnt(0) = SetScale(dCFD_MainX - conDou11, p_Scale) - 300
                            InsPnt(1) = insPntS(1)
                            InsPnt(2) = 0.0#

                            pnt10 = insPntS(0) & "," & insPntS(1) & "," & insPntS(2)
                            pnt11 = insPntE(0) & "," & insPntE(1) & "," & insPntE(2)
                            pnt12 = InsPnt(0) & "," & InsPnt(1) & "," & InsPnt(2)
                            acadDoc.SendCommand("_dimlinear" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & "V" & vbCrLf & pnt12 & vbCrLf)

                            'アクティブレイヤーの変更
                            Call SetActiveLayer("自動作成")
                        End If



                    ElseIf P_sBanDat(pc_KankiRow, iBanCnt - 1) = "背面扉" Then
                        InsPnt(0) = SetScale(dCFD_MainX, p_Scale) + Val(H_W(iBanCnt)) / 2
                        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val - 900
                        InsPnt(2) = 0.0#
                        blockObj = moSpace.InsertBlock(InsPnt, P_HBlkPath & "O_KANKI_FH.dwg", 1, 1, 1, 0.0#)
                    End If

                ElseIf IO = "屋内" Then
                    '屋内用換気箱
                    If P_sBanDat(pc_KankiRow, iBanCnt - 1) = "天井" Then
                        InsPnt(0) = SetScale(dCFD_MainX, p_Scale) + Val(H_W(iBanCnt)) / 2
                        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val
                        InsPnt(2) = 0.0#
                        If InStr(ExtCubNo(iBanCnt), "納入外") = 0 Then  '納入外でない盤の場合 
                            blockObj = moSpace.InsertBlock(InsPnt, P_HBlkPath & "I_KANKI_FT.dwg", 1, 1, 1, 0.0#)
                        Else
                            blockObj = moSpace.InsertBlock(InsPnt, P_HBlkPath & "EI_KANKI_FT.dwg", 1, 1, 1, 0.0#)
                        End If


                        If iBanCnt = 1 Then                 '1箱目なら
                            'アクティブレイヤーの変更
                            Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                            '線種変更
                            Call SetActiveLine("BYLAYER")

                            '換気箱高さ寸法
                            insPntS(0) = InsPnt(0) - Val(H_W(iBanCnt)) / 2 - 500
                            insPntS(1) = InsPnt(1)
                            insPntS(2) = 0.0#
                            insPntE(0) = InsPnt(0) - 300
                            insPntE(1) = InsPnt(1) + 400
                            insPntE(2) = 0.0#
                            InsPnt(0) = SetScale(dCFD_MainX - conDou11, p_Scale) - 300
                            InsPnt(1) = InsPnt(1)
                            InsPnt(2) = 0.0#

                            pnt10 = insPntS(0) & "," & insPntS(1) & "," & insPntS(2)
                            pnt11 = insPntE(0) & "," & insPntE(1) & "," & insPntE(2)
                            pnt12 = InsPnt(0) & "," & InsPnt(1) & "," & InsPnt(2)
                            acadDoc.SendCommand("_dimlinear" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & "V" & vbCrLf & pnt12 & vbCrLf)
                            'アクティブレイヤーの変更
                            Call SetActiveLayer("自動作成")
                        End If

                    ElseIf P_sBanDat(pc_KankiRow, iBanCnt - 1) = "背面扉" Then
                        InsPnt(0) = SetScale(dCFD_MainX, p_Scale) + Val(H_W(iBanCnt)) / 2
                        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val - 900
                        InsPnt(2) = 0.0#
                        blockObj = moSpace.InsertBlock(InsPnt, P_HBlkPath & "O_KANKI_FH.dwg", 1, 1, 1, 0.0#)
                    End If


                End If
                '箱巾分だけ加算
                dCFD_MainX = dCFD_MainX + (H_W(iBanCnt) / p_Scale)
                Zencho = Zencho + Val(H_W(iBanCnt))                     '全長を計算する
                bFstBan = False                                         '以後は2つめ以降の盤とする
            End If



            H_Cnt = H_Cnt + 1
            i = i + 1
            iBanCnt = iBanCnt + 1

        Loop






        '箱の右端位置（右側に納入外のが無い場合）
        If (dCFD_ExtXR = 0) Or (dCFD_ExtXR = dPntX) Then
            dCFD_ExtXR = dCFD_MainX
        End If
        '箱の左端位置（左側に納入外のが無い場合）
        If dCFD_ExtXL = 0 Then dCFD_ExtXL = dPntX

        'If iPage = TL_ZMaisu And nps = False Then       '最後のページの場合、且つ簡略図ではない場合
        If iPage = TL_ZMaisu Then
            '扉最大開放寸法
            'ブロック位置(最右端の箱の右隣にはりつける)
            InsPnt(0) = SetScale(dCFD_ExtXR, p_Scale)
            InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + dH_Val - iH_IO
            InsPnt(2) = 0.0#


            sCFD_Block = "O_DOOR_SR"
            CSD_OD_Sunpo = Val(H_W(iBanCnt - 1)) / 2                '扉最大開放寸法の計算
            blockObj = fVariSize(InsPnt(0), InsPnt(1), sCFD_Block, Val(H_W(iBanCnt - 1)), dH_Val - iH_IO, "", "")
            Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
            Attribs(0).TextString = CSD_OD_Sunpo        '扉最大開放寸法値に書き換え

        End If


        'アクティブレイヤーの変更 あとまわし knsknskns
        'Call SetActiveLayer("自動作成")

        ' 線分の作成（基礎ベース）
        '縦線
        insPntS(0) = SetScale(dCFD_ExtXL, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dCFD_ExtXL, p_Scale)
        insPntE(1) = SetScale(conZhyY2 - YDown - Val(BaseH / p_Scale), p_Scale)
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        lin_obj.color = ACAD_COLOR.acCyan

        '横線
        insPntS(0) = SetScale(dPntX, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown - Val(BaseH / p_Scale), p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dCFD_MainX, p_Scale)
        insPntE(1) = SetScale(conZhyY2 - YDown - Val(BaseH / p_Scale), p_Scale)
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        lin_obj.color = ACAD_COLOR.acCyan

        '縦線
        If sExtChk = "ON" Then
            insPntS(0) = SetScale(dCFD_ExtXR, p_Scale)
            insPntE(0) = SetScale(dCFD_ExtXR, p_Scale)
        Else
            insPntS(0) = SetScale(dCFD_MainX, p_Scale)
            insPntE(0) = SetScale(dCFD_MainX, p_Scale)
        End If
        insPntS(1) = SetScale(conZhyY2 - YDown - Val(BaseH / p_Scale), p_Scale)
        insPntS(2) = 0.0#
        insPntE(1) = SetScale(conZhyY2 - YDown, p_Scale)
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        lin_obj.color = ACAD_COLOR.acCyan

        'アクティブレイヤーの変更 あとまわし knsknskns
        'Call SetActiveLayer("寸法")
        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        '線種変更
        Call SetActiveLine("BYLAYER")

        ' 寸法線の作成（基礎ベース)
        If BaseH > 0 Then
            insPntS(0) = SetScale(dPntX, p_Scale)
            insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(dPntX, p_Scale)
            insPntE(1) = SetScale(conZhyY2 - YDown - Val(BaseH / p_Scale), p_Scale)
            insPntE(2) = 0.0#
            If IO = "屋内" Then
                'InsPnt(0) = SetScale(dPntX - conDou11, p_Scale)
                InsPnt(0) = SetScale(dPntX, p_Scale) - 600
            Else
                'InsPnt(0) = SetScale(dPntX - conDou24, p_Scale)
                InsPnt(0) = SetScale(dPntX, p_Scale) - 600
            End If
            InsPnt(1) = SetScale(conZhyY2 - YDown - (Val(BaseH / p_Scale)), p_Scale)
            InsPnt(2) = 0.0#
            dimLin = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        End If
        'アクティブレイヤーの変更 あとまわし knsknskns
        'Call SetActiveLayer("自動作成")
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")

        ' ブロックの作成（ＦＬ、ＧＬ線）
        InsPnt(0) = SetScale(dCFD_MainX, p_Scale)
        InsPnt(1) = SetScale(conZhyY2 - YDown - Val(BaseH / p_Scale), p_Scale)
        InsPnt(2) = 0.0#
        If IO = "屋内" Then
            sBlock = "FL_F"
        Else
            sBlock = "GL_F"
        End If
        blockObj = fInsBlk(InsPnt, P_HBlkPath & sBlock, 1, "")   'ﾌﾞﾛｯｸ挿入

        ' ブロックの作成（化粧板（左用））
        Select Case KeshoType
            Case V_KeshoType_1
                sBlock = "23"
            Case V_KeshoType_2
                sBlock = "32"
            Case V_KeshoType_3
                sBlock = "50"
            Case V_KeshoType_4
                sBlock = "25"
        End Select
        InsPnt(0) = SetScale(dCFD_ExtXL, p_Scale)
        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
        InsPnt(2) = 0.0#
        If IO = "屋内" Then
            blockObj = fVariSize(InsPnt(0), InsPnt(1), "正面化粧板", Val(H_W(iBanNum)), dH_Val - iH_IO, sBlock & "_L", "")
        Else
            blockObj = fVariSize(InsPnt(0), InsPnt(1), "正面化粧板", Val(H_W(iBanNum)), dH_Val - iH_IO, sBlock & "_L", "")
        End If

        ' ブロックの作成（化粧板（右用））
        InsPnt(0) = SetScale(dCFD_ExtXR, p_Scale)
        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
        InsPnt(2) = 0.0#
        If IO = "屋内" Then
            blockObj = fVariSize(InsPnt(0), InsPnt(1), "正面化粧板", Val(H_W(iBanNum)), dH_Val - iH_IO, sBlock & "_R", "")
        Else
            blockObj = fVariSize(InsPnt(0), InsPnt(1), "正面化粧板", Val(H_W(iBanNum)), dH_Val - iH_IO, sBlock & "_R", "")
        End If

        'アクティブレイヤーの変更 あとまわし knsknskns
        'SetActiveLayer("寸法")

        ' 寸法線の作成（化粧板)

        If KeshoType = V_KeshoType_3 Or KeshoType = V_KeshoType_4 Then
            If IO = "屋外" Then
                dOrgHigh = 2450
            Else
                dOrgHigh = 2300
            End If
            'アクティブレイヤーの変更
            Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
            '線種変更
            Call SetActiveLine("BYLAYER")
            '左側面用
            If KeshoType = V_KeshoType_3 Then
                insPntE(0) = SetScale(dCFD_ExtXL - conDou19, p_Scale)
                InsPnt(0) = SetScale(dCFD_ExtXL - (Val(conDou19) / 2), p_Scale)
            Else
                insPntE(0) = SetScale(dCFD_ExtXL - conDou20, p_Scale)
                InsPnt(0) = SetScale(dCFD_ExtXL - (Val(conDou20) / 2), p_Scale)
            End If
            insPntS(0) = SetScale(dCFD_ExtXL, p_Scale)
            'insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_Val) / p_Scale), p_Scale)
            'insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) - 100  '箱の天井-100の高さ
            insPntS(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_Val - dOrgHigh) / 6 / p_Scale * 3, p_Scale) + 250
            insPntS(2) = 0.0#
            'insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale)
            'insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) - 100
            insPntE(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_Val - dOrgHigh) / 6 / p_Scale * 3, p_Scale) + 250
            insPntE(2) = 0.0#
            'InsPnt(1) = SetScale(conDou18 - ((H_Limit - dH_Val) / p_Scale), p_Scale)
            'InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) - 100
            InsPnt(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_Val - dOrgHigh) / 6 / p_Scale * 3, p_Scale) + 250
            InsPnt(2) = 0.0#
            dimRotate = moSpace.AddDimRotated(insPntS, insPntE, InsPnt, 0)
            '表示寸法を書き換える
            If KeshoType = V_KeshoType_3 Then
                dimRotate.TextOverride = "50"
            Else
                dimRotate.TextOverride = "25"
            End If
            '右側面用
            Select Case sExtChk
                Case "ON" '納入外有りの場合
                    If KeshoType = V_KeshoType_3 Then
                        insPntE(0) = SetScale(dCFD_ExtXR + conDou19, p_Scale)
                        InsPnt(0) = SetScale(dCFD_ExtXR + (Val(conDou19) / 2), p_Scale)
                    Else
                        insPntE(0) = SetScale(dCFD_ExtXR + conDou20, p_Scale)
                        InsPnt(0) = SetScale(dCFD_ExtXR + (Val(conDou20) / 2), p_Scale)
                    End If
                    insPntS(0) = SetScale(dCFD_ExtXR, p_Scale)
                Case "OFF"
                    If KeshoType = V_KeshoType_3 Then
                        insPntE(0) = SetScale(dCFD_MainX + conDou19, p_Scale)
                        InsPnt(0) = SetScale(dCFD_MainX + (Val(conDou19) / 2), p_Scale)
                    Else
                        insPntE(0) = SetScale(dCFD_MainX + conDou20, p_Scale)
                        InsPnt(0) = SetScale(dCFD_MainX + (Val(conDou20) / 2), p_Scale)
                    End If
                    insPntS(0) = SetScale(dCFD_MainX, p_Scale)
            End Select
            'insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_Val) / p_Scale), p_Scale)
            insPntS(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_Val - dOrgHigh) / 4 / p_Scale * 3, p_Scale) + 250   '把手位置+250(把手ブロックはりつけのところから引用)
            insPntS(2) = 0.0#
            'insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale)
            'insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) - 100
            insPntE(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_Val - dOrgHigh) / 4 / p_Scale * 3, p_Scale) + 250
            insPntE(2) = 0.0#
            'InsPnt(1) = SetScale(conDou18 - YDown - ((H_Limit - dH_Val) / p_Scale), p_Scale)
            'InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) - 100
            InsPnt(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_Val - dOrgHigh) / 4 / p_Scale * 3, p_Scale) + 250
            InsPnt(2) = 0.0#
            dimRotate = moSpace.AddDimRotated(insPntS, insPntE, InsPnt, 0)
            '表示寸法を書き換える
            If KeshoType = V_KeshoType_3 Then
                dimRotate.TextOverride = "50"
            Else
                dimRotate.TextOverride = "25"
            End If
            'アクティブレイヤーの変更
            Call SetActiveLayer("自動作成")
        End If
        'アクティブレイヤーの変更 あとまわし knsknskns
        'Call SetActiveLayer("自動作成")

        If sExtChk = "ON" Then '最終CUB.が納入外なら納入外化粧板を挿入
            InsPnt(0) = SetScale(dCFD_MainX, p_Scale)
            InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
            InsPnt(2) = 0.0#
            If IO = "屋内" Then
                blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外正面化粧板", Val(H_W(iBanNum)), dH_Val - iH_IO, sBlock & "_R", "")
            Else
                blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外正面化粧板", Val(H_W(iBanNum)), dH_Val - iH_IO, sBlock & "_R", "")
            End If
        End If
        'アクティブレイヤーの変更 あとまわし knsknskns
        'Call SetActiveLine("BYLAYER")

        ' 天井板区切り線の作成
        If IO = "屋外" Then
            'アクティブレイヤーの変更 あとまわし knsknskns
            'SetActiveLayer("自動作成")
            '横線
            insPntS(0) = SetScale(dCFD_ExtXL, p_Scale)
            insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale) - conDou21, p_Scale)
            insPntS(2) = 0.0#
            If sExtChk = "ON" Then '納入外有りの場合
                insPntE(0) = SetScale(dCFD_ExtXR, p_Scale)
            Else
                insPntE(0) = SetScale(dCFD_MainX, p_Scale)
            End If
            insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale) - conDou21, p_Scale)
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.color = ACAD_COLOR.acCyan
        End If

        'アクティブレイヤーの変更  あとまわし knsknskns
        'SetActiveLayer("寸法")
        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        '線種変更
        Call SetActiveLine("BYLAYER")

        ' 寸法線の作成（全体巾寸法)

        insPntS(0) = SetScale(dPntX, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown + (dH_Val / p_Scale), p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dCFD_MainX, p_Scale)
        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_Val / p_Scale), p_Scale)
        insPntE(2) = 0.0#
        InsPnt(0) = SetScale((dCFD_MainX - dPntX) / 2, p_Scale)
        'InsPnt(1) = SetScale(conDou4 - ((cH_Limit - dH_Val) / p_Scale), p_Scale)
        'InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) + 735    '16.10.28 松本修正
        InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_Val - iH_IO) / p_Scale), p_Scale) + 750
        InsPnt(2) = 0.0#
        dimLin = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        '表示寸法を書き換える
        dimLin.TextOverride = Zencho

        '寸法スタイルを元に戻す あとまわし knsknskns
        'SetActiveDim("配列１")

        'アクティブレイヤーの変更 あとまわし knsknskns
        'Call SetActiveLayer("自動作成")
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")

        ' 表題欄を読込
        'Dim pntX As Double, pntY As Double              '縮尺が1/25以外のときに表題欄の位置が合わないのでそれを合わせるための変数(できれば使いたくない)
        'pntX = (((p_Scale / 5) - 5) * 250) / p_Scale    'X座標は縮尺1/25を基準に、250の倍数分のずれ
        'pntY = (((p_Scale / 5) - 5) * 520) / p_Scale    'Y座標は縮尺1/25を基準に、520の倍数分のずれ

        'InsPnt(0) = SetScale(dPntX - conDou10 + conDou39 + pntX, p_Scale)
        'InsPnt(1) = SetScale(conDou40 - YDown + pntY, p_Scale) - BaseH    '基礎ﾍﾞｰｽの突出寸法分下げる

        InsPnt(0) = SetScale(dPntX, p_Scale) - conDou48
        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) - BaseH - conDou49     '基礎ﾍﾞｰｽの突出寸法分下げる
        'InsPnt(0) = conDou50 + (p_Scale / 5) * 770 - 100
        'InsPnt(1) = conDou51 + (p_Scale / 5) * 795 - YDown * p_Scale - BaseH   '基礎ﾍﾞｰｽの突出寸法分下げる
        InsPnt(2) = 0.0#
        If nps = True Then                  'NPS承認図として作図するなら(17/01/18追加)
            sCFD_Block = "hyoudai_NPS"      'ブロック名設定
        Else                                '通常の配列図なら
            sCFD_Block = "hyoudai"
        End If
        blockObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入


        'insPntS(0) = SetScale(dX + conDou15, p_Scale)
        'insPntS(1) = SetScale(conZhyY2, p_Scale) - conDou16 - conDou17 * iLin - BaseH '基礎ﾍﾞｰｽの突出寸法分下げる
        'insPntE(0) = SetScale(dX + (H_W(iBanNo) / p_Scale) - conDou15, p_Scale)
        'insPntE(1) = insPntS(1)


        ' 複数ページに続く場合の記号又は右端納入外CUB.の化粧板挿入
        If TL_ZMaisu <> 1 Then
            'Call SetActiveLine("一点鎖線")
            Select Case iPage
                Case 1
                    'Pos = CalPosition(H_PageHakoNo(Page, I - 1))
                    'insPntS(0) = SetScale(CFD_ExtXR, conScale_H)
                    'insPntS(1) = SetScale(conZhyY2, conScale_H)
                    'insPntS(2) = 0#
                    'insPntE(0) = SetScale(CFD_ExtXR + conDou45, conScale_H)
                    'If IO = "屋内" Then
                    'insPntE(1) = SetScale(conZhyY2, conScale_H) + H_H(Pos)
                    'Else
                    'insPntE(1) = SetScale(conZhyY2 + conDou22, conScale_H) + H_H(Pos)
                    'End If
                    'insPntE(2) = 0#
                    'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
                    '線種変更
                    'lin_obj.Color = acYellow

                    'insPntS(0) = insPntE(0)
                    'insPntS(1) = insPntE(1)
                    'insPntS(2) = 0#
                    'insPntE(0) = SetScale(CFD_ExtXR, conScale_H)
                    'insPntE(1) = insPntS(1)
                    'insPntE(2) = 0#
                    'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
                    '線種変更
                    'lin_obj.Color = acYellow
                    InsPnt(0) = SetScale(dCFD_MainX, p_Scale)
                    InsPnt(1) = SetScale(conZhyY2, p_Scale)
                    InsPnt(2) = 0.0#
                    'add by ehiro 2001/3/12
                    blockObj = fVariSize(InsPnt(0), InsPnt(1) - (YDown * p_Scale), "次頁繋ぎ", Val(H_W(iBanNum)), dH_Val, "", "")
                    '        Call InsContBlk(Page, "Aft", InsPnt())
                Case Else
                    If iPage = TL_ZMaisu Then '最終ページ
                        'Pos = CalPosition(H_PageHakoNo(Page, 1))
                        'If IO = "屋内" Then
                        'insPntS(0) = SetScale(conZhyX3 - conDou46, conScale_H)
                        'insPntS(1) = SetScale(conZhyY3, conScale_H) + H_H(Pos)
                        'insPntE(0) = SetScale(conZhyX3 - conDou46 - conDou43, conScale_H)
                        'Else
                        'insPntS(0) = SetScale(conZhyX3 - conDou44, conScale_H)
                        'insPntS(1) = SetScale(conZhyY3 + conDou22, conScale_H) + H_H(Pos)
                        'insPntE(0) = SetScale(conZhyX3 - conDou44 - conDou43, conScale_H)
                        'End If
                        'insPntS(2) = 0#
                        'insPntE(1) = SetScale(conZhyY3, conScale_H)
                        'insPntE(2) = 0#
                        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
                        '線種変更
                        'lin_obj.Color = acYellow
                        InsPnt(0) = SetScale(conZhyX3, p_Scale)
                        InsPnt(1) = SetScale(conZhyY3, p_Scale)
                        InsPnt(2) = 0.0#
                        'add by ehiro 2001/3/12
                        blockObj = fVariSize(InsPnt(0), InsPnt(1) - (YDown * p_Scale), "前頁繋ぎ", Val(H_W(iBanCnt - 1)), dH_Val, "", "")
                        '          Call InsContBlk(Page, "Bef", InsPnt())
                        'If ExtChk = "ON" Then '最終CUB.が納入外なら納入外化粧板を挿入
                        '    InsPnt(0) = SetScale(dPntX, conScale_H)
                        '    InsPnt(1) = SetScale(conZhyY2, conScale_H)
                        '    InsPnt(2) = 0.0#
                        '    If IO = "屋内" Then
                        '        blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外正面化粧板", Val(H_W(iBanCnt)), dH_Val - iH_IO, sBlock & "_R", "")
                        '        '                Chk = FunInsertBlock("EI_" & Block & "_R", InsPnt(0), InsPnt(1), _
                        '        '                    InsPnt(2), 1#, 1#, 0#, "配列")
                        '    Else
                        '        blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外正面化粧板", Val(H_W(iBanCnt)), dH_Val - iH_IO, sBlock & "_R", "")
                        '        '                Chk = FunInsertBlock("EO_" & Block & "_R", InsPnt(0), InsPnt(1), _
                        '        '                    InsPnt(2), 1#, 1#, 0#, "配列")
                        '    End If
                        'End If
                    Else  '中間ページ
                        'Pos = CalPosition(H_PageHakoNo(Page, I - 1))
                        'insPntS(0) = SetScale(CFD_ExtXR, conScale_H)
                        'insPntS(1) = SetScale(conZhyY3, conScale_H)
                        'insPntS(2) = 0#
                        'insPntE(0) = SetScale(CFD_ExtXR + conDou45, conScale_H)
                        'If IO = "屋内" Then
                        'insPntE(1) = SetScale(conZhyY3, conScale_H) + H_H(Pos)
                        'Else
                        'insPntE(1) = SetScale(conZhyY3 + conDou22, conScale_H) + H_H(Pos)
                        'End If
                        'insPntE(2) = 0#
                        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
                        '線種変更
                        'lin_obj.Color = acYellow

                        'insPntS(0) = insPntE(0)
                        'insPntS(1) = insPntE(1)
                        'insPntS(2) = 0#
                        'insPntE(0) = SetScale(CFD_ExtXR, conScale_H)
                        'insPntE(1) = insPntS(1)
                        'insPntE(2) = 0#
                        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
                        '線種変更
                        'lin_obj.Color = acYellow
                        'insPnt(0) = SetScale(CFD_ExtXR, conScale_H)
                        InsPnt(0) = SetScale(dPntX, p_Scale)
                        InsPnt(1) = SetScale(conZhyY3, p_Scale)
                        InsPnt(2) = 0.0#
                        'add by ehiro 2001/3/12
                        blockObj = fVariSize(InsPnt(0), InsPnt(1) - (YDown * p_Scale), "次頁繋ぎ", Val(H_W(iBanCnt)), dH_Val, "", "")
                        '          Call InsContBlk(Page, "Aft", InsPnt())
                        'Pos = CalPosition(H_PageHakoNo(Page, 1))
                        'If IO = "屋内" Then
                        'insPntS(0) = SetScale(conZhyX3 - conDou46, conScale_H)
                        'insPntS(1) = SetScale(conZhyY3, conScale_H) + H_H(Pos)
                        'insPntE(0) = SetScale(conZhyX3 - conDou46 - conDou43, conScale_H)
                        'Else
                        'insPntS(0) = SetScale(conZhyX3 - conDou44, conScale_H)
                        'insPntS(1) = SetScale(conZhyY3 + conDou22, conScale_H) + H_H(Pos)
                        'insPntE(0) = SetScale(conZhyX3 - conDou44 - conDou43, conScale_H)
                        'End If
                        'insPntS(2) = 0#
                        'insPntE(1) = SetScale(conZhyY3, conScale_H)
                        'insPntE(2) = 0#
                        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
                        '線種変更
                        'lin_obj.Color = acYellow
                        InsPnt(0) = SetScale(conZhyX3, p_Scale)
                        InsPnt(1) = SetScale(conZhyY3, p_Scale)
                        InsPnt(2) = 0.0#
                        'add by ehiro 2001/3/12
                        blockObj = fVariSize(InsPnt(0), InsPnt(1) - (YDown * p_Scale), "前頁繋ぎ", Val(H_W(iBanCnt)), dH_Val, "", "")
                        '          Call InsContBlk(Page, "Bef", InsPnt())
                    End If
            End Select
        Else
            'If ExtChk = "ON" Then '最終CUB.が納入外なら納入外化粧板を挿入
            '    InsPnt(0) = SetScale(dPntX, conScale_H)
            '    InsPnt(1) = SetScale(conZhyY2, conScale_H)
            '    InsPnt(2) = 0.0#
            '    If IO = "屋内" Then
            '        blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外正面化粧板", Val(H_W(iBanCnt)), dH_Val - iH_IO, sBlock & "_R", "")
            '        '            Chk = FunInsertBlock("EI_" & Block & "_R", InsPnt(0), InsPnt(1), _
            '        '                InsPnt(2), 1#, 1#, 0#, "配列")
            '    Else
            '        blockObj = fVariSize(InsPnt(0), InsPnt(1), "納入外正面化粧板", Val(H_W(iBanCnt)), dH_Val - iH_IO, sBlock & "_R", "")
            '        '            Chk = FunInsertBlock("EO_" & Block & "_R", InsPnt(0), InsPnt(1), _
            '        '                InsPnt(2), 1#, 1#, 0#, "配列")
            '    End If
            'End If
        End If






    End Sub



    '
    '扉構造に応じたﾌﾞﾛｯｸを挿入
    '
    Private Sub sSetDoorKouzo()
        Dim iDatNum As Integer                                      'ﾃﾞｰﾀ数
        Dim iDatCnt As Integer, iChkCnt As Integer                  'ﾃﾞｰﾀｶｳﾝﾀｰ/ﾁｪｯｸ用ｶｳﾝﾀｰ
        Dim sT_H_Totte As String                                    '一時取手の形
        Dim sT_Type As String                                       '扉構造
        Dim dX As Double, dY As Double                              'ﾌﾞﾛｯｸ挿入位置X,Y
        Dim blkObj As AcadBlockReference                            'ﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
        Dim sBlkNam As String                                       'ﾌﾞﾛｯｸ名

        iDatNum = 0 : ReDim P_Hairetu(0) : sT_H_Totte = ""          '変数初期化
        '--------------------------------------
        '正面扉構造全種類取得
        For iDatCnt = 1 To UBound(H_Totte)                          '全把手ﾃﾞｰﾀ
            Select Case H_Totte(iDatCnt)                            '把手の形
                Case V_H_Totte_1, V_H_Totte_5
                    sT_H_Totte = "_LT"
                Case V_H_Totte_2, V_H_Totte_6
                    sT_H_Totte = "_RT"
                Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                    sT_H_Totte = "_WO"
                Case V_H_Totte_4                                    '特殊
                    sT_H_Totte = "_OT"
            End Select
            sT_Type = "I_" & p_DoorTyp & sT_H_Totte
            '屋外型の特殊処理
            If IO = "屋外" Then
                Select Case p_DoorTyp
                    Case DoorType_3, DoorType_6
                        Select Case H_Totte(iDatCnt)
                            Case Not V_H_Totte_3, V_H_Totte_4, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                                sT_Type = "O_" & p_DoorTyp & sT_H_Totte
                        End Select
                    Case DoorType_7, DoorType_8, DoorType_9
                        sT_Type = "O_" & p_DoorTyp & sT_H_Totte
                End Select
            End If
            '同じ構造ﾀｲﾌﾟが既に出現してないかﾁｪｯｸ
            iDatNum = UBound(P_Hairetu)                             '取得済の構造数取得
            For iChkCnt = 1 To iDatNum                              '取得済の構造数
                If P_Hairetu(iChkCnt) = sT_Type Then                '取得済の構造の場合
                    Exit For                                        '検索中断
                End If
            Next iChkCnt
            If (iChkCnt > iDatNum) And (sT_H_Totte <> "_OT") Then   '未取得の特殊以外の構造の場合
                iDatNum = iDatNum + 1                               '取得済構造数を1増やす
                ReDim Preserve P_Hairetu(iDatNum)                   '配列再定義
                P_Hairetu(iChkCnt) = sT_Type                        '扉構造取得
            End If
        Next iDatCnt
        '--------------------------------------
        '構造図ﾌﾞﾛｯｸ挿入
        For iDatCnt = 1 To iDatNum
            dX = conZhyX1 + conDou41 * (iDatCnt - 1)
            dY = conZhyY1
            InsPnt(0) = SetScale(dX, p_Scale)                       'ﾌﾞﾛｯｸ挿入位置X設定
            InsPnt(1) = SetScale(dY - YDown, p_Scale)                       'ﾌﾞﾛｯｸ挿入位置Y設定
            InsPnt(2) = 0.0#                                        'ﾌﾞﾛｯｸ挿入位置Z設定
            blkObj = fInsBlk(InsPnt, P_HBlkPath & P_Hairetu(iDatCnt), 1, "")   'ﾌﾞﾛｯｸ挿入
            '--------------------------------------
            '化粧板ﾌﾞﾛｯｸ挿入(1つめの扉構造にのみ追加)
            If iDatCnt = 1 Then
                Select Case KeshoType
                    Case V_KeshoType_1
                        sBlkNam = "kesho_23"
                    Case V_KeshoType_2
                        sBlkNam = "kesho_32"
                    Case V_KeshoType_3
                        sBlkNam = "kesho_50"
                    Case V_KeshoType_4
                        sBlkNam = "kesho_25"
                End Select
                InsPnt(0) = SetScale(conZhyX1, p_Scale)
                InsPnt(1) = SetScale(conZhyY1 - YDown, p_Scale)
                InsPnt(2) = 0.0#
                blkObj = fInsBlk(InsPnt, P_HBlkPath & sBlkNam, 1, "")            'ﾌﾞﾛｯｸ挿入
            End If
            '--------------------------------------
            '屋外の場合ﾊﾟｯｷﾝ挿入
            If IO = "屋外" And KeshoType <> V_KeshoType_4 Then
                InsPnt(0) = SetScale(conZhyX1, p_Scale)
                InsPnt(1) = SetScale(conZhyY1 - YDown, p_Scale)
                InsPnt(2) = 0.0#
                sBlkNam = "O_KESHO"
                blkObj = fInsBlk(InsPnt, P_HBlkPath & sBlkNam, 1, "")            'ﾌﾞﾛｯｸ挿入
            End If
        Next iDatCnt
    End Sub
    '
    '側面図作成
    'iBanNum:盤数
    '
    Private Sub sCreSideDrw(ByVal iBanNum As Integer)
        Dim dBaseH As Double                        '基礎ベース突出寸法
        Dim iH_IO As Integer                        '屋内か屋外かを数字として記録
        Dim dH_val As Double
        Dim sCSD_Block As String                    'ﾌﾞﾛｯｸ名
        Dim sCSD_TmpStr As String                   '作業用文字列
        Dim CSD_BlockObj As Object                  'ﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
        Dim Attribs As Object
        Dim dCSD_TmpDou As Double                   '実数一時変数
        Dim blkObj As AcadBlockReference
        Dim CSD_Lin_Obj As Object                   '線分ｵﾌﾞｼﾞｪｸﾄ
        Dim dF1 As Double, dF2 As Double, dB1 As Double, dB2 As Double  '前背面座標      '16.10.28 松本追加
        Dim sBlkNamF As String, sBlkNamB As String                      '前背面ﾌﾞﾛｯｸ名   '16.10.28 松本追加
        Dim Katamuki As Double
        Dim Chk As Object
        Dim i As Integer, j As Integer
        Dim MString As String
        Dim HaimenCnt As Integer
        Dim KankiPtn As Integer     '0:換気箱なし 1:天井のみ 2:背面のみ 3:両方ともあり
        Dim DoorDis As Double       '側面図の正背面の扉の厚さ(扉が正面のみ：50 背面もあり：100)

        '---------------------------
        '変数の初期化
        i = 0
        j = 0
        MString = ""
        HaimenCnt = 0
        KankiPtn = 0
        Katamuki = 0
        '---------------------------

        'BaseHは基礎ベース突出寸法
        'Valは数字の文字列を数値型として返す
        dBaseH = Val(BaseH)

        '屋外かどうかを判定
        If IO = "屋外" Then
            iH_IO = 150
        Else
            iH_IO = 0
        End If

        'cH_Limitは高さの制限
        'Const cH_Limit = 2500      '16.9.13 吹野氏に確認 by 松本
        Const cH_Limit = 3150       '←


        'H_HはH箱の高さをもつ配列

        '側面図は1回しか作成されないので,H_H(1)のみ
        'dH_valに対して、H_H(1)が3150(cH_Limit)以下ならばH_H(1)の値を
        '3150以上ならば3150を代入する

        If H_H(1) <= cH_Limit Then  '側面図の高さは一番左の盤高さでOK '16.9.13 吹野氏に確認 by 松本
            dH_val = Val(H_H(1))
        Else
            dH_val = cH_Limit
        End If



        'ﾌﾞﾛｯｸの読込（扉最大開放寸法（＝背面））
        InsPnt(0) = SetScale(conZhyX2, p_Scale)
        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
        InsPnt(2) = 0.0#
        sCSD_Block = fChkWakuType("B", iBanNum)     '枠ﾌﾞﾛｯｸの選択
        CSD_OD_Sunpo = fCalODSunpo()                '扉最大開放寸法の計算
        sCSD_TmpStr = Left(H_WakuType(iBanNum), 1)  '一番右の盤の枠形式の1文字目取得
        If sCSD_TmpStr = "A" Or sCSD_TmpStr = "C" Then
            CSD_BlockObj = fVariSize(InsPnt(0), InsPnt(1), sCSD_Block, Val(H_W(1)), dH_val - iH_IO, "", "")
            'If nps = False Then                     '簡略図ではない場合
            CSD_OD_Sunpo = fCalODSunpo()                '扉最大開放寸法の計算
            Attribs = CSD_BlockObj.GetAttributes '属性を全て取り出し配列にセット
            Attribs(0).TextString = CSD_OD_Sunpo
            'End If
        Else
            CSD_BlockObj = fVariSize(InsPnt(0), InsPnt(1), sCSD_Block, Val(H_W(1)), dH_val - iH_IO, "", "")
        End If
        'ブロックの読込（扉最大開放寸法（＝正面））
        sCSD_Block = fChkWakuType("F", iBanNum)     '枠ﾌﾞﾛｯｸの選択
        dCSD_TmpDou = conZhyX2 + (Val(H_D(iBanNum)) / p_Scale)
        If P_sBanDat(pc_RDoorRow, iBanNum - 1) = "扉" Then
            DoorDis = 100
        Else
            DoorDis = 50
        End If
        InsPnt(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
        InsPnt(2) = 0.0#
        CSD_BlockObj = fVariSize(InsPnt(0), InsPnt(1), sCSD_Block, Val(H_W(1)), dH_val - iH_IO, "", "")
        'If nps = False Then
        CSD_OD_Sunpo = fCalODSunpo() '扉最大開放寸法の計算
        Attribs = CSD_BlockObj.GetAttributes '属性を全て取り出し配列にセット
        Attribs(0).TextString = CSD_OD_Sunpo
        'End If


        'ブロックの読込（文字列「正面」）
        InsPnt(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
        InsPnt(2) = 0.0#
        sCSD_Block = "MOJI_SHOMEN"
        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCSD_Block, 1, "")
        'ブロックの読込（列番止め穴）
        If KeshoType = V_KeshoType_1 Or KeshoType = V_KeshoType_2 Then
            InsPnt(0) = SetScale(conZhyX2 + conDou42, p_Scale)
            InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
            InsPnt(2) = 0.0#
            sCSD_Block = "DOOR_TOME_B"
            CSD_BlockObj = fVariSize(InsPnt(0), InsPnt(1), "側面化粧板締付穴", Val(H_W(1)), dH_val, "B", "")
            InsPnt(0) = SetScale(dCSD_TmpDou - conDou42, p_Scale) - DoorDis
            InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
            InsPnt(2) = 0.0#
            sCSD_Block = "DOOR_TOME_F"
            CSD_BlockObj = fVariSize(InsPnt(0), InsPnt(1), "側面化粧板締付穴", Val(H_W(1)), dH_val, "F", "")
        End If
        '線分の作成（箱上下水平接続用）
        '下水平線の記入
        insPntS(0) = SetScale(conZhyX2, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        insPntE(1) = SetScale(conZhyY2 - YDown, p_Scale)
        insPntE(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan
        '上水平線の記入
        insPntS(0) = SetScale(conZhyX2, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale)
        insPntE(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan
        '線分の作成（箱垂直接続用）<--背面カバーの場合のみ
        If sCSD_TmpStr = "B" Or sCSD_TmpStr = "D" Or sCSD_TmpStr = "E" Then
            insPntS(0) = SetScale(conZhyX2, p_Scale)
            insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(conZhyX2, p_Scale)
            insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale)
            insPntE(2) = 0.0#
            CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
        End If
        '線色変更
        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan
        '線分の作成（側面図用基礎ベース）
        '縦線
        insPntS(0) = SetScale(conZhyX2, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(conZhyX2, p_Scale)
        insPntE(1) = SetScale(conZhyY2 - YDown - dBaseH / p_Scale, p_Scale)
        insPntE(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan
        '横線
        insPntS(0) = SetScale(conZhyX2, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown - dBaseH / p_Scale, p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        insPntE(1) = SetScale(conZhyY2 - YDown - dBaseH / p_Scale, p_Scale)
        insPntE(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan
        '縦線
        insPntS(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        insPntS(1) = SetScale(conZhyY2 - YDown - dBaseH / p_Scale, p_Scale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        insPntE(1) = SetScale(conZhyY2 - YDown, p_Scale)
        insPntE(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan
        'ブロックの読込（FL,GL線分ブロック）
        '背面側線
        InsPnt(0) = SetScale(conZhyX2, p_Scale)
        InsPnt(1) = SetScale(conZhyY2 - YDown - dBaseH / p_Scale, p_Scale)
        InsPnt(2) = 0.0#
        sCSD_Block = "FL_GL_B"
        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCSD_Block, 1, "")
        'FL,GL線
        InsPnt(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        InsPnt(1) = SetScale(conZhyY2 - YDown - dBaseH / p_Scale, p_Scale)
        InsPnt(2) = 0.0#
        If IO = "屋内" Then
            sCSD_Block = "FL_F"
        Else
            sCSD_Block = "GL_F"
        End If
        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCSD_Block, 1, "")


        'ブロックの読込（天井板ブロック、換気箱）
        If IO = "屋外" Then
            If P_SeikanTyp = cP_Gage Then                                   '製缶方式選択肢追加 '16.10.25 松本
                sBlkNamB = "O_ROOF_B" : sBlkNamF = "O_ROOF_F"               '前背面天井板ﾌﾞﾛｯｸ名定義
                dB1 = 185.17 : dF1 = 215.6775 : dB2 = 100 : dF2 = 150       '前背天井の接続高さ定義
            Else
                sBlkNamB = "O_ROOF_BQ" : sBlkNamF = "O_ROOF_FQ"             '前背面天井板ﾌﾞﾛｯｸ名定義
                dB1 = 127.0646 : dF1 = 229.2868 : dB2 = 74.2325 : dF2 = 174.2325    '前背天井の接続高さ定義
            End If
            insPntS(2) = 0.0# : insPntE(2) = 0.0# : InsPnt(2) = 0.0#
            '背面用
            InsPnt(0) = SetScale(conZhyX2, p_Scale)
            InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale)
            sCSD_Block = sBlkNamB
            blkObj = fInsBlk(InsPnt, P_HBlkPath & sCSD_Block, 1, "")
            '正面用
            InsPnt(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
            sCSD_Block = sBlkNamF
            blkObj = fInsBlk(InsPnt, P_HBlkPath & sCSD_Block, 1, "")
            '前背天井1の接続
            insPntS(0) = SetScale(conZhyX2, p_Scale) : insPntS(1) = InsPnt(1) + dB1
            insPntE(0) = InsPnt(0) : insPntE(1) = InsPnt(1) + dF1
            CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
            CSD_Lin_Obj.Color = ACAD_COLOR.acCyan                           '線色変更
            '前背天井2の接続
            insPntS(1) = InsPnt(1) + dB2
            insPntE(1) = InsPnt(1) + dF2
            CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
            CSD_Lin_Obj.Color = ACAD_COLOR.acGreen                          '線色変更


            Mult_String = ""
            '換気箱
            For i = 0 To iBanNum - 1
                If P_sBanDat(pc_KankiRow, i) = "天井" Then
                    If KankiPtn = 0 Then
                        KankiPtn = 1
                    ElseIf KankiPtn = 2 Then
                        KankiPtn = 3
                    End If
                End If
                If P_sBanDat(pc_KankiRow, i) = "背面扉" Then
                    If KankiPtn = 0 Then
                        KankiPtn = 2
                    ElseIf KankiPtn = 1 Then
                        KankiPtn = 3
                    End If
                    If Mult_String = "" Then
                        'Mult_String = "換気装置\P[" & P_sBanDat(pc_BanNoRow, i) & "]"
                        Mult_String = "扉取付換気箱"
                        'Else
                        '    Mult_String = Mult_String & "[" & P_sBanDat(pc_BanNoRow, i) & "]"
                    End If
                End If
            Next



            If KankiPtn = 1 Or KankiPtn = 3 Then
                Katamuki = Math.Atan2(dF1 - dB1, SetScale(dCSD_TmpDou, p_Scale) - DoorDis - SetScale(conZhyX2, p_Scale))  '換気箱ブロックを傾ける角度を求める。
                InsPnt(0) = SetScale(conZhyX2, p_Scale) + (Val(H_D(iBanNum)) - DoorDis) / 2                                 'ブロック挿入位置(x):基準位置+箱の幅の半分
                InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale) + dB1 + ((dF1 - dB1) / 2)    'ブロック挿入位置(y):基準位置+箱の高さ+前背天井1接続線の高さの半分
                Chk = FunInsertBlock("O_KANKI_ST", InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, Katamuki, "配列") '換気箱ブロックの挿入
            End If
            If KankiPtn = 2 Or KankiPtn = 3 Then
                Dim DX As Double        '扉の厚さ

                'If P_sBanDat(pc_RDoorRow, iBanNum - 1) = "背板" Or P_sBanDat(pc_RDoorRow, iBanNum - 1) = "背板（中MCB）" Or P_sBanDat(pc_RDoorRow, iBanNum - 1) = "背板（中MCB）2" Then
                If P_sBanDat(pc_RDoorRow, iBanNum - 1) = "引掛扉" Or P_sBanDat(pc_RDoorRow, iBanNum - 1) = "無" Then
                    DX = 0
                Else
                    DX = -50
                End If

                InsPnt(0) = SetScale(conZhyX2, p_Scale) + DX                                'ブロック挿入位置(x)

                If Val(H_H(1)) < 2500 Then
                    InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + Val(H_H(1)) - 650   'ブロック挿入位置(y)
                Else
                    InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + 1850   'ブロック挿入位置(y)
                End If



                'InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + 1850   'ブロック挿入位置(y):基準位置+箱の高さ+前背天井1接続線の高さの半分

                Chk = fVariSize(InsPnt(0), InsPnt(1), "側面図背面換気箱", 0, 0, "", "")


                'Chk = FunInsertBlock("O_KANKI_SH", InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "配列") '換気箱ブロックの挿入
            End If

            'If P_sBanDat(pc_KankiRow, iBanNum - 1) = "天井" Then
            '    Katamuki = Math.Atan2(dF1 - dB1, SetScale(dCSD_TmpDou, p_Scale) - SetScale(conZhyX2, p_Scale))  '換気箱ブロックを傾ける角度を求める。
            '    InsPnt(0) = SetScale(conZhyX2, p_Scale) + Val(H_D(iBanNum)) / 2                                 'ブロック挿入位置(x):基準位置+箱の幅の半分
            '    InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale) + dB1 + ((dF1 - dB1) / 2)    'ブロック挿入位置(y):基準位置+箱の高さ+前背天井1接続線の高さの半分
            '    Chk = FunInsertBlock("O_KANKI_ST", InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, Katamuki, "配列") '換気箱ブロックの挿入
            'ElseIf P_sBanDat(pc_KankiRow, iBanNum - 1) = "背面扉" Then
            '    Dim DX As Double        '扉の厚さ

            '    If P_sBanDat(pc_RDoorRow, iBanNum - 1) = "背板" Or P_sBanDat(pc_RDoorRow, iBanNum - 1) = "背板（中MCB）" Or P_sBanDat(pc_RDoorRow, iBanNum - 1) = "背板（中MCB）2" Then
            '        DX = 0
            '    Else
            '        DX = -50
            '    End If

            '    InsPnt(0) = SetScale(conZhyX2, p_Scale) + DX                                'ブロック挿入位置(x):基準位置+箱の幅の半分
            '    InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale) + 1850   'ブロック挿入位置(y):基準位置+箱の高さ+前背天井1接続線の高さの半分
            '    Chk = FunInsertBlock("O_KANKI_SH", InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, Katamuki, "配列") '換気箱ブロックの挿入
            'End If



        End If

        'ブロックの読込（換気箱）
        If IO = "屋内" Then
            InsPnt(0) = SetScale(conZhyX2, p_Scale) + (Val(H_D(iBanNum)) - DoorDis) / 2                 'ブロック挿入位置(x):基準位置+箱の幅の半分
            InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale)  'ブロック挿入位置(y):基準位置+箱の高さ
            Chk = FunInsertBlock("I_KANKI_ST", InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "配列") '換気箱ブロックの挿入
        End If


        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
        insPntS(2) = 0.0#
        insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale)
        insPntE(2) = 0.0#


        Dim H_BunkatuLimit1_1 As Integer    '定義がない為とりあえず追加 '16.9.9 松本
        Dim H_BunkatuLimit1_2 As Integer    '定義がない為とりあえず追加 '16.9.9 松本
        Dim H_BunkatuLimit2_1 As Integer    '定義がない為とりあえず追加 '16.9.9 松本
        Dim H_BunkatuLimit2_2 As Integer    '定義がない為とりあえず追加 '16.9.9 松本

        H_BunkatuLimit1_2 = 2700    '16.02.14
        H_BunkatuLimit2_2 = 2700    '16.02.14


        Select Case KeshoType
            Case V_KeshoType_1, V_KeshoType_2
                If (dCSD_TmpDou - conZhyX2) - DoorDis / p_Scale > (H_BunkatuLimit1_1 / p_Scale) Then
                    If (dCSD_TmpDou - conZhyX2) - DoorDis / p_Scale <= (H_BunkatuLimit1_2 / p_Scale) Then '２本線
                        insPntS(0) = SetScale(conZhyX2 + (((dCSD_TmpDou - conZhyX2) / 2) - 1), p_Scale) - DoorDis / 2
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                        insPntS(0) = SetScale(conZhyX2 + (((dCSD_TmpDou - conZhyX2) / 2) + 1), p_Scale) - DoorDis / 2
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                    Else '４本線
                        insPntS(0) = SetScale(conZhyX2 + (((dCSD_TmpDou - conZhyX2) / 3) - 1), p_Scale) - DoorDis / 3
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                        insPntS(0) = SetScale(conZhyX2 + (((dCSD_TmpDou - conZhyX2) / 3) + 1), p_Scale) - DoorDis / 3
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                        insPntS(0) = SetScale(conZhyX2 + ((((dCSD_TmpDou - conZhyX2) / 3) * 2) - 1), p_Scale) - DoorDis / 3 * 2
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                        insPntS(0) = SetScale(conZhyX2 + ((((dCSD_TmpDou - conZhyX2) / 3) * 2) + 1), p_Scale) - DoorDis / 3 * 2
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                    End If
                End If
            Case V_KeshoType_3, V_KeshoType_4
                If (dCSD_TmpDou - conZhyX2) > (H_BunkatuLimit2_1 / p_Scale) Then
                    If Val(H_D(iBanNum)) <= H_BunkatuLimit2_2 Then '奥行が2700未満なら１本線         
                        insPntS(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), p_Scale) - DoorDis / 2
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                    Else '奥行が2700以上なら２本線                                   
                        insPntS(0) = SetScale(conZhyX2, p_Scale) + 1050
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                        insPntS(0) = SetScale(conZhyX2, p_Scale) + Val(H_D(iBanNum)) - DoorDis - 1050
                        insPntE(0) = insPntS(0)
                        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                    End If
                End If
                'If (dCSD_TmpDou - conZhyX2) > (H_BunkatuLimit2_1 / p_Scale) Then
                '    If (dCSD_TmpDou - conZhyX2) <= (H_BunkatuLimit2_2 / p_Scale) Then '１本線
                '        insPntS(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), _
                '            p_Scale)
                '        insPntE(0) = insPntS(0)
                '        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                '        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                '    Else '２本線
                '        insPntS(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 3), _
                '            p_Scale)
                '        insPntE(0) = insPntS(0)
                '        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                '        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                '        insPntS(0) = SetScale(conZhyX2 + (((dCSD_TmpDou - conZhyX2) / 3) * 2), _
                '            p_Scale)
                '        insPntE(0) = insPntS(0)
                '        CSD_Lin_Obj = moSpace.AddLine(insPntS, insPntE)
                '        CSD_Lin_Obj.Color = ACAD_COLOR.acCyan '線色変更
                '    End If
                'End If
        End Select

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        '線種変更
        Call SetActiveLine("BYLAYER")
        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale) : insPntE(1) = insPntS(1)
        '寸法線の作成（側面図用）
        '下部寸法の記入
        insPntS(0) = SetScale(conZhyX2, p_Scale) : insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale) : insPntE(1) = insPntS(1)
        InsPnt(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), p_Scale) - DoorDis
        InsPnt(1) = SetScale(conDou2 - YDown, p_Scale)
        insPntS(2) = 0.0# : insPntE(2) = 0.0# : InsPnt(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        '上部寸法の記入
        insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) + 50 - DoorDis
        insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale) : insPntE(1) = insPntS(1)
        InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale) + 525
        Select Case sCSD_TmpStr
            Case "A", "C"
                insPntS(0) = insPntS(0) - 50
                InsPnt(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), p_Scale) - DoorDis
            Case "B", "D"
                InsPnt(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), p_Scale) + 50 - DoorDis
        End Select


        '下部寸法の記入
        insPntS(0) = SetScale(conZhyX2, p_Scale) : insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale) : insPntE(1) = insPntS(1)
        InsPnt(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), p_Scale) - DoorDis
        InsPnt(1) = SetScale(conDou2 - YDown, p_Scale)
        insPntS(2) = 0.0# : insPntE(2) = 0.0# : InsPnt(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        '上部寸法の記入
        insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) + 50 - DoorDis
        insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale) : insPntE(1) = insPntS(1)
        InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale), p_Scale) + 525
        Select Case sCSD_TmpStr
            Case "A", "C"
                insPntS(0) = insPntS(0) - 50
                InsPnt(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), p_Scale)
            Case "B", "D"
                InsPnt(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2), p_Scale) + 50
        End Select
        CSD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)

        If IO = "屋外" Then
            If P_SeikanTyp = cP_Gage Then                           '製缶方式選択肢追加 '16.10.25 松本
                dB1 = conDou5 : dF1 = conDou5 : dB2 = conDou6       '天井幅定義
            Else
                dB1 = 164.26 : dF1 = 159.17 : dB2 = 230             '天井幅定義
            End If
            sCSD_TmpStr = Str(insPntE(0) - insPntS(0))
            insPntS(0) = SetScale(conZhyX2, p_Scale) - dB1
            insPntE(0) = SetScale(dCSD_TmpDou, p_Scale) + dF1 - DoorDis
            InsPnt(0) = SetScale(conZhyX2 + ((dCSD_TmpDou - conZhyX2) / 2) - 1, p_Scale) - DoorDis
            InsPnt(1) = InsPnt(1) + 210                             '寸法表記高さ2
            CSD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
            CSD_Lin_Obj.TextOverride = Format(Val(sCSD_TmpStr) + dB2 - DoorDis) '表示寸法を書き換える  '06.10.23 松本修正
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")

        'ﾌﾞﾛｯｸの読込（機器引出所要寸法）(前面用)
        If FntSunpo <> "" And FntSunpo <> "0" Then
            sCSD_Block = "KIKI_F"
            InsPnt(0) = SetScale(dCSD_TmpDou, p_Scale) - DoorDis
            InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
            InsPnt(2) = 0.0#
            CSD_KM_Sunpo = FntSunpo
            blkObj = fInsBlk(InsPnt, P_HBlkPath & sCSD_Block, p_Scale / p_Scale, CSD_KM_Sunpo)
        End If
        'ﾌﾞﾛｯｸの読込（機器引出所要寸法）(背面用)
        If BckSunpo <> "" And BckSunpo <> "0" Then
            sCSD_Block = "KIKI_B"
            InsPnt(0) = SetScale(conZhyX2, p_Scale)
            InsPnt(1) = SetScale(conZhyY2 - YDown, p_Scale)
            InsPnt(2) = 0.0#
            CSD_KM_Sunpo = BckSunpo
            blkObj = fInsBlk(InsPnt, P_HBlkPath & sCSD_Block, p_Scale / p_Scale, CSD_KM_Sunpo)
        End If
    End Sub
    '
    '枠ﾌﾞﾛｯｸの選択
    'sFB_Type:F(前)orB(背)　iBanNum:盤数
    '
    Private Function fChkWakuType(ByVal sFB_Type As String, ByVal iBanNum As Integer) As Object
        Dim sChkPnt As String
        Dim sTmpType As String

        sChkPnt = "" : sTmpType = "" : fChkWakuType = ""    '初期化

        'If nps = False Then     '簡略図の場合は扉解放角度を表示しないので、解放寸法は省略する
        Select Case H_WakuType(iBanNum)
            Case V_H_WakuType_1, V_H_WakuType_13, V_H_WakuType_14
                sTmpType = "DOOR_A1"
            Case V_H_WakuType_2
                sTmpType = "DOOR_A2"
            Case V_H_WakuType_3
                sTmpType = "DOOR_A3"
            Case V_H_WakuType_4
                sTmpType = "DOOR_A4"
            Case V_H_WakuType_5
                sTmpType = "DOOR_A5"
            Case V_H_WakuType_6
                sTmpType = "DOOR_A6"
            Case V_H_WakuType_7, V_H_WakuType_15, V_H_WakuType_16
                sChkPnt = "カバー"
                sTmpType = "DOOR_B1"
            Case V_H_WakuType_8
                sChkPnt = "カバー"
                sTmpType = "DOOR_B2"
            Case V_H_WakuType_9
                sChkPnt = "カバー"
                sTmpType = "DOOR_B3"
            Case V_H_WakuType_10
                sChkPnt = "カバー"
                sTmpType = "DOOR_B4"
            Case V_H_WakuType_11
                sChkPnt = "カバー"
                sTmpType = "DOOR_B5"
            Case V_H_WakuType_12
                sChkPnt = "カバー"
                sTmpType = "DOOR_B6"
            Case V_H_WakuType_17
                sChkPnt = "カバー"
                sTmpType = "DOOR_E1"
            Case V_H_WakuType_18
                sChkPnt = "カバー"
                sTmpType = "DOOR_E2"
            Case V_H_WakuType_19
                sChkPnt = "カバー"
                sTmpType = "DOOR_E3"
            Case V_H_WakuType_20
                sChkPnt = "カバー"
                sTmpType = "DOOR_E4"

        End Select
        'End If

        If IO = "屋内" Then
            'If nps = True Then      '簡略図の場合
            'fChkWakuType = "DOOR_" & Left(H_WakuType(iBanNum), 1) & "_" & sFB_Type & "_NPS"
            'Else
            fChkWakuType = sTmpType & "_" & sFB_Type
            'End If
        Else
            If sChkPnt = "カバー" Then
                Select Case sFB_Type
                    Case "F"
                        'If nps = True Then
                        'fChkWakuType = "O_DOOR_" & Left(H_WakuType(iBanNum), 1) & "_" & sFB_Type & "_NPS"
                        'Else
                        fChkWakuType = "O_" & sTmpType & "_" & sFB_Type
                        'End If
                    Case "B"
                        'If nps = True Then
                        'fChkWakuType = "DOOR_" & Left(H_WakuType(iBanNum), 1) & "_" & sFB_Type & "_NPS"
                        'Else
                        fChkWakuType = sTmpType & "_" & sFB_Type
                        'End If
                End Select
            Else
                'If nps = True Then
                'fChkWakuType = "O_DOOR_" & Left(H_WakuType(iBanNum), 1) & "_" & sFB_Type & "_NPS"
                'Else
                fChkWakuType = "O_" & sTmpType & "_" & sFB_Type
                'End If
            End If
        End If
    End Function
    '
    '扉最大開放寸法計算
    '
    Public Function fCalODSunpo() As Integer
        Dim iMax_W1 As Integer, iMax_W2 As Integer          '片扉/観音扉の最大盤幅
        Dim iBanCnt As Integer                              '盤ｶｳﾝﾀｰ
        Dim iBanNum As Integer = UBound(H_Totte)            '盤数
        Dim sT_Type(iBanNum, 1) As String                   '把手ﾀｲﾌﾟ
        Dim iTmpW As Integer                                '盤幅
        '-------------------------------------------
        '取手ﾀｲﾌﾟ/最大盤幅取得
        iMax_W1 = 0 : iMax_W2 = 0                           '片扉/観音扉の最大盤幅初期化
        For iBanCnt = 1 To iBanNum                          '全盤
            iTmpW = H_W(iBanCnt)                            '盤幅を数値で取得
            sT_Type(iBanCnt, 1) = H_W(iBanCnt)              '盤幅を文字列で取得
            Select Case H_Totte(iBanCnt)
                Case V_H_Totte_1, V_H_Totte_2, V_H_Totte_4, V_H_Totte_5, V_H_Totte_6
                    sT_Type(iBanCnt, 0) = "片開"
                    If iMax_W1 < iTmpW Then iMax_W1 = iTmpW '今のところの片扉最大盤幅なら取得
                Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                    sT_Type(iBanCnt, 0) = "両開"
                    If iMax_W2 < iTmpW Then iMax_W2 = iTmpW '今のところの観音扉最大盤幅なら取得
            End Select
        Next iBanCnt
        '-------------------------------------------
        '計算
        If iMax_W1 <= ((iMax_W2 / 2) + 50) Then             '片扉最大幅が観音扉最大幅+50以下の場合
            fCalODSunpo = (iMax_W2 / 2) + 100               '扉最大開放寸法=観音扉最大幅+重ね合わせ分50+旋回裕度50
        Else                                                '片扉最大幅が観音扉最大幅+50より大きい場合
            fCalODSunpo = iMax_W1 + 50                      '扉最大開放寸法=形扉最大幅+旋回裕度50
        End If
    End Function

    '
    '配列図の箱幅及び箱高さを可変するﾌﾞﾛｯｸを作成する
    '
    'BlkKind :ﾌﾞﾛｯｸ種類
    'BlkWid  :箱幅
    'BlkHigh :箱高さ
    'BlkPos  :ﾌﾞﾛｯｸ位置(F,B or (23,25,32,50)_(L,R))
    'BlkType :枠形状(A1-A6,B1-B6)
    '
    '属性を持つブロックは要素を移動や伸縮で変更して、属性を持たないブロックは挿入時にスケールを変更する
    '
    Function fVariSize(ByVal dXpnt As Double, ByVal dYpnt As Double, ByVal sBlkKind As String, ByVal dBlkWid As Double, ByVal dBlkHigh As Double, _
                       ByVal sBlkPos As String, ByVal sBlkType As String) As Object
        Dim dBaseH As Double
        'ﾌﾞﾛｯｸ→選択ｾｯﾄ取得用ﾌﾞﾛｯｸ名,ｵﾌﾞｼﾞｪｸﾄ
        Dim dBpnt(2) As Double
        Dim sGBlkSet As String
        Dim dGScal(2) As Double
        Dim GBlkObj As AcadBlockReference
        Dim Attribs As Object
        Dim dOrgHigh As Double                                              '基準寸法
        Const iOrgWid = 1000
        Dim sHKind As String                                                '屋内外納入外文字列
        Dim sHBlkNam As String                                              '作成ﾌﾞﾛｯｸ名
        Dim iSelNo As Integer, iOrgLen As Integer, TmpObj As Object         'ｻｲｽﾞ変更用
        Dim sTSaveFld As String                                             '一時保存場所
        Dim ZksObj As Object, ZksObj2 As Object, ZksObj3 As Object          '選択ｾｯﾄ用
        Dim dlineS(2) As Double, dlineE(2) As Double                        '線用変数
        Dim iHatchNo As Integer, dHatchS(2) As Double, dHatchE(2) As Double 'ﾊｯﾁﾝｸﾞ用変数
        Dim iDatCnt As Integer                                              'ﾃﾞｰﾀｶｳﾝﾀｰ

        'Dim IOBlkobj As Object
        'Dim m As Integer
        'Dim pos As String

        dBaseH = Val(BaseH)
        dBpnt(0) = 0 : dBpnt(1) = 0 : dBpnt(2) = 0
        If IO = "屋内" Then
            dOrgHigh = 2300
            If sChkExtHako = "納入外" Then
                sHKind = "EI"
            Else
                sHKind = "I"
            End If
        Else
            'dOrgHigh = 2450
            dOrgHigh = 2480     '屋外用天井ブロック「O_1000.dwg」を修正したため変更
            If sChkExtHako = "納入外" Then
                sHKind = "EO"
            Else
                sHKind = "O"
            End If
        End If
        '------------------------------------------------------
        '作成するﾌﾞﾛｯｸ名と元になるﾌﾞﾛｯｸ名定義
        Select Case sBlkKind    '引数
            Case "屋内"
                dOrgHigh = 2300
                sHBlkNam = "I_" & Format(dBlkWid)
                If nps = True Then                  'NPSなら
                    sGBlkSet = "I_1000_NPS"         '表の項目を減らしたブロックを指定(17/01/19)
                Else
                    sGBlkSet = "I_1000"
                End If
                iSelNo = 1

            Case "屋外"
                sHBlkNam = "O_" & Format(dBlkWid)
                sGBlkSet = "O_1000"
                'Do While m < acadDoc.Blocks.Count
                '    IOBlkobj = acadDoc.Blocks.Item(m)

                '    If IOBlkobj.name = sHBlkNam Then
                '        pos = dXpnt & "," & dYpnt & "," & dBpnt(2)
                '        acadDoc.SendCommand("-insert" & vbCrLf & sHBlkNam & vbCrLf & pos & vbCrLf & "1" & vbCrLf & "1" & vbCrLf & "0" & vbCrLf)
                '        fVariSize = IOBlkobj
                '        Exit Function
                '    End If
                '    m = m + 1
                'Loop
                iSelNo = 2

            Case "納入外屋内"
                dOrgHigh = 2300
                sHBlkNam = "EI_" & Format(dBlkWid)
                If nps = True Then
                    sGBlkSet = "EI_1000_NPS"
                Else
                    sGBlkSet = "EI_1000"
                End If
                iSelNo = 3
            Case "納入外屋外"
                sHBlkNam = "EO_" & Format(dBlkWid)
                sGBlkSet = "EO_1000"
                'Do While m < acadDoc.Blocks.Count
                '    IOBlkobj = acadDoc.Blocks.Item(m)

                '    If IOBlkobj.name = sHBlkNam Then
                '        pos = dXpnt & "," & dYpnt & "," & dBpnt(2)
                '        acadDoc.SendCommand("-insert" & vbCrLf & sHBlkNam & vbCrLf & pos & vbCrLf & "1" & vbCrLf & "1" & vbCrLf & "0" & vbCrLf)
                '        fVariSize = IOBlkobj
                '        Exit Function
                '    End If
                '    m = m + 1
                'Loop
                iSelNo = 4
            Case "次頁繋ぎ"
                If sHKind = "EO" Then
                    sHBlkNam = "ContAft_OE"
                ElseIf sHKind = "EI" Then
                    sHBlkNam = "ContAft_IE"
                Else
                    sHBlkNam = "ContAft_" & sHKind
                End If
                sGBlkSet = sHBlkNam
                iSelNo = 5
            Case "前頁繋ぎ"
                If sHKind = "EO" Then
                    sHBlkNam = "ContBef_OE"
                ElseIf sHKind = "EI" Then
                    sHBlkNam = "ContBef_IE"
                Else
                    sHBlkNam = "ContBef_" & sHKind
                End If
                sGBlkSet = sHBlkNam
                iSelNo = 6
            Case "機器引出寸法"
                dOrgHigh = 2300
                sHBlkNam = "DOOR_" & sBlkType & "_" & sBlkPos
                sGBlkSet = sHBlkNam
                iSelNo = 7
            Case "機器引出寸法屋外"
                dOrgHigh = 2300
                sHBlkNam = "O_DOOR_" & sBlkType & "_" & sBlkPos
                sGBlkSet = sHBlkNam
                iSelNo = 8
            Case "正面化粧板"
                If IO = "屋内" Then
                    sHKind = "I"
                Else
                    sHKind = "O"
                End If
                dOrgHigh = 2300
                sHBlkNam = sHKind & "_KESHO_" & sBlkPos
                sGBlkSet = sHBlkNam
                iSelNo = 9
            Case "側面化粧板締付穴"
                sHBlkNam = "DOOR_TOME_" & sBlkPos
                sGBlkSet = sHBlkNam
                iSelNo = 10
            Case "納入外正面化粧板"
                If IO = "屋内" Then
                    sHKind = "EI"
                Else
                    sHKind = "EO"
                End If
                sHBlkNam = sHKind & "_KESHO_" & sBlkPos
                sGBlkSet = sHBlkNam
                iSelNo = 9
            Case "ブロックスケルトン"


                'sHBlkNam = "BLKSK_" & sBlkPos
                'sGBlkSet = sHBlkNam

                sHBlkNam = SKname & "-" & BanNoSK
                sGBlkSet = SKname

                'sGBlkSet = sHBlkNam


                iSelNo = 11

            Case "側面図背面換気箱"

                If IO = "屋外" Then
                    sHBlkNam = "O_KANKI_SH-1"
                    sGBlkSet = "O_KANKI_SH"
                ElseIf IO = "屋内" Then
                    sHBlkNam = "I_KANKI_ST-1"
                    sGBlkSet = "I_KANKI_ST"
                End If


                iSelNo = 12

            Case Else
                If Left(sBlkKind, 6) = "O_DOOR" Or Left(sBlkKind, 4) = "DOOR" Then
                    'X999999 B1の現状の設定ではここを通る(nps,notnpsに関わらず)
                    dOrgHigh = 2300
                    sHBlkNam = sBlkKind '引数
                    sGBlkSet = sHBlkNam
                    iSelNo = 7
                End If
        End Select

        dGScal(0) = 1 : dGScal(1) = 1 : dGScal(2) = 1
        sTSaveFld = "c:\Temp\"                                                              '一時保存場所指定
        If iSelNo = 11 Then
            FileCopy(SKCopyPath, sTSaveFld & sHBlkNam & EndString)   'ﾌﾞﾛｯｸを指定した名前にｺﾋﾟｰ
        Else
            'ローカルにコピーする
            MsgBox(P_HBlkPath & sGBlkSet & EndString)
            FileCopy(P_HBlkPath & sGBlkSet & EndString, sTSaveFld & sHBlkNam & EndString)   'ﾌﾞﾛｯｸを指定した名前にｺﾋﾟｰ
        End If

        GBlkObj = fInsBlk(dBpnt, sTSaveFld & sHBlkNam, 1, "") 'ｺﾋﾟｰしたﾌﾞﾛｯｸを挿入
        Kill(sTSaveFld & sHBlkNam & EndString)                                              'ｺﾋﾟｰしたﾌｧｲﾙを削除
        ZksObj = acadDoc.Blocks.Item(sHBlkNam)                          '挿入したﾌﾞﾛｯｸの定義ｵﾌﾞｼﾞｪｸﾄを取得
        GBlkObj.Erase()                                                 '挿入したﾌﾞﾛｯｸを削除(定義は残る)

        If iSelNo = 11 Then
            Dim BlkItem As Object, BlkItem2 As Object
            Dim a As Integer

            BlkItem = acadDoc.Blocks.Item(sHBlkNam)

            For a = 0 To BlkItem.count - 1
                BlkItem2 = BlkItem.item(a)


                If TypeOf BlkItem2 Is IAcadLWPolyline Then

                    SP(0) = BlkItem2.coordinates(0)     'ブロックが貼り付けられた座標を(0,0)としたときの枠(ポリライン)の基準点のx座標
                    SP(1) = BlkItem2.coordinates(1)     '枠の基準点のy座標
                    SP(2) = BlkItem2.coordinates(2)     '2点目のx座標
                    SP(3) = BlkItem2.coordinates(3)     '2点目のy座標
                    SP(4) = BlkItem2.coordinates(4)     '3点目のx座標
                    SP(5) = BlkItem2.coordinates(5)     '3点目のy座標
                    SP(6) = BlkItem2.coordinates(6)     '4点目のx座標
                    SP(7) = BlkItem2.coordinates(7)     '4点目のy座標

                    If SP(1) = 0 Then
                        BlkItem.item(a).erase()
                        Exit For
                    End If

                End If


            Next

        End If


        With ZksObj
            For iDatCnt = 0 To .Count - 1
                ZksObj2 = .Item(iDatCnt)
                With ZksObj2
                    If TypeOf ZksObj2 Is AcadLine Then
                        Select Case iSelNo
                            Case 1 To 4                                 'ﾌﾞﾛｯｸSK,箱外形,下表
                                iOrgLen = Val(Mid(sGBlkSet, InStr(1, sGBlkSet, "_") + 1))
                                '線の始点
                                TmpObj = .StartPoint
                                '少数第三位で四捨五入(○.9999などといった長さの線への対策)
                                dlineS(0) = Math.Round(TmpObj(0), 2, MidpointRounding.AwayFromZero) : dlineS(1) = Math.Round(TmpObj(1), 2, MidpointRounding.AwayFromZero) : dlineS(2) = 0
                                '線の終点
                                TmpObj = .EndPoint
                                dlineE(0) = Math.Round(TmpObj(0), 2, MidpointRounding.AwayFromZero) : dlineE(1) = Math.Round(TmpObj(1), 2, MidpointRounding.AwayFromZero) : dlineE(2) = 0
                                '幅方向の線の場合
                                If dlineS(1) = dlineE(1) Then
                                    If Math.Abs(dlineS(0) - dlineE(0)) = iOrgLen Then
                                        '始点が終点より大きい場合
                                        If dlineS(0) > dlineE(0) Then
                                            dlineS(0) = dlineS(0) + (dBlkWid - iOrgLen)
                                        Else
                                            dlineE(0) = dlineE(0) + (dBlkWid - iOrgLen)
                                        End If

                                        '高さが基準高さと違う場合変更する
                                        If dBlkHigh <> 0 And dBlkHigh <> dOrgHigh Then
                                            If dlineS(1) = dOrgHigh Then
                                                dlineS(1) = dBlkHigh : dlineE(1) = dBlkHigh
                                            End If
                                        End If
                                    Else
                                        If iSelNo = 2 Or iSelNo = 4 Then
                                            If dlineS(0) < iOrgWid / 2 And dlineE(0) > iOrgWid / 2 Then
                                                dlineE(0) = dlineE(0) + (dBlkWid - iOrgLen)
                                                dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                            ElseIf dlineS(0) > iOrgWid / 2 And dlineE(0) < iOrgWid / 2 Then
                                                dlineS(0) = dlineS(0) + (dBlkWid - iOrgLen)
                                                dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                            ElseIf dlineS(0) > iOrgWid / 2 And dlineE(0) > iOrgWid / 2 Then
                                                dlineS(0) = dlineS(0) + (dBlkWid - iOrgLen)
                                                dlineE(0) = dlineE(0) + (dBlkWid - iOrgLen)
                                                dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                            Else
                                                dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                            End If
                                        End If
                                    End If
                                    '始点、終点を再設定する
                                    TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                    '属性表の場合(ﾌﾞﾛｯｸ挿入位置より下にある)は基礎ﾍﾞｰｽの突出寸法分下げる  '07.11.26 松本追加
                                    If TmpObj(1) < dBpnt(1) Then TmpObj(1) = TmpObj(1) - dBaseH
                                    .StartPoint = TmpObj
                                    TmpObj(0) = dlineE(0) : TmpObj(1) = dlineE(1) : TmpObj(2) = dlineE(2)

                                    If XLen = 0 Then
                                        XLen = dlineE(0) - dlineS(0)    '幅方向の線の長さ
                                    End If

                                    '属性表の場合(ﾌﾞﾛｯｸ挿入位置より下にある)は基礎ﾍﾞｰｽの突出寸法分下げる  '07.11.26 松本追加
                                    If TmpObj(1) < dBpnt(1) Then TmpObj(1) = TmpObj(1) - dBaseH
                                    .EndPoint = TmpObj
                                ElseIf dlineS(0) = dlineE(0) Then
                                    '高さ方向の線で挿入点から元サイズ分離れている場合新しいサイズに移動する
                                    If dlineS(0) = iOrgLen Then
                                        dlineS(0) = dlineS(0) + (dBlkWid - iOrgLen)
                                        dlineE(0) = dlineE(0) + (dBlkWid - iOrgLen)
                                        '高さが基準高さと違う場合変更する
                                        If dBlkHigh <> 0 And dBlkHigh <> dOrgHigh Then
                                            If dlineS(1) > dlineE(1) And dlineS(1) = dOrgHigh Then
                                                If dlineE(1) = 0 Then
                                                    dlineS(1) = dBlkHigh
                                                Else
                                                    dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                    dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                                End If
                                            ElseIf dlineS(1) < dlineE(1) And dlineE(1) = dOrgHigh Then
                                                If dlineS(1) = 0 Then
                                                    dlineE(1) = dBlkHigh
                                                Else
                                                    dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                    dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                                End If
                                            ElseIf dlineS(1) > dlineE(1) And dlineE(1) = 0 Then
                                                If Cellingflg = True Then
                                                    dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                Else
                                                    dlineS(1) = dBlkHigh
                                                End If
                                            ElseIf dlineS(1) < dlineE(1) And dlineS(1) = 0 Then
                                                If Cellingflg = True Then
                                                    dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                                Else
                                                    dlineE(1) = dBlkHigh
                                                End If
                                            End If
                                        End If
                                    ElseIf dlineS(0) = 0 Then
                                        '高さが基準高さと違う場合変更する
                                        If dBlkHigh <> 0 And dBlkHigh <> dOrgHigh Then
                                            If dlineS(1) > dlineE(1) And dlineS(1) = dOrgHigh Then
                                                If dlineE(1) = 0 Then
                                                    dlineS(1) = dBlkHigh
                                                Else
                                                    dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                    dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                                End If
                                            ElseIf dlineS(1) < dlineE(1) And dlineE(1) = dOrgHigh Then
                                                If dlineS(1) = 0 Then
                                                    dlineE(1) = dBlkHigh
                                                Else
                                                    dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                    dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                                End If
                                            ElseIf dlineS(1) > dlineE(1) And dlineE(1) = 0 Then
                                                If Cellingflg = True Then
                                                    dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                Else
                                                    dlineS(1) = dBlkHigh
                                                End If
                                            ElseIf dlineS(1) < dlineE(1) And dlineS(1) = 0 Then
                                                If Cellingflg = True Then
                                                    dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                                Else
                                                    dlineE(1) = dBlkHigh
                                                End If

                                            End If
                                        End If
                                    Else
                                        If iSelNo = 2 Or iSelNo = 4 Then
                                            If dlineS(0) > iOrgWid / 2 Then
                                                dlineS(0) = dlineS(0) + (dBlkWid - iOrgLen)
                                                dlineE(0) = dlineE(0) + (dBlkWid - iOrgLen)
                                                dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                            Else
                                                dlineS(1) = dlineS(1) + (dBlkHigh - dOrgHigh)
                                                dlineE(1) = dlineE(1) + (dBlkHigh - dOrgHigh)
                                            End If
                                        End If
                                    End If
                                    '始点、終点を再設定する
                                    TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                    '属性表の場合(ﾌﾞﾛｯｸ挿入位置より下にある)は基礎ﾍﾞｰｽの突出寸法分下げる  '07.11.26 松本追加
                                    If TmpObj(1) < dBpnt(1) Then TmpObj(1) = TmpObj(1) - dBaseH
                                    .StartPoint = TmpObj
                                    TmpObj(0) = dlineE(0) : TmpObj(1) = dlineE(1) : TmpObj(2) = dlineE(2)

                                    If YLen = 0 Then
                                        YLen = dlineS(1) - dlineE(1)    '幅方向の線の長さ
                                    End If

                                    '属性表の場合(ﾌﾞﾛｯｸ挿入位置より下にある)は基礎ﾍﾞｰｽの突出寸法分下げる  '07.11.26 松本追加
                                    If TmpObj(1) < dBpnt(1) Then TmpObj(1) = TmpObj(1) - dBaseH
                                    .EndPoint = TmpObj
                                End If
                            Case 5, 6
                                '線の始点
                                TmpObj = .StartPoint
                                dlineS(0) = TmpObj(0)
                                If (iSelNo = 5 Or iSelNo = 6) And TmpObj(1) <= 0 Then
                                    dlineS(1) = TmpObj(1)
                                Else
                                    dlineS(1) = TmpObj(1) + (dBlkHigh - dOrgHigh)
                                End If
                                dlineS(2) = TmpObj(2)
                                '線の終点
                                TmpObj = .EndPoint
                                dlineE(0) = TmpObj(0)
                                If (iSelNo = 5 Or iSelNo = 6) And TmpObj(1) <= 0 Then
                                    dlineE(1) = TmpObj(1)
                                Else
                                    dlineE(1) = TmpObj(1) + (dBlkHigh - dOrgHigh)
                                End If
                                dlineE(2) = TmpObj(2)
                                '始点、終点を再設定する
                                TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                .StartPoint = TmpObj
                                TmpObj(0) = dlineE(0) : TmpObj(1) = dlineE(1) : TmpObj(2) = dlineE(2)
                                .EndPoint = TmpObj
                                '側面化粧板締付穴,機器引出寸法
                                '単純に(与えられた高さ)/(基準高さ)を掛けているが締め付け間隔が高さによって
                                '決まっていればこのような変更の仕方ではまずいかも
                            Case 7, 8, 9, 10
                                '線の始点
                                TmpObj = .StartPoint
                                dlineS(0) = TmpObj(0)
                                If iSelNo = 6 And TmpObj(1) <= 0 Then
                                    dlineS(1) = TmpObj(1)
                                Else
                                    dlineS(1) = TmpObj(1) * dBlkHigh / dOrgHigh
                                End If
                                dlineS(2) = TmpObj(2)
                                '線の終点
                                TmpObj = .EndPoint
                                dlineE(0) = TmpObj(0)
                                If iSelNo = 6 And TmpObj(1) <= 0 Then
                                    dlineE(1) = TmpObj(1)
                                Else
                                    dlineE(1) = TmpObj(1) * dBlkHigh / dOrgHigh
                                End If
                                dlineE(2) = TmpObj(2)
                                '始点、終点を再設定する
                                TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                .StartPoint = TmpObj
                                TmpObj(0) = dlineE(0) : TmpObj(1) = dlineE(1) : TmpObj(2) = dlineE(2)
                                .EndPoint = TmpObj
                            Case 11

                                'For k = 0 To ZksObj.count - 1

                                If SKCnt < 2 Then       '母船の処理を2本していないなら
                                    Dim Bosenflg As Integer     'ブロックSKの枠に母船のどの端が接しているか判断
                                    Bosenflg = 0


                                    If Math.Round(ZksObj2.startpoint(0), MidpointRounding.AwayFromZero) = SP(0) Then
                                        '母船の始点が枠の左側(枠の基点が左側にあるなら)に接している場合
                                        Bosenflg = 1
                                    End If
                                    If Math.Round(ZksObj2.startpoint(0), MidpointRounding.AwayFromZero) = SP(2) Then
                                        '母船の始点が枠の右側に接している場合
                                        Bosenflg = 2
                                    End If
                                    If Math.Round(ZksObj2.endpoint(0), MidpointRounding.AwayFromZero) = SP(0) Then
                                        '母船の終点が枠の左側に接している場合
                                        If Bosenflg = 2 Then    '母船が1本のみの場合(始点も枠に接している場合)
                                            Bosenflg = 6
                                        Else
                                            Bosenflg = 3
                                        End If
                                    End If
                                    If Math.Round(ZksObj2.endpoint(0), MidpointRounding.AwayFromZero) = SP(2) Then
                                        '母船の終点が枠の右側に接している場合
                                        If Bosenflg = 1 Then    '母船が1本のみの場合(始点も枠に接している場合)
                                            Bosenflg = 5
                                        Else
                                            Bosenflg = 4
                                        End If

                                    End If

                                    If Bosenflg = 5 Then
                                        '母船1本パターン(母船の始点が枠の基点と同じx座標)
                                        TmpObj = .StartPoint

                                        If ZksObj2.startpoint(0) > 0 Then
                                            dlineS(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) + (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        Else
                                            dlineS(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        End If
                                        TmpObj(0) = dlineS(0)
                                        .StartPoint = TmpObj
                                        SKCnt = SKCnt + 1



                                        TmpObj = .EndPoint

                                        If ZksObj2.endpoint(0) > 0 Then
                                            Console.WriteLine(ZksObj2.endpoint(0))
                                            dlineE(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) + (H_W(BanNoSK) / 2 - Math.Abs(LineArray(k).endpoint(0)))
                                            Console.WriteLine(ZksObj2.endpoint(0))
                                        Else
                                            dlineE(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).endpoint(0))
                                        End If
                                        TmpObj(0) = dlineE(0)
                                        .EndPoint = TmpObj
                                        SKCnt = SKCnt + 1

                                    ElseIf Bosenflg = 6 Then
                                        '母船1本パターン(母船の終点が枠の基点と同じx座標)
                                        TmpObj = .StartPoint

                                        If ZksObj2.startpoint(0) > 0 Then
                                            dlineS(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) + (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        Else
                                            dlineS(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        End If
                                        TmpObj(0) = dlineS(0)
                                        .StartPoint = TmpObj
                                        SKCnt = SKCnt + 1


                                        TmpObj = .EndPoint

                                        If ZksObj2.endpoint(0) > 0 Then
                                            dlineE(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) + (H_W(BanNoSK) / 2 - LineArray(k).endpoint(0))
                                        Else
                                            dlineE(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).endpoint(0))
                                        End If
                                        TmpObj(0) = dlineE(0)
                                        .EndPoint = TmpObj
                                        SKCnt = SKCnt + 1


                                        'If Math.Round(ZksObj2.startpoint(0), MidpointRounding.AwayFromZero) = SP(0) Then
                                    ElseIf Bosenflg = 1 Then

                                        TmpObj = .StartPoint

                                        If ZksObj2.startpoint(0) > 0 Then
                                            dlineS(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) + (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        Else
                                            dlineS(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        End If
                                        TmpObj(0) = dlineS(0)
                                        .StartPoint = TmpObj
                                        SKCnt = SKCnt + 1           '母船1本分終わったので

                                        'ElseIf Math.Round(ZksObj2.startpoint(0), MidpointRounding.AwayFromZero) = SP(2) Then
                                    ElseIf Bosenflg = 2 Then
                                        TmpObj = .StartPoint

                                        If ZksObj2.startpoint(0) > 0 Then
                                            dlineS(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) + (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        Else
                                            dlineS(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).startpoint(0) = LineArray(k).startpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).startpoint(0))
                                        End If
                                        TmpObj(0) = dlineS(0)
                                        .StartPoint = TmpObj
                                        SKCnt = SKCnt + 1

                                        'ElseIf Math.Round(ZksObj2.endpoint(0), MidpointRounding.AwayFromZero) = SP(0) Then
                                    ElseIf Bosenflg = 3 Then
                                        TmpObj = .EndPoint

                                        If ZksObj2.endpoint(0) > 0 Then
                                            dlineE(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) + (H_W(BanNoSK) / 2 - LineArray(k).endpoint(0))
                                        Else
                                            dlineE(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).endpoint(0))
                                        End If
                                        TmpObj(0) = dlineE(0)
                                        .EndPoint = TmpObj
                                        SKCnt = SKCnt + 1

                                        'ElseIf Math.Round(ZksObj2.endpoint(0), MidpointRounding.AwayFromZero) = SP(2) Then
                                    ElseIf Bosenflg = 4 Then
                                        TmpObj = .EndPoint

                                        If ZksObj2.endpoint(0) > 0 Then
                                            Console.WriteLine(ZksObj2.endpoint(0))
                                            dlineE(0) = TmpObj(0) + (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) + (H_W(BanNoSK) / 2 - Math.Abs(LineArray(k).endpoint(0)))
                                            Console.WriteLine(ZksObj2.endpoint(0))
                                        Else
                                            dlineE(0) = TmpObj(0) - (dBlkWid / 2 - Math.Abs(TmpObj(0)))
                                            'LineArray(k).endpoint(0) = LineArray(k).endpoint(0) - (H_W(BanNoSK) / 2 - LineArray(k).endpoint(0))
                                        End If
                                        TmpObj(0) = dlineE(0)
                                        .EndPoint = TmpObj
                                        SKCnt = SKCnt + 1
                                    End If

                                End If


                                'Console.WriteLine(LineArray(k).startpoint(0) & "," & LineArray(k).startpoint(1) & "," & LineArray(k).endpoint(0) & "," & LineArray(k).endpoint(1))



                                'Next


                                'LineArray(iDatCnt) = ZksObj2



                        End Select
                    ElseIf TypeOf ZksObj2 Is AcadCircle Then
                        Select Case iSelNo
                            '機器引出寸法
                            '単純に(与えられた高さ)/(基準高さ)を掛けているが締め付け間隔が高さによって
                            '決まっていればこのような変更の仕方ではまずいかも
                            Case 7, 8
                                '基準点を取得する
                                TmpObj = .Center
                                dHatchS(0) = TmpObj(0) : dHatchS(1) = TmpObj(1) : dHatchS(2) = TmpObj(2)
                                dlineS(0) = TmpObj(0)
                                dlineS(1) = TmpObj(1) * dBlkHigh / dOrgHigh
                                dlineS(2) = TmpObj(2)
                                '基準点を再設定する
                                TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                dHatchE(0) = TmpObj(0) : dHatchE(1) = TmpObj(1) : dHatchE(2) = TmpObj(2)
                                .Center = TmpObj
                                '円が２個ある為、１回だけ移動するようにする
                                If iHatchNo <> 0 Then
                                    ZksObj3 = ZksObj.Item(iHatchNo)
                                    ZksObj3.Move(dHatchS, dHatchE)
                                    iHatchNo = 0
                                End If
                            Case Else
                        End Select
                    ElseIf TypeOf ZksObj2 Is AcadText Then
                        Select Case iSelNo
                            '機器引出寸法
                            '単純に(与えられた高さ)/(基準高さ)を掛けているが締め付け間隔が高さによって
                            '決まっていればこのような変更の仕方ではまずいかも
                            Case 7, 8
                                '基準点を取得する
                                TmpObj = .InsertionPoint
                                dlineS(0) = TmpObj(0)
                                dlineS(1) = TmpObj(1) * dBlkHigh / dOrgHigh
                                dlineS(2) = TmpObj(2)
                                '基準点を再設定する
                                TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                .InsertionPoint = TmpObj
                                '位置合わせ点を取得する
                                TmpObj = .TextAlignmentPoint
                                dlineS(0) = TmpObj(0)
                                dlineS(1) = TmpObj(1) * dBlkHigh / dOrgHigh
                                dlineS(2) = TmpObj(2)
                                '位置合わせ点を再設定する
                                TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                .TextAlignmentPoint = TmpObj
                        End Select
                    ElseIf TypeOf ZksObj2 Is AcadAttribute Then
                        Select Case iSelNo
                            'ブロックSK、箱外形、下表 '07.11.25 松本追加(基礎ﾍﾞｰｽの突出寸法分下げる)
                            Case 1 To 4
                                TmpObj = .InsertionPoint
                                '属性表の場合(ﾌﾞﾛｯｸ挿入位置より下にある)は基礎ﾍﾞｰｽの突出寸法分下げる  '07.11.26 松本追加
                                If TmpObj(1) < dBpnt(1) Then TmpObj(1) = TmpObj(1) - dBaseH
                                .InsertionPoint = TmpObj
                                '機器引出寸法
                                '単純に(与えられた高さ)/(基準高さ)を掛けているが締め付け間隔が高さによって
                                '決まっていればこのような変更の仕方ではまずいかも
                            Case 7, 8
                                TmpObj = .InsertionPoint
                                dlineS(0) = TmpObj(0)
                                dlineS(1) = TmpObj(1) * dBlkHigh / dOrgHigh
                                dlineS(2) = TmpObj(2)
                                '基準点を再設定する
                                TmpObj(0) = dlineS(0) : TmpObj(1) = dlineS(1) : TmpObj(2) = dlineS(2)
                                .InsertionPoint = TmpObj
                        End Select
                    ElseIf TypeOf ZksObj2 Is AcadHatch Then
                        'ハッチングのオブジェクト番号を取得
                        '円を移動するときに同時に移動させる
                        iHatchNo = iDatCnt
                        'ElseIf TypeOf ZksObj2 Is IAcadLWPolyline Then
                        '    SP(0) = ZksObj2.coordinates(0)     'ブロックが貼り付けられた座標を(0,0)としたときの枠(ポリライン)の基準点のx座標
                        '    SP(1) = ZksObj2.coordinates(1)     '枠の基準点のy座標
                        '    SP(2) = ZksObj2.coordinates(2)     '2点目のx座標
                        '    SP(3) = ZksObj2.coordinates(3)     '2点目のy座標
                        '    SP(4) = ZksObj2.coordinates(4)     '3点目のx座標
                        '    SP(5) = ZksObj2.coordinates(5)     '3点目のy座標
                        '    SP(6) = ZksObj2.coordinates(6)     '4点目のx座標
                        '    SP(7) = ZksObj2.coordinates(7)     '4点目のy座標
                    ElseIf TypeOf ZksObj2 Is AcadMText Then
                        If iSelNo = 12 Then
                            ZksObj2.TextString = Mult_String


                        End If


                    End If
                End With
            Next iDatCnt
        End With


BlkExist:
        '変更したブロック定義を使用してブロック挿入する
        dBpnt(0) = dXpnt : dBpnt(1) = dYpnt : dBpnt(2) = 0
        GBlkObj = moSpace.InsertBlock(dBpnt, sHBlkNam, 1, 1, 1, 0.0#)
        'GBlkObj = fInsBlk(dBpnt, P_HBlkPath & sHBlkNam, 1, "")
        '箱配置の場合、属性値を設定する
        If iSelNo = 1 Or iSelNo = 3 Then
            Attribs = GBlkObj.GetAttributes '属性を全て取り出し配列にセット
            For iDatCnt = LBound(Attribs) To UBound(Attribs)
                Select Case Attribs(iDatCnt).TagString
                    Case "S_DOORZUBAN"
                        Attribs(iDatCnt).TextString = S_DOORZUBAN
                    Case "S_DRZUBAN"
                        Attribs(iDatCnt).TextString = S_DRZUBAN
                    Case "S_DOOROPEN"
                        Attribs(iDatCnt).TextString = S_DOOROPEN
                    Case "S_JYOTAI"
                        Attribs(iDatCnt).TextString = S_JYOTAI
                    Case "S_DENATU"
                        Attribs(iDatCnt).TextString = S_DENATU
                    Case "S_TNP"
                        Attribs(iDatCnt).TextString = S_TNP
                    Case "S_ZETUEN"
                        Attribs(iDatCnt).TextString = S_ZETUEN
                    Case "S_HZ"
                        Attribs(iDatCnt).TextString = S_HZ
                    Case "S_KATA"
                        Attribs(iDatCnt).TextString = S_KATA
                    Case "S_HOGO"
                        Attribs(iDatCnt).TextString = S_HOGO
                    Case "S_HOGO2"
                        Attribs(iDatCnt).TextString = S_HOGO2
                    Case "S_CUBNO"
                        Attribs(iDatCnt).TextString = S_CUBNO
                    Case "S_JYURYO"
                        Attribs(iDatCnt).TextString = S_JYURYO
                    Case "S_NP1"
                        Attribs(iDatCnt).TextString = S_NP1
                    Case "S_NP2"
                        Attribs(iDatCnt).TextString = S_NP2
                    Case "S_NP3"
                        Attribs(iDatCnt).TextString = S_NP3
                    Case "S_POWERFREQUENCY"
                        Attribs(iDatCnt).TextString = S_POWERFREQUENCY
                    Case "S_LIGHTNINGIMPULSE"
                        Attribs(iDatCnt).TextString = S_LIGHTNINGIMPULSE
                End Select
            Next
        ElseIf iSelNo = 11 Then
            Dim pgpnt As String
            pgpnt = Int(dXpnt) & "," & Int(dYpnt + 1000) & ",0"

            acadDoc.SendCommand("EXPLODE" & vbCrLf & pgpnt & vbCrLf & vbCrLf)
        End If
        'acadDoc.Regen(acActiveViewport)
        acadDoc.Regen(AcRegenType.acActiveViewport) 'ひとまずこっちに変更  '16.9.9 松本
        fVariSize = GBlkObj
    End Function
    '
    '配列図の箱毎の属性にﾃﾞｰﾀが無い場合は線を引く
    '
    Public Sub sWrtNulLin(ByVal dX As Double, ByVal iBanNo As Integer, ByVal iLin As Integer)
        '基本X座標     CUB.位置         基準行から何行下か
        Dim objLin As AcadLine

        'Call SetActiveLayer("自動作成")
        insPntS(0) = SetScale(dX + conDou15, p_Scale)
        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale) - conDou16 - conDou17 * iLin - BaseH '基礎ﾍﾞｰｽの突出寸法分下げる
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(dX + (H_W(iBanNo) / p_Scale) - conDou15, p_Scale)
        insPntE(1) = insPntS(1)
        insPntE(2) = 0.0#
        objLin = moSpace.AddLine(insPntS, insPntE)
        objLin.color = ACAD_COLOR.acYellow
    End Sub
    '-----------------------------------------------
    ' 扉形状の作成＆取手ブロックの貼り付け
    '-----------------------------------------------
    '   WakuType      : 枠のタイプ(ex A1)
    '   Dot           : 納入外なら"DOT_"それ以外は""
    '   i             : 対象箱データの配列内の位置を示すカウンター
    '   MainX         : 箱データの挿入基点（X座標）
    '-----------------------------------------------
    Public Sub sCreTotte(ByVal sWakuType As String, ByVal sDot As String, ByVal iBanNo As Integer, ByVal dMainX As Double)
        Dim dOrgHigh As Double
        Dim iH_IO As Integer
        Dim dH_val As Double
        Dim LinTyp As AcadLineType          '現在の線種
        Dim sCFD_Block As String            'ﾌﾞﾛｯｸ名
        Dim blkObj As AcadBlockReference
        Dim linObj As AcadLine
        Dim dtmpHigh As Double

        'Const cH_Limit = 2500      '16.9.13 吹野氏に確認 by 松本
        Const cH_Limit = 3150       '←
        If IO = "屋外" Then
            dOrgHigh = 2450
            iH_IO = 150
        Else
            dOrgHigh = 2300
            iH_IO = 0
        End If
        If Val(H_H(iBanNo)) <= cH_Limit Then
            dH_val = Val(H_H(iBanNo))
        Else
            dH_val = cH_Limit
        End If

        'アクティブレイヤーの変更 あとまわし knsknskns
        'SetActiveLayer("自動作成")

        If sDot <> "" Then '納入外ならば線種を破線にする
            LinTyp = acadDoc.ActiveLinetype
            Call SetActiveLine("破線")
        End If

        Select Case sWakuType
            Case "A1", "C1", "C2", "B1", "D1", "D2", "E1"
                Select Case H_Totte(iBanNo)
                    Case V_H_Totte_1, V_H_Totte_5
                        'ブロック配置
                        If nps = True Then
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_1 Then
                            sCFD_Block = sDot & "TOTTE_LT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RLT"
                        End If


                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou13 + (dH_val - dOrgHigh) / 2 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_2, V_H_Totte_6
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_2 Then
                            sCFD_Block = sDot & "TOTTE_RT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RRT"
                        End If
                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou13 + (dH_val - dOrgHigh) / 2 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_WO_NPS"
                        Else
                            Select Case H_Totte(iBanNo)
                                Case V_H_Totte_3
                                    sCFD_Block = sDot & "TOTTE_WO"
                                Case V_H_Totte_7
                                    sCFD_Block = sDot & "TOTTE_RWO"
                                Case V_H_Totte_8
                                    sCFD_Block = sDot & "TOTTE_WO2"
                                Case V_H_Totte_9
                                    sCFD_Block = sDot & "TOTTE_RWO2"
                            End Select
                        End If

                        InsPnt(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo)) / 2
                        'InsPnt(1) = SetScale(conZhyY2 - YDown + conDou13, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou13 + (dH_val - dOrgHigh) / 2 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        '区切り線の作成
                        insPntS(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val / p_Scale), p_Scale)
                        If IO = "屋外" Then insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale) - 1, p_Scale)
                        insPntE(2) = 0.0#
                        linObj = moSpace.AddLine(insPntS, insPntE)
                        '線色変更
                        linObj.color = ACAD_COLOR.acGreen
                    Case V_H_Totte_4 '例外処理
                End Select
            Case "A2", "B2", "E2"
                Select Case H_Totte(iBanNo)
                    Case V_H_Totte_1, V_H_Totte_5
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_1 Then
                            sCFD_Block = sDot & "TOTTE_LT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RLT"
                        End If
                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou27 + (dH_val - dOrgHigh) / 4 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou28 + (dH_val - dOrgHigh) / 4 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_2, V_H_Totte_6
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_2 Then
                            sCFD_Block = sDot & "TOTTE_RT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RRT"
                        End If
                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou27 + (dH_val - dOrgHigh) / 4 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou28 + (dH_val - dOrgHigh) / 4 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_WO_NPS"
                        Else
                            Select Case H_Totte(iBanNo)
                                Case V_H_Totte_3
                                    sCFD_Block = sDot & "TOTTE_WO"
                                Case V_H_Totte_7
                                    sCFD_Block = sDot & "TOTTE_RWO"
                                Case V_H_Totte_8
                                    sCFD_Block = sDot & "TOTTE_WO2"
                                Case V_H_Totte_9
                                    sCFD_Block = sDot & "TOTTE_RWO2"
                            End Select
                        End If
                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou27 + (dH_val - dOrgHigh) / 4 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou28 + (dH_val - dOrgHigh) / 4 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        '区切り線の作成
                        insPntS(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val / p_Scale), p_Scale)
                        If IO = "屋外" Then insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale) - 1, p_Scale)
                        insPntE(2) = 0.0#
                        linObj = moSpace.AddLine(insPntS, insPntE)
                        '線色変更
                        linObj.color = ACAD_COLOR.acGreen
                    Case V_H_Totte_4 '例外処理
                End Select

                '区切り線の作成
                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale / 2), p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale / 2), p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen
            Case "A3", "B3", "E3"
                Select Case H_Totte(iBanNo)
                    Case V_H_Totte_1, V_H_Totte_5
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_1 Then
                            sCFD_Block = sDot & "TOTTE_LT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RLT"
                        End If
                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou29 + (dH_val - dOrgHigh) / 6 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_val - dOrgHigh) / 6 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou31 + (dH_val - dOrgHigh) / 6 / p_Scale * 5, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                    Case V_H_Totte_2, V_H_Totte_6
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_2 Then
                            sCFD_Block = sDot & "TOTTE_RT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RRT"
                        End If
                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou29 + (dH_val - dOrgHigh) / 6 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_val - dOrgHigh) / 6 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou31 + (dH_val - dOrgHigh) / 6 / p_Scale * 5, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                    Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_WO_NPS"
                        Else
                            Select Case H_Totte(iBanNo)
                                Case V_H_Totte_3
                                    sCFD_Block = sDot & "TOTTE_WO"
                                Case V_H_Totte_7
                                    sCFD_Block = sDot & "TOTTE_RWO"
                                Case V_H_Totte_8
                                    sCFD_Block = sDot & "TOTTE_WO2"
                                Case V_H_Totte_9
                                    sCFD_Block = sDot & "TOTTE_RWO2"
                            End Select
                        End If
                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou29 + (dH_val - dOrgHigh) / 6 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou30 + (dH_val - dOrgHigh) / 6 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou31 + (dH_val - dOrgHigh) / 6 / p_Scale * 5, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        '区切り線の作成
                        insPntS(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val / p_Scale), p_Scale)
                        If IO = "屋外" Then insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale) - 1, p_Scale)
                        insPntE(2) = 0.0#
                        linObj = moSpace.AddLine(insPntS, insPntE)
                        '線色変更
                        linObj.color = ACAD_COLOR.acGreen
                    Case V_H_Totte_4 '例外処理
                End Select

                '区切り線の作成
                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 6 / p_Scale * 2, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 6 / p_Scale * 2, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen

                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 6 / p_Scale * 4, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 6 / p_Scale * 4, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen

            Case "A4", "B4", "E4"
                Select Case H_Totte(iBanNo)
                    Case V_H_Totte_1, V_H_Totte_5
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_1 Then
                            sCFD_Block = sDot & "TOTTE_LT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RLT"
                        End If
                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (dH_val - dOrgHigh) / 8 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + conDou27 + (dH_val - dOrgHigh) / 8 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (conDou27 * 2) + (dH_val - dOrgHigh) / 8 / p_Scale * 5, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (conDou27 * 3) + (dH_val - dOrgHigh) / 8 / p_Scale * 7, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入


                    Case V_H_Totte_2, V_H_Totte_6
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_2 Then
                            sCFD_Block = sDot & "TOTTE_RT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RRT"
                        End If
                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (dH_val - dOrgHigh) / 8 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + conDou27 + (dH_val - dOrgHigh) / 8 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (conDou27 * 2) + (dH_val - dOrgHigh) / 8 / p_Scale * 5, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (conDou27 * 3) + (dH_val - dOrgHigh) / 8 / p_Scale * 7, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                    Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_WO_NPS"
                        Else
                            Select Case H_Totte(iBanNo)
                                Case V_H_Totte_3
                                    sCFD_Block = sDot & "TOTTE_WO"
                                Case V_H_Totte_7
                                    sCFD_Block = sDot & "TOTTE_RWO"
                                Case V_H_Totte_8
                                    sCFD_Block = sDot & "TOTTE_WO2"
                                Case V_H_Totte_9
                                    sCFD_Block = sDot & "TOTTE_RWO2"
                            End Select
                        End If
                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (dH_val - dOrgHigh) / 8 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + conDou27 + (dH_val - dOrgHigh) / 8 / p_Scale * 3, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (conDou27 * 2) + (dH_val - dOrgHigh) / 8 / p_Scale * 5, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + conDou34 + (conDou27 * 3) + (dH_val - dOrgHigh) / 8 / p_Scale * 7, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        '区切り線の作成
                        insPntS(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val / p_Scale), p_Scale)
                        If IO = "屋外" Then insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale) - 1, p_Scale)
                        insPntE(2) = 0.0#
                        linObj = moSpace.AddLine(insPntS, insPntE)
                        '線色変更
                        linObj.color = ACAD_COLOR.acGreen
                    Case V_H_Totte_4 '例外処理
                End Select
                '区切り線の作成
                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 8 / p_Scale * 2, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 8 / p_Scale * 2, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen

                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 8 / p_Scale * 4, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 8 / p_Scale * 4, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen

                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 8 / p_Scale * 6, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val - iH_IO) / 8 / p_Scale * 6, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen

            Case "A5", "B5"
                dtmpHigh = 575 * (dH_val / dOrgHigh)
                Select Case H_Totte(iBanNo)
                    Case V_H_Totte_1, V_H_Totte_5
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_1 Then
                            sCFD_Block = sDot & "TOTTE_LT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RLT"
                        End If
                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / 2 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_2, V_H_Totte_6
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_2 Then
                            sCFD_Block = sDot & "TOTTE_RT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RRT"
                        End If
                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / 2 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_WO_NPS"
                        Else
                            Select Case H_Totte(iBanNo)
                                Case V_H_Totte_3
                                    sCFD_Block = sDot & "TOTTE_WO"
                                Case V_H_Totte_7
                                    sCFD_Block = sDot & "TOTTE_RWO"
                                Case V_H_Totte_8
                                    sCFD_Block = sDot & "TOTTE_WO2"
                                Case V_H_Totte_9
                                    sCFD_Block = sDot & "TOTTE_RWO2"
                            End Select
                        End If
                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / 2 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        '区切り線の作成
                        insPntS(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val / conScale_H), p_Scale)
                        If IO = "屋外" Then insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale) - 1, p_Scale)
                        insPntE(2) = 0.0#
                        linObj = moSpace.AddLine(insPntS, insPntE)
                        '線色変更
                        linObj.color = ACAD_COLOR.acGreen
                    Case V_H_Totte_4 '例外処理
                End Select
                '区切り線の作成
                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / p_Scale, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / p_Scale, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen

            Case "A6", "B6"
                dtmpHigh = 575 * (dH_val / dOrgHigh)
                Select Case H_Totte(iBanNo)
                    Case V_H_Totte_1, V_H_Totte_5
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_1 Then
                            sCFD_Block = sDot & "TOTTE_LT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RLT"
                        End If
                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / 4 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX + conDou14, p_Scale)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - dtmpHigh - iH_IO) * 3 / 4 + dtmpHigh) / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_2, V_H_Totte_6
                        'ブロック配置
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_T_NPS"
                        ElseIf H_Totte(iBanNo) = V_H_Totte_2 Then
                            sCFD_Block = sDot & "TOTTE_RT"
                        Else
                            sCFD_Block = sDot & "TOTTE_RRT"
                        End If
                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / 4 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX - conDou14, p_Scale) + Val(H_W(iBanNo))
                        InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - dtmpHigh - iH_IO) * 3 / 4 + dtmpHigh) / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入
                    Case V_H_Totte_3, V_H_Totte_7, V_H_Totte_8, V_H_Totte_9
                        If nps = True Then                          '(条件追加 17/01/19)
                            sCFD_Block = sDot & "TOTTE_WO_NPS"
                        Else
                            Select Case H_Totte(iBanNo)
                                Case V_H_Totte_3
                                    sCFD_Block = sDot & "TOTTE_WO"
                                Case V_H_Totte_7
                                    sCFD_Block = sDot & "TOTTE_RWO"
                                Case V_H_Totte_8
                                    sCFD_Block = sDot & "TOTTE_WO2"
                                Case V_H_Totte_9
                                    sCFD_Block = sDot & "TOTTE_RWO2"
                            End Select
                        End If
                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + (dH_val - dtmpHigh - iH_IO) / 4 / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        InsPnt(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        InsPnt(1) = SetScale(conZhyY2 - YDown + ((dH_val - dtmpHigh - iH_IO) * 3 / 4 + dtmpHigh) / p_Scale, p_Scale)
                        InsPnt(2) = 0.0#
                        blkObj = fInsBlk(InsPnt, P_HBlkPath & sCFD_Block, 1, "")   'ﾌﾞﾛｯｸ挿入

                        '区切り線の作成
                        insPntS(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntS(1) = SetScale(conZhyY2 - YDown, p_Scale)
                        insPntS(2) = 0.0#
                        insPntE(0) = SetScale(dMainX, p_Scale) + (Val(H_W(iBanNo)) / 2)
                        insPntE(1) = SetScale(conZhyY2 - YDown + (dH_val / p_Scale), p_Scale)
                        If IO = "屋外" Then insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - iH_IO) / p_Scale) - 1, p_Scale)
                        insPntE(2) = 0.0#
                        linObj = moSpace.AddLine(insPntS, insPntE)
                        '線色変更
                        linObj.color = ACAD_COLOR.acGreen
                    Case V_H_Totte_4 '例外処理
                End Select
                '区切り線の作成
                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_val - dtmpHigh - iH_IO) / 2) / p_Scale, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - dtmpHigh - iH_IO) / 2) / p_Scale, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen

                insPntS(0) = SetScale(dMainX, p_Scale)
                insPntS(1) = SetScale(conZhyY2 - YDown + ((dH_val - dtmpHigh - iH_IO) / 2 + dtmpHigh) / p_Scale, p_Scale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(dMainX, p_Scale) + Val(H_W(iBanNo))
                insPntE(1) = SetScale(conZhyY2 - YDown + ((dH_val - dtmpHigh - iH_IO) / 2 + dtmpHigh) / p_Scale, p_Scale)
                insPntE(2) = 0.0#
                linObj = moSpace.AddLine(insPntS, insPntE)
                '線色変更
                linObj.color = ACAD_COLOR.acGreen
        End Select
        If sDot <> "" Then SetActiveLine(LinTyp.Name) '納入外ならば線種を元に戻す
    End Sub
    '
    '
    '
    Public Sub ClearHairetu()
        '-----------------------------------------------
        '配列(Hairetu)のクリアー
        '-----------------------------------------------
        Dim i As Integer
        i = 1
        Do While P_Hairetu(i) <> ""
            P_Hairetu(i) = ""
            i = i + 1
        Loop
    End Sub
    '
    '扉形状作成
    '
    Public Function fCreDoorTyp(ByVal sSelStrF As String, ByVal sSelStrR As String) As String
        Select Case sSelStrF & sSelStrR
            Case conD1 & conDR
                fCreDoorTyp = "A1"
            Case conD2 & conDR
                fCreDoorTyp = "A2"
            Case conD3 & conDR
                fCreDoorTyp = "A3"
            Case conD4 & conDR
                fCreDoorTyp = "A4"
            Case conBU & conBU
                fCreDoorTyp = "A5"
            Case conBM & conDR
                fCreDoorTyp = "A6"
            Case conD1 & conPR
                fCreDoorTyp = "B1"
            Case conD2 & conPR
                fCreDoorTyp = "B2"
            Case conD3 & conPR
                fCreDoorTyp = "B3"
            Case conD4 & conPR
                fCreDoorTyp = "B4"
            Case conBU & conPR
                fCreDoorTyp = "B5"
            Case conBM & conPR
                fCreDoorTyp = "B6"
            Case conD1 & conDMcb1
                fCreDoorTyp = "C1"
            Case conD1 & conDMcb2
                fCreDoorTyp = "C2"
            Case conD1 & conPMcb1
                fCreDoorTyp = "D1"
            Case conD1 & conPMcb2
                fCreDoorTyp = "D2"

            Case conD1 & conHDR
                fCreDoorTyp = "B1"
            Case conD2 & conHDR
                fCreDoorTyp = "B2"
            Case conD3 & conHDR
                fCreDoorTyp = "B3"
            Case conD4 & conHDR
                fCreDoorTyp = "B4"
            Case conD1 & conN
                fCreDoorTyp = "E1"
            Case conD2 & conN
                fCreDoorTyp = "E2"
            Case conD3 & conN
                fCreDoorTyp = "E3"
            Case conD4 & conN
                fCreDoorTyp = "E4"


            Case Else
                fCreDoorTyp = ""
        End Select
    End Function


    Public Sub CalNeedPageH()
        '-----------------------------------------------
        '必要なページ数を計算(配列用）
        '-----------------------------------------------
        Dim AnsYN As String
        Dim Dummy2 As String
        Dim HakoD As Integer
        Dim i As Integer, j As Integer, CurPage As Integer
        Dim TmpLen As Integer

        '最右端箱番号（納入外を除く）が格納されている配列位置の計算
        Read_NO = 0
        AnsYN = "YES"
        i = 1
        Dummy2 = ExtCubNo(0)
        Do Until ExtCubNo(i) = ""
            Dummy2 = Dummy2 + "," + ExtCubNo(i)
            i = i + 1
        Loop
        Do Until AnsYN = "NO"
            Read_NO = Read_NO + 1
            AnsYN = ChkReadYN(H_CubNo(Read_NO), Dummy2)
        Loop
        '側面図のＤ寸法
        HakoD = (Val(H_D(Read_NO))) / p_Scale
        '正面図の描き始め座標
        S_X = conZhyX2 + HakoD + conDou10

        '
        '各ページ毎の表示箱Ｎｏのセット
        '
        i = 1
        j = 1
        TmpLen = S_X
        CurPage = 1
        Do Until (H_CubNo(i) = "")
            TmpLen = TmpLen + (Val(H_W(i)) / p_Scale)
            If TmpLen <= H_Limit Then
                H_PageHakoNo(CurPage, j) = H_CubNo(i)
                j = j + 1
            Else
                CurPage = CurPage + 1
                j = 1
                'TmpLen = conZhyX3
                TmpLen = conZhyX3 + (Val(H_W(i)) / p_Scale)
                H_PageHakoNo(CurPage, j) = H_CubNo(i)
                j = j + 1
            End If
            i = i + 1
        Loop
        TL_ZMaisu = CurPage '全必要枚数
    End Sub

End Module
