﻿Module FunDB

    Public cn As Object
    Public qy As Object
    Public rs As Object
    Public rs2 As Object
    Public FlagOraCnn As Boolean
    Public DB_HostStr As String
    Public DB_UID As String
    Public DB_PWD As String
    'Public stat As Integer
    'Public stat As Boolean
    '

    '
    '   Oracle DB に接続する
    '
    Public Function OraCnn(ByVal HostStr As String, ByVal UID As String, ByVal PWD As String) As Boolean
        Dim ConStr As String
        Dim TryCnt As Integer
        Dim stat As Long

        On Error GoTo ErrRtn

        OraCnn = False

        ConStr = "DRIVER={Oracle ODBC Driver};" & _
            "UID=nps;" & _
            "PWD=nps;" & _
            "DBQ=orcl8;" & _
            "DBA=W;"

        ConStr = "DRIVER={Microsoft ODBC Driver for Oracle}" & _
            ";ConnectString=" & HostStr & _
            ";UID=" & UID & _
            ";PWD=" & PWD

        If FlagOraCnn = False Then
            'RDOによる接続
            'cn.Connect = ConStr
            'cn.CursorDriver = rdUseClientBatch
            'cn.EstablishConnection(Prompt:=rdDriverNoPrompt)
            'Debug.Print(cn.Connect)
            'qy.ActiveConnection = cn

            'oo4oによる接続
            cn = CreateObject("OracleInProcServer.XOraSession")
            qy = cn.OpenDatabase(HostStr, UID & "/" & PWD, 0&)
            Console.WriteLine(qy.RDBMSVersion)

            '接続フラグ
            FlagOraCnn = True
        End If
        OraCnn = True
        DB_HostStr = HostStr
        DB_UID = UID
        DB_PWD = PWD
ExtFun:
        Exit Function
ErrRtn:
        Select Case Err.Number
            Case 40076
                stat = MsgBox("%DB接続ﾒｯｾｰｼﾞ:'" & Err.Number & "' - " & Err.Description, _
                            vbOKOnly + vbInformation, _
                            "Oracleデータベースアクセスエラー")
            Case 40072
                stat = MsgBox("%DB接続ﾒｯｾｰｼﾞ:'" & Err.Number & "' - " & Err.Description, _
                            vbOKOnly + vbInformation, _
                            "Oracleデータベースアクセスエラー")
            Case Else
                stat = MsgBox("%DB接続ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
                            vbOKOnly + vbCritical, _
                            "Oracleデータベースアクセスエラー")
        End Select
        Resume Next


        '↓以前の

        'Dim ConStr As String
        'Dim TryCnt As Integer
        'Dim stat As Long

        'On Error GoTo ErrRtn

        'OraCnn = False

        'ConStr = "DRIVER={Oracle ODBC Driver};" & _
        '    "UID=swg;" & _
        '    "PWD=swg;" & _
        '    "DBQ=orcl8;" & _
        '    "DBA=W;"

        'ConStr = "DRIVER={Microsoft ODBC Driver for Oracle}" & _
        '    ";ConnectString=" & HostStr & _
        '    ";UID=" & UID & _
        '    ";PWD=" & PWD

        'If FlagOraCnn = False Then
        'RDOによる接続
        'cn.Connect = ConStr
        'cn.CursorDriver = rdUseClientBatch
        'cn.EstablishConnection Prompt:=rdDriverNoPrompt
        '    Debug.Print cn.Connect
        'Set qy.ActiveConnection = cn

        'oo4oによる接続
        'cn = CreateObject("OracleInProcServer.XOraSession")
        'qy = cn.OpenDatabase(HostStr, UID & "/" & PWD, 0&)
        'Debug.Print(qy.RDBMSVersion)

        '接続フラグ
        'FlagOraCnn = True
        'End If
        'OraCnn = True
        'DB_HostStr = HostStr
        'DB_UID = UID
        'DB_PWD = PWD
        'ExtFun:
        'Exit Function
        'ErrRtn:
        'Select Case Err.Number
        '    Case 40076
        '        stat = MsgBox("%DB接続ﾒｯｾｰｼﾞ:'" & Err.Number & "' - " & Err.Description, _
        '                    vbOKOnly + vbInformation, _
        '                    "Oracleデータベースアクセスエラー")
        '    Case 40072
        '        stat = MsgBox("%DB接続ﾒｯｾｰｼﾞ:'" & Err.Number & "' - " & Err.Description, _
        '                    vbOKOnly + vbInformation, _
        '                    "Oracleデータベースアクセスエラー")
        '    Case Else
        '        stat = MsgBox("%DB接続ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
        '                    vbOKOnly + vbCritical, _
        '                    "Oracleデータベースアクセスエラー")
        'End Select
        'Resume Next
    End Function


    Function DB_配列基礎共通(ByVal Flg As String) As Boolean
        Dim Sql As String
        Dim tmp As Object
        DBHairetu = False

        DB_配列基礎共通 = False
        If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Function
        If Trim(FntSunpo) = "" Then FntSunpo = "0"
        If Trim(BckSunpo) = "" Then BckSunpo = "0"
        If Trim(BaseH) = "" Then BaseH = "0"

        Select Case UCase(Flg)
            Case "SELECT", "CHECK"
                Sql = "SELECT * FROM 配列基礎共通 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_配列基礎共通 = OraExeSql(Sql)
            Case "INSERT"
                Sql = "SELECT * FROM 配列基礎共通 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_配列基礎共通 = OraExeSql(Sql)
                tmp = StrBaseBunkatu(1, "")
                Call InsertPtn(tmp)
                rs.Update()
                DB_配列基礎共通 = True
            Case "UPDATE"
                tmp = StrBaseBunkatu(1, "")
                Call UpdatePtn(tmp)
                rs.Update()
                DB_配列基礎共通 = True
            Case "UPDATE2"
                Sql = "SELECT * FROM 配列基礎共通 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_配列基礎共通 = OraExeSql(Sql)
                tmp = StrBaseBunkatu(1, "")
                rs.Edit()

                rs.Update()
                DB_配列基礎共通 = True
            Case "DELETE"
                Sql = "DELETE FROM 配列基礎共通 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_配列基礎共通 = OraExeSql(Sql)
                'If rs.EOF Then
                '    DB_配列基礎共通 = False
                '    Exit Function
                'End If
                'rs.Delete()
                'rs.Update()
                DB_配列基礎共通 = True
        End Select

        Select Case UCase(Flg)
            Case "SELECT"
                If rs.EOF Then
                    DB_配列基礎共通 = False
                    Exit Function
                End If
                '(変数がないものはVBで変数が未定義)

                'FunNull → 値がNullなら空文字列に
                'FunZero2Null → 値が0なら空文字列に
                'D_Name = FunNull(rs.fields("設計者").Value)

                If Diversionflg = False Then

                    frm配列基礎メイン.cmbSegment.SelectedItem = FunNull(rs.fields("分野").Value)
                    frm配列基礎仕様.cmbInOut.SelectedItem = FunNull(rs.fields("屋内外").Value)
                    InOut = FunNull(rs.fields("屋内外").Value)         '屋内外
                    IO = FunNull(rs.fields("屋内外").Value)
                    frm配列基礎仕様.cmbDoorTyp.SelectedItem = FunNull(rs.fields("扉形番").Value)
                    Door = FunNull(rs.fields("扉形番").Value)        '扉型番
                    p_DoorTyp = FunNull(rs.fields("扉形番").Value)
                    frm配列基礎仕様.cmbKeshoTyp.SelectedItem = FunNull(rs.fields("側面化粧板").Value)
                    Kesho = FunNull(rs.fields("側面化粧板").Value)
                    KeshoType = FunNull(rs.fields("側面化粧板").Value)
                    'frm配列基礎仕様.cmbKeshoTyp.SelectedItem = FunCvtKeshoType(FunNull(rs.fields("側面化粧板").Value), 1)
                    frm配列基礎仕様.txtFntSunpo.Text = FunNull(rs.fields("前面機器引出所要寸法").Value)
                    TFntSunpo = FunNull(rs.fields("前面機器引出所要寸法").Value)
                    frm配列基礎仕様.txtBckSunpo.Text = FunNull(rs.fields("背面機器引出所要寸法").Value)
                    TBckSunpo = FunNull(rs.fields("背面機器引出所要寸法").Value)
                    frm配列基礎仕様.txtBaseH.Text = FunNull(rs.fields("ベース突出寸法").Value)                   '(基礎ベース突出寸法)
                    BaseH = FunNull(rs.fields("ベース突出寸法").Value)
                    frm配列基礎仕様.cmbKumitate.SelectedItem = FunNull(rs.fields("ベース組立方法").Value)
                    Kumitate = FunNull(rs.fields("ベース組立方法").Value)
                    frm配列基礎仕様.txtBunkatu.Text = FunNull(rs.fields("ベース分割寸法").Value)                   '(基礎ベース突出寸法)
                    Bunkatu = FunNull(rs.fields("ベース分割寸法").Value)
                    frm配列基礎仕様.cmbSeikanTyp.SelectedItem = FunNull(rs.fields("製缶方式").Value)
                    Seikan = FunNull(rs.fields("製缶方式").Value)
                    P_SeikanTyp = FunNull(rs.fields("製缶方式").Value)
                    frm配列基礎仕様.txtSyubetu.Text = FunNull(rs.fields("製品種別").Value)
                    Syubetu = FunNull(rs.fields("製品種別").Value)
                    frm配列基礎仕様.txtMeisyo.Text = FunNull(rs.fields("設備名称").Value)
                    Meisho = FunNull(rs.fields("設備名称").Value)
                End If
                

                'frm配列基礎仕様.cmbSeikanTyp.SelectedItem = FunNull(rs.fields("ベース組立方法").Value)

                'tmp = StrBaseBunkatu(0, FunNull(rs.fields("ベース分割位置").Value))
                ' = FunNull(rs.fields("製品種別").Value)

                'SeigyoAna = FunCvtSeigyoAna(FunNull(rs.fields("制御ケーブル穴仕様").Value), 1)  '基礎箱別へ

                'Meisho = FunNull(rs.fields("図題名").Value)


            Case "CHECK"
                If rs.EOF Then
                    DB_配列基礎共通 = False
                    Exit Function
                End If
        End Select

        '↓以前までの

        'Dim Sql As String
        'Dim tmp As Object

        'DB_配列基礎共通 = False
        'If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Function
        'If Trim(FntSunpo) = "" Then FntSunpo = "0"
        'If Trim(BckSunpo) = "" Then BckSunpo = "0"
        'If Trim(BaseH) = "" Then BaseH = "0"

        'Select Case UCase(Flg)
        '    Case "SELECT", "CHECK"
        'Sql = "SELECT * FROM 配列基礎共通 " & _
        '    "WHERE (工番='" & UCase(KoubanName) & "' " & _
        '        "AND 群番='" & UCase(GunbanName) & "') "
        'DB_配列基礎共通 = OraExeSql(Sql)
        '    Case "INSERT"
        'tmp = StrBaseBunkatu(1, "")
        'Call InsertPtn(tmp)
        'rs.Update()
        'DB_配列基礎共通 = True
        '    Case "UPDATE"
        'tmp = StrBaseBunkatu(1, "")
        'Call UpdatePtn(tmp)
        'rs.Update()
        'DB_配列基礎共通 = True
        '    Case "DELETE"
        'rs.Delete()
        'rs.Update()
        'DB_配列基礎共通 = True
        'End Select

        'Select Case UCase(Flg)
        '    Case "SELECT"
        'If rs.EOF Then
        'DB_配列基礎共通 = False
        'Exit Function
        'End If
        'D_Name = FunNull(rs.fields("設計者").Value)
        'DoorType = FunNull(rs.fields("扉形番").Value)
        'KeshoType = FunCvtKeshoType(FunNull(rs.fields("側面化粧板").Value), 1)
        'FntSunpo = FunZero2Null(rs.fields("前面機器引出所要寸法").Value)
        'BckSunpo = FunZero2Null(rs.fields("背面機器引出所要寸法").Value)
        'BaseH = FunNull(rs.fields("基礎ベース突出寸法").Value)
        'SeigyoAna = FunCvtSeigyoAna(FunNull(rs.fields("制御ケーブル穴仕様").Value), 1)
        'tmp = StrBaseBunkatu(0, FunNull(rs.fields("ベース分割位置").Value))
        'Meisho = FunNull(rs.fields("図題名").Value)
        'ChkExt = FunNull(rs.fields("配列納入外図示").Value)
        'ChkBase = FunNull(rs.fields("基礎納入外図示").Value)
        '    Case "CHECK"
        'If rs.EOF Then
        'DB_配列基礎共通 = False
        'Exit Function
        'End If
        'End Select

    End Function

    Function DB_配列図箱別(ByVal Flg As String) As Boolean
        Dim Sql As String
        Dim tmp As Object

        DBHairetu = True


        DB_配列図箱別 = False
        If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Function
        If Trim(FntSunpo) = "" Then FntSunpo = "0"
        If Trim(BckSunpo) = "" Then BckSunpo = "0"
        If Trim(BaseH) = "" Then BaseH = "0"

        Select Case UCase(Flg)
            Case "SELECT"
                BanCnt2 = 0
                Sql = "SELECT * FROM 配列図箱別 " & _
                    "WHERE 工番='" & UCase(KoubanName) & "' " & _
                    "AND 群番='" & UCase(GunbanName) & "' " & _
                        "ORDER BY 箱連番"
                DB_配列図箱別 = OraExeSql(Sql)
            Case "CHECK"
                Sql = "SELECT * FROM 配列図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_配列図箱別 = OraExeSql(Sql)
            Case "INSERT"
                Sql = "SELECT * FROM 配列図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "' " & _
                        "AND 箱連番='" & BanCnt2 & "') "
                DB_配列図箱別 = OraExeSql(Sql)
                tmp = StrBaseBunkatu(1, "")
                Call InsertPtnHairetu(tmp)
                rs.Update()
                DB_配列図箱別 = True
            Case "UPDATE"
                tmp = StrBaseBunkatu(1, "")
                Call UpdatePtnHairetu(tmp)
                rs.Update()
                DB_配列図箱別 = True
            Case "DELETE"
                Sql = "DELETE FROM 配列図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_配列図箱別 = OraExeSql(Sql)
                'If rs.EOF Then
                '    DB_配列図箱別 = False
                '    Exit Function
                'End If
                ''rs.Delete()
                'rs.Update()
                DB_配列図箱別 = True
        End Select

        Select Case UCase(Flg)
            Case "SELECT"
                If rs.EOF Then
                    DB_配列図箱別 = False
                    Exit Function
                End If
                '(変数がないものはVBで変数が未定義)

                'FunNull → 値がNullなら空文字列に
                'FunZero2Null → 値が0なら空文字列に

                'ChkExt = FunNull(rs.fields("配列図示タイプ").Value)                    'ex)納入外(表示)
                ReDim P_sBanDat(LoadCnt, frm配列基礎仕様.pc_HeaderTxt.Length - 4 + frm配列基礎仕様.pc_HeaderTxt2.Length - 4 + 4 * 4)
                ReDim BanCnt(LoadCnt)
                Loopnum = LoadCnt
                CntB = LoadCnt
                For i = 0 To Loopnum
                    Sql = "SELECT * FROM 配列図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "' " & _
                        "AND 箱連番='" & BanCnt2 + 1 & "') "
                    DB_配列図箱別 = OraExeSql(Sql)
                    BanCnt2 = i + 1
                    P_sBanDat(BanCnt2 - 1, pc_BanNoRow) = FunNull(rs.fields("箱番").Value)
                    'P_sBanDat(BanCnt2 - 1, pc_NoHairetuRow) = rs.fields("箱連番").Value
                    P_sBanDat(BanCnt2 - 1, pc_NoHairetuRow) = FunNull(rs.fields("配列図示タイプ").Value)
                    P_sBanDat(BanCnt2 - 1, pc_NP1Row) = FunNull(rs.fields("名称1").Value)
                    P_sBanDat(BanCnt2 - 1, pc_NP2Row) = FunNull(rs.fields("名称2").Value)
                    P_sBanDat(BanCnt2 - 1, pc_NP3Row) = FunNull(rs.fields("名称3").Value)
                    'P_sBanDat(BanCnt2 - 1, pc_Fullname) = FunNull(rs.fields("盤総称").Value)
                    P_sBanDat(BanCnt2 - 1, pc_DRZbnRow) = FunNull(rs.fields("側面図図番").Value)
                    P_sBanDat(BanCnt2 - 1, pc_DoorZbnRow) = FunNull(rs.fields("正面扉図図番").Value)
                    P_sBanDat(BanCnt2 - 1, pc_BlkSKRow) = FunNull(rs.fields("ブロックSKコード").Value)
                    P_sBanDat(BanCnt2 - 1, pc_KikakuNoRow) = FunNull(rs.fields("規格番号").Value)
                    P_sBanDat(BanCnt2 - 1, pc_BoxTypRow) = FunNull(rs.fields("形").Value)
                    P_sBanDat(BanCnt2 - 1, pc_HogoBoxRow) = FunNull(rs.fields("保護等級_閉鎖箱").Value)
                    P_sBanDat(BanCnt2 - 1, pc_HogoItaRow) = FunNull(rs.fields("保護等級_仕切板").Value)
                    P_sBanDat(BanCnt2 - 1, pc_TeikakuVRow) = FunNull(rs.fields("定格電圧").Value)
                    P_sBanDat(BanCnt2 - 1, pc_FreqRow) = FunNull(rs.fields("定格周波数").Value)
                    P_sBanDat(BanCnt2 - 1, pc_ComFreqRow) = FunNull(rs.fields("定格耐電圧_商用周波").Value)
                    P_sBanDat(BanCnt2 - 1, pc_ImplsRow) = FunNull(rs.fields("定格耐電圧_雷インパルス").Value)
                    P_sBanDat(BanCnt2 - 1, pc_ClsRow) = FunNull(rs.fields("絶縁階級").Value)
                    P_sBanDat(BanCnt2 - 1, pc_NPRow) = FunNull(rs.fields("製造者銘板番号").Value)
                    P_sBanDat(BanCnt2 - 1, pc_KankyouRow) = FunNull(rs.fields("環境条件").Value)
                    P_sBanDat(BanCnt2 - 1, pc_DoorOpnRow) = FunNull(rs.fields("扉開放角度").Value)
                    P_sBanDat(BanCnt2 - 1, pc_JyuryoRow) = FunNull(rs.fields("盤概略質量").Value)
                    P_sBanDat(BanCnt2 - 1, pc_BanDRow) = FunNull(rs.fields("盤寸法D").Value)
                    P_sBanDat(BanCnt2 - 1, pc_BanHRow) = FunNull(rs.fields("盤寸法H").Value)
                    P_sBanDat(BanCnt2 - 1, pc_BanWRow) = FunNull(rs.fields("盤寸法W").Value)
                    P_sBanDat(BanCnt2 - 1, pc_KankiRow) = FunNull(rs.fields("換気箱").Value)
                    P_sBanDat(BanCnt2 - 1, pc_FDoorRow) = FunNull(rs.fields("扉形状_正面").Value)
                    P_sBanDat(BanCnt2 - 1, pc_RDoorRow) = FunNull(rs.fields("扉形状_背面").Value)
                    P_sBanDat(BanCnt2 - 1, pc_FTotteRow) = FunNull(rs.fields("把手_正面").Value)
                    BanCnt(i) = FunNull(rs.fields("箱番").Value)


                Next
            Case "CHECK"
                If rs.EOF Then
                    DB_配列図箱別 = False
                    Exit Function
                End If
        End Select


        DBHairetu = False

    End Function

    Function DB_基礎図箱別(ByVal Flg As String) As Boolean
        Dim Sql As String
        Dim tmp As Object
        Dim i As Integer

        DB_基礎図箱別 = False
        If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Function
        If Trim(FntSunpo) = "" Then FntSunpo = "0"
        If Trim(BckSunpo) = "" Then BckSunpo = "0"
        If Trim(BaseH) = "" Then BaseH = "0"

        Select Case UCase(Flg)
            Case "SELECT"
                Sql = "SELECT * FROM 基礎図箱別 " & _
                    "WHERE 工番='" & UCase(KoubanName) & "' " & _
                    "AND 群番='" & UCase(GunbanName) & "' " & _
                        "ORDER BY 箱番"       '←箱連番を用意してもらってから箱連番に変更
                DB_基礎図箱別 = OraExeSql(Sql)
            Case "CHECK"
                Sql = "SELECT * FROM 基礎図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_基礎図箱別 = OraExeSql(Sql)
            Case "INSERT"
                Sql = "SELECT * FROM 基礎図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "' " & _
                        "AND 箱番='" & BanNo & "') "
                DB_基礎図箱別 = OraExeSql(Sql)
                tmp = StrBaseBunkatu(1, "")
                Call InsertPtnKiso(tmp)
                rs.Update()
                DB_基礎図箱別 = True
            Case "UPDATE"
                tmp = StrBaseBunkatu(1, "")
                Call UpdatePtnKiso(tmp)
                rs.Update()
                DB_基礎図箱別 = True
            Case "DELETE"
                'Sql = "DELETE FROM 基礎図箱別 " & _
                '    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                '        "AND 群番='" & UCase(GunbanName) & "' " & _
                '        "AND 箱番='" & BanNo & "') "
                Sql = "DELETE FROM 基礎図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "') "
                DB_基礎図箱別 = OraExeSql(Sql)
                'If rs.EOF Then
                '    DB_基礎図箱別 = False
                '    Exit Function
                'End If
                ''rs.Delete()
                'rs.Update()
                DB_基礎図箱別 = True
        End Select

        Select Case UCase(Flg)
            Case "SELECT"
                If rs.EOF Then
                    Console.WriteLine(rs.EOF)
                    DB_基礎図箱別 = False
                    Exit Function
                End If

                For i = 0 To Loopnum
                    BanCnt2 = i + 1

                    Sql = "SELECT * FROM 基礎図箱別 " & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "' " & _
                        "AND 箱番='" & BanCnt(i) & "') "
                    DB_基礎図箱別 = OraExeSql(Sql)

                    P_sBanDat(BanCnt2 - 1, pc_BanNoRow) = FunNull(rs.fields("箱番").Value)
                    'P_sBanDat(BanCnt2 - 1, pc_NoHairetuRow) = rs.fields("箱連番").Value
                    P_sBanDat(BanCnt2 - 1, pc_NoKisoRow) = FunNull(rs.fields("基礎図示タイプ").Value)
                    frm配列基礎仕様.cmbSeigyo.SelectedItem = FunCvtSeigyoAna(FunNull(rs.fields("制御ケーブル穴仕様").Value), 1)
                    SeigyoK = FunCvtSeigyoAna(FunNull(rs.fields("制御ケーブル穴仕様").Value), 1)
                    SeigyoAna = FunCvtSeigyoAna(FunNull(rs.fields("制御ケーブル穴仕様").Value), 1)
                    'P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2) = FunNull(rs.fields("主回路ケーブル穴仕様").Value)
                    P_sBanDat(BanCnt2 - 1, pc_HokyoKataRow2) = FunNull(rs.fields("補強枠_形式").Value)
                    P_sBanDat(BanCnt2 - 1, pc_HokyoARow2) = FunNull(rs.fields("補強枠_寸法1").Value)
                    P_sBanDat(BanCnt2 - 1, pc_HokyoBRow2) = FunNull(rs.fields("補強枠_寸法2").Value)
                    P_sBanDat(BanCnt2 - 1, pc_HokyoXRow2) = FunNull(rs.fields("補強枠_寸法3").Value)
                    P_sBanDat(BanCnt2 - 1, pc_HokyoYRow2) = FunNull(rs.fields("補強枠_寸法4").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2) = FunNull(rs.fields("引込穴1_形式").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 1) = FunNull(rs.fields("引込穴1_寸法1").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 2) = FunNull(rs.fields("引込穴1_寸法2").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 3) = FunNull(rs.fields("引込穴1_寸法3").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 4) = FunNull(rs.fields("引込穴1_寸法4").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2) = FunNull(rs.fields("引込穴2_形式").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 1) = FunNull(rs.fields("引込穴2_寸法1").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 2) = FunNull(rs.fields("引込穴2_寸法2").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 3) = FunNull(rs.fields("引込穴2_寸法3").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 4) = FunNull(rs.fields("引込穴2_寸法4").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2) = FunNull(rs.fields("引込穴3_形式").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 1) = FunNull(rs.fields("引込穴3_寸法1").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 2) = FunNull(rs.fields("引込穴3_寸法2").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 3) = FunNull(rs.fields("引込穴3_寸法3").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 4) = FunNull(rs.fields("引込穴3_寸法4").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2) = FunNull(rs.fields("引込穴4_形式").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 1) = FunNull(rs.fields("引込穴4_寸法1").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 2) = FunNull(rs.fields("引込穴4_寸法2").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 3) = FunNull(rs.fields("引込穴4_寸法3").Value)
                    P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 4) = FunNull(rs.fields("引込穴4_寸法4").Value)
                    P_sBanDat(BanCnt2 - 1, pc_LOkuyukiRow2) = FunNull(rs.fields("奥行枠_左").Value)
                    P_sBanDat(BanCnt2 - 1, pc_ROkuyukiRow2) = FunNull(rs.fields("奥行枠_右").Value)



                Next

                'P_sBanDat(BanCnt2 - 1, pc_NoKisoRow) = FunNull(rs.fields("基礎図示タイプ").Value)        'ex)納入外(表示)
                'Next

                '(変数がないものはVBで変数が未定義)

                'FunNull → 値がNullなら空文字列に
                'FunZero2Null → 値が0なら空文字列に
                'ChkBase = FunNull(rs.fields("基礎図示タイプ").Value)                    'ex)納入外(表示)
                ' = FunNull(rs.fields("主回路ケーブル穴仕様").Value)
                'SeigyoAna = FunCvtSeigyoAna(FunNull(rs.fields("制御ケーブル穴仕様").Value), 1)

            Case "CHECK"
                If rs.EOF Then
                    DB_基礎図箱別 = False
                    Exit Function
                End If
        End Select





    End Function



    Public Sub InsertPtn(ByVal tmp As Object)
        'INSERTなら(DB_配列基礎共通より)

        rs.AddNew()
        rs.fields("工番").Value = UCase(KoubanName)
        rs.fields("群番").Value = UCase(GunbanName)
        rs.fields("分野").Value = frm配列基礎メイン.cmbSegment.SelectedItem
        'rs.fields("図枠言語").Value = 
        rs.fields("屋内外").Value = frm配列基礎仕様.cmbInOut.SelectedItem
        rs.fields("扉形番").Value = frm配列基礎仕様.cmbDoorTyp.SelectedItem
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(frm配列基礎仕様.cmbKeshoTyp.SelectedItem, 0)
        rs.fields("側面化粧板").Value = frm配列基礎仕様.cmbKeshoTyp.SelectedItem
        rs.fields("前面機器引出所要寸法").Value = frm配列基礎仕様.txtFntSunpo.Text
        rs.fields("背面機器引出所要寸法").Value = frm配列基礎仕様.txtBckSunpo.Text
        rs.fields("ベース突出寸法").Value = frm配列基礎仕様.txtBaseH.Text
        rs.fields("ベース分割寸法").Value = frm配列基礎仕様.txtBunkatu.Text
        rs.fields("ベース組立方法").Value = frm配列基礎仕様.cmbKumitate.SelectedItem
        rs.fields("製缶方式").Value = frm配列基礎仕様.cmbSeikanTyp.SelectedItem
        rs.fields("製品種別").Value = frm配列基礎仕様.txtSyubetu.Text
        rs.fields("設備名称").Value = frm配列基礎仕様.txtMeisyo.Text
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(frm配列基礎仕様.cmbSeigyo.SelectedItem, 0)
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割寸法").Value = tmp
        'rs.fields("図題名").Value = Meisho

        '以前の
        'rs.AddNew()
        'rs.fields("工番").Value = UCase(KoubanName)
        'rs.fields("群番").Value = UCase(GunbanName)
        'rs.fields("設計者").Value = D_Name
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割位置").Value = tmp
        'rs.fields("図題名").Value = Meisho
        'rs.fields("配列納入外図示").Value = ChkExt
        'rs.fields("基礎納入外図示").Value = ChkBase
    End Sub

    Public Sub UpdatePtn(ByVal tmp As Object)
        'UPDATEなら(DB_配列基礎共通より)
        rs.Edit()
        'rs.fields("図枠言語").Value = 
        rs.fields("分野").Value = frm配列基礎メイン.cmbSegment.SelectedItem
        rs.fields("屋内外").Value = frm配列基礎仕様.cmbInOut.SelectedItem
        rs.fields("扉形番").Value = frm配列基礎仕様.cmbDoorTyp.SelectedItem
        rs.fields("側面化粧板").Value = frm配列基礎仕様.cmbKeshoTyp.SelectedItem
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(frm配列基礎仕様.cmbKeshoTyp.SelectedItem, 0)
        rs.fields("前面機器引出所要寸法").Value = frm配列基礎仕様.txtFntSunpo.Text
        rs.fields("背面機器引出所要寸法").Value = frm配列基礎仕様.txtBckSunpo.Text
        rs.fields("ベース突出寸法").Value = frm配列基礎仕様.txtBaseH.Text
        rs.fields("ベース組立方法").Value = frm配列基礎仕様.cmbKumitate.SelectedItem
        rs.fields("ベース分割寸法").Value = frm配列基礎仕様.txtBunkatu.Text
        rs.fields("製缶方式").Value = frm配列基礎仕様.cmbSeikanTyp.SelectedItem
        'rs.fields("ベース組立方法").Value = frm配列基礎仕様.cmbSeikanTyp.SelectedItem
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割寸法").Value = tmp
        'rs.fields("図題名").Value = Meisho


        '以前の
        'rs.Edit()
        'rs.fields("設計者").Value = D_Name
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割位置").Value = tmp
        'rs.fields("図題名").Value = Meisho
        'rs.fields("配列納入外図示").Value = ChkExt
        'rs.fields("基礎納入外図示").Value = ChkBase
    End Sub

    Public Sub InsertPtnHairetu(ByVal tmp As Object)
        'INSERTなら(DB_配列図箱別より)

        rs.AddNew()
        rs.fields("工番").Value = UCase(KoubanName)
        rs.fields("群番").Value = UCase(GunbanName)
        rs.fields("箱番").Value = P_sBanDat(BanCnt2 - 1, pc_BanNoRow)
        rs.fields("箱連番").Value = BanCnt2            '列ヘッダー
        rs.fields("配列図示タイプ").Value = P_sBanDat(BanCnt2 - 1, pc_NoHairetuRow)
        rs.fields("名称1").Value = P_sBanDat(BanCnt2 - 1, pc_NP1Row)
        rs.fields("名称2").Value = P_sBanDat(BanCnt2 - 1, pc_NP2Row)
        rs.fields("名称3").Value = P_sBanDat(BanCnt2 - 1, pc_NP3Row)

        'rs.fields("盤総称").Value = P_sBanDat(BanCnt2 - 1, pc_Fullname)

        rs.fields("側面図図番").Value = P_sBanDat(BanCnt2 - 1, pc_DRZbnRow)
        rs.fields("正面扉図図番").Value = P_sBanDat(BanCnt2 - 1, pc_DoorZbnRow)
        rs.fields("ブロックSKコード").Value = P_sBanDat(BanCnt2 - 1, pc_BlkSKRow)
        rs.fields("規格番号").Value = P_sBanDat(BanCnt2 - 1, pc_KikakuNoRow)
        rs.fields("形").Value = P_sBanDat(BanCnt2 - 1, pc_BoxTypRow)
        rs.fields("保護等級_閉鎖箱").Value = P_sBanDat(BanCnt2 - 1, pc_HogoBoxRow)
        rs.fields("保護等級_仕切板").Value = P_sBanDat(BanCnt2 - 1, pc_HogoItaRow)
        rs.fields("定格電圧").Value = P_sBanDat(BanCnt2 - 1, pc_TeikakuVRow)
        rs.fields("定格周波数").Value = P_sBanDat(BanCnt2 - 1, pc_FreqRow)
        rs.fields("定格耐電圧_商用周波").Value = P_sBanDat(BanCnt2 - 1, pc_ComFreqRow)
        rs.fields("定格耐電圧_雷インパルス").Value = P_sBanDat(BanCnt2 - 1, pc_ImplsRow)
        rs.fields("絶縁階級").Value = P_sBanDat(BanCnt2 - 1, pc_ClsRow)
        rs.fields("製造者銘板番号").Value = P_sBanDat(BanCnt2 - 1, pc_NPRow)
        rs.fields("環境条件").Value = P_sBanDat(BanCnt2 - 1, pc_KankyouRow)
        rs.fields("扉開放角度").Value = P_sBanDat(BanCnt2 - 1, pc_DoorOpnRow)
        rs.fields("盤概略質量").Value = P_sBanDat(BanCnt2 - 1, pc_JyuryoRow)
        rs.fields("盤寸法D").Value = P_sBanDat(BanCnt2 - 1, pc_BanDRow)
        rs.fields("盤寸法H").Value = P_sBanDat(BanCnt2 - 1, pc_BanHRow)
        rs.fields("盤寸法W").Value = P_sBanDat(BanCnt2 - 1, pc_BanWRow)
        rs.fields("換気箱").Value = P_sBanDat(BanCnt2 - 1, pc_KankiRow)
        rs.fields("扉形状_正面").Value = P_sBanDat(BanCnt2 - 1, pc_FDoorRow)
        rs.fields("扉形状_背面").Value = P_sBanDat(BanCnt2 - 1, pc_RDoorRow)
        rs.fields("把手_正面").Value = P_sBanDat(BanCnt2 - 1, pc_FTotteRow)




        '以前の
        'rs.AddNew()
        'rs.fields("工番").Value = UCase(KoubanName)
        'rs.fields("群番").Value = UCase(GunbanName)
        'rs.fields("設計者").Value = D_Name
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割位置").Value = tmp
        'rs.fields("図題名").Value = Meisho
        'rs.fields("配列納入外図示").Value = ChkExt
        'rs.fields("基礎納入外図示").Value = ChkBase
    End Sub

    Public Sub UpdatePtnHairetu(ByVal tmp As Object)
        'UPDATEなら(DB_配列図箱別より)
        rs.Edit()
        rs.fields("箱連番").Value = BanCnt2            '列ヘッダー
        rs.fields("配列図示タイプ").Value = P_sBanDat(BanCnt2 - 1, pc_NoHairetuRow)
        rs.fields("名称1").Value = P_sBanDat(BanCnt2 - 1, pc_NP1Row)
        rs.fields("名称2").Value = P_sBanDat(BanCnt2 - 1, pc_NP2Row)
        rs.fields("名称3").Value = P_sBanDat(BanCnt2 - 1, pc_NP3Row)

        'rs.fields("盤総称").Value = P_sBanDat(BanCnt2 - 1, pc_Fullname)

        rs.fields("側面図図番").Value = P_sBanDat(BanCnt2 - 1, pc_DRZbnRow)
        rs.fields("正面扉図図番").Value = P_sBanDat(BanCnt2 - 1, pc_DoorZbnRow)
        rs.fields("ブロックSKコード").Value = P_sBanDat(BanCnt2 - 1, pc_BlkSKRow)
        rs.fields("規格番号").Value = P_sBanDat(BanCnt2 - 1, pc_KikakuNoRow)
        rs.fields("形").Value = P_sBanDat(BanCnt2 - 1, pc_BoxTypRow)
        rs.fields("保護等級_閉鎖箱").Value = P_sBanDat(BanCnt2 - 1, pc_HogoBoxRow)
        rs.fields("保護等級_仕切板").Value = P_sBanDat(BanCnt2 - 1, pc_HogoItaRow)
        rs.fields("定格電圧").Value = P_sBanDat(BanCnt2 - 1, pc_TeikakuVRow)
        rs.fields("定格周波数").Value = P_sBanDat(BanCnt2 - 1, pc_FreqRow)
        rs.fields("定格耐電圧_商用周波").Value = P_sBanDat(BanCnt2 - 1, pc_ComFreqRow)
        rs.fields("定格耐電圧_雷インパルス").Value = P_sBanDat(BanCnt2 - 1, pc_ImplsRow)
        rs.fields("絶縁階級").Value = P_sBanDat(BanCnt2 - 1, pc_ClsRow)
        rs.fields("製造者銘板番号").Value = P_sBanDat(BanCnt2 - 1, pc_NPRow)
        rs.fields("環境条件").Value = P_sBanDat(BanCnt2 - 1, pc_KankyouRow)
        rs.fields("扉開放角度").Value = P_sBanDat(BanCnt2 - 1, pc_DoorOpnRow)
        rs.fields("盤概略質量").Value = P_sBanDat(BanCnt2 - 1, pc_JyuryoRow)
        rs.fields("盤寸法D").Value = P_sBanDat(BanCnt2 - 1, pc_BanDRow)
        rs.fields("盤寸法H").Value = P_sBanDat(BanCnt2 - 1, pc_BanHRow)
        rs.fields("盤寸法W").Value = P_sBanDat(BanCnt2 - 1, pc_BanWRow)
        rs.fields("換気箱").Value = P_sBanDat(BanCnt2 - 1, pc_KankiRow)
        rs.fields("扉形状_正面").Value = P_sBanDat(BanCnt2 - 1, pc_FDoorRow)
        rs.fields("扉形状_背面").Value = P_sBanDat(BanCnt2 - 1, pc_RDoorRow)
        rs.fields("把手_正面").Value = P_sBanDat(BanCnt2 - 1, pc_FTotteRow)

        '以前の
        'rs.Edit()
        'rs.fields("設計者").Value = D_Name
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割位置").Value = tmp
        'rs.fields("図題名").Value = Meisho
        'rs.fields("配列納入外図示").Value = ChkExt
        'rs.fields("基礎納入外図示").Value = ChkBase
    End Sub

    Public Sub InsertPtnKiso(ByVal tmp As Object)
        'INSERTなら(DB_基礎図箱別より)

        rs.AddNew()
        rs.fields("工番").Value = UCase(KoubanName)
        rs.fields("群番").Value = UCase(GunbanName)
        rs.fields("箱番").Value = P_sBanDat(BanCnt2 - 1, pc_BanNoRow)
        rs.fields("基礎図示タイプ").Value = P_sBanDat(BanCnt2 - 1, pc_NoKisoRow)
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(frm配列基礎仕様.cmbSeigyo.SelectedItem, 0)
        rs.fields("主回路ケーブル穴仕様").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2)
        rs.fields("補強枠_形式").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoKataRow2)
        rs.fields("補強枠_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoARow2)
        rs.fields("補強枠_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoBRow2)
        rs.fields("補強枠_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoXRow2)
        rs.fields("補強枠_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoYRow2)

        rs.fields("引込穴1_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2)
        rs.fields("引込穴1_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 1)
        rs.fields("引込穴1_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 2)
        rs.fields("引込穴1_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 3)
        rs.fields("引込穴1_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 4)
        rs.fields("引込穴2_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2)
        rs.fields("引込穴2_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 1)
        rs.fields("引込穴2_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 2)
        rs.fields("引込穴2_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 3)
        rs.fields("引込穴2_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 4)
        rs.fields("引込穴3_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2)
        rs.fields("引込穴3_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 1)
        rs.fields("引込穴3_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 2)
        rs.fields("引込穴3_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 3)
        rs.fields("引込穴3_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 4)
        rs.fields("引込穴4_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2)
        rs.fields("引込穴4_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 1)
        rs.fields("引込穴4_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 2)
        rs.fields("引込穴4_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 3)
        rs.fields("引込穴4_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 4)
        rs.fields("奥行枠_左").Value = P_sBanDat(BanCnt2 - 1, pc_LOkuyukiRow2)
        rs.fields("奥行枠_右").Value = P_sBanDat(BanCnt2 - 1, pc_ROkuyukiRow2)
        
        

        'rs.fields("ベース分割位置").Value = tmp
        'rs.fields("図題名").Value = Meisho



        '以前の
        'rs.AddNew()
        'rs.fields("工番").Value = UCase(KoubanName)
        'rs.fields("群番").Value = UCase(GunbanName)
        'rs.fields("設計者").Value = D_Name
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割位置").Value = tmp
        'rs.fields("図題名").Value = Meisho
        'rs.fields("配列納入外図示").Value = ChkExt
        'rs.fields("基礎納入外図示").Value = ChkBase
    End Sub

    Public Sub UpdatePtnKiso(ByVal tmp As Object)
        'UPDATEなら(DB_基礎図箱別より)
        rs.Edit()
        rs.fields("基礎図示タイプ").Value = P_sBanDat(BanCnt2 - 1, pc_NoKisoRow)
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(frm配列基礎仕様.cmbSeigyo.SelectedItem, 0)
        rs.fields("主回路ケーブル穴仕様").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2)
        'rs.fields("ベース分割位置").Value = tmp

        rs.fields("補強枠_形式").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoKataRow2)
        rs.fields("補強枠_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoARow2)
        rs.fields("補強枠_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoBRow2)
        rs.fields("補強枠_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoXRow2)
        rs.fields("補強枠_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_HokyoYRow2)
        rs.fields("引込穴1_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2)
        rs.fields("引込穴1_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 1)
        rs.fields("引込穴1_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 2)
        rs.fields("引込穴1_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 3)
        rs.fields("引込穴1_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki1Row2 + 4)
        rs.fields("引込穴2_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2)
        rs.fields("引込穴2_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 1)
        rs.fields("引込穴2_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 2)
        rs.fields("引込穴2_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 3)
        rs.fields("引込穴2_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki2Row2 + 4)
        rs.fields("引込穴3_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2)
        rs.fields("引込穴3_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 1)
        rs.fields("引込穴3_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 2)
        rs.fields("引込穴3_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 3)
        rs.fields("引込穴3_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki3Row2 + 4)
        rs.fields("引込穴4_形式").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2)
        rs.fields("引込穴4_寸法1").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 1)
        rs.fields("引込穴4_寸法2").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 2)
        rs.fields("引込穴4_寸法3").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 3)
        rs.fields("引込穴4_寸法4").Value = P_sBanDat(BanCnt2 - 1, pc_Hiki4Row2 + 4)
        rs.fields("奥行枠_左").Value = P_sBanDat(BanCnt2 - 1, pc_LOkuyukiRow2)
        rs.fields("奥行枠_右").Value = P_sBanDat(BanCnt2 - 1, pc_ROkuyukiRow2)
        'rs.fields("図題名").Value = Meisho



        '以前の
        'rs.Edit()
        'rs.fields("設計者").Value = D_Name
        'rs.fields("扉形番").Value = DoorType
        'rs.fields("側面化粧板").Value = FunCvtKeshoType(KeshoType, 0)
        'rs.fields("前面機器引出所要寸法").Value = FntSunpo
        'rs.fields("背面機器引出所要寸法").Value = BckSunpo
        'rs.fields("基礎ベース突出寸法").Value = BaseH
        'rs.fields("制御ケーブル穴仕様").Value = FunCvtSeigyoAna(SeigyoAna, 0)
        'rs.fields("ベース分割位置").Value = tmp
        'rs.fields("図題名").Value = Meisho
        'rs.fields("配列納入外図示").Value = ChkExt
        'rs.fields("基礎納入外図示").Value = ChkBase
    End Sub



    '
    '箱別基本仕様テーブルへのアクセス（入力 共通仕様から）
    '
    Sub DB_Get箱番号(ByVal Dest() As String)
        Dim Sql As String
        Dim tmp As Integer
        Dim i As Integer

        If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Sub

        Sql = "SELECT 箱番,納入外フラグ,基礎ベースフラグ FROM 箱別基本仕様 " & vbCrLf & _
            "WHERE (工番='" & UCase(KoubanName) & "' " & _
                "AND 群番='" & UCase(GunbanName) & "') " & _
            "ORDER BY 箱連番 "
        stat = OraExeSql(Sql)
        If rs.EOF Then
            Dest(0) = ""
        Else
            i = 0
            Do Until rs.EOF
                Dest(i) = rs.fields("箱番").Value
                tmp = FunExtSet("Ext", Dest(i), FunNull0(rs.fields("納入外フラグ").Value))
                tmp = FunExtSet("Base", Dest(i), FunNull0(rs.fields("基礎ベースフラグ").Value))
                i = i + 1
                rs.MoveNext()
            Loop
        End If

        '↓以前の
        'Dim Sql As String
        'Dim tmp As Integer
        'Dim i As Integer

        'If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Sub

        'Sql = "SELECT 箱番,納入外フラグ,基礎ベースフラグ FROM 箱別基本仕様 " & vbCrLf & _
        '    "WHERE (工番='" & UCase(KoubanName) & "' " & _
        '        "AND 群番='" & UCase(GunbanName) & "') " & _
        '    "ORDER BY 箱連番 "
        'stat = OraExeSql(Sql)
        'If rs.EOF Then
        'Dest(0) = ""
        'Else
        'i = 0
        'Do Until rs.EOF
        'Dest(i) = rs.fields("箱番").Value
        'tmp = FunExtSet("Ext", Dest(i), FunNull0(rs.fields("納入外フラグ").Value))
        'tmp = FunExtSet("Base", Dest(i), FunNull0(rs.fields("基礎ベースフラグ").Value))
        'i = i + 1
        'rs.MoveNext()
        'Loop
        'End If

    End Sub

    '
    '箱別基本仕様テーブルへのアクセス（入力 箱別仕様から）
    '
    Function DB_箱別基本仕様2(ByVal Flg As String) As Boolean
        Dim Sql As String
        'Dim tmp As String
        Sql = ""        '初期値

        DB_箱別基本仕様2 = False
        If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Function

        If Trim(H_D(0)) = "" Then H_D(0) = "0"
        If Trim(H_H(0)) = "" Then H_H(0) = "0"
        If Trim(H_W(0)) = "" Then H_W(0) = "0"
        If Trim(H_Jyuryo(0)) = "" Then H_Jyuryo(0) = "0"

        Select Case UCase(Flg)
            Case "SELECT", "CHECK"
                Sql = "SELECT * FROM 箱別基本仕様 " & vbCrLf & _
                    "WHERE (工番='" & UCase(KoubanName) & "' " & _
                        "AND 群番='" & UCase(GunbanName) & "' " & _
                        "AND 箱番='" & CubNo(CubCnt) & "') "
                DB_箱別基本仕様2 = OraExeSql(Sql)
            Case "INSERT"
                If Trim(H_HPage(0)) = "" Then H_HPage(0) = "0"
                If Trim(H_KPage(0)) = "" Then H_KPage(0) = "0"
                Call InsertPtn2()
                rs.Update()
                DB_箱別基本仕様2 = True
            Case "UPDATE"
                rs.Edit()
                Call UpdatePtn2()
                rs.Update()
                DB_箱別基本仕様2 = True
            Case "DELETE"
                rs.Delete()
                rs.Update()
                DB_箱別基本仕様2 = True
        End Select
        DB_箱別基本仕様2 = OraExeSql(Sql)

        Select Case UCase(Flg)
            Case "SELECT"
                If rs.EOF Then
                    DB_箱別基本仕様2 = False
                    Exit Function
                End If
                Call FirstYoso()
                '寸法 0 のクリア
                If H_D(0) = "0" Then H_D(0) = ""
                If H_H(0) = "0" Then H_H(0) = ""
                If H_W(0) = "0" Then H_W(0) = ""
            Case "CHECK"
                If rs.EOF Then
                    DB_箱別基本仕様2 = False
                    Exit Function
                End If
        End Select


        '以前の
        'Dim Sql As String
        'Dim tmp As String

        'DB_箱別基本仕様2 = False
        'If Trim(UCase(KoubanName)) = "" Or Trim(UCase(GunbanName)) = "" Then Exit Function

        'If Trim(H_D(0)) = "" Then H_D(0) = "0"
        'If Trim(H_H(0)) = "" Then H_H(0) = "0"
        'If Trim(H_W(0)) = "" Then H_W(0) = "0"
        'If Trim(H_Jyuryo(0)) = "" Then H_Jyuryo(0) = "0"

        'Select Case UCase(Flg)
        '    Case "SELECT", "CHECK"
        'Sql = "SELECT * FROM 箱別基本仕様 " & vbCrLf & _
        '    "WHERE (工番='" & UCase(KoubanName) & "' " & _
        '        "AND 群番='" & UCase(GunbanName) & "' " & _
        '        "AND 箱番='" & CubNo(CubCnt) & "') "
        'DB_箱別基本仕様2 = OraExeSql(Sql)
        '    Case "INSERT"
        'If Trim(H_HPage(0)) = "" Then H_HPage(0) = "0"
        'If Trim(H_KPage(0)) = "" Then H_KPage(0) = "0"
        'Call InsertPtn2()
        'rs.Update()
        'DB_箱別基本仕様2 = True
        '    Case "UPDATE"
        'rs.Edit()
        'Call UpdatePtn2()
        'rs.Update()
        'DB_箱別基本仕様2 = True
        '    Case "DELETE"
        'rs.Delete()
        'rs.Update()
        'DB_箱別基本仕様2 = True
        'End Select
        '    DB_箱別基本仕様2 = OraExeSql(Sql)

        'Select Case UCase(Flg)
        '    Case "SELECT"
        'If rs.EOF Then
        'DB_箱別基本仕様2 = False
        'Exit Function
        'End If
        'Call FirstYoso()
        '寸法 0 のクリア
        'If H_D(0) = "0" Then H_D(0) = ""
        'If H_H(0) = "0" Then H_H(0) = ""
        'If H_W(0) = "0" Then H_W(0) = ""
        '    Case "CHECK"
        'If rs.EOF Then
        'DB_箱別基本仕様2 = False
        'Exit Function
        'End If
        'End Select

    End Function

    Public Sub InsertPtn2()
        'INSERTなら(DB_箱別基本仕様2より)

        rs.AddNew()
        rs.fields("工番").Value = UCase(KoubanName)
        rs.fields("群番").Value = UCase(GunbanName)
        rs.fields("箱番").Value = CubNo(CubCnt)
        rs.fields("箱連番").Value = CubCnt
        rs.fields("配列ページ番号").Value = H_HPage(0)
        rs.fields("基礎ページ番号").Value = H_KPage(0)
        rs.fields("平面ページ番号").Value = 0
        rs.fields("側面ページ番号").Value = 0
        rs.fields("盤面ページ番号").Value = 0
        rs.fields("納入外フラグ").Value = FunExtFlg(ExtCubNo, CubNo(CubCnt))
        rs.fields("基礎ベースフラグ").Value = FunExtFlg(BaseCubNo, CubNo(CubCnt))
        rs.fields("周波数").Value = H_Hz(0)
        rs.fields("保護構造").Value = FunCvtJyotai(H_Jyotai(0), 0)
        rs.fields("側面図図番").Value = H_DRZuban(0)
        rs.fields("製作図図番").Value = H_DoorZuban(0)
        rs.fields("標準盤コード").Value = ""
        rs.fields("外形寸法D").Value = H_D(0)
        rs.fields("外形寸法H").Value = H_H(0)
        rs.fields("外形寸法W").Value = H_W(0)
        rs.fields("絶縁階級").Value = H_Zetuen(0)
        rs.fields("絶縁規格").Value = H_Kata1(0)
        rs.fields("規格番号").Value = H_Kata2(0)
        rs.fields("定格電圧").Value = H_DenAtu(0)
        rs.fields("閉鎖箱保護等級").Value = H_Hogo1(0)
        rs.fields("仕切板保護等級").Value = H_Hogo2(0)
        rs.fields("定格銘板").Value = FunCvtTNP(H_TNP(0), 0)
        rs.fields("定格銘板規格").Value = ""
        rs.fields("ブロックSKコード").Value = ""
        rs.fields("NP1").Value = H_NP1(0)
        rs.fields("NP2").Value = H_NP2(0)
        rs.fields("NP3").Value = H_NP3(0)
        rs.fields("NP4").Value = H_NP4(0)
        rs.fields("枠形式").Value = FunCvtWakuType(H_WakuType(0), 0)
        rs.fields("把手回転方向").Value = FunCvtTotte(H_Totte(0), 0)
        rs.fields("把手取付位置").Value = ""
        rs.fields("主ケーブル穴仕様").Value = ""
        rs.fields("扉開放角度").Value = FunCvtDoorOpen(H_DoorOpen(0), 0)
        rs.fields("概略重量").Value = H_Jyuryo(0)
        rs.fields("商用周波").Value = H_PowerFreq(0)
        rs.fields("雷インパルス").Value = H_Impulse(0)


        '以前の
        'rs.AddNew()
        'rs.fields("工番").Value = UCase(KoubanName)
        'rs.fields("群番").Value = UCase(GunbanName)
        'rs.fields("箱番").Value = CubNo(CubCnt)
        'rs.fields("箱連番").Value = CubCnt
        'rs.fields("配列ページ番号").Value = H_HPage(0)
        'rs.fields("基礎ページ番号").Value = H_KPage(0)
        'rs.fields("平面ページ番号").Value = 0
        'rs.fields("側面ページ番号").Value = 0
        'rs.fields("盤面ページ番号").Value = 0
        'rs.fields("納入外フラグ").Value = FunExtFlg(ExtCubNo, CubNo(CubCnt))
        'rs.fields("基礎ベースフラグ").Value = FunExtFlg(BaseCubNo, CubNo(CubCnt))
        'rs.fields("周波数").Value = H_Hz(0)
        'rs.fields("保護構造").Value = FunCvtJyotai(H_Jyotai(0), 0)
        'rs.fields("側面図図番").Value = H_DRZuban(0)
        'rs.fields("製作図図番").Value = H_DoorZuban(0)
        'rs.fields("標準盤コード").Value = ""
        'rs.fields("外形寸法D").Value = H_D(0)
        'rs.fields("外形寸法H").Value = H_H(0)
        'rs.fields("外形寸法W").Value = H_W(0)
        'rs.fields("絶縁階級").Value = H_Zetuen(0)
        'rs.fields("絶縁規格").Value = H_Kata1(0)
        'rs.fields("規格番号").Value = H_Kata2(0)
        'rs.fields("定格電圧").Value = H_DenAtu(0)
        'rs.fields("閉鎖箱保護等級").Value = H_Hogo1(0)
        'rs.fields("仕切板保護等級").Value = H_Hogo2(0)
        'rs.fields("定格銘板").Value = FunCvtTNP(H_TNP(0), 0)
        'rs.fields("定格銘板規格").Value = ""
        'rs.fields("ブロックSKコード").Value = ""
        'rs.fields("NP1").Value = H_NP1(0)
        'rs.fields("NP2").Value = H_NP2(0)
        'rs.fields("NP3").Value = H_NP3(0)
        'rs.fields("NP4").Value = H_NP4(0)
        'rs.fields("枠形式").Value = FunCvtWakuType(H_WakuType(0), 0)
        'rs.fields("把手回転方向").Value = FunCvtTotte(H_Totte(0), 0)
        'rs.fields("把手取付位置").Value = ""
        'rs.fields("主ケーブル穴仕様").Value = ""
        'rs.fields("扉開放角度").Value = FunCvtDoorOpen(H_DoorOpen(0), 0)
        'rs.fields("概略重量").Value = H_Jyuryo(0)
        'rs.fields("商用周波").Value = H_PowerFreq(0)
        'rs.fields("雷インパルス").Value = H_Impulse(0)
    End Sub

    Public Sub UpdatePtn2()
        'UPDATEなら(DB_箱別基本仕様2より)

        rs.fields("周波数").Value = H_Hz(0)
        rs.fields("保護構造").Value = FunCvtJyotai(H_Jyotai(0), 0)
        rs.fields("側面図図番").Value = H_DRZuban(0)
        rs.fields("製作図図番").Value = H_DoorZuban(0)
        rs.fields("標準盤コード").Value = ""
        rs.fields("外形寸法D").Value = H_D(0)
        rs.fields("外形寸法H").Value = H_H(0)
        rs.fields("外形寸法W").Value = H_W(0)
        rs.fields("絶縁階級").Value = H_Zetuen(0)
        rs.fields("絶縁規格").Value = H_Kata1(0)
        rs.fields("規格番号").Value = H_Kata2(0)
        rs.fields("定格電圧").Value = H_DenAtu(0)
        rs.fields("閉鎖箱保護等級").Value = H_Hogo1(0)
        rs.fields("仕切板保護等級").Value = H_Hogo2(0)
        rs.fields("定格銘板").Value = FunCvtTNP(H_TNP(0), 0)
        rs.fields("定格銘板規格").Value = ""
        rs.fields("ブロックSKコード").Value = ""
        rs.fields("NP1").Value = H_NP1(0)
        rs.fields("NP2").Value = H_NP2(0)
        rs.fields("NP3").Value = H_NP3(0)
        rs.fields("NP4").Value = H_NP4(0)
        rs.fields("枠形式").Value = FunCvtWakuType(H_WakuType(0), 0)
        rs.fields("把手回転方向").Value = FunCvtTotte(H_Totte(0), 0)
        rs.fields("把手取付位置").Value = ""
        rs.fields("主ケーブル穴仕様").Value = ""
        rs.fields("扉開放角度").Value = FunCvtDoorOpen(H_DoorOpen(0), 0)
        rs.fields("概略重量").Value = H_Jyuryo(0)
        rs.fields("商用周波").Value = H_PowerFreq(0)
        rs.fields("雷インパルス").Value = H_Impulse(0)

        '以前の
        'rs.fields("周波数").Value = H_Hz(0)
        'rs.fields("保護構造").Value = FunCvtJyotai(H_Jyotai(0), 0)
        'rs.fields("側面図図番").Value = H_DRZuban(0)
        'rs.fields("製作図図番").Value = H_DoorZuban(0)
        'rs.fields("標準盤コード").Value = ""
        'rs.fields("外形寸法D").Value = H_D(0)
        'rs.fields("外形寸法H").Value = H_H(0)
        'rs.fields("外形寸法W").Value = H_W(0)
        'rs.fields("絶縁階級").Value = H_Zetuen(0)
        'rs.fields("絶縁規格").Value = H_Kata1(0)
        'rs.fields("規格番号").Value = H_Kata2(0)
        'rs.fields("定格電圧").Value = H_DenAtu(0)
        'rs.fields("閉鎖箱保護等級").Value = H_Hogo1(0)
        'rs.fields("仕切板保護等級").Value = H_Hogo2(0)
        'rs.fields("定格銘板").Value = FunCvtTNP(H_TNP(0), 0)
        'rs.fields("定格銘板規格").Value = ""
        'rs.fields("ブロックSKコード").Value = ""
        'rs.fields("NP1").Value = H_NP1(0)
        'rs.fields("NP2").Value = H_NP2(0)
        'rs.fields("NP3").Value = H_NP3(0)
        'rs.fields("NP4").Value = H_NP4(0)
        'rs.fields("枠形式").Value = FunCvtWakuType(H_WakuType(0), 0)
        'rs.fields("把手回転方向").Value = FunCvtTotte(H_Totte(0), 0)
        'rs.fields("把手取付位置").Value = ""
        'rs.fields("主ケーブル穴仕様").Value = ""
        'rs.fields("扉開放角度").Value = FunCvtDoorOpen(H_DoorOpen(0), 0)
        'rs.fields("概略重量").Value = H_Jyuryo(0)
        'rs.fields("商用周波").Value = H_PowerFreq(0)
        'rs.fields("雷インパルス").Value = H_Impulse(0)
    End Sub

    Public Sub FirstYoso()
        '(DB_箱別基本仕様2より)
        Dim tmp As String

        H_CubNo(0) = CubNo(CubCnt)
        H_HPage(0) = rs.fields("配列ページ番号").Value
        H_KPage(0) = rs.fields("基礎ページ番号").Value
        tmp = FunExtSet("Ext", CubNo(CubCnt), FunNull0(rs.fields("納入外フラグ").Value))
        tmp = FunExtSet("Base", CubNo(CubCnt), FunNull0(rs.fields("基礎ベースフラグ").Value))
        H_Hz(0) = FunNull(rs.fields("周波数").Value)
        H_Jyotai(0) = FunCvtJyotai(FunNull(rs.fields("保護構造").Value), 1)
        H_DRZuban(0) = FunNull(rs.fields("側面図図番").Value)
        H_DoorZuban(0) = FunNull(rs.fields("製作図図番").Value)
        tmp = FunNull(rs.fields("標準盤コード").Value)
        'H_D(0) = FunNull(rs.fields("外形寸法D").Value)
        H_H(0) = FunNull(rs.fields("外形寸法H").Value)
        H_W(0) = FunNull(rs.fields("外形寸法W").Value)
        H_Zetuen(0) = FunNull(rs.fields("絶縁階級").Value)
        H_Kata1(0) = FunNull(rs.fields("絶縁規格").Value)
        H_Kata2(0) = FunNull(rs.fields("規格番号").Value)
        H_DenAtu(0) = FunNull(rs.fields("定格電圧").Value)
        H_Hogo1(0) = FunNull(rs.fields("閉鎖箱保護等級").Value)
        H_Hogo2(0) = FunNull(rs.fields("仕切板保護等級").Value)
        H_TNP(0) = FunCvtTNP(FunNull(rs.fields("定格銘板").Value), 1)
        tmp = FunNull(rs.fields("定格銘板規格").Value)
        tmp = FunNull(rs.fields("ブロックSKコード").Value)
        H_NP1(0) = FunNull(rs.fields("NP1").Value)
        H_NP2(0) = FunNull(rs.fields("NP2").Value)
        H_NP3(0) = FunNull(rs.fields("NP3").Value)
        H_NP4(0) = FunNull(rs.fields("NP4").Value)
        H_WakuType(0) = FunCvtWakuType(FunNull(rs.fields("枠形式").Value), 1)
        H_Totte(0) = FunCvtTotte(FunNull(rs.fields("把手回転方向").Value), 1)
        tmp = FunNull(rs.fields("把手取付位置").Value)
        tmp = FunNull(rs.fields("主ケーブル穴仕様").Value)
        H_DoorOpen(0) = FunCvtDoorOpen(FunNull(rs.fields("扉開放角度").Value), 1)
        H_Jyuryo(0) = FunNull(rs.fields("概略重量").Value)
        H_PowerFreq(0) = FunNull(rs.fields("商用周波").Value)
        H_Impulse(0) = FunNull(rs.fields("雷インパルス").Value)



        'Dim tmp As String

        'H_CubNo(0) = CubNo(CubCnt)
        'H_HPage(0) = rs.fields("配列ページ番号").Value
        'H_KPage(0) = rs.fields("基礎ページ番号").Value
        'tmp = FunExtSet("Ext", CubNo(CubCnt), FunNull0(rs.fields("納入外フラグ").Value))
        'tmp = FunExtSet("Base", CubNo(CubCnt), FunNull0(rs.fields("基礎ベースフラグ").Value))
        'H_Hz(0) = FunNull(rs.fields("周波数").Value)
        'H_Jyotai(0) = FunCvtJyotai(FunNull(rs.fields("保護構造").Value), 1)
        'H_DRZuban(0) = FunNull(rs.fields("側面図図番").Value)
        'H_DoorZuban(0) = FunNull(rs.fields("製作図図番").Value)
        'tmp = FunNull(rs.fields("標準盤コード").Value)
        ''H_D(0) = FunNull(rs.fields("外形寸法D").Value)
        'H_H(0) = FunNull(rs.fields("外形寸法H").Value)
        'H_W(0) = FunNull(rs.fields("外形寸法W").Value)
        'H_Zetuen(0) = FunNull(rs.fields("絶縁階級").Value)
        'H_Kata1(0) = FunNull(rs.fields("絶縁規格").Value)
        'H_Kata2(0) = FunNull(rs.fields("規格番号").Value)
        'H_DenAtu(0) = FunNull(rs.fields("定格電圧").Value)
        'H_Hogo1(0) = FunNull(rs.fields("閉鎖箱保護等級").Value)
        'H_Hogo2(0) = FunNull(rs.fields("仕切板保護等級").Value)
        'H_TNP(0) = FunCvtTNP(FunNull(rs.fields("定格銘板").Value), 1)
        'tmp = FunNull(rs.fields("定格銘板規格").Value)
        'tmp = FunNull(rs.fields("ブロックSKコード").Value)
        'H_NP1(0) = FunNull(rs.fields("NP1").Value)
        'H_NP2(0) = FunNull(rs.fields("NP2").Value)
        'H_NP3(0) = FunNull(rs.fields("NP3").Value)
        'H_NP4(0) = FunNull(rs.fields("NP4").Value)
        'H_WakuType(0) = FunCvtWakuType(FunNull(rs.fields("枠形式").Value), 1)
        'H_Totte(0) = FunCvtTotte(FunNull(rs.fields("把手回転方向").Value), 1)
        'tmp = FunNull(rs.fields("把手取付位置").Value)
        'tmp = FunNull(rs.fields("主ケーブル穴仕様").Value)
        'H_DoorOpen(0) = FunCvtDoorOpen(FunNull(rs.fields("扉開放角度").Value), 1)
        'H_Jyuryo(0) = FunNull(rs.fields("概略重量").Value)
        'H_PowerFreq(0) = FunNull(rs.fields("商用周波").Value)
        'H_Impulse(0) = FunNull(rs.fields("雷インパルス").Value)
    End Sub

    '-----------------------------------------------
    '使用状態の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtJyotai(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtJyotai = ""           '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case H_Jyotai_1
                        FunCvtJyotai = V_H_Jyotai_1
                    Case H_Jyotai_2
                        FunCvtJyotai = V_H_Jyotai_2
                    Case H_Jyotai_3
                        FunCvtJyotai = V_H_Jyotai_3
                    Case H_Jyotai_4
                        FunCvtJyotai = V_H_Jyotai_4
                    Case H_Jyotai_5
                        FunCvtJyotai = V_H_Jyotai_5
                    Case H_Jyotai_6
                        FunCvtJyotai = V_H_Jyotai_6
                    Case H_Jyotai_7
                        FunCvtJyotai = V_H_Jyotai_7
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case V_H_Jyotai_1
                        FunCvtJyotai = H_Jyotai_1
                    Case V_H_Jyotai_2
                        FunCvtJyotai = H_Jyotai_2
                    Case V_H_Jyotai_3
                        FunCvtJyotai = H_Jyotai_3
                    Case V_H_Jyotai_4
                        FunCvtJyotai = H_Jyotai_4
                    Case V_H_Jyotai_5
                        FunCvtJyotai = H_Jyotai_5
                    Case V_H_Jyotai_6
                        FunCvtJyotai = H_Jyotai_6
                    Case V_H_Jyotai_7
                        FunCvtJyotai = H_Jyotai_7
                End Select
            Case 2  '図面属性 → コード
                If InStr(tmp, D_H_Jyotai_1) > 0 Then
                    FunCvtJyotai = V_H_Jyotai_1
                End If
                If InStr(tmp, D_H_Jyotai_2) > 0 Then
                    FunCvtJyotai = V_H_Jyotai_2
                End If
                If InStr(tmp, D_H_Jyotai_3) > 0 Then
                    FunCvtJyotai = V_H_Jyotai_3
                End If
                If InStr(tmp, D_H_Jyotai_4) > 0 Then
                    FunCvtJyotai = V_H_Jyotai_4
                End If
                If InStr(tmp, D_H_Jyotai_5) > 0 Then
                    FunCvtJyotai = V_H_Jyotai_5
                End If
                If InStr(tmp, D_H_Jyotai_6) > 0 Then
                    FunCvtJyotai = V_H_Jyotai_6
                End If
                If InStr(tmp, D_H_Jyotai_7) > 0 Then
                    FunCvtJyotai = V_H_Jyotai_7
                End If
        End Select
    End Function
    '-----------------------------------------------
    '枠形式の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtWakuType(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtWakuType = ""         '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case H_WakuType_1
                        FunCvtWakuType = V_H_WakuType_1
                    Case H_WakuType_2
                        FunCvtWakuType = V_H_WakuType_2
                    Case H_WakuType_3
                        FunCvtWakuType = V_H_WakuType_3
                    Case H_WakuType_4
                        FunCvtWakuType = V_H_WakuType_4
                    Case H_WakuType_5
                        FunCvtWakuType = V_H_WakuType_5
                    Case H_WakuType_6
                        FunCvtWakuType = V_H_WakuType_6
                    Case H_WakuType_7
                        FunCvtWakuType = V_H_WakuType_7
                    Case H_WakuType_8
                        FunCvtWakuType = V_H_WakuType_8
                    Case H_WakuType_9
                        FunCvtWakuType = V_H_WakuType_9
                    Case H_WakuType_10
                        FunCvtWakuType = V_H_WakuType_10
                    Case H_WakuType_11
                        FunCvtWakuType = V_H_WakuType_11
                    Case H_WakuType_12
                        FunCvtWakuType = V_H_WakuType_12
                    Case H_WakuType_13
                        FunCvtWakuType = V_H_WakuType_13
                    Case H_WakuType_14
                        FunCvtWakuType = V_H_WakuType_14
                    Case H_WakuType_15
                        FunCvtWakuType = V_H_WakuType_15
                    Case H_WakuType_16
                        FunCvtWakuType = V_H_WakuType_16
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case V_H_WakuType_1
                        FunCvtWakuType = H_WakuType_1
                    Case V_H_WakuType_2
                        FunCvtWakuType = H_WakuType_2
                    Case V_H_WakuType_3
                        FunCvtWakuType = H_WakuType_3
                    Case V_H_WakuType_4
                        FunCvtWakuType = H_WakuType_4
                    Case V_H_WakuType_5
                        FunCvtWakuType = H_WakuType_5
                    Case V_H_WakuType_6
                        FunCvtWakuType = H_WakuType_6
                    Case V_H_WakuType_7
                        FunCvtWakuType = H_WakuType_7
                    Case V_H_WakuType_8
                        FunCvtWakuType = H_WakuType_8
                    Case V_H_WakuType_9
                        FunCvtWakuType = H_WakuType_9
                    Case V_H_WakuType_10
                        FunCvtWakuType = H_WakuType_10
                    Case V_H_WakuType_11
                        FunCvtWakuType = H_WakuType_11
                    Case V_H_WakuType_12
                        FunCvtWakuType = H_WakuType_12
                    Case V_H_WakuType_13
                        FunCvtWakuType = H_WakuType_13
                    Case V_H_WakuType_14
                        FunCvtWakuType = H_WakuType_14
                    Case V_H_WakuType_15
                        FunCvtWakuType = H_WakuType_15
                    Case V_H_WakuType_16
                        FunCvtWakuType = H_WakuType_16
                End Select
        End Select
    End Function
    '-----------------------------------------------
    '把手の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtTotte(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtTotte = ""            '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case H_Totte_1
                        FunCvtTotte = V_H_Totte_1
                    Case H_Totte_2
                        FunCvtTotte = V_H_Totte_2
                    Case H_Totte_3
                        FunCvtTotte = V_H_Totte_3
                    Case H_Totte_4
                        FunCvtTotte = V_H_Totte_4
                    Case H_Totte_5
                        FunCvtTotte = V_H_Totte_5
                    Case H_Totte_6
                        FunCvtTotte = V_H_Totte_6
                    Case H_Totte_7
                        FunCvtTotte = V_H_Totte_7
                    Case H_Totte_8
                        FunCvtTotte = V_H_Totte_8
                    Case H_Totte_9
                        FunCvtTotte = V_H_Totte_9
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case V_H_Totte_1
                        FunCvtTotte = H_Totte_1
                    Case V_H_Totte_2
                        FunCvtTotte = H_Totte_2
                    Case V_H_Totte_3
                        FunCvtTotte = H_Totte_3
                    Case V_H_Totte_4
                        FunCvtTotte = H_Totte_4
                    Case V_H_Totte_5
                        FunCvtTotte = H_Totte_5
                    Case V_H_Totte_6
                        FunCvtTotte = H_Totte_6
                    Case V_H_Totte_7
                        FunCvtTotte = H_Totte_7
                    Case V_H_Totte_8
                        FunCvtTotte = H_Totte_8
                    Case V_H_Totte_9
                        FunCvtTotte = H_Totte_9
                End Select
        End Select
    End Function


    '
    'ベース分割データの編集
    '
    Function StrBaseBunkatu(ByVal Flg As Integer, ByVal BASE As String) As String
        Dim J As Integer, p1 As Integer
        Dim tmp As String
        StrBaseBunkatu = ""             '初期値

        Select Case Flg
            Case 1  '配列から一文字列に合成
                tmp = Trim(BaseBunkatu(0))
                J = 1
                Do Until Trim(BaseBunkatu(J)) = ""
                    tmp = tmp & "," & Trim(BaseBunkatu(J))
                    J = J + 1
                Loop
                StrBaseBunkatu = tmp
            Case 0  '一文字列を配列に分解
                tmp = BASE
                J = 0
                p1 = InStr(tmp, ",")
                Do Until p1 = 0
                    BaseBunkatu(J) = Left(tmp, p1 - 1)
                    J = J + 1
                    tmp = Right(tmp, Len(tmp) - p1)
                    p1 = InStr(tmp, ",")
                Loop
                BaseBunkatu(J) = tmp
                BaseBunkatu(J + 1) = ""
        End Select
    End Function

    '-----------------------------------------------
    '側面化粧板の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtKeshoType(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtKeshoType = ""            '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case KeshoType_1
                        FunCvtKeshoType = V_KeshoType_1
                    Case KeshoType_2
                        FunCvtKeshoType = V_KeshoType_2
                    Case KeshoType_3
                        FunCvtKeshoType = V_KeshoType_3
                    Case KeshoType_4
                        FunCvtKeshoType = V_KeshoType_4
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case V_KeshoType_1
                        FunCvtKeshoType = KeshoType_1
                    Case V_KeshoType_2
                        FunCvtKeshoType = KeshoType_2
                    Case V_KeshoType_3
                        FunCvtKeshoType = KeshoType_3
                    Case V_KeshoType_4
                        FunCvtKeshoType = KeshoType_4
                End Select
        End Select
    End Function
    '-----------------------------------------------
    '制御ケーブル穴仕様の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtSeigyoAna(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtSeigyoAna = ""            '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case SeigyoAna_1
                        FunCvtSeigyoAna = V_SeigyoAna_1
                    Case SeigyoAna_2
                        FunCvtSeigyoAna = V_SeigyoAna_2
                    Case SeigyoAna_3
                        FunCvtSeigyoAna = V_SeigyoAna_3
                    Case SeigyoAna_4
                        FunCvtSeigyoAna = V_SeigyoAna_4
                    Case SeigyoAna_5
                        FunCvtSeigyoAna = V_SeigyoAna_5
                    Case SeigyoAna_6
                        FunCvtSeigyoAna = V_SeigyoAna_6
                    Case SeigyoAna_7
                        FunCvtSeigyoAna = V_SeigyoAna_7
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case V_SeigyoAna_1
                        FunCvtSeigyoAna = SeigyoAna_1
                    Case V_SeigyoAna_2
                        FunCvtSeigyoAna = SeigyoAna_2
                    Case V_SeigyoAna_3
                        FunCvtSeigyoAna = SeigyoAna_3
                    Case V_SeigyoAna_4
                        FunCvtSeigyoAna = SeigyoAna_4
                    Case V_SeigyoAna_5
                        FunCvtSeigyoAna = SeigyoAna_5
                    Case V_SeigyoAna_6
                        FunCvtSeigyoAna = SeigyoAna_6
                    Case V_SeigyoAna_7
                        FunCvtSeigyoAna = SeigyoAna_7
                End Select
        End Select
    End Function

    '
    '   SQL 文を実行して結果をレコードセットに保存する
    '
    Public Function OraExeSql(ByVal Sql As String) As Boolean
        Dim stat As Long

        On Error GoTo ErrRtn

        stat = OraClsRs()
        Console.WriteLine(Sql)
        GoTo SQL_EXE

ExtFun:
        Exit Function
        'SQL 実行サブ
SQL_EXE:
        OraExeSql = False

        'RDOの場合
        'qy.Sql = Sql
        'Set rs = qy.OpenResultset(rdOpenKeyset, rdConcurBatch)

        'oo4oの場合
        Select Case UCase(Left(Sql, 6))
            Case "SELECT"
                rs = qy.CreateDynaset(Sql, 0&)
                Console.WriteLine(rs.RecordCount)
                If BanCnt2 = 0 And DBHairetu = True Then
                    LoadCnt = rs.RecordCount - 1        'ループ回数決定(箱数-1)
                End If

            Case "CHECK"
                rs = qy.CreateDynaset(Sql, 0&)
                Console.WriteLine(rs.RecordCount)
            Case Else
                qy.ExecuteSQL(Sql)
        End Select
        OraExeSql = True
        Exit Function

        'DB に接続し直す
ReConnect:
        stat = OraCnn("orcl8", "nps", "nps")
        GoTo SQL_EXE
        Exit Function

ErrRtn:
        Select Case Err.Number
            Case 40074, 91
                Resume ReConnect
                stat = MsgBox("%SQL実行時ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
                            vbOKOnly + vbCritical, _
                            "Oracleデータベースアクセスエラー")
            Case Else
                stat = MsgBox("SQL実行ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
                            vbOKOnly + vbCritical, _
                            "Oracleデータベースアクセスエラー")
        End Select
        Resume ExtFun



        '↓以前の
        '        Dim stat As Long

        '        On Error GoTo ErrRtn

        '        stat = OraClsRs()
        '        Debug.Print(Sql)
        '        GoTo SQL_EXE

        'ExtFun:
        '        Exit Function
        '        'SQL 実行サブ
        'SQL_EXE:
        '        OraExeSql = False

        '        'RDOの場合
        '        'qy.Sql = Sql
        '        'Set rs = qy.OpenResultset(rdOpenKeyset, rdConcurBatch)

        '        'oo4oの場合
        '        Select Case UCase(Left(Sql, 6))
        '            Case "SELECT", "CHECK"
        '                rs = qy.CreateDynaset(Sql, 0&)
        '            Case Else
        '                qy.ExecuteSQL(Sql)
        '        End Select
        '        OraExeSql = True
        '        'Return

        '        'DB に接続し直す
        'ReConnect:
        '        stat = OraCnn("orcl8", "swg", "swg")
        '        GoTo SQL_EXE
        '        Exit Function

        'ErrRtn:
        '        Select Case Err.Number
        '            Case 40074, 91
        '                Resume ReConnect
        '                stat = MsgBox("%SQL実行時ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
        '                            vbOKOnly + vbCritical, _
        '                            "Oracleデータベースアクセスエラー")
        '            Case Else
        '                stat = MsgBox("SQL実行ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
        '                            vbOKOnly + vbCritical, _
        '                            "Oracleデータベースアクセスエラー")
        '        End Select
        '        Resume ExtFun
    End Function

    '-----------------------------------------------
    '目的の箱が納入外（納入基礎ベース）かのフラグを返す
    '-----------------------------------------------
    Function FunExtFlg(ByVal Src() As String, ByVal Tgt As String) As Integer
        Dim J As Integer

        FunExtFlg = 0
        J = 0
        Do Until Trim(Src(J)) = "" Or FunExtFlg = 1
            If Trim(Src(J)) = Trim(Tgt) Then FunExtFlg = 1
            J = J + 1
        Loop

    End Function
    '-----------------------------------------------
    '目的の箱を納入外（納入基礎ベース）にセットする
    '-----------------------------------------------
    Function FunExtSet(ByVal ExtType As String, ByVal Tgt As String, ByVal Flg As Integer) As Integer
        Dim J As Integer
        Dim Find As Integer

        FunExtSet = 0           '初期値
        Find = -1
        J = 0
        Select Case ExtType
            Case "Ext"  '納入外
                Do Until Trim(ExtCubNo(J)) = "" Or Find > -1
                    If Trim(ExtCubNo(J)) = Trim(Tgt) Then Find = J
                    J = J + 1
                Loop
                If Flg = 1 And Find = -1 Then    '追加
                    ExtCubNo(J) = Trim(Tgt)
                End If
                If Flg = 0 And Find > -1 Then    '消去
                    J = Find
                    Do Until Trim(ExtCubNo(J)) = ""
                        ExtCubNo(J) = Trim(ExtCubNo(J + 1))
                        J = J + 1
                    Loop
                End If
            Case "Base" '納入基礎ベース
                Do Until Trim(BaseCubNo(J)) = "" Or Find > -1
                    If Trim(BaseCubNo(J)) = Trim(Tgt) Then Find = J
                    J = J + 1
                Loop
                If Flg = 1 And Find = -1 Then    '追加
                    BaseCubNo(J) = Trim(Tgt)
                End If
                If Flg = 0 And Find > -1 Then    '消去
                    J = Find
                    Do Until Trim(BaseCubNo(J)) = ""
                        BaseCubNo(J) = Trim(BaseCubNo(J + 1))
                        J = J + 1
                    Loop
                End If
        End Select

    End Function

    '-----------------------------------------------
    '定格銘板規格の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtTNP(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtTNP = ""              '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case H_TNP_1
                        FunCvtTNP = V_H_TNP_1
                    Case H_TNP_2
                        FunCvtTNP = V_H_TNP_2
                    Case H_TNP_3
                        FunCvtTNP = V_H_TNP_3
                    Case H_TNP_4
                        FunCvtTNP = V_H_TNP_4
                    Case H_TNP_5
                        FunCvtTNP = V_H_TNP_5
                    Case H_TNP_6
                        FunCvtTNP = V_H_TNP_6
                    Case H_TNP_7
                        FunCvtTNP = V_H_TNP_7
                    Case H_TNP_8
                        FunCvtTNP = V_H_TNP_8
                    Case H_TNP_9
                        FunCvtTNP = V_H_TNP_9
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case V_H_TNP_1
                        FunCvtTNP = H_TNP_1
                    Case V_H_TNP_2
                        FunCvtTNP = H_TNP_2
                    Case V_H_TNP_3
                        FunCvtTNP = H_TNP_3
                    Case V_H_TNP_4
                        FunCvtTNP = H_TNP_4
                    Case V_H_TNP_5
                        FunCvtTNP = H_TNP_5
                    Case V_H_TNP_6
                        FunCvtTNP = H_TNP_6
                    Case V_H_TNP_7
                        FunCvtTNP = H_TNP_7
                    Case V_H_TNP_8
                        FunCvtTNP = H_TNP_8
                    Case V_H_TNP_9
                        FunCvtTNP = H_TNP_9
                End Select
            Case 2  '表記 → コード
                Select Case tmp
                    Case D_H_TNP_1
                        FunCvtTNP = V_H_TNP_1
                    Case D_H_TNP_2
                        FunCvtTNP = V_H_TNP_2
                    Case D_H_TNP_3
                        FunCvtTNP = V_H_TNP_3
                    Case D_H_TNP_4
                        FunCvtTNP = V_H_TNP_4
                    Case D_H_TNP_5
                        FunCvtTNP = V_H_TNP_5
                    Case D_H_TNP_6
                        FunCvtTNP = V_H_TNP_6
                    Case D_H_TNP_7
                        FunCvtTNP = V_H_TNP_7
                    Case D_H_TNP_8
                        FunCvtTNP = V_H_TNP_8
                    Case D_H_TNP_9
                        FunCvtTNP = V_H_TNP_9
                End Select
        End Select
    End Function

    '-----------------------------------------------
    '扉開放角度の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtDoorOpen(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtDoorOpen = ""             '初期値
        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case H_DoorOpen_1
                        FunCvtDoorOpen = V_H_DoorOpen_1
                    Case H_DoorOpen_2
                        FunCvtDoorOpen = V_H_DoorOpen_2
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case V_H_DoorOpen_1
                        FunCvtDoorOpen = H_DoorOpen_1
                    Case V_H_DoorOpen_2
                        FunCvtDoorOpen = H_DoorOpen_2
                End Select
            Case 2  '図面属性 → コード
                Select Case tmp
                    Case D_H_DoorOpen_1, D_H_DoorOpen_3
                        FunCvtDoorOpen = V_H_DoorOpen_1
                    Case Else
                        FunCvtDoorOpen = V_H_DoorOpen_2
                End Select
        End Select
    End Function

    '-----------------------------------------------
    '屋内外の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtInOut(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtInOut = ""            '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case "屋内"
                        FunCvtInOut = "IN"
                    Case "屋外"
                        FunCvtInOut = "OUT"
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case "IN"
                        FunCvtInOut = "屋内"
                    Case "OUT"
                        FunCvtInOut = "屋外"
                End Select
        End Select
    End Function
    '-----------------------------------------------
    '英文・和文の表記とコードを変換して返す
    '-----------------------------------------------
    Function FunCvtZumen(ByVal tmp As String, ByVal Flg As Integer) As String
        FunCvtZumen = ""            '初期値

        Select Case Flg
            Case 0  '表記 → コード
                Select Case tmp
                    Case "和文"
                        FunCvtZumen = "J"
                    Case "英文"
                        FunCvtZumen = "E"
                End Select
            Case 1  'コード → 表記
                Select Case tmp
                    Case "J"
                        FunCvtZumen = "和文"
                    Case "E"
                        FunCvtZumen = "英文"
                End Select
        End Select
    End Function


    '
    'Null値の場合は文字列の""を返す
    '
    Function FunNull(ByVal tmp) As String
        'If IsNull(tmp) Then
        If IsDBNull(tmp) Then
            FunNull = ""
        Else
            FunNull = Trim(tmp)
        End If
    End Function
    '
    '""の場合は文字列の"0"を返す
    '
    Function FunNull0(ByVal tmpdat) As String
        'If IsNull(tmp) Then
        '    FunNull0 = "0"
        'ElseIf tmp = "" Then ←2000.7.10 tmp="1"のとき何故かｴﾗｰになったのでﾌﾟﾛｸﾞﾗﾑを下のように変えてみた
        '    FunNull0 = "0"
        'Else
        '    FunNull0 = Trim(tmp)
        'End If

        'If IsNull(tmpdat) Then
        If IsDBNull(tmpdat) Then
            FunNull0 = "0"
        Else
            If StrComp(tmpdat, "") = 0 Then
                FunNull0 = "0"
            Else
                FunNull0 = Trim(tmpdat)
            End If
        End If
    End Function

    '
    '数値 0 の場合は文字列の""
    '
    Function FunZero2Null(ByVal tmp) As String
        If tmp = 0 Then
            FunZero2Null = ""
        Else
            FunZero2Null = tmp
        End If
    End Function


    '
    '   レコードセットを閉じる
    '
    Public Function OraClsRs() As Boolean
        On Error GoTo ErrRtn

        OraClsRs = False
        rs.Close()
        rs = Nothing
        OraClsRs = True
ExtFun:
        Exit Function
ErrRtn:
        Resume Next
    End Function

    '
    'ﾃﾞｰﾀｺﾋﾟｰ元工番のﾁｪｯｸ
    '
    Public Function CpyKbnChk(ByVal OldKbn As String, ByVal OldGbn As String)
        'ｺﾋﾟｰ元工番        ｺﾋﾟｰ元群番
        Dim Kbn As String   '工番(ﾒﾓ)
        Dim Gbn As String   '群番(ﾒﾓ)
        Dim Ans As Integer  'ﾒｯｾｰｼﾞﾎﾞｯｸｽの返値

        CpyKbnChk = True
        'stat = DB_工番("check")                         'ｺﾋﾟｰ先工番のﾃﾞｰﾀが既にあるかﾁｪｯｸ
        If Not rs.EOF Then                              '警告ﾒｯｾｰｼﾞを表示し、ｺﾋﾟｰの必要が
            Ans = MsgBox("ｺﾋﾟｰ先ﾃﾞｰﾀは既に存在します。" + vbCrLf + _
                         "ｺﾋﾟｰを実行するとﾃﾞｰﾀは上書きされます。", vbOKCancel + vbExclamation, _
                         "ﾃﾞｰﾀ上書き確認")              'なければ終了
            If Ans = vbCancel Then
                CpyKbnChk = False
                Exit Function
            End If
        End If
        Kbn = KoubanName                                '作業中の工番を覚えておく
        Gbn = GunbanName                                '作業中の群番を覚えておく

        'frmKouban.Caption = "ｺﾋﾟｰ元の工番・群番指定"     '工番入力画面のﾀｲﾄﾙを変える
        'frmKouban.Show(1)                                '工番入力画面表示

        If OkCancel = False Then                        'ｷｬﾝｾﾙを選択されれば終了
            CpyKbnChk = False
            Exit Function
        End If
        OldKbn = KoubanName                             'ｺﾋﾟｰ元の工番を取得
        OldGbn = GunbanName                             'ｺﾋﾟｰ元の群番を取得
        If Kbn = OldKbn And Gbn = OldGbn Then           '工番・群番が作業中のものの時は
            MsgBox("工番・群番が作業中のものと同じです") '警告ﾒｯｾｰｼﾞを表示し、終了
            CpyKbnChk = False
            Exit Function
        End If
        'stat = DB_工番("check")                         'ｺﾋﾟｰ元工番のﾃﾞｰﾀがあるかﾁｪｯｸ
        If rs.EOF Then                                  '警告ﾒｯｾｰｼﾞを表示し、終了
            MsgBox("ｺﾋﾟｰ元ﾃﾞｰﾀがありません")
            CpyKbnChk = False
        End If
        KoubanName = Kbn                                '作業工番のｾｯﾄ
        GunbanName = Gbn                                '作業群番のｾｯﾄ
    End Function

    '
    ' 配列基礎データコピー(１から２へ）
    '
    Sub DB_Copy配列基礎(ByVal Kbn1 As String, ByVal Gbn1 As String, ByVal Kbn2 As String, ByVal Gbn2 As String)
        Dim Sql As String
        Dim stat2 As Boolean

        '工番テーブル
        Sql = "SELECT * from 工番 " & _
              "WHERE (工番='" & UCase(Kbn1) & "' AND 群番='" & UCase(Gbn1) & "') "
        stat = OraExeSql(Sql)
        If Not rs.EOF Then
            Sql = "SELECT * from 工番 " & _
                  "WHERE (工番='" & UCase(Kbn2) & "' AND 群番='" & UCase(Gbn2) & "') "
            stat2 = OraExeSql2(Sql)
            Call DB_CopyRecord(Kbn2, Gbn2)
        End If

        '配列基礎共通テーブル
        Sql = "SELECT * from 配列基礎共通 " & _
              "WHERE (工番='" & UCase(Kbn1) & "' AND 群番='" & UCase(Gbn1) & "') "
        stat = OraExeSql(Sql)
        If Not rs.EOF Then
            Sql = "SELECT * from 配列基礎共通 " & _
                  "WHERE (工番='" & UCase(Kbn2) & "' AND 群番='" & UCase(Gbn2) & "') "
            stat2 = OraExeSql2(Sql)
            Call DB_CopyRecord(Kbn2, Gbn2)
        End If



        '基礎図箱別テーブル
        Sql = "SELECT * from 箱別基本仕様 " & _
              "WHERE (工番='" & UCase(Kbn1) & "' AND 群番='" & UCase(Gbn1) & "') "
        stat = OraExeSql(Sql)
        If Not rs.EOF Then
            Do Until rs.EOF
                Sql = "SELECT * from 基礎図箱別 " & _
                      "WHERE (工番='" & UCase(Kbn2) & "' " & _
                      "AND 群番='" & UCase(Gbn2) & "' " & _
                      "AND 箱番='" & rs.fields("箱番").Value & "') "
                stat2 = OraExeSql2(Sql)
                Call DB_CopyRecord(Kbn2, Gbn2)
                rs.MoveNext()
            Loop
        End If


        '箱別基本仕様テーブル
        'Sql = "SELECT * from 箱別基本仕様 " & _
        '      "WHERE (工番='" & UCase(Kbn1) & "' AND 群番='" & UCase(Gbn1) & "') "
        'stat = OraExeSql(Sql)
        'If Not rs.EOF Then
        '    Do Until rs.EOF
        '        Sql = "SELECT * from 箱別基本仕様 " & _
        '              "WHERE (工番='" & UCase(Kbn2) & "' " & _
        '              "AND 群番='" & UCase(Gbn2) & "' " & _
        '              "AND 箱番='" & rs.fields("箱番").Value & "') "
        '        stat2 = OraExeSql2(Sql)
        '        Call DB_CopyRecord(Kbn2, Gbn2)
        '        rs.MoveNext()
        '    Loop
        'End If

    End Sub

    '
    '   SQL 文を実行して結果をレコードセット２に保存する
    '
    Public Function OraExeSql2(ByVal Sql As String) As Boolean
        Dim stat As Long
        Dim OES2 As Boolean
        OraExeSql2 = Nothing            '初期値

        On Error GoTo ErrRtn

        stat = OraClsRs2()
        Debug.Print(Sql)

        Call SQL_EXE(Sql, OES2)

ExtFun:
        Exit Function

        'DB に接続し直す
ReConnect:
        stat = OraCnn(DB_HostStr, DB_UID, DB_PWD)
        Call SQL_EXE(Sql, OES2)
        Exit Function

ErrRtn:
        Select Case Err.Number
            Case 40074
                Resume ReConnect
                '            stat = MsgBox("%SQL実行時ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
                '        vbOKOnly + vbCritical, _
                '        "Oracleデータベースアクセスエラー")
            Case Else
                stat = MsgBox("SQL実行ｴﾗｰ:'" & Err.Number & "' - " & Err.Description, _
                            vbOKOnly + vbCritical, _
                            "Oracleデータベースアクセスエラー")
        End Select
        Resume ExtFun
    End Function

    Public Sub SQL_EXE(ByVal Sql As String, ByVal OES2 As Boolean)
        'SQL 実行サブ
        OES2 = False


        'RDOの場合
        'qy.Sql = Sql
        'Set rs2 = qy.OpenResultset(rdOpenKeyset, rdConcurBatch)

        'oo4oの場合
        rs2 = qy.CreateDynaset(Sql, 0&)

        OES2 = True
    End Sub


    '
    ' レコードセット内の１レコードをコピーする
    '
    Sub DB_CopyRecord(ByVal NewKbn As String, ByVal NewGbn As String)
        Dim i As Integer

        If Not rs2.EOF Then
            rs2.Edit()
        Else
            rs2.AddNew()
        End If
        For i = 0 To rs.fields.Count - 1
            rs2.fields(i).Value = rs.fields(i).Value
        Next i
        rs2.fields("工番").Value = UCase(NewKbn)
        rs2.fields("群番").Value = UCase(NewGbn)
        rs2.Update()
    End Sub

    '
    '   レコードセット２を閉じる
    '
    Public Function OraClsRs2() As Boolean
        On Error GoTo ErrRtn

        OraClsRs2 = False
        rs2.Close()
        rs2 = Nothing
        OraClsRs2 = True
ExtFun:
        Exit Function
ErrRtn:
        Resume Next
    End Function

End Module
