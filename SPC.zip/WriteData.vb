﻿Imports System.IO
Imports System.Text

Module WriteData


#Region "共通ヘッダ作成"


    ''' <summary>
    ''' 共通ヘッダ作成
    ''' </summary>
    ''' <param name="Job">ジョブNo.</param>
    ''' <param name="RecNo" >レコードNo.</param>
    ''' <param name="series" >シリーズNo.</param>
    ''' <remarks></remarks>
    Function CreCommonRec(ByVal Job As String, ByVal RecNo As String, ByVal series As String) As String

        '共通ヘッダ作成
        Dim str As New StringBuilder(18)    '戻り値
        Dim Gunban As String = Dic1("群番").Trim()    '群番
        Dim BanNo As String = Dic1("盤No").Trim()     '盤No

        'ジョブNo.
        str.Append(Job)
        str.Append(CreSpace(ComDic("ジョブNo") - Job.Length, " "))

        'レコードNo.
        str.Append(RecNo)

        'シリーズNo.
        str.Append(CreSpace(ComDic("シリーズNo") - series.Length, "0"))
        str.Append(series)

        '空白
        str.Append(CreSpace(ComDic("空白"), " "))

        '子番号=群番
        str.Append(Gunban)
        str.Append(CreSpace(ComDic("子番号") - Gunban.Length, " "))

        '盤No
        str.Append(BanNo)
        str.Append(CreSpace(ComDic("盤No") - BanNo.Length, " "))

        CreCommonRec = str.ToString
    End Function

#End Region


#Region "Create Record1"

    ''' <summary>
    ''' レコード1作成
    ''' </summary>
    ''' <param name="job">ジョブNo</param>
    ''' <remarks></remarks>
    Public Sub CreRec1(ByVal job As Integer)

        Dim Line As New StringBuilder
        Dim Kouban As String = TrimOrder(Dic1("工番"))        '工番
        Dim Coordcnt As String = CStr(ArrCoord.Count - 1)     '座標数
        Dim spacecnt = RecDic1("座標数") - Coordcnt.Length


        '共通ヘッダ
        Line.Append(CreCommonRec(CStr(job), CStr(1), CStr(1)))

        '前背
        Line.Append(FB)

        'SCT
        Line.Append(CreSpace(RecDic1("SCT"), " "))

        'ゾーン
        Line.Append(CreSpace(RecDic1("ゾーン"), " "))

        '工番
        Line.Append(Kouban)
        Line.Append(RecDic1("工番") - Kouban.Length)
        'データベース用の工番DBKoubanを求める
        DBOrder(Kouban)

        '?
        Line.Append(CreSpace(RecDic1("?"), " "))

        '空白2
        Line.Append(CreSpace(RecDic1("空白2"), " "))

        '客先名

        ConnectODB(DBKouban)
        Line.Append(CustomerName)
        Line.Append(CreSpace(RecDic1("客先名") - LenB(CustomerName), " "))

        '客先コード
        Line.Append(CreSpace(RecDic1("客先コード"), " "))

        '空白3
        Line.Append(CreSpace(RecDic1("空白3"), " "))

        '座標数
        If spacecnt <> 0 Then
            '0つめ
            Line.Append(CreSpace(spacecnt, "0"))
        End If

        Line.Append(Coordcnt)

        'マークバンド
        'マークバンド読み込み
        Dim Mark(,) As String = ReadXLSX(XlsxPath, SheetName)
        MarkBand = MarkParse(Mark, "X14-237")
        Line.Append(MarkBand)

        '空白4
        Line.Append(CreSpace(RecDic1("空白4"), " "))

        '結果をPublicに保存
        Rec1 = Line.ToString

    End Sub

#End Region


#Region "Create Record2"


    Public Sub CreRec2(ByVal job As Integer)
        '切り捨て
        Dim max As Integer = CInt(Math.Floor(CSVDataDic.Count / 3)) - 1
        Dim Line As New StringBuilder



        For i As Integer = 0 To max
            '共通ヘッダ
            Line.Append(CreCommonRec(CStr(job), CStr(2), CStr(i + 1)))

            '前背
            Line.Append(FB)

            'SCT
            Line.Append(CreSpace(CInt(RecDic2("SCT")), " "))

            'ゾーン
            Line.Append(CreSpace(CInt(RecDic2("ゾーン")), " "))

            '空白2
            Line.Append(CreSpace(CInt(RecDic2("空白2")), " "))

            For j As Integer = 1 To 3
                SupRec2(i * 3 + j, Line)
            Next j

            '空白3
            Line.Append(CreSpace(CInt(RecDic2("空白3")), " "))
            '結果をRec2に保存
            Rec2.Add(Line.ToString)
            '初期化
            Line.Clear()
        Next i

        '3で割って余りが存在する場合
        If (ArrCoord.Length - 1) Mod 3 <> 0 Then

            For i As Integer = Rec2.Count * 3 + 1 To CSVDataDic.Count
                If i = Rec2.Count * 3 + 1 Then
                    '共通ヘッダ
                    Line.Append(CreCommonRec(CStr(job), CStr(2), CStr(Rec2.Count)))

                    '前背
                    Line.Append(FB)

                    'SCT
                    Line.Append(CreSpace(CInt(RecDic2("SCT")), " "))

                    'ゾーン
                    Line.Append(CreSpace(CInt(RecDic2("ゾーン")), " "))

                    '空白2
                    Line.Append(CreSpace(CInt(RecDic2("空白2")), " "))
                End If

                SupRec2(i, Line)

            Next

            'データ数が1,2の場合、空白を追加(第1引数が0の場合、CreSpaceは何もせず終了)
            Line.Append(CreSpace(33 * (3 - (CSVDataDic.Count - Rec2.Count * 3)), " "))

            '空白3
            Line.Append(CreSpace(CInt(RecDic2("空白3")), " "))

            Rec2.Add(Line.ToString)
            '初期化
            Line.Clear()
        End If '(ArrCoord.Length - 1) Mod 3 <> 0
    End Sub

    Sub SupRec2(ByVal index As Integer, ByRef Line As StringBuilder)
        Dim coord As String = ""
        Dim data() As String

        coord = ArrCoord(index)
        '0=略称、1=形式、2=端子種類
        data = CSVDataDic(coord)
        '座標名+分割名
        Line.Append(coord)
        '略称
        Line.Append(data(0))
        '空白詰め
        Line.Append(CreSpace(SetDic2("略称") - data(0).Length, " "))

        '形式
        Line.Append(data(1))
        '空白詰め
        Line.Append(CreSpace(SetDic2("形式") - data(1).Length, " "))

        'フレーム
        Line.Append(CreSpace(SetDic2("フレーム"), " "))

        '空白
        Line.Append(CreSpace(SetDic2("空白"), " "))

        '端子種類
        Line.Append(data(2))
        '空白詰め
        Line.Append(CreSpace(SetDic2("端子種類") - data(2).Length, " "))
    End Sub

#End Region


#Region "Create Record3"


    Sub CreRec3(ByVal job As Integer)



        '共通ヘッダの作成
        If Rec3Cnt = 0 Then

            '共通ヘッダ
            Line3.Append(CreCommonRec(CStr(job), CStr(3), CStr(Row3Cnt)))

            '前背
            Line3.Append(FB)

            'SCT
            Line3.Append(CreSpace(CInt(RecDic3("SCT")), " "))

            'ゾーン
            Line3.Append(CreSpace(CInt(RecDic3("ゾーン")), " "))

            '空白2
            Line3.Append(CreSpace(CInt(RecDic3("空白2")), " "))

            '行数カウントアップ
            Row3Cnt = Row3Cnt + 1
        End If

        'SQコード
        If SQCord.ContainsKey(SQ.Trim) = True Then
            'SQがGlobal.vbで定義されているDictionary:SQCordのKeyに存在する場合
            Line3.Append(SQCord(SQ.Trim))
        Else
            'SQがKeyに存在しない場合
            Line3.Append(CreSpace(2, " "))
        End If

        '肉厚コード
        Line3.Append(CreSpace(2, " "))  '空白

        '撚りコード
        If YoriCord.ContainsKey(LnKnd.Trim) = True Then
            'LnKndがKeyに存在する場合
            Line3.Append(SQCord(LnKnd.Trim))
        Else
            'LnKndがKeyに存在しない場合
            Line3.Append(CreSpace(2, " "))
        End If

        '色コード
        If ColorCord.ContainsKey(Color.Trim) = True Then
            'ColorがKeyに存在する場合
            Line3.Append(ColorCord(Color.Trim))
        Else
            'ColorがKeyに存在しない場合、直接入力
            Line3.Append(Color)
        End If

        Rec3Cnt = Rec3Cnt + 1

        If Rec3Cnt = 10 Then
            '10データまでデータ入力できたとき
            'レコード長を揃えるための空白を用意
            Line3.Append(CreSpace(CInt(RecDic3("空白3")), " "))
            'データを追加
            Rec3.Add(Line3.ToString)
            Line3.Clear()
            Rec3Cnt = 0
        ElseIf LastFlg = True Then
            '10データまでの入力ができていない状態で、最終行を迎えたとき
            '不足分を空白で埋める
            Line3.Append(CreSpace((10 - Rec3Cnt) * 8, " "))
            'レコード長を揃えるための空白を用意
            Line3.Append(CreSpace(CInt(RecDic3("空白3")), " "))
            'データを追加
            Rec3.Add(Line3.ToString)
            Line3.Clear()
            Rec3Cnt = 0

        End If


    End Sub

#End Region


#Region "Create Record4"



    Sub CreRec4(ByVal job As Integer)

        Console.WriteLine(FB)

        Dim Series As String = Dic2("シリーズNo")                     'シリーズNo.
        NowData = LnKnd & SQ & Color

        'Public変数に値を導入
        SetPubFT()


Start:
        If Rec4Cnt = 0 Then

            CreRec4Header(FB)
        End If

        If FirstInFlg = True Or Rec6flg = True Then
            '最初の布線行が読み込まれた時、
            '0詰め
            Line4.Append(CreSpace(Set4Area, "0"))
            '線種、線サイズ、色を記録
            OldData = NowData
            State4 = "From"
            Rec4Cnt = Rec4Cnt + 1

            If Rec6flg = True Then
                Rec6flg = False
            End If

            If FirstInFlg = True Then
                FirstInFlg = False
                Rec4flg = True
            End If
        End If


        If OldData = NowData Then
            '線種、線サイズ、色が前データと同じ場合
            If State4 = "From" Then
                '0詰め(1 then 001)
                Line4.Append(CreSpace(SetDic4("仮座標") - FromTemp.Length, "0"))
                '仮座標
                Line4.Append(FromTemp)
                'カラー
                Line4.Append(FromClr)
                '空白
                Line4.Append(CreSpace(SetDic4("空白"), " "))
                '端子番号
                Line4.Append(FromPin)
                'ベンチNo
                Line4.Append(CreSpace(SetDic4("ベンチNo"), " "))
                '線符号
                Line4.Append(LFSign)

                State4 = "To"

                Rec4Cnt = Rec4Cnt + 1
                If Rec4Cnt = 6 Then
                    'データとして完成したら(From,To,From,To,From,To = 6)
                    Rec4Cnt = 0     'カウントリセット
                    Rec4.Add(Line4.ToString)    'データ追加
                    Line4.Clear()               '初期化
                    '次の行に行くので、まず共通ヘッダを作成しにいく
                    GoTo Start  'Startラベルまで移動
                End If

            End If 'If State = "From" Then

            If State4 = "To" Then
                '0詰め
                Line4.Append(CreSpace(SetDic4("仮座標") - ToTemp.Length, "0"))
                '仮座標
                Line4.Append(ToTemp)
                'カラー
                Line4.Append(ToClr)
                '空白
                Line4.Append(CreSpace(SetDic4("空白"), " "))
                '端子番号
                Line4.Append(ToPin)
                'ベンチNo
                Line4.Append(CreSpace(SetDic4("ベンチNo"), " "))

                State4 = "From"

                Rec4Cnt = Rec4Cnt + 1
                If Rec4Cnt = 6 Then
                    Rec4.Add(Line4.ToString)    'データ追加
                    Line4.Clear()
                    Rec4Cnt = 0
                End If

            End If 'If State = "To" Then
        Else
            'OldData <> NowData の時
            '線種、線サイズ、色が前データと同じでない場合
            If State4 = "From" Then
                'From+線符号分だけ0詰め
                Line4.Append(CreSpace(Set4Area + 10, "0"))
                State4 = "To"
                Rec4Cnt = Rec4Cnt + 1
                If Rec4Cnt = 6 Then
                    Rec4Cnt = 0                 'Rec4Cnt=0は共通ヘッダ作成条件
                    Rec4.Add(Line4.ToString)    'データ追加
                    Line4.Clear()
                    '次の行に行くので共通ヘッダを作成しにいく
                    GoTo Start
                End If
            End If

            If State4 = "To" Then
                '線種、線サイズ、色のデータを更新
                OldData = NowData
                'To分だけ0詰め
                Line4.Append(CreSpace(Set4Area, "0"))
                State4 = "From"
                Rec4Cnt = Rec4Cnt + 1
                If Rec4Cnt = 6 Then
                    Rec4.Add(Line4.ToString)    'データ追加
                    Line4.Clear()
                    Rec4Cnt = 0                 'Rec4Cnt=0は共通ヘッダ作成条件
                End If
                GoTo Start                    'Start ラベルまで移動
            End If
        End If 'If OldData = NowData Then

        If LastFlg = True Then

            If Rec4Cnt = 0 Then
                CreRec4Header(FB)
            End If

            'From+線符号分だけ0詰め
            Line4.Append(CreSpace(Set4Area + 10, "0"))
            'レコード長になるまで空白詰め
            Line4.Append(CreSpace(RecordLength - Line4.Length, " "))
            Rec4.Add(Line4.ToString)    'データ追加
            Line4.Clear()

            '------------------------Rec6-----------------------------
            '空白埋め(ただしRecCnt= 6の時はなし)
            If Rec6Cnt <> 6 Then FillSpace6()
            '空白埋め
            Line6.Append(CreSpace(CInt(RecDic6("空白4")), " "))
            Rec6.Add(Line6.ToString)    'データ追加
            Line6.Clear()
            '------------------------Rec6-----------------------------
        End If
    End Sub 'CreRec4

    Sub CreRec4Header(ByVal FB As String)
                    '共通ヘッダ
            Line4.Append(CreCommonRec(CStr(job), CStr(4), CStr(Row4Cnt)))

            '前背
            Line4.Append(FB)

            'SCT
            Line4.Append(CreSpace(CInt(RecDic4("SCT")), " "))

            'ゾーン
            Line4.Append(CreSpace(CInt(RecDic4("ゾーン")), " "))

            '空白2
            Line4.Append(CreSpace(CInt(RecDic4("空白2")), " "))

            '行数カウントアップ
            Row4Cnt = Row4Cnt + 1
    End Sub


#End Region


#Region "Create Record5"

    ''' <summary>
    ''' レコードNo.5作成
    ''' </summary>
    ''' <param name="job"></param>
    ''' <remarks></remarks>
    Sub CreRec5(ByVal job As Integer)
        Dim max As Integer = CInt(Math.Floor(Seq.Count / 10) - 1)
        Dim Line As New StringBuilder
        Dim str As String
        Dim place As Integer
        Dim i As Integer, j As Integer

        For i = 0 To max
            '共通ヘッダ
            Line.Append(CreCommonRec(CStr(job), CStr(5), CStr(i + 1)))

            '前背
            Line.Append(FB)

            '9999
            Line.Append("9999")


            '空白2
            Line.Append(CreSpace(CInt(RecDic5("空白2")), " "))

            For j = 0 To 9
                str = Seq(i * 10 + j)

                Line.Append(str)
                Line.Append(CreSpace(10 - str.Length, " "))
            Next j

            If i = max Then
                'jが9まではFor文が動くので、最後にカウントアップされてj=10
                place = i * 10 + j
            End If

            '空白3
            Line.Append(CreSpace(CInt(RecDic5("空白3")), " "))
            '結果をRec5に保存
            Rec5.Add(Line.ToString)
            '初期化
            Line.Clear()
        Next i

        If place <> Seq.Count Then
            'データ数が10で割り切れないとき
            '共通ヘッダ
            Line.Append(CreCommonRec(CStr(job), CStr(5), CStr(i + 1)))

            '前背
            Line.Append(FB)

            '9999
            Line.Append("9999")


            '空白2
            Line.Append(CreSpace(CInt(RecDic5("空白2")), " "))

            For i = place + 1 To Seq.Count


                str = Seq(i - 1)
                Line.Append(str)
                Line.Append(CreSpace(10 - str.Length, " "))
            Next

            Line.Append(CreSpace((10 - (Seq.Count - place)) * 10, " "))

            '空白3
            Line.Append(CreSpace(CInt(RecDic5("空白3")), " "))
            '結果をRec5に保存
            Rec5.Add(Line.ToString)
            '初期化
            Line.Clear()
        End If
    End Sub

#End Region


#Region "Create Record6"
    Public Sub CreRec6(ByVal job As Integer)
        Dim Series As String = Dic2("シリーズNo")                     'シリーズNo.

        '現在の線種、線サイズ、線色のデータ
        NowData = LnKnd & SQ & Color
        'Public変数に値を導入
        SetPubFT()

Start:
        If Rec6Cnt = 0 Then

            '共通ヘッダ
            Line6.Append(CreCommonRec(CStr(job), CStr(6), CStr(Row6Cnt)))

            '前背
            Line6.Append(FB)

            'SCT
            Line6.Append(CreSpace(CInt(RecDic6("SCT")), " "))

            'ゾーン
            Line6.Append(CreSpace(CInt(RecDic6("ゾーン")), " "))

            '空白2
            Line6.Append(CreSpace(CInt(RecDic6("空白2")), " "))

            '電線種
            Line6.Append(LnKnd)
            '太さ(1.25等が入る場合に備えて左から三文字)
            Line6.Append(Left(SQ, CInt(RecDic6("太さ"))))
            '線色
            Line6.Append(Color)

            '行数カウントアップ
            Row6Cnt = Row6Cnt + 1
        End If

        If FirstInFlg = True Or Rec4flg = True Then
            '線種、線サイズ、色を記録
            OldData = NowData
            State6 = "From"
            Rec6Cnt = Rec6Cnt + 1

            If Rec4flg = True Then
                Rec4flg = False
            End If

            If FirstInFlg = True Then
                FirstInFlg = False
                Rec6flg = True
            End If
        End If

        If OldData = NowData Then
            '線種、線サイズ、色が前データと同じ場合
            If State6 = "From" Then

                '仮座標
                Line6.Append(FromTemp)
                '*詰め
                Line6.Append(CreSpace(SetDic6("空白"), "*"))
                '端子番号
                Line6.Append(FromPin)

                State6 = "To"

                Rec6Cnt = Rec6Cnt + 1
                If Rec6Cnt = 6 Then
                    'データとして完成したら(From,To,From,To,From,To = 6)
                    '空白埋め
                    Line6.Append(CreSpace(CInt(RecDic6("空白4")), " "))

                    Rec6.Add(Line6.ToString)    'データ追加
                    Line6.Clear()               '初期化
                    Rec6Cnt = 0                 'カウントリセット
                    '次の行に行くので、まず共通ヘッダを作成しにいく
                    GoTo Start  'Startラベルまで移動
                End If

            End If 'If State = "From" Then

            If State6 = "To" Then

                '仮座標
                Line6.Append(ToTemp)

                '*詰め
                Line6.Append(CreSpace(SetDic6("空白"), "*"))

                '端子番号
                Line6.Append(ToPin)

                '線符号
                Line6.Append(LFSign)

                'カラー
                Line6.Append(FromClr)

                State6 = "From"


                Rec6Cnt = Rec6Cnt + 1
                If Rec6Cnt = 6 Then
                    'データとして完成したら(From,To,From,To,From,To = 6)
                    '空白埋め
                    Line6.Append(CreSpace(CInt(RecDic6("空白4")), " "))
                    Rec6.Add(Line6.ToString)    'データ追加
                    Line6.Clear()
                    Rec6Cnt = 0
                End If

            End If 'If State = "To" Then

        Else
            'OldData <> NowData の時

            '空白埋め(ただしRecCnt= 6の時はなし)
            If Rec6Cnt <> 6 Then FillSpace6()
            '空白埋め
            Line6.Append(CreSpace(CInt(RecDic6("空白4")), " "))
            Rec6.Add(Line6.ToString)    'データ追加
            Line6.Clear()
            Rec6Cnt = 0
            'Startラベルへ移動
            GoTo Start
        End If 'OldData = NowData 


        If LastFlg = True Then

            '空白埋め(ただしRecCnt= 6の時はなし)
            If Rec6Cnt <> 6 Then FillSpace6()
            '空白埋め
            Line6.Append(CreSpace(CInt(RecDic6("空白4")), " "))
            Rec6.Add(Line6.ToString)    'データ追加
            Line6.Clear()


            '------------------------Rec4-----------------------------
            If Rec4Cnt = 0 Then
                CreRec4Header(FB)
            End If

            'From+線符号分だけ0詰め
            Line4.Append(CreSpace(Set4Area + 10, "0"))

            Line4.Append(CreSpace(RecordLength - Line4.Length, " "))
            Rec4.Add(Line4.ToString)    'データ追加
            Line4.Clear()
            '------------------------Rec4-----------------------------


        End If 'LastFlg=True

    End Sub 'CreRec6

    Sub FillSpace6()
        While Rec6Cnt <= 6

            '仮座標
            Line6.Append(CreSpace(SetDic6("仮座標"), " "))

            '*詰め
            Line6.Append(CreSpace(SetDic6("空白"), "*"))

            '端子番号
            Line6.Append(CreSpace(SetDic6("端子番号"), " "))

            If State6 = "From" Then


                State6 = "To"

                Rec6Cnt = Rec6Cnt + 1
            ElseIf State6 = "To" Then


                '線符号
                Line6.Append(CreSpace(CInt(RecDic6("線符号1")), " "))

                'カラー
                Line6.Append(CreSpace(CInt(RecDic6("カラー1")), " "))

                State6 = "From"

                Rec6Cnt = Rec6Cnt + 1
            End If

        End While
    End Sub


#End Region


#Region "Create Record9"


    Public Sub CreRec9(ByVal job As String)
        '線サイズ
        Dim TrimSQ As String = SQ.Trim
        '線種
        Dim LK As String = Left(LnKnd.Trim, 2)

        Select Case LK

            Case "1C", "2C", "Fu"
                '1芯、2芯シールド、付属線の場合
                CountRec9(LK) = CountRec9(LK) + 1
            Case Else
                Select Case TrimSQ
                    Case "0.3", "0.5", "1.25", "2.0", _
                        "3.5", "5.5", "8", "14", "22", _
                        "38", "60", "100", "150"
                        '線サイズが上記の場合
                        CountRec9(TrimSQ) = CountRec9(TrimSQ) + 1

                    Case Else
                        '線サイズが規定以外の場合
                        CountRec9("その他") = CountRec9("その他") + 1

                End Select
        End Select

        '最終行の時
        If LastFlg = True Then
            'カウント結果を文字列にして保存する

            Dim line As New StringBuilder
            Dim key As String = ""

            '共通ヘッダ
            line.Append(CreCommonRec(CStr(job), CStr(9), CStr(Rec9Cnt)))
            'シリーズNo.カウントアップ
            Rec9Cnt = Rec9Cnt + 1

            '9詰
            line.Append(CreSpace(RecDic9("9詰"), "9"))
            '空白2
            line.Append(CreSpace(RecDic9("空白2"), " "))

            '0.3-付属線まで
            For i = 0 To CountRec9.Keys.Count - 1
                key = CountRec9.Keys(i)

                '空白詰
                line.Append(CreSpace(RecDic9(key) - CStr(CountRec9(key)).Length, " "))
                '0.3
                line.Append(CountRec9(key))
            Next

            '扉
            line.Append(CreSpace(RecDic9("扉"), " "))

            '空白3
            line.Append(CreSpace(RecDic9("空白3") - 1, " "))
            line.Append("*")

            '空白4
            line.Append(CreSpace(RecDic9("空白4"), " "))

            'データ追加
            Rec9.Add(line.ToString)
            LastFlg = False
        End If
    End Sub


#End Region



#Region "結果をファイルに出力"


    Sub OutPutFiles()

        ' 出力ファイルパスを組み立てる
        Dim opWD As String = OutPutPath & "WD(" & job & ").DAT"
        Dim opNC As String = OutPutPath & "NC(" & job & ").DAT"
        Dim opDEV As String = OutPutPath & "DEV(" & job & ").DAT"
        Dim opMRK As String = OutPutPath & "MRK(" & job & ").DAT"
        Dim opMJ As String = OutPutPath & "MJ(" & job & ").DAT"
        Dim opHON As String = OutPutPath & "HON(" & job & ").DAT"

        Dim i As Integer


        '作成するStreamWriterの宣言
        Using WD As New StreamWriter(opWD, FirstOutFlg, Encoding.Default)
            Using NC As New StreamWriter(opNC, FirstOutFlg, Encoding.Default)
                Using DEV As New StreamWriter(opDEV, FirstOutFlg, Encoding.Default)
                    Using MRK As New StreamWriter(opMRK, FirstOutFlg, Encoding.Default)
                        Using MJ As New StreamWriter(opMJ, FirstOutFlg, Encoding.Default)
                            Using HON As New StreamWriter(opHON, FirstOutFlg, Encoding.Default)
                                'レコード1出力
                                WD.WriteLine(Rec1)
                                NC.WriteLine(Rec1)
                                DEV.WriteLine(Rec1)
                                MRK.WriteLine(Rec1)
                                MJ.WriteLine(Rec1)
                                HON.WriteLine(Rec1)

                                'レコード2出力
                                For i = 0 To Rec2.Count - 1
                                    WD.WriteLine(Rec2(i))
                                    NC.WriteLine(Rec2(i))
                                Next

                                'レコード3出力
                                For i = 0 To Rec3.Count - 1
                                    WD.WriteLine(Rec3(i))
                                    NC.WriteLine(Rec3(i))
                                Next

                                'レコード4出力
                                For i = 0 To Rec4.Count - 1
                                    WD.WriteLine(Rec4(i))
                                    NC.WriteLine(Rec4(i))
                                Next

                                'レコード5出力
                                For i = 0 To Rec5.Count - 1
                                    WD.WriteLine(Rec5(i))
                                    DEV.WriteLine(Rec5(i))
                                Next

                                'レコード6出力
                                For i = 0 To Rec6.Count - 1
                                    WD.WriteLine(Rec6(i))
                                    MRK.WriteLine(Rec6(i))
                                Next

                                'レコード9出力
                                WD.WriteLine(Rec9(0))
                                HON.WriteLine(Rec9(0))


                                Rec1 = "" : Rec2.Clear() : Rec3.Clear()
                                Rec4.Clear() : Rec5.Clear() : Rec6.Clear()
                                Rec9.Clear()

                                'ファイルを閉じる
                                WD.Close() : NC.Close() : DEV.Close() : MRK.Close() : MJ.Close() : HON.Close()
                            End Using   'HON    
                        End Using   'MJ
                    End Using   'MRK
                End Using   'DEV
            End Using   'NC
        End Using   'WD

        If FirstOutFlg = False Then
            FirstOutFlg = True
        End If


        Row3Cnt = 1 : Rec3Cnt = 0
        Row4Cnt = 1 : Rec4Cnt = 0
    End Sub

#End Region


#Region "工番体系調整"

    ''' <summary>
    ''' 工番体系を整える。
    ''' </summary>
    ''' <param name="str">調べる文字列</param>
    ''' <returns>X**-****のような工番体系を返す</returns>
    ''' <remarks></remarks>
    Public Function TrimOrder(ByVal str As String) As String
        Dim result As Integer   '変換結果
        '半角+大文字にして空白全消し
        Dim Returns As String = Replace(StrConv(str, VbStrConv.Narrow + VbStrConv.Uppercase), " ", "")


        If Integer.TryParse(Left(Returns, 2), result) = True Then
            '引数文字列左から二文字がIntegerへの変換が成功したとき
            '3文字目からの文字列を返す。
            TrimOrder = Mid(Returns, 3)
        Else
            '変換が成功しなかったとき

            TrimOrder = Returns

        End If

        Dim f As String = Mid(TrimOrder, 1, 1)
        Dim s As String = Mid(TrimOrder, 2, 1)

        If f >= "A" And f <= "Z" And s >= "A" And s <= "Z" Then
            '2文字ともアルファベットの場合
            'XP等の場合→Xに
            TrimOrder = TrimOrder.Replace(f & s, f)
        End If

    End Function

    ''' <summary>
    ''' 工番をデータベース用に体系を整える
    ''' </summary>
    ''' <param name="Order"></param>
    ''' <remarks></remarks>
    Public Sub DBOrder(ByVal Order As String)
        'OrderはX**-****がくることを想定
        Dim arr As String() = Nothing

        arr = Order.Split("-")

        While arr(1).Length <> 4
            arr(1) = "0" & arr(1)
        End While

        arr(0) = "  " & arr(0)
        arr(0) = arr(0).Insert(3, " ")

        DBKouban = arr(0) & arr(1)
    End Sub
#End Region


#Region "FromTo関係"

    ''' <summary>
    ''' FromTo関係のPublic変数セット
    ''' </summary>
    ''' <remarks></remarks>
    ''' 
    Sub SetPubFT()

        '線符号
        LFSign = Dic2("FT線番号")
        LTSign = Dic2("TT線番号")

        'From
        FromCoord = Dic2("FT機器座標")
        FromPin = Dic2("FT器具端子")    '端子番号
        FromClr = Dic2("FT色別")        'カラー
        FromTemp = SerchTemp(FromCoord)   '仮座標

        'To
        ToCoord = Dic2("TT機器座標")
        ToPin = Dic2("TT器具端子")
        ToClr = Dic2("TT色別")
        ToTemp = SerchTemp(ToCoord)     '仮座標

        'FromToCoord.Add("From", Dic2("FT機器座標"))
        'FromToCoord.Add("To", Dic2("TT機器座標"))
        'FromToPin.Add("From", Dic2("FT器具端子"))
        'FromToPin.Add("To", Dic2("TT器具端子"))
        'FromToClr.Add("From", Dic2("FT色別"))
        'FromToClr.Add("To", Dic2("TT色別"))
        'FromToTemp.Add("From", SerchTemp(FromToCoord("From")))
        'FromToTemp.Add("To", SerchTemp(FromToCoord("To")))
    End Sub



    ''' <summary>
    ''' 座標名+分割名から仮座標を求める
    ''' </summary>
    ''' <param name="coord">座標名＋分割名(空白無)</param>
    ''' <returns>仮座標</returns>
    ''' <remarks></remarks>

    Function SerchTemp(ByVal coord As String) As String

        '見つからなければ、空白を返す
        SerchTemp = "   "

        For i As Integer = 1 To ArrCoord.Length - 1
            If coord.Trim = ArrCoord(i).Trim Then
                SerchTemp = CStr(i)
                Exit For
            End If
        Next

        'If SupRec4 = "   " Then
        '    MsgBox("仮座標が見つかりませんでした")
        'End If

    End Function

#End Region


End Module
