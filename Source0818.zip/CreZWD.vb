﻿Imports System.IO
Imports System.Text

Module CreZWD

#Region "Create FLP"

    Sub CreFLP()

        Dim StrB As New StringBuilder

        If RecFLP.Count = 0 Then

            CreFLPHeader(StrB)

        End If

        StrB.Append(CreSpace(FLPDic("空白1"), " "))

        FLPCnt += 1
        'シリーズNo.
        StrB.Append("(")
        StrB.Append(CreSpace(FLPDic("シリーズNo") - LenB(CStr(FLPCnt)), "0"))
        StrB.Append(CStr(FLPCnt))
        StrB.Append(")")

        StrB.Append(CreSpace(FLPDic("空白2"), " "))

        '群番

        StrB.Append("GRP---")
        StrB.Append(Gun)
        StrB.Append(CreSpace(FLPDic("GRP---") - LenB(Gun), " "))

        '盤No.
        Dim Ban As String = BanNo.Trim()
        StrB.Append("BAN---")
        StrB.Append(Ban)
        StrB.Append(CreSpace(FLPDic("BAN---") - LenB(Ban), " "))

        '前背
        StrB.Append("FB---")
        StrB.Append(FB)
        StrB.Append(CreSpace(FLPDic("FB---") - LenB(FB), " "))

        StrB.Append("SCT---")
        StrB.Append(CreSpace(FLPDic("SCT---"), " "))

        StrB.Append("ZONE---")
        StrB.Append(CreSpace(FLPDic("ZONE---"), " "))

        StrB.Append("LOCATION---")
        StrB.Append(CreSpace(FLPDic("LOCATION---"), " "))


        StrB.Append(CreSpace(FLPDic("空白3"), " "))

        RecFLP.Add(StrB.ToString)
        StrB.Clear()
    End Sub

    Sub CreFLPHeader(ByRef StrB As StringBuilder)

        StrB.Append(FLP_Header)

        '工番名
        StrB.Append("KOOBAN=")
        StrB.Append(Kouban)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("KOOBAN=") - LenB(Kouban), " "))

        '客先名
        StrB.Append("KYAKU=")
        StrB.Append(CustomerName)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("KYAKU=") - LenB(CustomerName), " "))

        '日時
        StrB.Append("DATE:")
        StrB.Append(NowDate)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("DATE:") - LenB(NowDate), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(FLPDic("従番"), " "))
        StrB.Append(")")

        'ジョブNo.
        StrB.Append("JOB=")
        StrB.Append(Job)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("JOB=") - LenB(Job), " "))

        RecFLP.Add(StrB.ToString)
        StrB.Clear()

        For Each s In Border
            RecFLP.Add(s)
        Next
    End Sub

    ''' <summary>
    ''' アルファべットと数字を分けた配列を返す
    ''' </summary>
    ''' <param name="str">対象文字列</param>
    ''' <returns>
    ''' (0):アルファべット,(1):数字　　
    ''' </returns>
    ''' <remarks></remarks>
    Function SepaStr(ByVal str As String) As String()
        Dim temp As String
        Dim ret(1) As String
        For i = 1 To str.Length
            temp = Mid(str, i, 1)
            Select Case temp
                Case "a" To "z", "A" To "Z"
                    ret(0) = ret(0) & temp
                Case "0" To "9"
                    ret(1) = ret(1) & temp
            End Select
        Next

        Return ret
    End Function
#End Region

#Region "Create HON"

    Sub CreHON()

        Dim StrB As New StringBuilder

        If LastFlg = True Then
            If RecHON.Count = 0 Then

                StrB.Append(HON_Header1)

                '工番名
                StrB.Append(Kouban)
                '空白詰め
                StrB.Append(CreSpace(HONDic("KOOBAN=") - LenB(Kouban), " "))

                StrB.Append(HON_Header2)
                StrB.Append(CreSpace(HONDic("空白1"), " "))

                '日時
                StrB.Append("DATE:")
                StrB.Append(NowDate)
                '空白詰め
                StrB.Append(CreSpace(HONDic("DATE:") - LenB(NowDate), " "))

                '従番
                StrB.Append("(")
                StrB.Append(CreSpace(HONDic("従番"), " "))
                StrB.Append(")")

                'ジョブNo.
                StrB.Append("JOB=")
                StrB.Append(Job)
                '空白詰め
                StrB.Append(CreSpace(HONDic("JOB=") - LenB(Job), " "))
                RecHON.Add(StrB.ToString)
                StrB.Clear()

                'ヘッダー二行目
                StrB.Append(HON_Header3)
                RecHON.Add(StrB.ToString)
                StrB.Clear()
            End If


            StrB.Append(CreSpace(HONDic("空白2"), " "))
            StrB.Append(Gun)
            StrB.Append(CreSpace(HONDic("GROUP") - LenB(Gun), " "))

            '盤No.
            Dim Ban As String = BanNo.Trim()
            StrB.Append(Ban)
            StrB.Append(CreSpace(HONDic("BAN") - LenB(Ban), " "))

            StrB.Append(FB)
            StrB.Append(CreSpace(HONDic("ZENHAI") - LenB(FB), " "))

            '0.3-付属線まで
            Dim Key As String
            For i = 0 To CountRec9.Keys.Count - 1
                key = CountRec9.Keys(i)

                '空白詰
                StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(CountRec9(Key))), " "))
                '0.3-TOBI
                StrB.Append(CountRec9(Key))
                'Total
                TotalHON(Key) = TotalHON(Key) + CountRec9(Key)
            Next

            RecHON.Add(StrB.ToString)
            StrB.Clear()

            LastFlg = False
            ClearRec9()                 'CountRec9の値の初期化

        End If
    End Sub

    Sub SetTotalHON()
        Dim StrB As New StringBuilder

        StrB.Append("     ---------------    ")

        Dim Key As String
        For i = 0 To TotalHON.Keys.Count - 1
            Key = TotalHON.Keys(i)

            '空白詰
            StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(TotalHON(Key))), " "))
            '0.3-TOBI
            StrB.Append(TotalHON(Key))


        Next

        RecHON.Add(StrB.ToString)
    End Sub
#End Region

#Region "KIK"

    Sub CreKIK()
        Dim StrB As New StringBuilder
        Dim key As String

        CreKIKHeader()



        For i = 0 To CSVDataDic.Keys.Count - 1

            StrB.Append(" ")
            key = CSVDataDic.Keys(i)
            '配列{略称,形式,端子種類,器具番号}
            Dim arr() As String = CSVDataDic(key)
            '0詰め
            StrB.Append(CreSpace(KIKDic("仮座標") - LenB(CStr(i)), "0"))
            '仮座標
            StrB.Append(CStr(i))
            '
            StrB.Append(CreSpace(KIKDic("空白2"), " "))
            '
            Dim temp = key.Split(" ")
            Dim str = temp(UBound(temp))

            '座標名
            StrB.Append(temp(0))
            StrB.Append(CreSpace(KIKDic("座標名") - LenB(temp(0)), " "))

            '分割名
            StrB.Append(str)
            StrB.Append(CreSpace(KIKDic("分割名") - LenB(str), " "))


        Next

    End Sub

#Region "Header"
    Sub CreKIKHeader()
        Dim StrB As New StringBuilder
        Dim jobs As String = "JOB=" & CreSpace(KIKHeaderDic("JOB=") - LenB(CStr(Job)), " ") & Job

        StrB.Append(KIKHeader1)

        '日時
        StrB.Append("DATE:")
        StrB.Append(NowDate)
        '空白詰め
        StrB.Append(CreSpace(KIKHeaderDic("DATE:") - LenB(NowDate), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(KIKHeaderDic("従番"), " "))
        StrB.Append(")")

        'ジョブNo.
        StrB.Append(jobs)

        RecKIK.Add(StrB.ToString)
        StrB.Clear()

        StrB.Append(" ")
        StrB.Append(jobs)
        StrB.Append(CreSpace(KIKHeaderDic("空白2"), " "))

        '工番
        StrB.Append("KOOBAN=")
        StrB.Append(Kouban)
        StrB.Append(CreSpace(KIKHeaderDic("KOOBAN=") - LenB(Kouban), " "))

        '群番

        StrB.Append("GRP=")
        StrB.Append(Gun)
        StrB.Append(CreSpace(KIKHeaderDic("GRP=") - LenB(Gun), " "))

        '盤No.

        StrB.Append("BAN---")
        StrB.Append(BanNo)
        StrB.Append(CreSpace(KIKHeaderDic("BAN=") - LenB(BanNo), " "))

        '前背
        StrB.Append("FB=")
        StrB.Append(FB)
        StrB.Append(CreSpace(KIKHeaderDic("FB=") - LenB(FB), " "))

        StrB.Append("SCT=")
        StrB.Append(CreSpace(KIKHeaderDic("SCT="), " "))

        StrB.Append("ZONE=")
        StrB.Append(CreSpace(KIKHeaderDic("ZONE="), " "))

        StrB.Append(CreSpace(KIKHeaderDic("空白3"), " "))

        RecKIK.Add(StrB.ToString)
        StrB.Clear()

        RecKIK.Add(CreSpace(KIKRecLen, " "))
        RecKIK.Add(KIKHeader2)
    End Sub

#End Region


#End Region


End Module
