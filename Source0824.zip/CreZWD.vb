﻿Imports System.IO
Imports System.Text

Module CreZWD

#Region "Create FLP"

    Sub CreFLP()

        Dim StrB As New StringBuilder

        If RecFLP.Count = 0 Then

            CreFLPHeader(StrB)

        End If

        StrB.Append(CreSpace(FLPDic("空白1"), " "))

        FLPCnt += 1
        'シリーズNo.
        StrB.Append("(")
        StrB.Append(CreSpace(FLPDic("シリーズNo") - LenB(CStr(FLPCnt)), "0"))
        StrB.Append(CStr(FLPCnt))
        StrB.Append(")")

        StrB.Append(CreSpace(FLPDic("空白2"), " "))

        '群番

        StrB.Append("GRP---")
        StrB.Append(Gun)
        StrB.Append(CreSpace(FLPDic("GRP---") - LenB(Gun), " "))

        '盤No.
        Dim Ban As String = BanNo.Trim()
        StrB.Append("BAN---")
        StrB.Append(Ban)
        StrB.Append(CreSpace(FLPDic("BAN---") - LenB(Ban), " "))

        '前背
        StrB.Append("FB---")
        StrB.Append(FB)
        StrB.Append(CreSpace(FLPDic("FB---") - LenB(FB), " "))

        StrB.Append("SCT---")
        StrB.Append(CreSpace(FLPDic("SCT---"), " "))

        StrB.Append("ZONE---")
        StrB.Append(CreSpace(FLPDic("ZONE---"), " "))

        StrB.Append("LOCATION---")
        StrB.Append(CreSpace(FLPDic("LOCATION---"), " "))


        StrB.Append(CreSpace(FLPDic("空白3"), " "))

        RecFLP.Add(StrB.ToString)
        StrB.Clear()
    End Sub

    Sub CreFLPHeader(ByRef StrB As StringBuilder)

        StrB.Append(FLP_Header)

        '工番名
        StrB.Append("KOOBAN=")
        StrB.Append(Kouban)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("KOOBAN=") - LenB(Kouban), " "))

        '客先名
        StrB.Append("KYAKU=")
        StrB.Append(CustomerName)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("KYAKU=") - LenB(CustomerName), " "))

        '日時
        StrB.Append("DATE:")
        StrB.Append(NowDate)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("DATE:") - LenB(NowDate), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(FLPDic("従番"), " "))
        StrB.Append(")")

        'ジョブNo.
        StrB.Append("JOB=")
        StrB.Append(Job)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("JOB=") - LenB(Job), " "))

        RecFLP.Add(StrB.ToString)
        StrB.Clear()

        For Each s In Border
            RecFLP.Add(s)
        Next
    End Sub


#End Region

#Region "Create HON"

    Sub CreHON()

        Dim StrB As New StringBuilder

        If LastFlg = True Then
            If RecHON.Count = 0 Then

                StrB.Append(HON_Header1)

                '工番名
                StrB.Append(Kouban)
                '空白詰め
                StrB.Append(CreSpace(HONDic("KOOBAN=") - LenB(Kouban), " "))

                StrB.Append(HON_Header2)
                StrB.Append(CreSpace(HONDic("空白1"), " "))

                '日時
                StrB.Append("DATE:")
                StrB.Append(NowDate)
                '空白詰め
                StrB.Append(CreSpace(HONDic("DATE:") - LenB(NowDate), " "))

                '従番
                StrB.Append("(")
                StrB.Append(CreSpace(HONDic("従番"), " "))
                StrB.Append(")")

                'ジョブNo.
                StrB.Append("JOB=")
                StrB.Append(Job)
                '空白詰め
                StrB.Append(CreSpace(HONDic("JOB=") - LenB(Job), " "))
                RecHON.Add(StrB.ToString)
                StrB.Clear()

                'ヘッダー二行目
                StrB.Append(HON_Header3)
                RecHON.Add(StrB.ToString)
                StrB.Clear()
            End If


            StrB.Append(CreSpace(HONDic("空白2"), " "))
            StrB.Append(Gun)
            StrB.Append(CreSpace(HONDic("GROUP") - LenB(Gun), " "))

            '盤No.
            Dim Ban As String = BanNo.Trim()
            StrB.Append(Ban)
            StrB.Append(CreSpace(HONDic("BAN") - LenB(Ban), " "))

            StrB.Append(FB)
            StrB.Append(CreSpace(HONDic("ZENHAI") - LenB(FB), " "))

            '0.3-付属線まで
            Dim Key As String
            For i = 0 To CountRec9.Keys.Count - 1
                key = CountRec9.Keys(i)

                '空白詰
                StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(CountRec9(Key))), " "))
                '0.3-TOBI
                StrB.Append(CountRec9(Key))

                'Part
                PartHON(Key) = PartHON(Key) + CountRec9(Key)
                'Total
                TotalHON(Key) = TotalHON(Key) + CountRec9(Key)
            Next

            RecHON.Add(StrB.ToString)
            StrB.Clear()

            LastFlg = False
            ClearRec9()                 'CountRec9の値の初期化

        End If
    End Sub

    Sub SetPartHON()
            Dim StrB As New StringBuilder

        StrB.Append("     ---------------    ")

        Dim Key As String
        Dim AllCnt As Integer
        For i = 0 To PartHON.Keys.Count - 1
            Key = PartHON.Keys(i)

            '空白詰
            StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(PartHON(Key))), " "))
            '0.3-TOBI
            StrB.Append(PartHON(Key))

            AllCnt += PartHON(Key)
            PartHON(Key) = 0
        Next i

        RecHON.Add(StrB.ToString)
        StrB.Clear()

    End Sub

    Sub SetTotalHON()
        Dim StrB As New StringBuilder

        SetPartHON()

        StrB.Append("     ** JOB TOTAL **    ")

        Dim Key As String
        Dim AllCnt As Integer
        For i = 0 To TotalHON.Keys.Count - 1
            Key = TotalHON.Keys(i)

            '空白詰
            StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(TotalHON(Key))), " "))
            '0.3-TOBI
            StrB.Append(TotalHON(Key))

            AllCnt += TotalHON(Key)
        Next i

        RecHON.Add(StrB.ToString)
        StrB.Clear()
        StrB.Append("             (")
        StrB.Append(CreSpace(6 - LenB(CStr(AllCnt)), " "))
        StrB.Append(CStr(AllCnt))
        StrB.Append(")                                                                                                               ")
        RecHON.Add(StrB.ToString)
    End Sub


#End Region

#Region "KIK"

    Sub CreKIK()
        Dim StrB As New StringBuilder
        Dim key As String

        CreKIKHeader()



        For i = 0 To CSVDataDic.Keys.Count - 1

            StrB.Append(" ")
            key = CSVDataDic.Keys(i)
            '配列{略称,形式,端子種類,器具番号}
            Dim arr() As String = CSVDataDic(key)
            '0詰め
            StrB.Append(CreSpace(KIKDic("仮座標") - LenB(CStr(i + 1)), "0"))
            '仮座標
            StrB.Append(CStr(i + 1))
            '
            StrB.Append(CreSpace(KIKDic("空白2"), " "))

            '座標名
            Dim temp = Left(key, 6).Trim
            StrB.Append(temp)
            StrB.Append(CreSpace(KIKDic("座標名") - LenB(temp), " "))

            '分割名
            Dim str = Right(key, 1)
            StrB.Append(str)
            StrB.Append(CreSpace(KIKDic("分割名") - LenB(str), " "))

            '端子種類
            StrB.Append("(")
            StrB.Append(arr(2))
            StrB.Append(CreSpace(KIKDic("端子種類") - LenB(arr(2)), " "))
            StrB.Append(")")

            StrB.Append(CreSpace(KIKDic("空白3"), " "))

            '形式
            StrB.Append(arr(1))
            StrB.Append(CreSpace(KIKDic("形式") - LenB(arr(1)), " "))

            'フレーム
            StrB.Append(CreSpace(KIKDic("フレーム"), " "))

            '略称
            StrB.Append(arr(0))
            StrB.Append(CreSpace(KIKDic("略称") - LenB(arr(0)), " "))

            StrB.Append(CreSpace(KIKDic("No"), " "))

            If Left(temp, 2) = "YY" Then
                StrB.Append(NextBanDic(BanNo))
                StrB.Append(CreSpace(KIKDic("CHUKEI") - LenB(NextBanDic(BanNo)), " "))
            Else
                StrB.Append(CreSpace(KIKDic("CHUKEI"), " "))
            End If

            'KIGU_No
            StrB.Append(CreSpace(KIKDic("KIGU_No"), " "))

            'デバイス名
            StrB.Append(arr(3))
            StrB.Append(CreSpace(KIKDic("デバイス名") - LenB(arr(3)), " "))

            'SOU
            StrB.Append(CreSpace(KIKDic("SOU"), " "))

            '(T)
            StrB.Append(CreSpace(KIKDic("(T)"), " "))

            RecKIK.Add(StrB.ToString)
            StrB.Clear()
        Next i

    End Sub

#Region "Header"
    Sub CreKIKHeader()
        Dim StrB As New StringBuilder
        Dim jobs As String = "JOB=" & CreSpace(KIKHeaderDic("JOB=") - LenB(CStr(Job)), " ") & Job

        StrB.Append(KIKHeader1)

        '日時
        StrB.Append("DATE:")
        StrB.Append(NowDate)
        '空白詰め
        StrB.Append(CreSpace(KIKHeaderDic("DATE:") - LenB(NowDate), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(KIKHeaderDic("従番"), " "))
        StrB.Append(")")

        'ジョブNo.
        StrB.Append(jobs)

        RecKIK.Add(StrB.ToString)
        StrB.Clear()

        StrB.Append(" ")
        StrB.Append(jobs)
        StrB.Append(CreSpace(KIKHeaderDic("空白2"), " "))

        '工番
        StrB.Append("KOOBAN=")
        StrB.Append(Kouban)
        StrB.Append(CreSpace(KIKHeaderDic("KOOBAN=") - LenB(Kouban), " "))

        '群番

        StrB.Append("GRP=")
        StrB.Append(Gun)
        StrB.Append(CreSpace(KIKHeaderDic("GRP=") - LenB(Gun), " "))

        '盤No.

        StrB.Append("BAN=")
        StrB.Append(BanNo)
        StrB.Append(CreSpace(KIKHeaderDic("BAN=") - LenB(BanNo), " "))

        '前背
        StrB.Append("FB=")
        StrB.Append(FB)
        StrB.Append(CreSpace(KIKHeaderDic("FB=") - LenB(FB), " "))

        StrB.Append("SCT=")
        StrB.Append(CreSpace(KIKHeaderDic("SCT="), " "))

        StrB.Append("ZONE=")
        StrB.Append(CreSpace(KIKHeaderDic("ZONE="), " "))

        StrB.Append(CreSpace(KIKHeaderDic("空白3"), " "))

        RecKIK.Add(StrB.ToString)
        StrB.Clear()

        RecKIK.Add(CreSpace(KIKRecLen, " "))
        RecKIK.Add(KIKHeader2)
    End Sub

#End Region


#End Region


Public Root As New Dictionary(Of String, Dictionary(Of String, String()))

Public Sub CreRoot()

    Dim key As String = Dic2("FT機器座標").Trim
    Dim value As String = Dic2("TT機器座標").Trim

    'Toの仮座標
    Dim tem As String = SearchTemp(value, CSVDataDic)
    Dim temp As String = CreSpace(3 - LenB(tem), "0") & tem

    If Root.ContainsKey(key) = False Then
        Dim dic As New Dictionary(Of String, String()) _
         From {
                {temp, {value, "1"}}
              }
        Root.Add(key, dic)
    Else
        Dim tempdic As Dictionary(Of String, String()) = Root(key)

        If tempdic.ContainsKey(temp) = True Then

            '(0)=座標名、(1)=カウント、(2)=
            Dim arr As String() = tempdic(temp)
            arr(1) += 1

            tempdic(temp) = arr
        Else
            tempdic.Add(temp, {value, "1"})
        End If

        Sort_Dic_A(tempdic)
    End If

End Sub

    Public Const HeaderTEA As String = "*** TENKAIZU SETTKEI HONSU ***                                                  "
    Public Const HeaderTEB As String = "*** TENKAI HONSU HYO     ***(RETUBAKO CHUKEI)                                   "

    Public TEHeaderDic As New Dictionary(Of String, Integer) From
    {
        {"DATE:", 18},
        {"PAGE=", 3},
        {"空白1", 3},
        {"従番", 9},
        {"JOB=", 3},
        {"空白2", 3},
        {"空白3", 2},
        {"KOOBAN---", 13},
        {"GRP---", 9},
        {"BAN---", 9},
        {"FB---", 4},
        {"SCT---", 4},
        {"ZONE---", 4},
        {"空白4", 38}
    }

    Public Sub CreTEHeaderAorB(ByVal AorBH As String, ByVal Page As String, ByRef RecTE As List(Of String))
        Dim StrB As New StringBuilder
        Dim jobs As String = "JOB=" & CreSpace(TEHeaderDic("JOB=") - LenB(CStr(Job)), " ") & CStr(Job)
        Dim ReList As New List(Of String)

        StrB.Append(AorBH)

        StrB.Append("DATE:")
        StrB.Append(NowDate)
        StrB.Append(CreSpace(TEHeaderDic("DATE:") - LenB(NowDate), " "))

        StrB.Append("PAGE=")
        StrB.Append(CreSpace(TEHeaderDic("PAGE=") - LenB(Page), "0"))
        StrB.Append(Page)

        StrB.Append(CreSpace(TEHeaderDic("空白1"), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(TEHeaderDic("従番"), " "))
        StrB.Append(")")

        StrB.Append(jobs)

        RecTE.Add(StrB.ToString)
        StrB.Clear()

        StrB.Append(CreSpace(TEHeaderDic("空白2"), " "))

        'ジョブNo.
        StrB.Append(jobs)

        StrB.Append(CreSpace(TEHeaderDic("空白3"), " "))

        '工番
        StrB.Append("KOOBAN---")
        StrB.Append(Kouban)
        StrB.Append(CreSpace(TEHeaderDic("KOOBAN---") - LenB(Kouban), " "))

        '群番

        StrB.Append("GRP---")
        StrB.Append(Gun)
        StrB.Append(CreSpace(TEHeaderDic("GRP---") - LenB(Gun), " "))

        '盤No.
        Dim Ban As String = BanNo.Trim()
        StrB.Append("BAN---")
        StrB.Append(Ban)
        StrB.Append(CreSpace(TEHeaderDic("BAN---") - LenB(Ban), " "))

        '前背
        StrB.Append("FB---")
        StrB.Append(FB)
        StrB.Append(CreSpace(TEHeaderDic("FB---") - LenB(FB), " "))

        StrB.Append("SCT---")
        StrB.Append(CreSpace(TEHeaderDic("SCT---"), " "))

        StrB.Append("ZONE---")
        StrB.Append(CreSpace(TEHeaderDic("ZONE---"), " "))

        StrB.Append(CreSpace(TEHeaderDic("空白4"), " "))

        RecTE.Add(StrB.ToString)

    End Sub


    Public TEADic As New Dictionary(Of String, Object) From
    {
        {"空白1", 1},
        {"From仮座標", 3},
        {"空白2", 2},
        {"From座標", 6},
        {"From分割名", 2},
        {"-", 4},
        {"1", SetTEA},
        {"2", SetTEA},
        {"3", SetTEA},
        {"4", SetTEA},
        {"5", SetTEA},
        {"6", SetTEA},
        {"7", SetTEA},
        {"8", SetTEA}
    }

    Public SetTEA As New Dictionary(Of String, Integer) From
    {
        {"To座標", 6},
        {"To分割名", 2},
        {"本数", 3}
    }

    Public TEBDic As New Dictionary(Of String, Object) From
    {
        {"空白1", 1},
        {"From仮座標", 3},
        {"空白2", 2},
        {"From座標", 6},
        {"From分割名", 2},
        {"-", 4},
        {"1", SetTEB},
        {"2", SetTEB},
        {"3", SetTEB},
        {"4", SetTEB},
        {"5", SetTEB},
        {"空白3", 8}
    }

    Public SetTEB As New Dictionary(Of String, Integer) From
    {
        {"To座標", 6},
        {"To分割名", 1},
        {"To仮座標", 3},
        {"本数", 3}
    }


    Public Const NextSpace As String = "                   "
    Public Const TEAMAX = 8
    Public TEACount As Integer = 0
    Public TEBCount As Integer = 0

    Public LineTEA As New StringBuilder
    Public LineTEB As New StringBuilder
    Public RecTEA As New List(Of String)
    Public RecTEB As New List(Of String)
    Public TotalTEACount As Integer
    Public TotalTEBCount As Integer
    Public Const RecTELen As Integer = 132
    Public PageCnt As Integer = 0

     Sub CreTEABWAT()
        Dim key As String   'From座標名
        Dim dic As Dictionary(Of String, String())
        Dim temp As String
        Dim arr As String()

        PageCnt += 1

        For i As Integer = 0 To Root.Count - 1
            '座標名の分だけ繰り返す
            key = Root.Keys(i)      'From座標名
            dic = Root(key)

            If i = 0 Then
                CreTEHeaderAorB(HeaderTEA, PageCnt, RecTEA)
                CreTEHeaderAorB(HeaderTEB, PageCnt, RecTEB)
            End If

            For j As Integer = 0 To dic.Count - 1
                '仮座標の分だけ繰り返す
                temp = dic.Keys(j)
                '(0)=座標名、(1)=カウント、(2)=
                arr = dic(temp)

                If Left(key, 2) = "YY" Or Left(arr(0), 2) = "YY" Then
                    StartTE(i, key, TEBDic, LineTEB)

                    EndTE(SetTEB, LineTEB, TEBCount, TotalTEBCount, " TOTAL          ", RecTEB)
                Else

                    If TEACount = 0 Then
                        StartTE(i, key, TEADic, LineTEA)
                    End If

                    CreTEA(key, i + 1, arr(0), temp, arr(1))

                    If j = dic.Count - 1 Then
                        EndTE(SetTEA, LineTEA, TEACount, TotalTEACount, " TOTAL    ", RecTEA)
                    End If
                End If
            Next
        Next i

        Root.Clear()
     End Sub

     Sub StartTE(ByVal i As Integer, ByVal key As String, ByVal Dic As Dictionary(Of String, Object), ByRef Line As StringBuilder)

        Line.Append(" ")
        Line.Append(CreSpace(Dic("From仮座標") - LenB(i + 1), "0"))  '0詰め
        Line.Append(i + 1)

        Line.Append(CreSpace(Dic("空白2"), " "))

        Line.Append(key)
        Line.Append(CreSpace(Dic("From座標") - LenB(key), " "))

        Line.Append(",")
        Line.Append(CreSpace(Dic("From分割名"), " "))
        Line.Append(CreSpace(Dic("-"), "-"))
     End Sub

     Sub EndTE(ByVal Dic As Dictionary(Of String, Integer), ByRef Line As StringBuilder, ByRef TECount As Integer, ByRef TotalTECount As Integer, ByVal Totalstr As String, ByRef RecTE As List(Of String))

        Line.Append(Totalstr)
        Line.Append("(")
        Line.Append(CreSpace(Dic("本数") - LenB(TotalTECount), "0"))
        Line.Append(TotalTECount)
        Line.Append(")")

        Line.Append(CreSpace(RecTELen - LenB(Line.ToString), " "))
        RecTE.Add(Line.ToString)
        Line.Clear()
        TECount = 0 : TotalTECount = 0
     End Sub


    Sub CreTEA(ByVal FCoord As String, ByVal TempF As String, _
               ByVal TCoord As String, ByVal TempT As String, ByVal Hon As String)




        LineTEA.Append(" ")
        LineTEA.Append(TCoord)
        LineTEA.Append(CreSpace(SetTEA("To座標") - LenB(TCoord), " "))

        LineTEA.Append(",")
        LineTEA.Append(CreSpace(SetTEA("To分割名"), " "))

        LineTEA.Append("(")
        LineTEA.Append(CreSpace(SetTEA("本数") - LenB(Hon), "0"))  '0詰め
        LineTEA.Append(Hon)
        LineTEA.Append(") ")

        TotalTEACount += Hon

        TEACount += 1

        If TEACount = 8 Then

            LineTEA.Append(" ")
            RecTEA.Add(LineTEA.ToString)
            LineTEA.Clear()
            LineTEA.Append(NextSpace)
            TEACount = 0

        End If
    End Sub
End Module
