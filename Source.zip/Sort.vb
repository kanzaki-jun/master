﻿Imports System
Imports System.Collections.Generic
Imports System.Linq


Module Sort
    ''' <summary>
    '''　Keyが文字列、Valueが文字列型のリストのDictionaryのソート
    ''' </summary>
    ''' <param name="Dic">ソートする対象のDictionary</param>
    ''' <remarks>KeyとValueの両方のソートをおこなう</remarks>
    Function Sort_Dic(ByVal Dic As Dictionary(Of String, List(Of String))) As Dictionary(Of String, List(Of String))

        Dim SortedDic As New Dictionary(Of String, List(Of String)) '戻り値
        Dim TempList As New List(Of String)        'Valueのソートに使用

        'Keyのソート
        'Dictionaryの内容をコピーして、List(Of KeyValuePair(Of String, Integer))に変換

        Dim pairs As New List(Of KeyValuePair(Of String, List(Of String)))(Dic)

        ' List.Sortメソッドを使ってソート
        ' (引数に比較方法を定義したメソッドを指定する)
        pairs.Sort(AddressOf CompareKeyValuePair)


        For Each TDic In pairs
            'Valueのソート
            TempList = TDic.Value
            TempList.Sort()

            '戻り値にデータ追加
            SortedDic.Add(TDic.Key, TempList)
        Next

        'ソート後のDictionaryを返す
        Return SortedDic

    End Function

    'Keyのソート部分
    Function CompareKeyValuePair(ByVal x As KeyValuePair(Of String, List(Of String)), _
                                      ByVal y As KeyValuePair(Of String, List(Of String))) As Integer
        ' Keyで比較した結果を返す
        Return String.Compare(x.Key, y.Key)

    End Function

End Module
