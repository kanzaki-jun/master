﻿Option Strict On

Imports System.Text

Module Publics

#Region "レコードデータ"

    Public Rec1 As String
    Public Rec2 As New List(Of String)
    Public Rec3 As New List(Of String)
    Public Rec4 As New List(Of String)
    Public Rec5 As New List(Of String)
    Public Rec6 As New List(Of String)
    Public Rec7 As New List(Of String)
    Public Rec9 As New List(Of String)

    Public Rec3_4_Data As New Dictionary(Of String, List(Of String))
    Public SortedRec3_4_Data As New Dictionary(Of String, List(Of String))
    Public Rec6_Data As New Dictionary(Of String, List(Of String))
    Public SortedRec6_Data As New Dictionary(Of String, List(Of String))
    Public Rec7_DataList As New LinkedList(Of String())     '
#End Region

#Region "データベース"

    Public Const UserID As String = "dreamprj"
    Public Const Password As String = "dreamprj"
    Public Const Source As String = "x1svr"

#End Region


    Public Kouban As String = "X16-338"        '工番
    Public DBKouban As String                        'データベース用の工番
    Public Gunban As String = "B01"            '群番
    Public Job As Integer = 120                'JobNo.
    Public CustomerName As String                    '客先名

    Public Const RecordLength As Integer = 158              'レコード長

    Public ReadList As New List(Of String)                      'E3からの出力されたテキストファイルのデータを一つにまとめたもの
    Public ArrCoord() As String                                 '座標名と分割名をまとめた配列。(0)はNothing
    Public Seq As New List(Of String)                           '器具番号まとめ
    Public IndexToArea As New Dictionary(Of String, String)     'インデックスをキー、エリアを値とするDictionary
    Public CSVDataDic As New Dictionary(Of String, String())    'Key:座標名(空白含む)+分割名　Value:配列{略称,形式,端子種類,器具番号}

    Public MarkBand As String           'マークバンド
    Public FB As String                 '前背
    Public SQ As String                 '線サイズ
    Public LnKnd As String              '線種
    Public Color As String              'カラー


    '基本的にLFSignとLTSignは同一
    Public LFSign As String             'From線符号
    Public LTSign As String             'To線符号

    'From
    Public FromCoord As String          '座標名
    Public FromPin As String            '端子番号
    Public FromClr As String            'カラー
    Public FromTemp As String           '仮座標

    'To
    Public ToCoord As String            '座標名
    Public ToPin As String              '端子番号
    Public ToClr As String              'カラー
    Public ToTemp As String             '仮座標


    Public Rec4flg As Boolean = False
    Public Rec6flg As Boolean = False

    Public LastFlg As Boolean = False                                '最終行フラグ
    Public FirstInFlg As Boolean = False
    Public FirstOutFlg As Boolean = False                            '初めて出力したかどうかのフラグ(出力していなければFalse、出力したらTrue)

    Public Const MojiBaseMax = 24                                   '文字板の最大数



#Region "パス関係"

    Public Const CoordDPath As String = "C:\Users\94503\Desktop\配線革新資料"             '上記CSVがあるフォルダへのパス
    Public Const CSVDataDPath As String = "C:\Users\94503\Desktop\配線革新資料"           '上記CSVがあるフォルダへのパス

    Public CoordPath As String                                                          '読み込む座標名＋分割名のCSVへのパス
    Public CSVDataPath As String                                                        '座標名、略称、形式、端子種類、器具番号のデータがあるCSVへのパス


    Public Const AreaCSVPath As String = "C:\Users\94503\Desktop\配線革新資料\area.csv"   'エリアとインデックスの対応表へのパス 
    Public Const E3Path As String = "C:\Users\94503\Desktop\配線革新資料"                 'E3出力先フォルダパス

    Public Const OutPutPath As String = "C:\Users\94503\Desktop\OutPut\"                         '出力先パス

    Public Const SPCPath As String = "C:\Users\94503\Desktop\配線革新\SPC.csv"

    Public Const XlsxPath As String = "C:\Users\94503\Desktop\配線革新\マークバンド.xlsx"
    Public Const SheetName As String = "工番群番マーク"
#End Region


#Region "読み込みDic1"
    Public Dic1 As New Dictionary(Of String, String)

    Public Area1() As Integer = {2, 4, 3, 10, 4, 4}
    Public AreaName1() As String = {"布線台番号", "ジョブNo", "インデックス", "工番", "群番", "盤No"}

#End Region


#Region "読み込みDic2"
    Public Dic2 As New Dictionary(Of String, String)
    Public Area2() As Integer = { _
                                        4, 5, 4, 2, 5, _
                                        10, 7, 8, 2, 2, 2, 3, _
                                        10, 7, 8, 2, 2, 2, 3, _
                                        2, 2, _
                                        1, 3, 4, 3, 7, 2, _
                                        1, 3, 4, 3, 7, 2 _
                                  }
    Public AreaName2() As String = { _
                                        "シリーズNo", "線種", "線サイズ", "色", "線長さ", _
                                        "FT線番号", "FT機器座標", "FT器具端子", "FT色別", "FTマーク", "FT端子種", "FT布線アドレス", _
                                        "TT線番号", "TT機器座標", "TT器具端子", "TT色別", "TTマーク", "TT端子種", "TT布線アドレス", _
                                        "逆文字F", "逆文字T", _
                                        "FW曲方向", "FW曲げ位置", "FWバイパス位置", "FW端末長さ", "FW機器座標", "FW接続本数", _
                                        "TW曲方向", "TW曲げ位置", "TWバイパス位置", "TW端末長さ", "TW機器座標", "TW接続本数" _
                                    }

    'Public AreaRec1() As Integer = {3, 1, 3, 4, 4, 2, 2, 2, 8, 2, 24, 30, 10, 6, 3, 3, 34}
#End Region


#Region "SQコード"

    'E3出力データの布線行の線サイズから
    Public SQCord As New Dictionary(Of String, String) From
        {
            {"0.3", "01"},
            {"0.5", "02"},
            {"0.75", "04"},
            {"0.9", "06"},
            {"1.25", "08"},
            {"2.0", "10"},
            {"3.5", "20"},
            {"5.5", "40"},
            {"8.0", "80"}
        }

#End Region


#Region "撚りコード"


Public YoriCord As New Dictionary(Of String, String) From
        {
            {"KIV", "02"}
        }


#End Region


#Region "色コード"

    'E3出力データの布線行の色からレコード３の色コードへ変換するDictionary

    Public ColorCord As New Dictionary(Of String, String) From
        {
            {"B", "01"},
            {"R", "02"},
            {"D", "04"},
            {"Y", "08"},
            {"G", "10"},
            {"W", "20"}
        }

#End Region


#Region "共通ヘッダDic"

    Public ComDic As New Dictionary(Of String, Integer) From
        {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白", 3},
            {"子番号", 4},
            {"盤No", 4}
        }

#End Region


#Region "Record Dic1"

    Public RecDic1 As New Dictionary(Of String, Integer) From
        {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白1", 3},
            {"子番号", 4},
            {"盤No", 4},
            {"前背", 2},
            {"SCT", 2},
            {"ゾーン", 2},
            {"工番", 8},
            {"?", 2},
            {"空白2", 24},
            {"客先名", 30},
            {"客先コード", 10},
            {"空白3", 6},
            {"座標数", 3},
            {"マークバンド", 3},
            {"空白4", 48}
        }

#End Region


#Region "Record Dic2"

    '座標名、分割名、略称、形式、フレーム、器具No、空白3はレコード内に３つ
    'Public RecDic2 As New Dictionary(Of String, Integer) From
    '    {
    '        {"ジョブNo", 3},
    '        {"レコードNo", 1},
    '        {"シリーズNo", 3},
    '        {"空白1", 3},
    '        {"子番号", 4},
    '        {"盤No", 4},
    '        {"前背", 2},
    '        {"SCT", 2},
    '        {"ゾーン", 2},
    '        {"空白2", 4},
    '        {"座標名", 6},
    '        {"分割名", 1},
    '        {"略称", 4},
    '        {"形式", 12},
    '        {"フレーム", 5},
    '        {"空白3", 3},
    '        {"端子種類", 2},
    '        {"空白4", 31}
    '    }



    Public SetDic2 As New Dictionary(Of String, Integer) From
    {
                {"座標名", 6},
                {"分割名", 1},
                {"略称", 4},
                {"形式", 12},
                {"フレーム", 5},
                {"空白", 3},
                {"端子種類", 2}
    }

    Public Const Set2Area = 33

    Public Set2() As Integer = { _
                                    SetDic2("座標名"), _
                                    SetDic2("分割名"), _
                                    SetDic2("略称"), _
                                    SetDic2("形式"), _
                                    SetDic2("フレーム"), _
                                    SetDic2("空白"), _
                                    SetDic2("端子種類") _
                                }

    Public RecDic2 As New Dictionary(Of String, Object) From
    {
                {"ジョブNo", 3},
                {"レコードNo", 1},
                {"シリーズNo", 3},
                {"空白1", 3},
                {"子番号", 4},
                {"盤No", 4},
                {"前背", 2},
                {"SCT", 2},
                {"ゾーン", 2},
                {"空白2", 4},
                {"1", Set2},
                {"2", Set2},
                {"3", Set2},
                {"空白3", 31}
    }

#End Region


#Region "Record Dic3"

    Public Rec3Cnt As Integer = 0        '作成したデータ数のカウント
    Public Row3Cnt As Integer = 1        '行数のカウント
    Public Line3 As New StringBuilder   '作成したデータを保存しておくオブジェクト

    Public SetDic3 As New Dictionary(Of String, Integer) From
    {
                {"SQコード", 2},
                {"肉厚コード", 2},
                {"撚りコード", 2},
                {"色コード", 2}
    }

    Public Const Set3Area = 8

    Public Set3() As Integer = { _
                                SetDic3("SQコード"), _
                                SetDic3("肉厚コード"), _
                                SetDic3("撚りコード"), _
                                SetDic3("色コード")
                            }

    'SQコード、肉厚コード、撚りコード、色コードは1レコードにつき10個
    Public RecDic3 As New Dictionary(Of String, Object) From
    {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白1", 3},
            {"子番号", 4},
            {"盤No", 4},
            {"前背", 2},
            {"SCT", 2},
            {"ゾーン", 2},
            {"空白2", 8},
            {"1", Set3},
            {"2", Set3},
            {"3", Set3},
            {"4", Set3},
            {"5", Set3},
            {"6", Set3},
            {"7", Set3},
            {"8", Set3},
            {"9", Set3},
            {"10", Set3},
            {"空白3", 46}
    }


#End Region


#Region "Record Dic4"

    Public Rec4Cnt As Integer = 0       '作成したデータ数のカウント
    Public Row4Cnt As Integer = 1       '行数のカウント
    Public Line4 As New StringBuilder   '作成したデータを保存しておくオブジェクト




    Public State4 As String  'データの入力状態("From" or "To")


    Public SetDic4 As New Dictionary(Of String, Integer) From
    {
                {"仮座標", 3},
                {"カラー", 1},
                {"カール", 1},
                {"空白", 1},
                {"端子番号", 8},
                {"ベンチNo", 2}
    }

    Public Const Set4Area = 16

    Public Set4() As Integer = { _
                                SetDic4("仮座標"), _
                                SetDic4("カラー"), _
                                SetDic4("カール"), _
                                SetDic4("空白"), _
                                SetDic4("端子番号"), _
                                SetDic4("ベンチNo")
                            }

    '仮座標,カラー,カール,空白3,端子番号,ベンチNoは１レコードにつき3*2(FromTo)個
    '線符号は3個
    Public RecDic4 As New Dictionary(Of String, Object) From
    {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白1", 3},
            {"子番号", 4},
            {"盤No", 4},
            {"前背", 2},
            {"SCT", 2},
            {"ゾーン", 2},
            {"空白2", 8},
            {"To1", Set4},
            {"From1", Set4},
            {"線符号1", 10},
            {"To2", Set4},
            {"From2", Set4},
            {"線符号2", 10},
            {"To3", Set4},
            {"From3", Set4},
            {"線符号3", 10}
    }

#End Region


#Region "Record Dic5"

    '器具番号はレコード内に10個
    Public RecDic5 As New Dictionary(Of String, Integer) From
    {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白1", 3},
            {"子番号", 4},
            {"盤No", 4},
            {"前背", 2},
            {"9999", 4},
            {"空白2", 4},
            {"器具番号1", 10},
            {"器具番号2", 10},
            {"器具番号3", 10},
            {"器具番号4", 10},
            {"器具番号5", 10},
            {"器具番号6", 10},
            {"器具番号7", 10},
            {"器具番号8", 10},
            {"器具番号9", 10},
            {"器具番号10", 10},
            {"空白3", 30}
    }

#End Region


#Region "Record Dic6"

    Public Rec6Cnt As Integer = 0       '作成したデータ数のカウント
    Public Row6Cnt As Integer = 1       '行数のカウント
    Public Line6 As New StringBuilder   '作成したデータを保存しておくオブジェクト
    Public State6 As String  'データの入力状態("From" or "To")

    Public SetDic6 As New Dictionary(Of String, Integer) From
    {
                {"仮座標", 3},
                {"空白", 2},
                {"端子番号", 8}
    }

    Public Const Set6Area = 13

    Public Set6() As Integer = { _
                                SetDic6("仮座標"), _
                                SetDic6("空白"), _
                                SetDic6("端子番号")
                            }


    '仮座標,空白3,端子番号は3*2個
    '線符号、カラーは3個
    '器具番号はレコード内に10個
    Public RecDic6 As New Dictionary(Of String, Object) From
    {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白1", 3},
            {"子番号", 4},
            {"盤No", 4},
            {"前背", 2},
            {"SCT", 2},
            {"ゾーン", 2},
            {"空白2", 7},
            {"電線種", 5},
            {"太さ", 3},
            {"線色", 2},
            {"From1", Set6},
            {"To1", Set6},
            {"線符号1", 10},
            {"カラー1", 2},
            {"From2", Set6},
            {"To2", Set6},
            {"線符号2", 10},
            {"カラー2", 2},
            {"From3", Set6},
            {"To3", Set6},
            {"線符号3", 10},
            {"カラー3", 2},
            {"空白3", 3}
    }

#End Region


#Region "Record Dic7"

    Public Rec7Cnt As Integer = 0       '作成したデータ数のカウント
    Public Row7Cnt As Integer = 1       '行数のカウント
    Public Line7 As New StringBuilder
    Public SetDic7 As New Dictionary(Of String, Integer) From
    {
                {"端子No", 4},
                {"文字板", 10}
    }

    Public Const Set7Area = 14

    Public Set7() As Integer = { _
                                SetDic7("端子No"), _
                                SetDic7("文字板")
                            }

    '端子No、文字板は6個
    Public RecDic7 As New Dictionary(Of String, Object) From
    {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白1", 3},
            {"子番号", 4},
            {"盤No", 4},
            {"前背", 2},
            {"9999", 4},
            {"空白2", 8},
            {"形式", 10},
            {"座標", 4},
            {"1", Set7},
            {"2", Set7},
            {"3", Set7},
            {"4", Set7},
            {"5", Set7},
            {"6", Set7},
            {"空白3", 28}
    }

#End Region


#Region "Record Dic9"

    Public Rec9Cnt As Integer = 1

    Public CountRec9 As New Dictionary(Of String, Integer) From
    {
            {"0.3", 0},
            {"0.5", 0},
            {"1.25", 0},
            {"2.0", 0},
            {"3.5", 0},
            {"5.5", 0},
            {"8", 0},
            {"14", 0},
            {"22", 0},
            {"38", 0},
            {"60", 0},
            {"100", 0},
            {"150", 0},
            {"その他", 0},
            {"1C", 0},
            {"2C", 0},
            {"Fu", 0}
    }

    Public RecDic9 As New Dictionary(Of String, Integer) From
    {
            {"ジョブNo", 3},
            {"レコードNo", 1},
            {"シリーズNo", 3},
            {"空白1", 3},
            {"子番号", 4},
            {"盤No", 4},
            {"9詰", 6},
            {"FB", 2},
            {"空白2", 4},
            {"0.3", 5},
            {"0.5", 5},
            {"1.25", 5},
            {"2.0", 5},
            {"3.5", 5},
            {"5.5", 5},
            {"8", 5},
            {"14", 5},
            {"22", 5},
            {"38", 5},
            {"60", 5},
            {"100", 5},
            {"150", 5},
            {"その他", 5},
            {"1C", 5},
            {"2C", 5},
            {"Fu", 5},
            {"扉", 4},
            {"空白3", 9},
            {"空白4", 30}
    }

#End Region


End Module
