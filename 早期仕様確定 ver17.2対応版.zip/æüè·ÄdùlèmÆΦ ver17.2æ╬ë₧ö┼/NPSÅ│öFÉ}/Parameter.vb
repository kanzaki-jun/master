﻿Imports BricscadApp
Imports BricscadDb

Module Parameter
    'ﾌｧｲﾙ保存場所
    Public P_sPrgPath As String                     'ｼｽﾃﾑﾃﾞｰﾀ保存場所
    Public P_sDatFld As String                      'ﾃﾞｰﾀ保存場所(共通)
    Public P_sSangyoFld As String                   '産業ﾃﾞｰﾀ保存場所
    Public P_sMizuFld As String                     '水ﾃﾞｰﾀ保存場所(未定)
    Public P_sDentetuFld As String                  '電鉄ﾃﾞｰﾀ保存場所(未定)
    Public P_sDenryokuFld As String                 '電力ﾃﾞｰﾀ保存場所
    Public P_sDouroFld As String                    '道路ﾃﾞｰﾀ保存場所

    Public P_sBlkPath As String                     'ﾌﾞﾛｯｸ保存場所
    Public P_sWakPath As String                     '枠ﾌｧｲﾙ保存場所
    Public Tmpnam As String                         'テンプレートファイル名

    'Public txtPath As String = "C:\BanData.txt"                '盤情報ファイル保存場所、ファイル名
    Public txtPath As String = "BanData.txt"                '盤情報ファイル保存場所、ファイル名
    Public TKbn As String                                   'ファイルタイトル用変数(工番名)
    Public TGbn As String                                   'ファイルタイトル用変数(群番名)
    Public TKi As String                                    'フォルダ用変数(期)
    Public txtNam As String                         '群番ごとの配列基礎仕様マスターファイル名
    Public txtkisoNam As String                    '基礎図全体(製品名称等)の情報のマスターファイル名
    Public kisodata(5) As String                     'txtkisoNamから読み取った情報を代入する配列
    Public fileNumber As Integer                    'ファイル番号
    Public ArrayBan() As String                     '盤情報ファイルの1行の要素数
    Public ArrayHokyo() As String                   '補強枠情報ファイルの1行の要素数
    Public P_sHokyoDat(,) As String                 '補強枠情報配列
    Public picPath As String = "testHokyo\"
    Public txtPath2 As String = "HokyoData.txt"
    Public Loadflg As Boolean                       'HokyoData用読込フラグ
    Public Ovrlapflg As Boolean                     '作図するファイルと同名のファイルが既に開かれているか確認するためのフラグ
    Public PageCnt As Integer                       '今のページ(同名ファイル探しに使用)

    'ｾｸﾞﾒﾝﾄ名
    Public Const P_sSangyoSeg As String = "産業"    '産業ｾｸﾞﾒﾝﾄ
    Public Const P_sMizuSeg As String = "水"        '水ｾｸﾞﾒﾝﾄ
    Public Const P_sDentetuSeg As String = "電鉄"   '電鉄ｾｸﾞﾒﾝﾄ
    Public Const P_sDenryokuSeg As String = "電力"  '電力ｾｸﾞﾒﾝﾄ
    Public Const P_sDouroSeg As String = "道路"     '道路ｾｸﾞﾒﾝﾄ


    '盤情報
    Public P_sBanDat(,) As String '= New String(,) {} '{ _
    '{"101", "102", "103", "104", "105", "106", "107", "108", "109"}, _
    '{"直流電源収納盤", "特高現場監視盤", "所内変圧器盤", "No.1変圧器2次盤", "F11/配電線盤", "母線連絡盤", _
    '    "No.2変圧器2次盤", "F21/配電線盤", "F23/配電線盤"}, _
    '{"", "", "", "", "F12/配電線盤", "", "", "F22/配電線盤", "F24/配電線盤"}, _
    '{"", "", "", "", "", "", "", "", ""}, _
    '{"CP-176558 R0", "CP-176556 R0", "CP-175393 R1", "CP-175376 R0", "XP15-0186-BD005", "CP-175390 R0", _
    '    "CP-176376 R0", "XP15-0186-BD005", "XP15-0186-BD005"}, _
    '{"XP15-0186-BC001", "XP15-0186-BC002", "XP15-0186-BC003", "XP15-0186-BC004", "XP15-0186-BC005", _
    '    "XP15-0186-BC006", "XP15-0186-BC004", "XP15-0186-BC005", "XP15-0186-BC005"}, _
    '{"", "", "JEM1425", "JEM1425", "JEM1425", "JEM1425", "JEM1425", "JEM1425", "JEM1425"}, _
    '{"", "", "CY", "CW", "CW", "CW", "CW", "CW", "CW"}, _
    '{"IP2XW", "IP2XW", "IP2XW", "IP2XW", "IP2XW", "IP2XW", "IP2XW", "IP2XW", "IP2XW"}, _
    '{"", "", "", "", "", "", "", "", ""}, _
    '{"", "", "7.2kV", "7.2kV", "7.2kV", "7.2kV", "7.2kV", "7.2kV", "7.2kV"}, _
    '{"60Hz", "60Hz", "60Hz", "60Hz", "60Hz", "60Hz", "60Hz", "60Hz", "60Hz"}, _
    '{"", "", "22kV", "22kV", "22kV", "22kV", "22kV", "22kV", "22kV"}, _
    '{"", "", "60kV", "60kV", "60kV", "60kV", "60kV", "60kV", "60kV"}, _
    '{"", "", "6A", "6A", "6A", "6A", "6A", "6A", "6A"}, _
    '{"NP-6330E", "NP-6330E", "NPS-99538", "NPS-99538", "NPS-99538", "NPS-99538", "NPS-99538", "NPS-99538", "NPS-99538"}, _
    '{"防塵", "防塵", "防塵", "防塵", "防塵", "防塵", "防塵", "防塵", "防塵"}, _
    '{"120度", "120度", "120度", "120度", "120度", "120度", "120度", "120度", "120度"}, _
    '{"1550kg", "1300kg", "1400kg", "1200kg", "1100kg", "1300kg", "1200kg", "1100kg", "1200kg"}, _
    '{"納入外（表示）", "納入外（表示）", "", "", "", "", "", "", ""}, _
    '{"納入外（表示）", "納入外（表示）", "", "", "", "", "", "", ""}, _
    '{"1200", "1200", "900", "800", "700", "1000", "800", "700", "700"}, _
    '{"2300", "2300", "2300", "2300", "2300", "2300", "2300", "2300", "2300"}, _
    '{"2300", "2300", "2300", "2300", "2300", "2300", "2300", "2300", "2300"}, _
    '{"", "", "天井", "天井", "背面扉", "天井", "", "", ""}, _
    '{"1", "2", "3", "4", "5", "6", "7", "8", "9"}}
    Public P_sBanDat_cp(,) As String
    Public P_sBanDat2 As String
    Public Const pc_BanNoRow As Integer = 0         '盤No.行
    Public Const pc_Fullname As Integer = 1
    Public Const pc_NP1Row As Integer = 2           '名称(1)行
    Public Const pc_NP2Row As Integer = 3           '名称(2)行
    Public Const pc_NP3Row As Integer = 4           '名称(3)行
    Public Const pc_DRZbnRow As Integer = 5         '側面図番行
    Public Const pc_DoorZbnRow As Integer = 6       '盤面図番行
    Public Const pc_BlkSKRow As Integer = 7            'ブロックスケルトン行
    Public Const pc_KikakuNoRow As Integer = 8      '規格番号行
    Public Const pc_BoxTypRow As Integer = 9        'ｽｲｯﾁｷﾞﾔの形行
    Public Const pc_HogoBoxRow As Integer = 10       '保護等級(閉鎖箱)行
    Public Const pc_HogoItaRow As Integer = 11       '保護等級(仕切板)行
    Public Const pc_TeikakuVRow As Integer = 12     '定格電圧行
    Public Const pc_FreqRow As Integer = 13        '周波数行
    Public Const pc_ComFreqRow As Integer = 14      '商用周波行
    Public Const pc_ImplsRow As Integer = 15        '雷ｲﾝﾊﾟﾙｽ行
    Public Const pc_ClsRow As Integer = 16          '絶縁階級行
    Public Const pc_NPRow As Integer = 17           '製造者銘板番号行
    Public Const pc_KankyouRow As Integer = 18      '環境条件行
    Public Const pc_DoorOpnRow As Integer = 19      '扉開放角度行
    Public Const pc_JyuryoRow As Integer = 20       '盤概略質量行
    Public Const pc_NoHairetuRow As Integer = 21    '納入外配列行
    Public Const pc_NoKisoRow As Integer = 22       '納入外基礎行
    Public Const pc_BanWRow As Integer = 23         '盤寸法(幅)行
    Public Const pc_BanHRow As Integer = 24         '盤寸法(高さ)行
    Public Const pc_BanDRow As Integer = 25         '盤寸法(奥行)行
    Public Const pc_KankiRow As Integer = 26        '換気箱行          
    Public Const pc_FDoorRow As Integer = 27        '正面扉の扉形状行   'ﾃﾞｰﾀ行追加　'16.12.1 松本
    Public Const pc_RDoorRow As Integer = 28        '背面扉の扉形状行   '←
    Public Const pc_FTotteRow As Integer = 29       '正面扉の把手行     '←
    Public Const conD1 As String = "1段扉"
    Public Const conD2 As String = "2段扉"
    Public Const conD3 As String = "3段扉"
    Public Const conD4 As String = "4段扉"
    Public Const conBU As String = "上母線"
    Public Const conBM As String = "中母線"
    Public Const conDR As String = "扉"
    Public Const conPR As String = "背板"
    Public Const conDMcb1 As String = "扉（中MCB）"
    Public Const conDMcb2 As String = "扉（中MCB）2"
    Public Const conPMcb1 As String = "背板（中MCB）"
    Public Const conPMcb2 As String = "背板（中MCB）2"

    Public Const conHDR As String = "引掛扉"
    Public Const conN As String = "無"


    'Public Const pc_SeigyoAnaRow As Integer = 25
    'Public Const pc_SyukairoAnaRow As Integer = 28
    'Public Const pc_BanDataCopy As Integer = 25                        'ﾃﾞｰﾀ行追加に伴い行番号変更 '16.12.1 松本
    'Public Const pc_BanDataPaste As Integer = 26                       '
    'Public Const pc_BanDataDelete As Integer = 27                      '
    Public Const pc_BanDataCopy As Integer = 30                         '←
    Public Const pc_BanDataPaste As Integer = 31                       '←
    Public Const pc_BanDataDelete As Integer = 32                       '←

    Public BanDataArray() As String     '配列基礎仕様表で盤データのコピーをした際に値を代入する配列
    Public BanDataArray2() As String     '基礎図表で盤データのコピーをした際に値を代入する配列
    Public P_sBanDatK(,) As String       '列入替の影響で基礎図表の盤を並び替える際に、基礎図表のデータを一時保存するための配列

    'BricsCAD ｵﾌﾞｼﾞｪｸﾄ変数の宣言
    Public acadApp As AcadApplication   'ｱﾌﾟﾘｹｰｼｮﾝｵﾌﾞｼﾞｪｸﾄ
    Public acadDoc As AcadDocument      'ﾄﾞｷｭﾒﾝﾄｵﾌﾞｼﾞｪｸﾄ
    Public acadUtl As AcadUtility       'ﾕｰﾃｨﾘﾃｨｰｵﾌﾞｼﾞｪｸﾄ
    Public moSpace As AcadModelSpace    'ﾓﾃﾞﾙ空間ｵﾌﾞｼﾞｪｸﾄ

    Public ViewPort As Object 'アクティブビューポートオブジェクト

    Public P_sKbn As String      '工番
    Public P_sKbnNam As String   '工番("-"付き)
    Public P_sGbn As String      '群番
    Public P_sSegment As String  'ｾｸﾞﾒﾝﾄ


    'Public test As Application


    '--------------------------------------------20160810いろいろ持ってくる-----------------
    Public KoubanName As String    '工番名
    Public GunbanName As String    '群番名
    Public OkCancel As Boolean
    Public JobMode As String       '工番="",標準="UNIT",検討="TEMP"

    Public sScale As String     '縮尺
    'Public sScale2 As String
    Public sFilNam As String    '基礎図ﾌｧｲﾙ名
    Public sFilNam2 As String
    Public Kbnflg As Boolean       '工番入力フラグ
    Public Gbnflg As Boolean       '群番入力フラグ

    Public stat As Integer  'FunOra8Ole

    '-----------------------------------------------
    ' Path
    '-----------------------------------------------
    Public P_PrgPath As String                  'ﾌﾟﾛｸﾞﾗﾑ
    Public P_BlkPath As String                  'ﾌﾞﾛｯｸ
    Public P_DatPath As String                  '工番ﾃﾞｰﾀ
    Public P_TmpPath As String                  '一時ﾃﾞｰﾀ
    Public P_HjnPath As String                  '標準ﾃﾞｰﾀ
    Public P_NC_Path As String                  'NC
    Public P_RmnPath As String                  'NC裏面
    Public P_LstPath As String                  '機器一覧表

    '図面テンプレート
    'Public Const Template1 = BlockPath2 & "配列図.dwt"
    'Public Const Template2 = BlockPath2 & "基礎図.dwt"
    'Public Const Template3 = BlockPath2 & "側面図.dwt"
    'Public Const Template4 = BlockPath2 & "banmen.dwt"
    Public Template1 As String
    Public Template2 As String
    Public Template3 As String
    Public Template4 As String

    Public Template10 As String      'テスト用

    Public Const conNum = 30  '最大処理可能箱数（群レベル）
    Public Const partNum = 1500  '最大処理可能機器数（箱レベル）
    Public Const Math_PI = 3.1415926 'π
    '既設ファイル読み込み用
    Public OpnAcadType As String  '開ける既設図面タイプ
    Public pkname(0 To 1000) As String  '図面名一覧



    '共通事項
    Public p_DoorTyp As String '扉形番
    Public D_Name As String   '設計担当者名
    Public CubNo(conNum) As String  '全箱No
    Public ExtCubNo(conNum) As String '納入外配列箱No
    Public ChkExt As String '納入外配列箱Noを図示するかどうか
    Public T_Hako As String 'StringGetで抜き取った盤No
    Public BaseCubNo(conNum) As String  '基礎ベースが不要な箱No
    Public ChkBase As String '納入外基礎ベースを図示するかどうか
    Public DrowBase() As Boolean '納入外の盤を図示するかどうかのフラグ
    Public DoorType As String '扉形番
    Public IO As String '屋内外
    Public KeshoType As String  '化粧板タイプ
    'Public FntLifter As String  'フロントリフタータイプ
    'Public BckLifter As String  'バックリフタータイプ
    Public FntSunpo As String  'フロント機器引出寸法
    Public BckSunpo As String  'バック機器引出寸法
    Public BaseH As String '基礎ベース突出寸法
    Public SeigyoAna As String '制御穴タイプ
    Public BaseBunkatu(conNum) As String '基礎ベース分割位置
    Public Zumen As String '図面枠タイプ
    Public Meisho As String '図面名称
    Public P_SeikanTyp As String    '製缶方式               '16.10.25 松本追加

    Public AllIdx As Integer        '配列変更時の箱数
    Public BefBox(conNum) As String '配列変更前箱番
    Public AftBox(conNum) As String '配列変更後箱番

    '箱別事項
    Public CubCnt As Integer '箱順
    Public H_CubNo(conNum) As String '箱No
    Public H_HPage(conNum) As String '配列ページ番号
    Public H_KPage(conNum) As String '基礎ページ番号
    Public H_Hz(conNum) As String '周波数
    Public H_Zetuen(conNum) As String '絶縁階級
    Public H_Kata() As String           '形（規格番号）    '16.10.14 松本追加
    Public H_Kata1(conNum) As String '形（規格番号）JEM1265
    Public H_Kata2(conNum) As String '形（規格番号）JEM1425
    Public H_DenAtu(conNum) As String '定格電圧
    Public H_Hogo1(conNum) As String '保護等級（閉鎖箱）
    Public H_Hogo2(conNum) As String '保護等級(仕切板）
    Public H_TNP(conNum) As String '定格NP（規格）
    Public H_DRZuban(conNum) As String '制作図番
    Public H_DoorZuban(conNum) As String '正面扉図番
    Public H_NP1(conNum) As String 'NP1の形
    Public H_NP2(conNum) As String 'NP2の形
    Public H_NP3(conNum) As String 'NP3の形
    Public H_NP4(conNum) As String 'NP4の形
    Public H_Jyotai(conNum) As String '使用状態
    Public H_WakuType(conNum) As String '枠タイプ
    Public H_D(conNum) As String '箱Ｄ
    Public H_H(conNum) As String '箱Ｈ
    Public H_W(conNum) As String '箱Ｗ
    Public H_WC(conNum) As String '箱Ｗのコピー
    Public H_Totte(conNum) As String '取手の形
    Public H_DoorOpen(conNum) As String '扉開放角度
    Public H_Jyuryo(conNum) As String '盤概略質量
    Public H_PowerFreq(conNum) As String    '商用周波       '05.1.19 松本追加
    Public H_Impulse(conNum) As String      '雷インパルス   '05.1.19 松本追加
    Public Const P_conNoShow = "非表示"     '納入外（非表示）識別用文字列 '16.10.20 松本追加

    Public ChkFlag As String   '納入外基礎ベースNoをベース分割に追加したかどうか用
    '="in" 追加した
    '="" 追加してない

    ' 標準ユニットテーブル用
    Public U_UnitNo As String       'ユニット番号
    Public U_DRZuban As String      '側面図図番
    Public U_CableZuban As String   'ケーブル穴図図番
    Public U_PanelZuban1 As String  '盤面図図番1
    Public U_PanelZuban2 As String  '盤面図図番2
    Public U_D As Integer           '外形寸法D
    Public U_H As Integer           '外形寸法H
    Public U_W As Integer           '外形寸法W
    Public U_SKCode As String       'ブロックSKコード
    Public U_Bikou As String        '備考

    ' ユニット選択テーブル用
    Public US_Youto As String        '設備用途
    Public US_ShuKiki As String      '収納機器名
    Public US_Shubetu As String      'SWG種別
    Public US_KATA As String         'SWG形
    Public US_UnitName As String     'ユニット名称
    Public US_CableDir As String     'ケーブル引込方向
    Public US_UnitNo As String       'ユニット番号

    ' 箱別機器仕様テーブル用
    Public PB_ID(partNum) As Integer        '機器ID
    Public PB_Code(partNum) As String       '部品コード
    Public PB_Name(partNum) As String       '品名
    Public PB_Type(partNum) As String       '形式
    Public PB_Spec(partNum) As String       '定格仕様
    Public PB_WappenNo(partNum) As String   'ワッペン番号
    Public PB_D(partNum) As Double          '取付位置X
    Public PB_H(partNum) As Double          '取付位置Y
    Public PB_W(partNum) As Double          '取付位置Z
    Public PB_Muki(partNum) As String       '取付向き
    Public PB_Angle(partNum) As Integer     '取付角度
    Public PB_Biko(partNum) As String       '備考
    Public PB_Pitch(partNum) As String      'ピッチ

    ' 箱別器具仕様テーブル用
    'Public PP_Place As Integer              '扉位置
    'Public PP_ID(partNum) As Integer        '機器ID
    'Public PP_Code(partNum) As String       '部品コード
    'Public PP_Name(partNum) As String       '品名
    'Public PP_Type(partNum) As String       '形式
    'Public PP_Spec(partNum) As String       '定格仕様
    'Public PP_WappenNo(partNum) As String   'ワッペン番号
    'Public PP_X(partNum) As Integer         '取付位置X
    'Public PP_Y(partNum) As Integer         '取付位置Y
    'Public PP_BackFlag(partNum) As Integer  '裏面フラグ

    ' 部品マスタテーブル用
    Public BM_ID As Integer        '機器ID
    Public BM_Code As String       '部品コード
    Public BM_Name As String       '品名
    Public BM_Type As String       '形式
    Public BM_Spec As String       '定格仕様
    Public BM_Biko As String       '備考
    Public BM_Weight As Integer    '重量
    Public BM_WappenNo As String   'ワッペン番号
    Public BM_Level As Integer      '標準レベル

    '配列・基礎・側面ページテーブル用
    Public P_Kouban As String       '工番
    Public P_Gunban As String       '群番
    Public P_Page As Integer        'ページ番号
    Public P_Hakoban As String      '箱番
    Public P_Zuban As String        '図番
    Public P_kind As String         '種類（側面のみ）

    '選択肢の項目
    '   98-11-16 DB用定数追加 S.Toyo
    Public Const DoorType_1 = "PKA" '扉形番
    Public Const DoorType_2 = "PKB" '扉形番
    Public Const DoorType_3 = "PKC" '扉形番
    Public Const DoorType_4 = "PJA" '扉形番
    Public Const DoorType_5 = "PJB" '扉形番
    Public Const DoorType_6 = "PJC" '扉形番
    Public Const DoorType_7 = "A"   '扉形番
    Public Const DoorType_8 = "B"   '扉形番
    Public Const DoorType_9 = "C"   '扉形番
    Public Const H_Totte_1 = "左把手ＬＴ（標準＝外回転）", V_H_Totte_1 = "LT"   '取手の形
    Public Const H_Totte_2 = "右把手ＲＴ（標準＝外回転）", V_H_Totte_2 = "RT"   '取手の形
    Public Const H_Totte_3 = "両開ＷＯ（標準＝外回転）", V_H_Totte_3 = "WO"     '取手の形
    Public Const H_Totte_4 = "その他ＯＴ", V_H_Totte_4 = "OT"                  '取手の形
    Public Const H_Totte_5 = "左把手ＲＬＴ（逆＝内回転）", V_H_Totte_5 = "RLT"  '取手の形
    Public Const H_Totte_6 = "右把手ＲＲＴ（逆＝内回転）", V_H_Totte_6 = "RRT"  '取手の形
    Public Const H_Totte_7 = "両開ＲＷＯ（逆＝内回転）", V_H_Totte_7 = "RWO"    '取手の形
    Public Const H_Totte_8 = "両開ＷＯ２（標準＝外回転）", V_H_Totte_8 = "WO2"  '取手の形
    Public Const H_Totte_9 = "両開ＲＷＯ２（逆＝内回転）", V_H_Totte_9 = "RWO2" '取手の形
    Public Const KeshoType_1 = "板厚２．３ｔ", V_KeshoType_1 = "2.3T"   '化粧板タイプ
    Public Const KeshoType_2 = "板厚３．２ｔ", V_KeshoType_2 = "3.2T"   '化粧板タイプ
    Public Const KeshoType_3 = "５０巾", V_KeshoType_3 = "50W"          '化粧板タイプ
    Public Const KeshoType_4 = "２５巾", V_KeshoType_4 = "25W"          '化粧板タイプ
    Public Const Lifter_1 = "LG-T1"     'リフタータイプ
    Public Const Lifter_2 = "LG-T2"     'リフタータイプ
    Public Const Lifter_3 = "LG-T11"    'リフタータイプ
    Public Const Lifter_4 = "LG-T12"    'リフタータイプ
    Public Const Lifter_5 = "LG-T19"    'リフタータイプ
    Public Const Lifter_6 = "LG-T31"    'リフタータイプ
    Public Const Lifter_7 = "LG-T32"    'リフタータイプ
    Public Const Lifter_8 = "LG-T33"    'リフタータイプ
    Public Const Lifter_9 = "LG-T34"    'リフタータイプ
    Public Const Lifter_10 = "LG-T35"   'リフタータイプ
    Public Const Lifter_11 = "LG-T36"   'リフタータイプ
    Public Const Lifter_12 = "LG-T37"   'リフタータイプ
    Public Const Lifter_13 = "LG-T38"   'リフタータイプ
    Public Const Lifter_14 = "LG-T39"   'リフタータイプ
    Public Const Lifter_15 = "LG-T40"   'リフタータイプ
    Public Const Lifter_16 = "LG-T40F"  'リフタータイプ
    Public Const Lifter_17 = "LG-T39F"  'リフタータイプ
    Public Const Lifter_18 = "LG-TK1"   'リフタータイプ
    Public Const Lifter_19 = "LG-TK2"   'リフタータイプ
    Public Const Lifter_20 = "LG-T1S"   'リフタータイプ
    Public Const SeigyoAna_1 = "無", V_SeigyoAna_1 = ""                '制御穴タイプ
    'Public Const SeigyoAna_2 = "標準用：左ＦＬ（正面側）", V_SeigyoAna_2 = "FL" '制御穴タイプ
    'Public Const SeigyoAna_3 = "標準用：右ＦＲ（正面側）", V_SeigyoAna_3 = "FR" '制御穴タイプ
    'Public Const SeigyoAna_4 = "標準用：左ＲＬ（背面側）", V_SeigyoAna_4 = "RL" '制御穴タイプ
    'Public Const SeigyoAna_5 = "標準用：右ＲＲ（背面側）", V_SeigyoAna_5 = "RR" '制御穴タイプ
    'Public Const SeigyoAna_6 = "F-PAC用：左ＦＬ（正面側）", V_SeigyoAna_6 = "FL" '制御穴タイプ
    'Public Const SeigyoAna_7 = "F-PAC用：右ＦＲ（正面側）", V_SeigyoAna_7 = "FR" '制御穴タイプ
    'Public Const SeigyoAna_8 = "F-PAC用：左ＲＬ（背面側）", V_SeigyoAna_8 = "RL" '制御穴タイプ
    'Public Const SeigyoAna_9 = "F-PAC用：右ＲＲ（背面側）", V_SeigyoAna_9 = "RR" '制御穴タイプ
    'Public Const SeigyoAna_10 = "S-PAC7用：左ＦＬ（正面側）", V_SeigyoAna_10 = "FL" '制御穴タイプ
    'Public Const SeigyoAna_11 = "S-PAC7用：右ＦＲ（正面側）", V_SeigyoAna_11 = "FR" '制御穴タイプ
    'Public Const SeigyoAna_12 = "S-PAC7用：左ＲＬ（背面側）", V_SeigyoAna_12 = "RL" '制御穴タイプ
    'Public Const SeigyoAna_13 = "S-PAC7用：右ＲＲ（背面側）", V_SeigyoAna_13 = "RR" '制御穴タイプ
    Public Const SeigyoAna_2 = "COMPA(左優先)", V_SeigyoAna_2 = "CFL" '制御穴タイプ
    Public Const SeigyoAna_3 = "COMPA(右優先)", V_SeigyoAna_3 = "CFR" '制御穴タイプ
    Public Const SeigyoAna_4 = "F-PAC(左優先)", V_SeigyoAna_4 = "FFL" '制御穴タイプ
    Public Const SeigyoAna_5 = "F-PAC(右優先)", V_SeigyoAna_5 = "FFR" '制御穴タイプ
    Public Const SeigyoAna_6 = "S-PAC7(左優先)", V_SeigyoAna_6 = "SFL" '制御穴タイプ
    Public Const SeigyoAna_7 = "S-PAC7(右優先)", V_SeigyoAna_7 = "SFR" '制御穴タイプ




    Public Const H_TNP_1 = "高圧ＪＨ（和）<6449>", V_H_TNP_1 = "JH"         '定格NP（規格）
    Public Const H_TNP_2 = "低圧ＪＬ（和）<S-9878>", V_H_TNP_2 = "JL"       '定格NP（規格）
    Public Const H_TNP_3 = "コンスタＪＣ（和）<S-9881>", V_H_TNP_3 = "JC"   '定格NP（規格）
    Public Const H_TNP_4 = "ＢＡ盤<6330E>", V_H_TNP_4 = "BA"               '定格NP（規格）
    Public Const H_TNP_5 = "高圧ＥＨ（英）<6449E>", V_H_TNP_5 = "EH"        '定格NP（規格）
    Public Const H_TNP_6 = "低圧ＥＬ（英）<S-9879>", V_H_TNP_6 = "EL"       '定格NP（規格）
    Public Const H_TNP_7 = "コンスタEC (英)", V_H_TNP_7 = "EC"              '定格NP（規格）
    Public Const H_TNP_8 = "他", V_H_TNP_8 = ""                            '定格NP（規格）
    Public Const H_TNP_9 = "高圧ＪＨ（和）<S-99538>", V_H_TNP_9 = "JH2"     '定格NP（規格）'05.1.13 松本追加
    Public Const H_Jyotai_1 = "一般ＮＯＲ", V_H_Jyotai_1 = "NOR"        '使用状態
    Public Const H_Jyotai_2 = "防塵ＢＪＩ", V_H_Jyotai_2 = "BJI"        '使用状態
    Public Const H_Jyotai_3 = "耐塵ＴＪＩ", V_H_Jyotai_3 = "TJI"        '使用状態
    Public Const H_Jyotai_4 = "防滴ＢＴＥ", V_H_Jyotai_4 = "BTE"        '使用状態
    Public Const H_Jyotai_5 = "防雪ＢＳＥ", V_H_Jyotai_5 = "BSE"        '使用状態
    Public Const H_Jyotai_6 = "耐熱温帯ＴＲＯ", V_H_Jyotai_6 = "TRO"    '使用状態
    Public Const H_Jyotai_7 = "簡易防塵ＫＢＪ", V_H_Jyotai_7 = "KBJ"    '使用状態
    Public Const H_Jyotai_8 = "他", V_H_Jyotai_8 = ""                  '使用状態
    Public Const H_WakuType_1 = "A1(前背扉)", V_H_WakuType_1 = "A1"  '枠タイプ
    Public Const H_WakuType_2 = "A2(前背扉)", V_H_WakuType_2 = "A2"  '枠タイプ
    Public Const H_WakuType_3 = "A3(前背扉)", V_H_WakuType_3 = "A3"  '枠タイプ
    Public Const H_WakuType_4 = "A4(前背扉)", V_H_WakuType_4 = "A4"  '枠タイプ
    Public Const H_WakuType_5 = "A5(前背扉)", V_H_WakuType_5 = "A5"  '枠タイプ
    Public Const H_WakuType_6 = "A6(前背扉)", V_H_WakuType_6 = "A6"  '枠タイプ
    Public Const H_WakuType_7 = "B1(前扉、背板)", V_H_WakuType_7 = "B1"             '枠タイプ
    Public Const H_WakuType_8 = "B2(前扉、背板)", V_H_WakuType_8 = "B2"             '枠タイプ
    Public Const H_WakuType_9 = "B3(前扉、背板)", V_H_WakuType_9 = "B3"             '枠タイプ
    Public Const H_WakuType_10 = "B4(前扉、背板)", V_H_WakuType_10 = "B4"           '枠タイプ
    Public Const H_WakuType_11 = "B5(前扉、背板)", V_H_WakuType_11 = "B5"           '枠タイプ
    Public Const H_WakuType_12 = "B6(前扉、背板)", V_H_WakuType_12 = "B6"           '枠タイプ
    Public Const H_WakuType_13 = "C1(前背扉、中MCB)", V_H_WakuType_13 = "C1"        '枠タイプ
    Public Const H_WakuType_14 = "C2(前背扉、中MCB)", V_H_WakuType_14 = "C2"        '枠タイプ
    Public Const H_WakuType_15 = "D1(前扉、背板、中MCB)", V_H_WakuType_15 = "D1"    '枠タイプ
    Public Const H_WakuType_16 = "D2(前扉、背板、中MCB)", V_H_WakuType_16 = "D2"    '枠タイプ

    Public Const H_WakuType_17 = "BN1(前扉、背無)", V_H_WakuType_17 = "E1"    '枠タイプ
    Public Const H_WakuType_18 = "BN2(前扉、背無)", V_H_WakuType_18 = "E2"    '枠タイプ
    Public Const H_WakuType_19 = "BN3(前扉、背無)", V_H_WakuType_19 = "E3"    '枠タイプ
    Public Const H_WakuType_20 = "BN4(前扉、背無)", V_H_WakuType_20 = "E4"    '枠タイプ


    'Public Const H_DoorOpen_1 = "標準１２０度ＳＴＡ", V_H_DoorOpen_1 = "STA"   '扉開放角度
    Public Const H_DoorOpen_1 = "１２０度ＳＴＡ", V_H_DoorOpen_1 = "STA"        '扉開放角度
    Public Const H_DoorOpen_2 = "特殊ＴＯＫ", V_H_DoorOpen_2 = "TOK"            '扉開放角度
    '図面表記用
    Public Const D_H_TNP_1 = "NP-6449"  '定格NP（規格）
    Public Const D_H_TNP_2 = "NPS-9878"  '定格NP（規格）
    Public Const D_H_TNP_3 = "NPS-9881"  '定格NP（規格）
    Public Const D_H_TNP_4 = "NP-6330E"  '定格NP（規格）
    Public Const D_H_TNP_5 = "NP-6449E"  '定格NP（規格）
    Public Const D_H_TNP_6 = "NPS-9879"  '定格NP（規格）
    Public Const D_H_TNP_7 = ""  '定格NP（規格）
    Public Const D_H_TNP_8 = ""  '定格NP（規格）
    Public Const D_H_TNP_9 = "NPS-99538" '定格NP（規格）'05.1.13 松本追加
    Public Const D_H_Jyotai_1 = "一般"  '使用状態
    Public Const D_H_Jyotai_2 = "防塵"  '使用状態
    Public Const D_H_Jyotai_3 = "対塵"  '使用状態
    Public Const D_H_Jyotai_4 = "防滴"  '使用状態
    Public Const D_H_Jyotai_5 = "防雪"  '使用状態
    Public Const D_H_Jyotai_6 = "耐熱温帯"  '使用状態
    Public Const D_H_Jyotai_7 = "簡易防塵"  '使用状態
    Public Const D_H_Jyotai_8 = "他"  '使用状態
    'Public Const D_H_DoorOpen_1 = "標準１２０度"  '扉開放角度
    Public Const D_H_DoorOpen_1 = "１２０度"  '扉開放角度
    Public Const D_H_DoorOpen_2 = "特殊"  '扉開放角度
    Public Const D_H_DoorOpen_3 = "120度" '扉開放角度（自動作図の際に半角で入っている時期があった為）
    Public Const P_RenTan0 = "連動式"       '扉閉方式           '16.3.14 松本追加
    Public Const P_RenTan1 = "単動式"       '扉閉方式           '16.3.14 松本追加
    Public Const P_RenTan2 = "両側可動式"   '扉閉方式           '16.3.14 松本追加
    Public Const P_RenTan3 = "片側可動式"   '扉閉方式           '16.3.14 松本追加
    Public Const P_RenTanNo0 = "0"          '連動式の番号       '16.3.26 松本追加
    Public Const P_RenTanNo1 = "1"          '単動式の番号       '16.3.26 松本追加
    Public Const P_RenTanNo2 = "2"          '両側可動式の番号   '16.3.26 松本追加
    Public Const P_RenTanNo3 = "3"          '片側可動式の番号   '16.3.26 松本追加
    '
    '-----------------------------------------------
    '   ACAD.bas関係
    '-----------------------------------------------
    '文字列の宣言
    Public Hairetuzu As String '配列図
    Public Kisozu As String  '基礎図
    Public Sokumenzu As String  '側面図

    '縮尺指定
    Public Const conScale_H = 25.0# '配列図用
    Public Const conScale_K = 20.0# '基礎図用
    Public Const conScale_S = 10.0# '側面用
    Public p_Scale As Integer                   '縮尺

    '整数変数の宣言
    Public Zencho As Integer '列番全長(配列図）

    '図面名称記入
    Public Const Meisho_X = 506 '図面名称記入位置 X
    Public Const Meisho_Y = 44  '図面名称記入位置 Y
    Public Const Meisho_W = 49  '図面名称記入幅


    '-----------------------------------------------
    '   kisozu.bas関係
    '-----------------------------------------------
    '属性値
    'アンカーボルト取付穴
    Public Const I_ANKA1 As String = "－１６キリ（下辺に穴明）"
    Public Const I_ANKA2 As String = "－５０キリ（上辺に穴明）"
    Public Const I_SHIME1 As String = "－１２.５キリ（上辺に穴明）"
    Public Const I_SHIME2 As String = "－裏面にＭ１２ナット溶接"
    Public Const O_ANKA As String = "－１６キリ（下辺に穴明）"
    Public Const O_SHIME As String = "－１６キリ（上辺に穴明）"
    Public Const ANKA As String = "本－Ｍ１２ｘ１００"
    Public Const SEIGYO As String = "－１５０ｘ１５０穴"
    Public Const SEIGYOF As String = "－１００ｘ１５０穴"
    Public Const SEIGYOS As String = "－７５ｘ１２５穴"
    Public Mult_String As String
    Public Mult_String2 As String
    '座標データ
    Public KM_ZahyoX As Double  '列番左端座標（Ｘ座標）
    Public KM_ZahyoY As Double '列番左端座標（Ｙ座標）

    '配列データ
    Public KM_Box_Right(100, 2) As Integer 'アンカーボルト配置チェック用
    Public KM_BaseBunkatu(conNum) As String '分割データ用配列(納入外基礎ベース含む)

    '分割データ
    Public KM_Bunkatu As String '分割位置指示

    '倍精度浮動小数点データ
    Public KM_Len As Double '列番全長
    Public CUD_BaseH As Double '平面図用チャンネル巾

    '座標系の宣言
    Public KM_insPnt0(0 To 2) As Double '座標
    Public KM_insPntS0(0 To 2) As Double 'スタート座標
    Public KM_insPntE0(0 To 2) As Double 'エンド座標
    Public KM_insPnt1(0 To 2) As Double '座標
    Public KM_insPntS1(0 To 2) As Double 'スタート座標
    Public KM_insPntE1(0 To 2) As Double 'エンド座標
    Public KM_insPnt2(0 To 2) As Double '座標
    Public KM_insPntS2(0 To 2) As Double 'スタート座標
    Public KM_insPntE2(0 To 2) As Double 'エンド座標
    Public KM_insPnt3(0 To 2) As Double '座標
    Public KM_insPntS3(0 To 2) As Double 'スタート座標
    Public KM_insPntE3(0 To 2) As Double 'エンド座標

    '基礎図分割
    Public HAKO_No As String  '基礎図箱Ｎｏ
    Public T_Fugo As String '基礎図合符号
    Public Z_TEXT As String
    Public Limit_Bunkatu As Integer '分割制限（長さ）
    Public Const Limit_Hako As Integer = 5       '分割制限（箱）

    'ページ割り付け
    Public Const PageLimit As Integer = 9000  '１ページ最大全長
    'bunkatuSE(分割番号,0:最初の箱 1:最後の箱)
    Public BunkatuSE(0 To 20, 0 To 1) As String
    'PageSE(ページ番号,0:最初の箱 1:最後の箱)
    Public PageSE(0 To 10, 0 To 1) As String
    '各ページに収まる箱Noの羅列
    Public PageSEHakoNo(0 To 10, conNum) As String

    Public KM_Block As String 'ブロック名

    '突出寸法
    Public Const H_Okugai = "100"  'デフォルト突出寸法（屋外）
    Public Const H_Okunai = "50"  'デフォルト突出寸法（屋内）

    'A部詳細図・B部詳細図ﾌﾞﾛｯｸ挿入位置(CUB.No.)
    Public AShosai As String 'A部詳細図
    Public BShosai As String 'B部詳細図

    '図枠関係
    Public TL_Kouban As String  '工番
    Public TL_Zuban As String   '図番
    Public TL_Gunban As String  '群番号
    Public TL_Wakugai As String '図面枠外
    Public TL_Year As String    '年
    Public TL_Month As String   '月
    Public TL_Day As String     '日
    Public TL_Meisho As String   '図題
    Public TL_ZMaisu As String  '全ページ数
    Public TL_NMaisu As String  '現在のページ番号
    Public TL_Syubetu As String '製品種別
    Public TL_Mesure1 As String = 1 '尺度(分子)
    Public TL_Mesure2 As String  '尺度(分母)


    '図題関係
    Public TL_Type As String      '図面種類
    Public TL_Scale As String     '尺度
    Public TL_Date As String      '作成日付
    Public TL_Name As String      '作成者
    Public TL_DeltaNo As Integer  '改訂番号
    Public TL_DeltaDate As String '改訂日付
    Public TL_DeltaMemo As String '改訂内容
    Public TL_DeltaName As String '改訂者


    '-----------------------------------------------
    '   sokumi.bas関係
    '-----------------------------------------------
    'Public Const Sea_Dir = "\\f210-srv\swg\shounin\sokumi"          'データ格納場所
    'Public Const Sea_Dir_Hairetu = "\\f210-srv\swg\shounin\hairetu" 'データ格納場所（配列図）
    'Public Const Sea_Dir_Kiso = "\\f210-srv\swg\shounin\kiso"       'データ格納場所（基礎図）
    'Public Const Sea_Dir_Sokumen = "\\f210-srv\swg\shounin\sokumen" 'データ格納場所（側面図）
    'Public Const Sea_Dir_Banmen = "\\f210-srv\swg\shounin\banmen"   'データ格納場所（盤面図）
    'Public Const Sea_Dir_Heimen = "\\f210-srv\swg\shounin\heimen"   'データ格納場所（平面図）
    'Public Const Sea_Dir_Other = "\\f210-srv\swg\shounin\other"     'データ格納場所（その他）
    'Public Const Sea_Dir_Tmp = "\\f210-srv\swg\shounin\tmp"         '一時データ格納場所
    'Public Const Sea_Dir_Door = "\\f210-srv\swg\shounin\door" ←不要
    'Public Const Sea_Dir_SokumenH = "\\f210-srv\swg\shounin\hyoujun\unit\sokumen" '標準図ﾃﾞｰﾀ格納場所(側面図)
    Public Sea_Dir As String            'データ格納場所
    Public Sea_Dir_Hairetu As String    'データ格納場所（配列図）
    Public Sea_Dir_Kiso As String       'データ格納場所（基礎図）
    Public Sea_Dir_Sokumen As String    'データ格納場所（側面図）
    Public Sea_Dir_Banmen As String     'データ格納場所（盤面図）
    Public Sea_Dir_Heimen As String     'データ格納場所（平面図）
    Public Sea_Dir_Other As String      'データ格納場所（その他）
    Public Sea_Dir_Tmp As String        '一時データ格納場所
    Public Sea_Dir_SokumenH As String   '標準図ﾃﾞｰﾀ格納場所(側面図)
    Public Sea_Dir_BanmenH As String    '標準図ﾃﾞｰﾀ格納場所(盤面図)
    Public Sea_Dir_Rimen As String
    Public Sea_Dir_NC As String
    Public ChkFile As String '指定工番ファイルの有無
    Public Const knum = 9  '最大処理可能改訂番号（群レベル）
    Public K_number(knum) As String '改訂番号
    Public K_date(knum) As String '改訂日付
    Public K_comment(knum) As String '改訂内容
    'Public Const conNum = 30  '最大処理可能箱数（群レベル）
    'Public Const partNum = 1500  '最大処理可能機器数（箱レベル）
    'Public Const Math_PI = 3.1415926 'π
    '既設ファイル読み込み用
    'Public OpnAcadType As String  '開ける既設図面タイプ
    'Public pkname(0 To 1000) As String  '図面名一覧

    '-----------------------------------------------
    '   Tool.bas関係
    '-----------------------------------------------
    'オブジェクト変数の宣言
    'Public acadApp As Object 'アプリケーションオブジェクト
    'Public acadDoc As Object 'ドキュメントオブジェクト
    'Public acadApp As AcadApplication 'ｱﾌﾟﾘｹｰｼｮﾝｵﾌﾞｼﾞｪｸﾄ
    'Public acadDoc As AcadDocument    '

    'Public moSpace As Object 'モデル空間オブジェクト
    'Public acadUtl As Object 'ユーティリティーオブジェクト
    'Public ViewPort As Object 'アクティブビューポートオブジェクト

    '座標系の宣言
    Public InsPnt(0 To 2) As Double  '座標
    Public insPntS(0 To 2) As Double 'スタート座標
    Public insPntE(0 To 2) As Double 'エンド座標

    '変数の宣言
    Public hPath As String = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory)     'C:\Users\Public\Desktop → C:\Users\(従番)\Desktop
    Public UName As String = System.Environment.UserName            '(従番)
    Public NPath As String = hPath.Replace("Public", UName)         'publicを従番に
    'ブロックのパス名
    'Public Const BlockPath1 = "\\\\oa-server\\pcad\\河野\\AutoCAD\\ブロック\\"
    'Public Const BlockPath2 = "\\\\oa-server\\pcad\\河野\\AutoCAD\\図面\\"
    'Public Const BlockPath1 = "\\\\F210-srv\\swg\\shounin\\block\\hairetu\\"
    'Public Const BlockPath2 = "\\\\F210-srv\\swg\\shounin\\block\\waku\\"
    'Public Const BlockPath3 = "\\\\F210-srv\\swg\\shounin\\block\\kiso\\"
    Public Const EndString = ".dwg"
    'Public Const BlockPath1 = "\\F210-srv\swg\shounin\block\hairetu\"
    'Public Const BlockPath2 = "\\F210-srv\swg\shounin\block\waku\"
    'Public Const BlockPath3 = "\\F210-srv\swg\shounin\block\kiso\"
    'Public Const BlockPath4 = "\\F210-srv\swg\shounin\block\sokumen\"
    'Public Const BlockPath5 = "\\F210-srv\swg\shounin\block\wappen\"
    'Public Const BlockPath6 = "\\F210-srv\swg\shounin\block\banmen\"
    Public BlockPath1 As String
    'Public BlockPath2 As String
    'Public BlockPath2 = NPath + "\早期仕様確定\test\"     'テスト用   C:\Users\(ユーザー名)\Desktop\早期仕様確定\test\
    'Public BlockPath3 As String
    Public BlockPath3 = "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\kiso\"
    Public BlockPath4 As String
    Public BlockPath5 As String
    Public BlockPath6 As String
    Public BlockPath7 As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\skeleton\unit\"
    Public BlockPath8 As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\hairetu\"
    Public BlockPath12 As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\"

    '配列図関係
    Public Read_NO As Integer '最右端箱番号（納入外を除く）が格納されている配列位置
    'Public Const H_Limit = 470 '最右表示位置（Ｘ座標）
    Public Const H_Limit = 550 '最右表示位置（Ｘ座標）
    Public H_PageHakoNo(10, 20) As String '各ページ毎の表示する箱Ｎｏ

    '-----------------
    '  配列用定数宣言
    '-----------------

    '座標データ
    '扉、化粧板構造図
    Public Const conZhyX1 = 45.0# '（基準点）
    Public Const conZhyY1 = 358.0#  '（基準点）

    '扉側面図
    Public Const conZhyX2 = 82.0# '（基準点）
    Public Const conZhyY2 = 159.0#  '（基準点）


    '正面図（２ページ目以降用）
    Public Const conZhyX3 = 90.0# '（基準点）
    Public Const conZhyY3 = 159.0#  '（基準点）

    '定数の宣言
    Public Const conDou1 = 92.0# '配列図の箱高さ定数
    Public Const conDou2 = 150.0# '配列図（側面図）の底寸法位置定数（Ｙ座標）
    'Public Const conDou3 = 272.0# '配列図（側面図）のＤ寸法位置定数（Ｙ座標）           '最高高さ変更に伴い変更 '16.9.27 松本
    'Public Const conDou4 = 279.0# '配列図（側面図）のＤ寸法位置定数（屋外）（Ｙ座標）   '
    'Public Const conDou5 = 12.0# '配列図（側面図）の天井板加算寸法定数（正背面用）      '
    Public Const conDou3 = 298.0# '配列図（側面図）のＤ寸法位置定数（Ｙ座標）            '←
    Public Const conDou4 = 305.0# '配列図（側面図）のＤ寸法位置定数（屋外）（Ｙ座標）    '←
    Public Const conDou5 = 300.0# '配列図（側面図）の天井板加算寸法定数（正背面用）      '←
    Public Const conDou6 = 290.0# '配列図（側面図）のＤ寸法加算定数(屋外)
    'Public Const conDou7 = 253.0# '配列図（側面図）のＤ寸法補助線位置定数(正背面用)(Ｙ座標)  '最高高さ変更に伴い変更 '16.9.27 松本
    Public Const conDou7 = 279.0# '配列図（側面図）のＤ寸法補助線位置定数(正背面用)(Ｙ座標)   '←
    Public Const conDou8 = 263.0# '配列図（側面図）のＤ寸法補助線位置定数(屋外)(背面用)(Ｙ座標)
    'Public Const conDou9 = 255.0# '配列図（側面図）のＤ寸法補助線位置定数(屋外)(正面用)(Ｙ座標)   '最高高さ変更に伴い変更 '16.9.27 松本
    Public Const conDou9 = 281.0# '配列図（側面図）のＤ寸法補助線位置定数(屋外)(正面用)(Ｙ座標)    '←
    Public Const conRoof = 1000.0# '配列図（側面図）の天井板マスター寸法（Ｄ寸法）

    Public Const conDou10 = 72.0# '配列図（正面図）と配列図（側面図）との間の距離
    Public Const conDou11 = 12.0# '配列図（正面図）のＨ寸法補助線位置定数（距離）
    Public Const conDou12 = 10.0# '配列図（正面図）の左側床寸法
    Public Const conDou13 = 46.0# '配列図（正面図）の取手取付位置高さ定数（距離）
    Public Const conDou14 = 5.0# '配列図（正面図）の取手横方向定数（距離）
    Public Const conDou15 = 2.0# '配列図（正面図）の名称欄空白時の横間隔定数（距離）
    'Public Const conDou16 = 19.7 '配列図（正面図）の名称欄空白時の横線の開始位置定数（Ｙ方向距離）
    'Public Const conDou16 = 21.7 '配列図（正面図）の名称欄空白時の横線の開始位置定数（Ｙ方向距離）
    'Public Const conDou16 = 20.4 '配列図（正面図）の名称欄空白時の横線の開始位置定数（Ｙ方向距離）'変更 '16.10.28 松本
    'Public Const conDou17 = 5.5 '配列図（正面図）の名称欄空白時の横線の間隔定数（距離）
    'Public Const conDou17 = 5.2 '配列図（正面図）の名称欄空白時の横線の間隔定数（距離）           '←
    Public Const conDou16 = 510 '配列図（正面図）の名称欄空白時の横線の開始位置定数（Ｙ方向距離）　'←
    Public Const conDou17 = 130 '配列図（正面図）の名称欄空白時の横線の間隔定数（距離）            '←
    Public Const conDou18 = 265.0# '配列図（正面図）の化粧板厚寸法位置定数（Ｙ座標）
    Public Const conDou19 = 2.5 '配列図（正面図）の化粧板厚定数
    Public Const conDou20 = 1.3 '配列図（正面図）の化粧板厚定数
    Public Const conDou21 = 1.0# '配列図（正面図）の上部扉区切り線位置定数
    Public Const conDou22 = 6.0# '配列図（正面図）のＨ寸法補助線増分定数（距離）(屋外)
    'Public Const conDou23 = 9.0# '配列図（正面図）のＨ寸法補助線増分定数（距離）(屋外)
    Public Const conDou23 = 9.8 '配列図（正面図）のＨ寸法補助線増分定数（距離）(屋外)    '天井ブロックを新しくしたため変更
    Public Const conDou24 = 6.0# '配列図（正面図）のＨ寸法補助線位置定数（距離）(屋外)
    Public Const conDou25 = 16.0# '配列図（正面図）のＨ寸法補助線位置定数（距離）(屋外)
    Public Const conDou26 = 55.0# '配列図（正面図）のＨ寸法加算寸法定数（距離）(屋外)
    Public Const conDou27 = 23.0# '配列図（正面図）の下段取手高さ定数(2段扉)（距離）
    Public Const conDou28 = 69.0# '配列図（正面図）の下段取手高さ定数(2段扉)（距離）
    Public Const conDou29 = 15.333 '配列図（正面図）の下段取手高さ定数(3段扉)（距離）
    Public Const conDou30 = 46.0# '配列図（正面図）の中段取手高さ定数(3段扉)（距離）
    Public Const conDou31 = 76.667 '配列図（正面図）の上段取手高さ定数(3段扉)（距離）
    Public Const conDou32 = 30.667 '配列図（正面図）の下段区切り高さ定数(3段扉)（距離）
    Public Const conDou33 = 61.333 '配列図（正面図）の上段区切り高さ定数(3段扉)（距離）
    Public Const conDou34 = 11.5 '配列図（正面図）の下段取手高さ定数(4段扉)（距離）
    Public Const conDou35 = 23.0# '配列図（正面図）の下段区切り高さ定数(=扉係数)(4段扉)（距離）
    Public Const conDou36 = 34.5 '配列図（正面図）の取手高さ定数(名称台付扉)（距離）
    Public Const conDou37 = 17.25 '配列図（正面図）の下段取手高さ定数(名称台付扉)（距離）
    Public Const conDou38 = 57.5 '配列図（正面図）の上段区切り高さ定数(名称台付扉)（距離）
    Public Const conDou39 = 22.0# '図題欄（正面図）と配列図（側面図）との間の距離
    Public Const conDou40 = 55.0# '図題欄（正面図）の底寸法位置定数（Ｙ座標）

    Public Const conDou41 = 60.0# '配列図（扉構造図）の間隔
    Public Const conDou42 = 1.5 '配列図（側面図）側面板止め穴補正値

    Public Const conDou43 = 23.6  '左側続く線寸法（斜めＸ方向距離）
    Public Const conDou44 = 11.2  '左側続く線寸法（左端箱からのＸ方向寸法）
    Public Const conDou45 = 7.0#  '右側続く線寸法（X寸法）<-屋外用
    Public Const conDou46 = 5.0#   '右側続く線寸法（X寸法）<-屋内用

    Public Const conDou47 = 20.0# '配列図（正面図）のＨ寸法補助線位置増分定数(2頁目以降)

    Public Const conDou48 = 1250.0# '図題欄（正面図）の幅
    Public Const conDou49 = 2600.0# '図題欄（正面図）の高さ + 配列図（正面図）と図題欄との間隔
    Public Const conDou50 = 1150.0# '図題欄（正面図）の挿入点のX座標(縮尺1/1時)
    Public Const conDou51 = -2600.0# '図題欄（正面図）の挿入点のY座標(縮尺1/1時)


    '-------------------
    '  基礎図用定数宣言
    '-------------------
    '座標データ
    '中心位置
    Public Const HconZhyX1 = 328.0# '（基準点） '図面上の中心位置
    Public Const HconZhyY1 = 189.0#  '（基準点）'図面上の中心位置
    Public Const HconZhyX2 = 25.0# '（基準点）'図面の左下位置
    Public Const HconZhyY2 = 5.0#  '（基準点）'図面の左下位置

    '定数の宣言
    Public Const HconDou1 = 400.0# 'Ｂ部詳細図配置位置（Ｘ座標）
    Public Const HconDou2 = 49.0# 'Ａ,Ｂ部詳細図配置位置（Ｙ座標）
    Public Const HconDou3 = 470.0# 'Ａ部詳細図配置位置（Ｘ座標）
    Public Const HconDou4 = 90.0# '平面図配置位置（Ｙ座標）
    Public Const HconDou5 = 3.0# '平面図用アンカーボルト（下部）
    Public Const HconDou6 = 2.5 '平面図用アンカーボルト（下部）
    Public Const HconDou7 = 7.5 '平面図用高さ（距離）
    Public Const HconDou8 = 110 'アンカーボルトの最初と最後の位置（距離）
    Public Const HconDou9 = 0.5 '補助線飛び出し寸法（距離）
    Public Const HconDou10 = 1.5 '補助線飛び出し寸法（距離）
    Public Const HconDou11 = 16.0# '盤締付穴寸法配置位置（Ｙ方向）（距離）
    Public Const HconDou12 = 22.0# 'アンカーボルト寸法配置位置（Ｙ方向）（距離）
    Public Const HconDou13 = 28.0# '盤センター寸法配置位置（Ｙ方向）（距離）
    Public Const HconDou14 = 34.0# '盤巾寸法配置位置（Ｙ方向）（距離）
    Public Const HconDou15 = 40.0# '分割寸法配置位置（Ｙ方向）（距離）
    Public Const HconDou16 = 46.0# '全体寸法配置位置（Ｙ方向）（距離）
    Public Const HconDou17 = 15.0# '盤締付穴距離（Ｘ方向）（距離）
    Public Const HconDou18 = 22.5 '盤寸法（Ｘ寸法）（距離）
    Public Const HconDou19 = 77.0# '盤締付穴位置（Ｘ方向）（距離）
    Public Const HconDou20 = 70.0#  '正面文字位置（Y方向）（距離）
    Public Const HconDou21 = 75.0# '盤締付穴位置（Ｘ方向）（距離）
    Public Const HconDou22 = 50.0# '盤締付穴位置（Ｙ方向）（距離）
    Public Const HconDou23 = 25.0# '盤締付穴位置（Ｙ方向）（距離）
    Public Const HconDou24 = 54.0# '箱番号位置（Ｙ方向）（距離）
    Public Const HconDou25 = 66.5 '合符号位置（Ｙ方向）（距離）
    Public Const HconDou26 = 125.0# '制御穴位置（Ｘ方向）（距離）
    Public Const HconDou27 = 195.0# '制御穴位置（Ｙ方向）（距離）
    Public Const HconDou28 = 3.0# '制御穴寸法位置（Ｘ方向）（距離）
    Public Const HconDou29 = 8.75 '制御穴寸法位置（Ｙ方向）（距離）
    Public Const HconDou30 = 27.5 '制御文字位置（Ｘ方向）（距離）
    Public Const HconDou31 = 9.5 '合符号文字位置（Ｘ方向）（距離）
    Public Const HconDou32 = 15.0# '合符号文字位置（Y方向）（距離）
    Public Const HconDou33 = 2.5 'アンカーボルト周辺線間隔（X方向）（距離）
    Public Const HconDou34 = 0.25 '平面図アンカーボルト２重線間隔（Y方向）（距離）
    Public Const HconDou35 = 4.5 '正面図換気穴間隔（X方向）（距離）
    Public Const HconDou36 = 1.0#  '正面図換気穴位置（Y方向）（原点との距離）
    Public Const HconDou37 = 8.0#  '複数ページ時の延長寸法

    Public Const HconDou38 = 25.0#  '主回路ケーブル穴寸法配置位置(X方向) (センター線からの距離)
    Public Const HconDou39 = 50.0#  '主回路ケーブル穴寸法配置位置(Y方向) (ケーブル穴上横線からの距離)
    Public Const HconDou40 = 150.0# 'F-PAC用制御穴位置（Ｘ方向）（距離）
    Public Const HconDou41 = 150.0# 'F-PAC用制御穴位置（Ｙ方向）（距離）
    Public Const HconDou42 = 115.0# '屋内S-PAC7用制御穴位置（Ｘ方向）（距離）
    Public Const HconDou43 = 200.0# '屋内F-PAC7用制御穴位置（Ｙ方向）（距離）
    Public Const HconDou44 = 115.0# '屋外S-PAC7用制御穴位置（Ｘ方向）（距離）
    Public Const HconDou45 = 200.0# '屋外S-PAC7用制御穴位置（Ｙ方向）（距離）

    '-----------------------------------------------
    '   hairetuzu.bas関係
    '-----------------------------------------------
    Public CSD_OD_Sunpo As String '扉最大開放寸法
    Public CSD_KM_Sunpo As String '機器引出所要寸法

    Public S_CUBNO As String  '配列図定格欄
    Public S_DRZUBAN As String  '配列図定格欄
    Public S_DOORZUBAN As String  '配列図定格欄
    Public S_KATA As String  '配列図定格欄
    Public S_HOGO As String  '配列図定格欄
    Public S_HOGO2 As String  '配列図定格欄
    Public S_DENATU As String  '配列図定格欄
    Public S_HZ As String  '配列図定格欄
    Public S_ZETUEN As String  '配列図定格欄
    Public S_TNP As String  '配列図定格欄
    Public S_JYOTAI As String  '配列図定格欄
    Public S_DOOROPEN As String  '配列図定格欄
    Public S_JYURYO As String '盤概略質量
    Public S_NP1 As String '配列図定格欄
    Public S_NP2 As String '配列図定格欄
    Public S_NP3 As String '配列図定格欄
    Public S_NP4 As String '配列図定格欄
    Public S_POWERFREQUENCY As String     '配列図定格欄 '05.1.19 松本追加
    Public S_LIGHTNINGIMPULSE As String   '配列図定格欄 '05.1.19 松本追加

    Public S_CaulkingFlg As Boolean       'ｺｰｷﾝｸﾞ注意書きが必要かどうか   '05.9.28 松本追加

    Public S_X As Double '正面図のスタート座標（Ｘ座標）

    'テンポラリ配列
    Public Hairetu(conNum) As Object

    Public HM_MPKT As String '扉構造図用
    Public Const H_BunkatuLimit = 1100.0#   '側面図分割判断寸法


    '-----------------------------------------------
    '   ユニット関係
    '-----------------------------------------------
    Public UnitCode As String         'ユニットコード
    Public UnitKind As String         'ユニット図種類
    Public UnitSel As String          '標準種別
    Public BMCode As String           '盤面器具リストNo.
    Public BMNum As String            'ユニットスケルトン
    Public BMCodeNo As String         '盤面コードNo.
    Public BMSwg As String            'SWG種別
    Public BMOther As String          'Other
    Public BMFB As String             '標準扉位置
    Public BM_Name1(partNum) As String '名称1
    Public BM_Name2(partNum) As String '名称2
    Public BM_Number(partNum) As Integer '数量
    Public BM_Biko1(partNum) As String '備考1
    Public BM_Biko2(partNum) As String '備考2

    '-----------------------------------------------
    '   sokumen.vbp関係
    '-----------------------------------------------
    '側面図
    Public CR_AllHako(conNum) As String '全ての箱番号
    Public CR_PageNum(conNum) As Integer 'ページ番号
    Public CR_tmpPageNum(conNum) As Integer 'キャンセル用ページ番号
    Public CR_DelCHako(conNum) As String  '共有箱から除外された箱番号
    Public CR_NDelCHako As Integer      '現在の除外された箱の配列添字
    Public CR_NHako As String           '現在の箱番号
    Public CR_NowNum As Integer         '現在の箱連番
    Public CR_AllNum As Integer         '現在の工番・群番内の箱数
    Public CR_DeltaNum(conNum) As Integer '現在の改訂番号
    Public CR_FLG As Integer            '機器選択フォーム--0:機器配置,1:機器登録,2:一覧配置
    Public CR_Dir As String             '機器の向き
    Public CR_Ang As String             '機器の角度
    Public CR_Pitch As String           '機器のピッチ
    '側面図インプットデータ
    Public CR_CHako(conNum, conNum) As String  '共有箱番号
    Public CR_Zuban(conNum) As String   '側面図図番
    Public CR_IO(conNum) As String      '屋内外
    Public CR_D(conNum) As String       '箱Ｄ
    Public CR_H(conNum) As String       '箱Ｈ
    Public CR_W(conNum) As String       '箱Ｗ
    Public CR_Hogo(conNum) As String    '使用状態
    Public CR_FDoor(conNum) As String   '正面扉
    Public CR_FHinji(conNum) As String  '正面扉ヒンジ位置
    Public CR_FPos(3, conNum) As String '正面扉上端位置寸法
    Public CR_BDoor(conNum) As String   '背面扉
    Public CR_BHinji(conNum) As String  '背面扉ヒンジ位置
    Public CR_BPos(3, conNum) As String '背面扉上端位置寸法
    Public CR_HDoor(conNum) As String   '補助扉
    Public CR_HPos(conNum) As String    '補助扉上端位置寸法
    Public CR_HH(conNum) As String      '補助扉高さ寸法
    Public CR_Seikan(conNum) As String  '製缶方式
    Public CR_HaisenDir(conNum) As String   '配線室位置
    Public CR_HaisenPos(conNum) As String   '配線室寸法
    Public CR_Zatu(7, conNum) As String '雑器具
    Public CR_SoHai(2, conNum) As String    '主回路相配列(正面・背面)
    Public CR_SoName(3, conNum) As String   '主回路相配列(R,S,T,N相)
    Public CR_SoColor(3, conNum) As String  '主回路相配列(赤、白、青、黒、無)
    Public CR_SoName2(3, conNum) As String   '主回路相配列2(R,S,T,N相)
    Public CR_SoColor2(3, conNum) As String  '主回路相配列2(赤、白、青、黒、無)
    Public CR_Toso(conNum) As String    '導体色別処理
    Public CR_Duct(conNum) As String    'ダクトフランジ数量
    Public CR_Tansi(conNum) As String   '中継端子台
    Public CR_Kanki(4, conNum) As String    '換気穴

    Public CR_XX0 As Integer
    Public CR_YY0 As Integer
    Public CR_XX As Double
    Public CR_YY As Double
    Public CR_XS As Integer
    Public CR_YS As Integer
    Public CR_AA As Double
    Public CR_CC As Double
    Public CR_FCT As Double

    Public CR_Enable_Flg As Boolean
    '共有箱番号インデックス
    Public CR_ComHakoIndex As Integer
    '共有箱番号リスト
    Public CR_ComHakolist(conNum) As String   '共有元箱番号
    Public CR_ComHakolist_C(conNum) As String 'CANCEL時待避用
    '製缶方式データ
    Public CR_SeikanList(1, 2) As String
    '配線室データ
    Public CR_HaisenList(1, 1) As String
    '主回路相配列名称データ
    Public CR_SoNList(1, 9) As String
    '主回路相配列色データ
    Public CR_SoCList(1, 5) As String
    '導体色別処理
    Public CR_TosoList(2, 6) As String
    '中継端子台データ
    Public CR_TansiList(1, 2) As String

    '扉幅
    Public Door_Thick As Integer
    'ブロック挿入点
    Public Const CR_Ins_X = -800
    Public Const CR_Ins_Y = -400
    Public Const CR_Ins_Z = 0

    '屋内外
    Public Const CR_IO_IN = "屋内"
    Public Const CR_IO_OUT = "屋外"

    '扉ヒンジ位置
    Public Const CR_Hinji_L = "L"
    Public Const CR_Hinji_R = "R"
    Public Const CR_Hinji_W = "W"

    '扉種類
    Public Const CR_Door_N = "N"
    Public Const CR_Door_P = "P"
    Public Const CR_Door_D = "D"

    '補助扉種類
    Public Const CR_Hojyo_N = "N"
    Public Const CR_Hojyo_S = "S"
    Public Const CR_Hojyo_M = "M"

    '製缶方式
    Public Const CR_Seikan_GB = "ＧＢ"
    Public Const CR_Seikan_AA = "ＡＡ"
    Public Const CR_Seikan_KM = "組立"
    Public Const CR_Seikan_C_GB = "GB"
    Public Const CR_Seikan_C_AA = "AA"
    Public Const CR_Seikan_C_KM = "KM"

    '主回路相配列
    Public Const CR_So_Front = "正面"
    Public Const CR_So_Back = "背面"
    Public Const CR_So_C_Front = "F"
    Public Const CR_So_C_Back = "B"

    Public Const CR_So_Up = "上　"
    Public Const CR_So_Down = "下　"
    Public Const CR_So_Left = "左　"
    Public Const CR_So_Right = "右　"
    Public Const CR_So_Near = "手前"
    Public Const CR_So_Far = "奥"
    Public Const CR_So_C_Up = "U"
    Public Const CR_So_C_Down = "D"
    Public Const CR_So_C_Left = "L"
    Public Const CR_So_C_Right = "R"
    Public Const CR_So_C_Near = "F"
    Public Const CR_So_C_Far = "B"

    Public Const CR_So_R = "Ｒ相"
    Public Const CR_So_S = "Ｓ相"
    Public Const CR_So_T = "Ｔ相"
    Public Const CR_So_N = "Ｎ相"
    Public Const CR_So_A = "Ａ相"
    Public Const CR_So_B = "Ｂ相"
    Public Const CR_So_C = "Ｃ相"
    Public Const CR_So_1 = "１相"
    Public Const CR_So_2 = "２相"
    Public Const CR_So_C_R = "R"
    Public Const CR_So_C_S = "S"
    Public Const CR_So_C_T = "T"
    Public Const CR_So_C_N = "N"
    Public Const CR_So_C_A = "A"
    Public Const CR_So_C_B = "B"
    Public Const CR_So_C_C = "C"
    Public Const CR_So_C_1 = "1"
    Public Const CR_So_C_2 = "2"

    Public Const CR_So_Null = "無"
    Public Const CR_So_Red = "赤"
    Public Const CR_So_White = "白"
    Public Const CR_So_Blue = "青"
    Public Const CR_So_Dark = "黒"
    Public Const CR_So_Yellow = "黄"
    Public Const CR_So_C_Null = ""
    Public Const CR_So_C_Red = "R"
    Public Const CR_So_C_White = "W"
    Public Const CR_So_C_Blue = "B"
    Public Const CR_So_C_Dark = "D"
    Public Const CR_So_C_Yellow = "Y"

    '導体色別処理
    Public Const CR_Toso_C_PB = "PB"
    Public Const CR_Toso_C_S = "S"
    Public Const CR_Toso_C_Z = "Z"
    Public Const CR_Toso_C_I = "I"
    Public Const CR_Toso_C_VI = "VI"
    Public Const CR_Toso_C_PC = "PC"
    Public Const CR_Toso_C_O = "O"
    Public Const CR_Toso_PB = "黒塗装"
    Public Const CR_Toso_S = "すずメッキ"
    Public Const CR_Toso_Z = "エポキシ"
    Public Const CR_Toso_I = "黒チューブ"
    Public Const CR_Toso_VI = "色別チューブ"
    Public Const CR_Toso_PC = "クリヤ"
    Public Const CR_Toso_O = "その他"
    Public Const CR_Toso_Z_PB = "黒塗装後、要所に相色別表示"
    Public Const CR_Toso_Z_S = "全体すずメッキ後、要所に相色別表示"
    Public Const CR_Toso_Z_Z = "エポキシ絶縁被覆後、要所に相色別表示"
    Public Const CR_Toso_Z_I = "黒色イラックスチューブ被覆後、要所に相色別表示"
    Public Const CR_Toso_Z_VI = "色別チューブ被覆後で相表示"
    Public Const CR_Toso_Z_PC = "クリヤ塗装後、要所に相表示"
    Public Const CR_Toso_Z_O = ""

    '中継端子台
    Public Const CR_Tansi_Tbd = "ＴＢＤ　有"
    Public Const CR_Tansi_Tbc = "ＴＢＣ　有"
    Public Const CR_Tansi_N = "ＴＢＤ　無"
    Public Const CR_Tansi_C_Tbd = "TBD"
    Public Const CR_Tansi_C_Tbc = "TBC"
    Public Const CR_Tansi_C_N = "N"

    '側面図エラーメッセージ
    Public Const CR_Err_Hako = "箱寸法が大きすぎます"
    Public Const CR_Err_Haisen = "配線室が大きすぎます"
    Public Const CR_Err_FDoor = "正面扉ヒンジ高さが大きすぎます"
    Public Const CR_Err_BDoor = "背面扉ヒンジ高さが大きすぎます"
    Public Const CR_Err_Zatu = "雑器具の数量が多すぎます"
    Public Const CR_Err_Duct = "ダクトフランジの数量が多すぎます"


    'プログラムファイルのパス名
    'Public Const ProgPath1 = "\\\\F210-srv\\swg\\shounin\\program\\" 'LISP用
    'Public Const ProgPath1 = "\\F210-srv\swg\shounin\program\" 'ActiveX用
    Public ProgPath1 As String    'ActiveX用

    Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)


    '-----------------------------------------------
    '   banmen.vbp関係
    '-----------------------------------------------
    '共通事項
    Public Const BMconNum = 100 '盤面用最大処理可能箱数（群レベル）
    Public Const BMconNum1 = 5 '扉の種類(前,後,右,左,中）
    Public Const BMconNum2 = 5 '１箱内に入るSP等の最大数
    Public BM_FLG As Integer   '0:フォームロード時 1:表示切替時
    Public BM_ZExist As Boolean '図面作成時の該当ページの存在有無
    Public BM_Nkaitei As String '図面作成時の改訂番号
    Public BMkbnchk As Boolean  '配列・基礎図データの有無
    Public BM_Page As Integer   'ページ番号
    Public BM_Row As Integer    '図面作成時箱並び順
    Public BM_H(BMconNum) As String   '高さ
    Public BM_W(BMconNum) As String   '幅
    Public BM_D(BMconNum) As String   '奥行
    Public BMNowNum As Integer      '現在の箱番号を示すインデックス
    Public BMNowName As String      '現在の盤面用箱番号名
    Public BMNowOpt(2) As Integer   '現在のオプションボタンの値
    Public BMCpyOpt(2) As Integer   '現在のオプションボタンの値（ﾃﾞｰﾀｺﾋﾟｰ用）
    Public BM_AllHako(BMconNum) As String   '全ての箱番号
    Public BM_HakoName(BMconNum, 3, BMconNum1) As String  '盤面用の箱番号
    Public BM_AllAuto(BMconNum) As String   '自動作成の箱番号
    Public BM_DrPos(BMconNum, BMconNum1) As String   '扉の位置
    Public BM_DrHinji(BMconNum, 3, BMconNum1) As String  'ヒンジの位置
    Public BM_Hokyo(BMconNum, 3, BMconNum1) As String     '補強の有無
    Public BM_IL(BMconNum, 3, BMconNum1) As String        'インターロックの有無
    Public BM_DrHandle(BMconNum) As String  '把手の形式
    Public BM_TottePos(BMconNum) As String  '把手の位置
    Public BM_Meisyo(BMconNum) As String    '用途名称板
    Public BM_SPExist(BMconNum) As String   'SPの有無
    Public BM_SPPos(BMconNum, BMconNum1) As String    '扉の位置
    Public BM_SPNo(BMconNum, BMconNum2) As String     'SPの番号
    Public BM_BPExist(BMconNum) As String   '計器盤の有無
    Public BM_BPNo(BMconNum, BMconNum2) As String     '計器盤の番号
    Public BM_MBExist(BMconNum) As String   'MCB盤の有無
    Public BM_MBPos(BMconNum, BMconNum1) As String    '扉の位置
    Public BM_MBNo(BMconNum, BMconNum2) As String     'MCB盤の番号
    Public BM_Zumenlist(3, 4, BMconNum) As String '図面作成時、図面種類毎・扉位置毎の箱番号リスト
    Public BM_ZumenCre(BMconNum) As String     '図面作成時、選択ページ、選択箱番号
    Public BM_Tokki_Chk(4) As Boolean        '特記事項の項目表示有無
    Public BM_Tokki_Zuban(3) As String       '特記事項の別図図番
    Public BM_PageSelHideFlg As Boolean      'ページ選択フォームが(true:表示,false:非表示)

    'Public BM_DrThick(BMconNum, 5, BMconNum1) '扉板厚  10-Jul-03  Hashi Add
    '↑ﾃﾞｰﾀ型が定義されていないので定義↓ '16.3.22 松本
    Public BM_DrThick(BMconNum, 5, BMconNum1) As String   '扉板厚
    '扉閉方式(0:連動式/1:単動式/2:両側可動式/3:片側可動式) '16.3.14 松本追加
    Public BM_sDoorCloseTyp(BMconNum, 4, BMconNum1) As String

    '(箱数,0:扉 1:内部配電盤 2:扉取付配電盤 3:MCB取付盤,扉位置,1～3段)
    Public BM_DW(BMconNum, 3, BMconNum1) As String '扉種類の扉幅寸法
    Public BM_DH(BMconNum, 3, BMconNum1, 3) As String '扉種類の扉高さ寸法
    Public BM_TH(BMconNum, 3, BMconNum1, 3) As String '扉種類の把手高さ寸法
    Public BM_UH(BMconNum, 3, BMconNum1, 3) As String '扉種類の上端位置寸法

    Public BM_HH(BMconNum, 3, BMconNum1, 5) As String         'ヒンジ高さ位置
    Public BM_HokyoPos(BMconNum, 3, BMconNum1, 5) As String   '補強位置寸法

    '標準ヒンジ高さ寸法取得用
    Public BM_HGIO As String              '屋内外
    Public BM_HGDan As Double             '扉段数
    Public BM_HGHupp1 As Double           '扉１段目高さ上限
    Public BM_HGHlow1 As Double           '扉１段目高さ下限
    Public BM_HGHupp3 As Double           '扉３段目高さ上限
    Public BM_HGHlow3 As Double           '扉３段目高さ下限
    Public BM_HGPos(5) As Double          'ヒンジ高さ寸法1-6

    Public BM_KID(partNum) As Integer     '盤面器具ＩＤ
    Public BM_KCode(partNum) As String    '盤面器具コード
    Public BM_KNam(partNum) As String     '盤面器具名称
    Public BM_KSpc(partNum) As String     '盤面器具定格
    Public BM_KTyp(partNum) As String     '盤面器具形式
    Public BM_KNo(partNum) As String      '盤面器具ワッペン番号
    Public BM_KDNo(partNum) As String     '盤面器具自動器具No.
    Public BM_KNP(partNum) As String      '盤面器具NP番号
    Public BM_KX(partNum) As Double       '盤面器具位置座標X
    Public BM_KX1(partNum) As Double      '盤面器具位置座標X(図面上表示位置)
    Public BM_KY(partNum) As Double       '盤面器具位置座標Y
    Public BM_KY1(partNum) As Double      '盤面器具位置座標Y(図面上表示位置)
    Public BM_KZ(partNum) As Double       '盤面器具位置座標Z
    Public BM_KR(partNum) As Double       '盤面器具角度
    Public BM_Rimen(partNum) As Integer   '裏面フラグ
    Public BM_KHoleTyp(partNum) As String '盤面器具穴形式
    Public BM_KMaxX(partNum) As Double    '盤面器具X方向外形最大寸法
    Public BM_KMaxY(partNum) As Double    '盤面器具Y方向外形最大寸法
    Public BM_KMaxX2(partNum) As Double   '盤面器具X方向外形最大寸法(特殊用)
    Public BM_KMaxY2(partNum) As Double   '盤面器具Y方向外形最大寸法(特殊用)
    Public BM_KLevel(partNum) As Integer  '盤面器具標準レベル

    Public Const BM_CHKX_HAND = 165.0#   '把手方向の扉補強間隔
    Public Const BM_CHKX_HAND2 = 190.0#  '把手方向の扉補強間隔(観音用その2) '16.2.3 松本追加
    Public Const BM_CHKX_HING_i = 165.0# 'ヒンジ方向の扉補強間隔（屋内）
    Public Const BM_CHKX_HING_o = 110.0# 'ヒンジ方向の扉補強間隔（屋外）
    Public Const BM_CHKY_1 = 120.0#      '扉上部－補強上部間隔
    Public Const BM_CHKY_2 = 100.0#      '扉下部－補強下部間隔
    Public Const BM_CHKY_3_rl = 0.0#     '補強－把手間隔（片開き）
    'Public Const BM_CHKY_3_w = 310#    '補強－把手間隔（両開き）'基準変更
    Public Const BM_CHKY_3_w = 340.0#    '補強－把手間隔（両開き） '16.2.3 松本修正
    Public Const BM_CHKY_4_rl = 0.0#     '把手－補強間隔（片開き）
    'Public Const BM_CHKY_4_w = 310#    '把手－補強間隔（両開き）'基準変更
    Public Const BM_CHKY_4_w = 360.0#    '把手－補強間隔（両開き） '16.2.3 松本修正
    Public Const BM_CHKX_W = 30.0#       '補強幅
    Public Const BM_CHKY_H = 100.0#      '補強高さ(省略部分)
    '内部配電盤
    Public Const BM_CHKX_HAND_SP = 60.0# '把手方向の扉補強間隔
    Public Const BM_CHKX_HING_SP = 83.0# 'ヒンジ方向の扉補強間隔（屋内）
    Public Const BM_CHKY_1_SP = 25.0#      '扉上部－補強上部間隔
    Public Const BM_CHKY_2_SP = 120.0#      '扉下部－補強下部間隔
    Public Const BM_CHKY_3_SP = 100.0#     '補強－把手間隔（片開き）
    Public Const BM_CHKY_4_SP = 50.0#     '把手－補強間隔（片開き）

    Public Const BM_HKY_WPos = 50.0#     '補強幅方向位置寸法の補強上端からの表示位置
    Public Const BM_KPlate_W = 62      '扉取付配電盤用取付板幅サイズ（把手部）
    Public Const BM_KPlate_H = 38      '扉取付配電盤用取付板高さサイズ（把手部）
    Public Const BM_KiKiMove = 20      '図面枠付き図面機器位置寸法の表記位置移動距離
    Public Const BM_TotteWapNoIR = "100" '把手ワッペン番号(屋内右ヒンジ)
    Public Const BM_TotteWapNoIR3 = "101" '把手ワッペン番号(屋内右ヒンジ３段扉)
    Public Const BM_TotteWapNoIL = "102" '把手ワッペン番号(屋内左ヒンジ)
    Public Const BM_TotteWapNoIL3 = "103" '把手ワッペン番号(屋内左ヒンジ３段扉)
    Public Const BM_TotteWapNoIWL = "104" '把手ワッペン番号(屋内観音左ヒンジ)
    Public Const BM_TotteWapNoOR = "105" '把手ワッペン番号(屋外右ヒンジ)
    Public Const BM_TotteWapNoOL = "106" '把手ワッペン番号(屋外左ヒンジ)
    Public Const BM_TotteWapNoOWR = "107" '把手ワッペン番号(屋外観音左ヒンジ)
    Public Const BM_TotteWapNoSBL = "110" 'ボルトワッペン番号(内部配電盤右ヒンジ)
    Public Const BM_TotteWapNoSBR = "111" 'ボルトワッペン番号(内部配電盤左ヒンジ)
    Public Const BM_TotteWapNoSHL = "112" 'ハンドルワッペン番号(内部配電盤左ヒンジ)
    Public Const BM_TotteWapNoSHR = "113" 'ハンドルワッペン番号(内部配電盤右ヒンジ)
    Public Const BM_KindStr = "DSKMN"    '扉種類文字
    Public Const BM_PosStr = "FBLRN"     '扉位置文字
    Public Const BM_Tspace = 110  '扉からの把手の距離
    Public Const BM_TDimPos = 20  '把手寸法値の表示位置
    Public Const BM_DoorWDim = 50 '扉高さ寸法値の表示位置
    Public Const BM_BoxDim = 200  '箱外形寸法値の表示位置
    Public Const BM_KHDim = 100   '器具の高さ寸法線長さ
    Public Const BM_KWDim = 50    '器具の幅寸法線長さ
    Public Const BM_RLspace = 7   '片開き扉の盤幅との隙間サイズ
    Public Const BM_Wspace = 6    '両開き扉の盤幅との隙間サイズ
    '  Public Const BM_Base_X = 1300 '図面枠付盤面図左下基準点X座標
    Public Const BM_Base_X = 1000 '図面枠付盤面図左下基準点X座標
    '  Public Const BM_Base_Y = 2400 '図面枠付盤面図左下基準点Y座標 (2D)
    Public Const BM_Base_Y = 1300 '図面枠付盤面図左下基準点Y座標 (2C)
    Public Const BM_Spec1_Base_X = 6700 '図面枠付盤面図仕様1基準点X座標
    Public Const BM_Spec1_Base_Y = 4700 '図面枠付盤面図仕様1基準点Y座標
    Public Const BM_Spec2_Base_X = 6700 '図面枠付盤面図仕様2基準点X座標
    Public Const BM_Spec2_Base_Y = 3600 '図面枠付盤面図仕様2基準点Y座標
    Public Const BM_OneDoor_Base_X = 700 '片開き扉詳細図基準点X座標
    Public Const BM_OneDoor_Base_Y = 1200 '片開き扉詳細図基準点Y座標
    Public Const BM_DoubleDoor_Base_X = 2280 '両開き扉詳細図基準点X座標
    Public Const BM_DoubleDoor_Base_Y = 1200 '両開き扉詳細図基準点Y座標
    Public Const BM_ZSpacer = "-----" '図面作成時に盤間にスペースを入れる
    '  Public Const BM_BoxSpace = 1000 '図面作成時の盤間に空間を入れる場合の盤間距離(2D)
    Public Const BM_BoxSpace = 500 '図面作成時の盤間に空間を入れる場合の盤間距離(2C)
    Public Const BM_HakoPos = 120   '箱番号の配置位置
    '  Public Const BM_MeiBlkPos = 300 '"名称板記入文字"の表を配置する位置
    Public Const BM_RimenBlkPos = 300 '"裏面器具一覧表"の表を配置する位置

    Public Const BM_NP_Base_X = 4800    '銘板一覧表配置基準点X座標
    Public Const BM_NP_Base_Y = 3700    '銘板一覧表配置基準点Y座標
    Public Const BM_NP_Space = 40       '銘板一覧表配置間隔

    Public Const BM_Hinge_Text_1 = "右"
    Public Const BM_Hinge_Text_2 = "左"
    Public Const BM_Hinge_Text_3 = "両"
    Public Const BM_Hinge_SP_Text_1 = "ハンドル式右開"
    Public Const BM_Hinge_SP_Text_2 = "ハンドル式左開"
    Public Const BM_Hinge_SP_Text_3 = "ボルト式右開"
    Public Const BM_Hinge_SP_Text_4 = "ボルト式左開"

    '↓扉取付配電盤 2010.12.8 松本追加(裏面ﾋﾟｯﾁ鋼追加に伴う)
    Public Const BM_K_HKX_L = 60      '扉左部－左側補強間隔
    Public Const BM_K_HKX_R = 60      '扉右部－右側補強間隔
    Public Const BM_K_HKY_1 = 125     '扉上部－扉センター間隔
    Public Const BM_K_HKY_2 = 175     '扉下部－扉センター間隔
    Public Const BM_K_TDimPos = 50    '把手位置寸法値表示位置補正値
    '↑ここまで

    Public Const BM_Tokki_Base_X = 4500 '特記事項配置基準点X座標
    '  Public Const BM_Tokki_Base_Y = 1000 '特記事項配置基準点Y座標 (2D)
    Public Const BM_Tokki_Base_Y = 1900 '特記事項配置基準点Y座標 (2C)
    Public Const BM_Tokki_Space = 80    '特記事項配置間隔
    Public Const BM_Tokki_Str1_1 = "操作開閉把手は彫刻文字付とします。"
    Public Const BM_Tokki_Str1_2 = "　彫刻文字範囲：ＣＳ・ＣＯＳ・ＰＢＳ・ＶＳ・ＡＳ"
    Public Const BM_Tokki_Str1_3 = ""
    Public Const BM_Tokki_Str1_4 = ""
    Public Const BM_Tokki_Str2_1 = "ＧＦＩ記入文字は別図"
    Public Const BM_Tokki_Str2_2 = ""
    Public Const BM_Tokki_Str2_3 = "　～"
    Public Const BM_Tokki_Str2_4 = "によります。"
    Public Const BM_Tokki_Str3_1 = "扉裏面に取り付ける補助継電器は別図"
    Public Const BM_Tokki_Str3_2 = ""
    Public Const BM_Tokki_Str3_3 = "　～"
    Public Const BM_Tokki_Str3_4 = "によります。"
    Public Const BM_Tokki_Str4_1 = "※印機器は将来実装とします。"
    Public Const BM_Tokki_Str4_2 = "　尚、今回は穴明後、仮蓋及び仮端子を取り付けます。"
    Public Const BM_Tokki_Str4_3 = ""
    Public Const BM_Tokki_Str4_4 = ""
    Public Const BM_Tokki_Str5_1 = "扉面機器・扉裏面機器は、端子カバー又は"
    Public Const BM_Tokki_Str5_2 = "　絶縁キャップにて端子部をカバーします。"
    Public Const BM_Tokki_Str5_3 = ""
    Public Const BM_Tokki_Str5_4 = ""


    '-----------------------------------------------------------------------------------------


    '現在の図面保存場所までのパス
    Public ppath As String

    '主回路ケーブル穴
    'Public Sayu As String       '箱のセンターからの振分長さ
    'Public SayuFugo As String   '箱のセンターからの振分長さの符号(センターから左が-)
    'Public Zengo As String       '基準線からの長さ
    'Public ZengoFugo As String   '箱のセンターからの振分長さの符号(背面側からの寸法の場合が-)
    'Public Haba As String       'ケーブル穴の幅方向のサイズ
    'Public Okuyuki As String    'ケーブル穴の奥行き方向のサイズ
    'Public HakoNo As String     '一時的に箱番号を格納
    'Public HakoNoData() As String
    'Public SyukairoData(,) As String        '各箱に作図する主回路ケーブル穴の高さや幅等のデータ
    'Public Syukairoflg As Boolean = False   '主回路ケーブル穴設定フラグ
    'Public OldAna As AcadObject
    'Public AnaCLineX As Object              '主回路ケーブル穴センター線(x軸に平行)
    'Public AnaCLineY As AcadObject          '主回路ケーブル穴センター線(y軸に平行)
    'Public CLineAXCenter As Object
    'Public KLineAYCenter As AcadDimAligned
    Public SFlg As Boolean = True
    Public pnt10 As String              '座標をコマンドで送るためのString型変数
    Public pnt11 As String              '座標をコマンドで送るためのString型変数
    Public pnt12 As String              '座標をコマンドで送るためのString型変数
    Public num As String
    Public insPntMS(0 To 2) As Double
    Public insPntME(0 To 2) As Double

    Public Okugai As Boolean            '屋内外判断フラグ
    Public HokyoPtn As Integer          '各箱の補強板パターン
    Public Hako() As String             '
    Public PLHakoNo As Integer          '各箱の分割有無確認用配列
    Public OHokyoflg As Boolean         '奥行方向の補強追加フラグ
    Public Platingflg As Boolean        'メッキ使用フラグ

    Public IFG_Cnt2 As Integer          '次のページにいったとき用合符号カウンター

    Public KijunX() As Double           '補強板作図用の各箱基準点記憶用配列
    Public iDatNum2 As Integer          '補強板作図用の各ページの全箱数記憶用配列

    Public H_Cnt As Integer             '1ページに収まった箱数
    Public iPage As Integer             '配列図用ページカウンタ


    Public HokyoKata As String
    Public HokyoD As String
    Public LX As Double                 '左側外形線と左側奥行枠との距離(補強枠作図で使用)
    Public RX As Double                 '右側奥行枠

    Public BReadflg As Boolean          '盤データ読込フラグ
    Public Lflg As Boolean              'cellvaluechangedイベントがフォーム読み込み時に反応しないようにするためのフラグ

    Public Kpics As Image()             '引込穴のプレビュー画像用配列
    Public Kpicname() As String         '引込穴の名前用配列
    Public dwges As String()            '引込穴のブロック用配列
    Public dwgname() As String          '引込穴のブロック名用配列
    Public Hpics As Image()             '補強枠のプレビュー画像用配列
    Public Hpicname() As String         '補強枠の名前用配列

    Public tateumu As Integer           '線分での補強枠作図時に左右の縦線が必要か判断するための変数
    Public tateumu2 As Integer          '線分での補強枠作図時に左右の縦線が必要か判断するための変数

    Public InOut As String              '屋内外
    Public Door As String               '扉
    Public Kesho As String              '化粧板
    Public Seikan As String             '製缶
    Public SeigyoK As String            '制御ケーブル穴
    Public TFntSunpo As String          '前面機器引出所要寸法
    Public TBckSunpo As String          '背面機器引出所要寸法
    Public Kumitate As String           '組立方式

    'アンカー関連追加
    Public LoopLimit As Integer 'ループの制限（分割数）
    Public S_End As Integer
    Public SPO As Integer, EPO As Integer
    Public ANC_CHK As Integer, Add_ANC As Integer, ANC(0 To 20) As Integer
    Public ES As Integer
    Public AncBlk As AcadBlock      'ｱﾝｶｰﾎﾞﾙﾄﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
    Public AncPnt(0 To 2) As Double
    Public AncNum As Integer   'ｱﾝｶｰﾎﾞﾙﾄ列数
    Public AncNam As String   'ｱﾝｶｰﾎﾞﾙﾄ名
    Public BlkObj As Object     'アンカーボルトのセット(同じx座標のもの)を代入する変数
    Public insPntA As Double    '屋内のときに分割点間のアンカーボルトの寸法の値がおかしくならないようにする(Y座標を取っておく)
    Public insPntB As Double    '左端が納入外の場合、1つめのアンカーボルト挿入点が最左端箱ではないので、その点を覚えておくための変数

    '基礎図表
    Public Const pc_HokyoKataRow As Integer = 1        '補強枠型選択行
    Public Const pc_HokyoARow As Integer = 2           '補強枠A寸法行
    Public Const pc_HokyoBRow As Integer = 3           '補強枠B寸法行
    Public Const pc_HokyoXRow As Integer = 4           '補強枠X寸法行
    Public Const pc_HokyoYRow As Integer = 5           '補強枠Y寸法行
    Public Const pc_LOkuyukiRow As Integer = 6         '奥行枠有無選択行(左)
    Public Const pc_ROkuyukiRow As Integer = 7         '奥行枠有無選択行(右)
    Public Const pc_BunkatuRow As Integer = 8          '分割点(箱の右側)
    Public Const pc_Hiki1Row As Integer = 9            '引込穴1の形式
    Public Const pc_Hiki2Row As Integer = 10            '引込穴2の形式
    Public Const pc_Hiki3Row As Integer = 11            '引込穴3の形式
    Public Const pc_Hiki4Row As Integer = 12            '引込穴4の形式
    Public Const pc_BanCopyRow As Integer = 13            '「保存」ボタン行
    Public Const pc_BanPasteRow As Integer = 14            '「貼り付け」ボタン行
    Public Bunkatu As String                            '最大分割地点
    Public Bunkatuiti() As String                       '分割指示があった箱名


    'P_sBanDat内での基礎図表タブの表の項目の位置
    Public Const pc_HokyoKataRow2 As Integer = 29        '補強枠型選択行
    Public Const pc_HokyoARow2 As Integer = 30           '補強枠A寸法行
    Public Const pc_HokyoBRow2 As Integer = 31           '補強枠B寸法行
    Public Const pc_HokyoXRow2 As Integer = 32           '補強枠X寸法行
    Public Const pc_HokyoYRow2 As Integer = 33           '補強枠Y寸法行
    Public Const pc_LOkuyukiRow2 As Integer = 34         '奥行枠有無選択行(左)
    Public Const pc_ROkuyukiRow2 As Integer = 35         '奥行枠有無選択行(右)
    Public Const pc_BunkatuRow2 As Integer = 36          '分割点(箱の右側)
    Public Const pc_Hiki1Row2 As Integer = 37            '引込穴1の形式
    Public Const pc_Hiki2Row2 As Integer = 42            '引込穴2の形式
    Public Const pc_Hiki3Row2 As Integer = 47            '引込穴3の形式
    Public Const pc_Hiki4Row2 As Integer = 52            '引込穴4の形式


    Public DelNo() As Integer                           '納入外(非表示)の箱が何番目にあったかを記憶しておく配列

    Public Const KumiBlkX As Integer = 480
    Public Const KumiBlkY As Integer = 80               '「注）本ベースは現地組立式ベースです」ブロックの位置(Y)

    Public PCnt As Integer                              '図番表記用現在のページカウンタ
    Public AncMFlg As Boolean                           'アンカーボルト間の寸法を書くときに、右から左に寸法線を作図するFlg
    Public oneboxflg As Boolean                         '1箱のみならtrue  

    'DB関連
    Public sTmpKbn As String                            '工番体系を揃えた工番 ex)X 999999
    Public SyukairoA As String                          '引込穴(主回路ケーブル穴)
    Public BanNo As String                              '盤No
    Public BanCnt() As String                           'データベースから読み込んだ箱番をセットする
    Public BanCnt2 As Integer                           '何箱目の処理かを判断するカウンタ
    Public LoadCnt As Integer                           'DBから読み込み時に何箱分読み込むか(ループ回数)
    Public DBHairetu As Boolean                         'DBで工群番で検索したときに見つかった件数を下記LoopCntに記憶するか判断するフラグ(DB配列箱別のときのみTrue)
    Public Loopnum As Integer                           '上記LoopCntの値を引き継ぐ
    Public CntB As Integer                              '保存時に読み込んだ盤数(上記LoopCnt)より盤が減っていたらDBからその盤を消す処理へとつなげる
    Public Syubetu As String                            '製品種別
    Public Kanki As String                              '換気穴
    Public Renban() As Integer                          '箱連番

    Public frmkisoflg As Boolean                        'マスターデータがないときにどのフォームからアクセスしているか判断(Trueならfrm配列基礎仕様からではない)

    '配列図追加
    Public nps As Boolean                               'NPS承認図として作図するかどうかのフラグ(True → NPS承認図として作図)
    Public Const NPSDown As Double = 31.32              'NPSとして作図する場合は、表の項目が減ってブロックの長さ(図面での奥行)が短くなるので、その分の半分位置を下げて、ブロックを貼る
    Public YDown As Double                              'NPS承認図なら上記NPSDownを代入し、通常なら0
    Public Cellingflg As Boolean                           '屋外の天井を作図中かを判断するフラグ(True → 天井作図中)
    Public SKCode As String                             'ブロックスケルトンコード


    Public Wakuflg As Boolean                           '枠の二重作図防止(true → 作図済み)


    '仕様流用
    Public koubanname2 As String                        '流用元の工番
    Public gunbanname2 As String                        '流用元の群番
    Public Diversionflg As Boolean                      '流用するか否かのフラグ(true → 流用する)
    Public P_sBanDatR(,) As String                      '流用する工番の配列基礎仕様のデータをDBから読込、DataGridViewへ表示
    Public CopyBan() As String                          'クリックされた列ヘッダーを記憶


    'ブロックスケルトン
    Public XLen As Double
    Public YLen As Double
    Public LineArray(300) As Object                     'ブロックスケルトンの要素(線分やポリライン)を並べた配列
    Public SP(7) As Double                              'スケルトンの枠のCoordinates値
    Public BanNoSK As Integer                            '今何箱目の処理か
    Public SKCnt As Integer                             'スケルトンのファイルにはたくさんの要素(線分など)があり、それをすべて見に行くと処理に時間がかかるので、2つ処理が終わったら残りの要素は見ない
    Public SKname As String                             '正面図に設定するスケルトンブロックの名前

    'Public Bunkatuflg As Boolean                        'CalPageプロシーシャを2回通るので、今何回目かを判断(False → 1回目,True → 2回目)
    Public BoxNo(conNum) As String                              '納入外の箱番
    Public RBox As String                             '一番右端の箱の箱番





    Public ErrCell() As String
    Public ErrCellList As String                        'エラー番号2のときのエラーメッセージ

    Public ErrNum As Integer                            'エラー番号用配列
    Public Stopflg As Boolean                           '作業中断判断フラグ(True → 中断    DBへの保存時や作図時にエラーがあるなら中断)
    Public Sakuzuflg As Boolean                         '保存処理中か作図処理中か判断(True → 作図処理中)

    'エラーテキスト
    Public EMsg As String = "作図時にエラーが発生する可能性があるので修正してください。"
    Public EMsg2 As String = "保存時にエラーが発生する可能性があるので修正してください。"
    Public Err1 As String = "箱番でエラーが発生しています。"
    Public Err2 As String = "盤No、扉解放角度、質量、各寸法と" & vbCrLf & "「最大分割位置」は数値のみの入力です。"
    Public Err3 As String = "箱の幅、高さ、奥行は1以上の値を入力してください。"
    Public Err4 As String = "補強枠が箱よりも大きい箇所があるので、" & vbCrLf & "補強枠の各寸法を修正してください。"
    Public Err5 As String = "引込穴が箱よりも大きい箇所があるので、" & vbCrLf & "引込穴の各寸法を修正してください。"
    Public Err6 As String = "扉の組み合わせが異なる箱があります。"
    Public Err7 As String = "入力形式が異なるのでDBへ保存できません。" & vbCrLf & "数値のみ有効です。"
    Public Err8 As String = "補強枠のA寸法が0以下の箱があります。" & vbCrLf & "補強を設定する際、A寸法は1以上で設定してください。"
    Public Err9 As String = "補強枠のB寸法が0以下の箱があります。" & vbCrLf & "補強を設定する際、B寸法は1以上で設定してください。"
    Public Err10 As String = "補強枠のY寸法が0以下の箱があります。" & vbCrLf & "補強を設定する際、Y寸法は1以上で設定してください。"
    Public Err11 As String = "引込穴のA寸法が0以下の箱があります。" & vbCrLf & "引込穴を設定する際、A寸法は1以上で設定してください。"
    Public Err12 As String = "引込穴のB寸法が0以下の箱があります。" & vbCrLf & "引込穴を設定する際、B寸法は1以上で設定してください。"
    Public Err13 As String = "引込穴のY寸法が0以下の箱があります。" & vbCrLf & "引込穴を設定する際、Y寸法は1以上で設定してください。"

    Public ErrT1 As String = "箱番の重複エラー"
    Public ErrT2 As String = "入力形式エラー"
    Public ErrT3 As String = "箱寸法値0エラー"
    Public ErrT4 As String = "補強枠はみ出しエラー"
    Public ErrT5 As String = "引込穴はみ出しエラー"
    Public ErrT6 As String = "扉形状エラー"
    Public ErrT7 As String = "入力形式エラー"
    Public ErrT8 As String = "補強枠A寸法値エラー"
    Public ErrT9 As String = "補強枠B寸法値エラー"
    Public ErrT10 As String = "補強枠Y寸法値エラー"
    Public ErrT11 As String = "引込穴A寸法値エラー"
    Public ErrT12 As String = "引込穴B寸法値エラー"
    Public ErrT13 As String = "引込穴Y寸法値エラー"

    'エラーテキスト用配列
    Public ErrList() As String = {"", Err1, Err2, Err3, Err4, Err5, Err6, Err7, Err8, Err9, Err10, Err11, Err12, Err13}

    Public ErrTitle() As String = {"", ErrT1, ErrT2, ErrT3, ErrT4, ErrT5, ErrT6, ErrT7, ErrT8, ErrT9, ErrT10, ErrT11, ErrT12, ErrT13}



    'エラー箇所表記リストボックス
    Public Const lblitiX As Integer = 12
    Public Const lblitiY As Integer = 9
    Public Const txtitiX As Integer = 215
    Public Const txtitiY As Integer = 6
    Public Const NextY As Integer = 25
    Public Const lblSizeX As Integer = 197
    Public Const lblSizeY As Integer = 12
    Public Const txtSizeX As Integer = 117
    Public Const txtSizeY As Integer = 19
    Public lblCnt As Integer
    Public ACnt As Integer
    Public BCnt As Integer
    Public YCnt As Integer


    'frmBlkSK関連
    Public SKPath As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\skeleton\SKTree"
    Public rootNode As New TreeNode        'ルートノード
    'Public nodename As String = "7.2kV"
    'Public nodenameS As String = "7.2kV S-PAC"
    'Public childNode As New TreeNode       '1つ下の階層のノード
    'Public nodenameTR As String = "TR2次"
    'Public nodenameFi As String = "フィーダ"
    'Public nodenameBo As String = "母連"
    'Public nodenameSh As String = "所内"
    'Public childNodeHa As New TreeNode '2つ下の階層のノード(配列)
    'Public nodenameHa As String = "配列"
    'Public nodenameHLR As String = "配列:左→右"
    'Public nodenameHRL As String = "配列:左←右"
    'Public childNodeHi As New TreeNode '3つ下の階層のノード(引込)
    'Public nodenameHi As String = "引込"
    'Public nodenameHT As String = "引込:上引込み"
    'Public nodenameHU As String = "引込:下引込み"
    'Public nodenameHD As String = "引込:ダクト引込み"
    'Public childNodeT As New TreeNode '4つ下の階層のノード(上段機器)
    'Public nodenameTN As String = "上段機器:無し"
    'Public nodenameTEVT As String = "上段機器:EVT"
    'Public nodenameTVT As String = "上段機器:VT"
    'Public nodenameTVCB As String = "上段機器:VCB"
    'Public nodenameTSh As String = "上段機器:将来"
    'Public childNodeU As New TreeNode '5つ下の階層のノード(下段機器)
    'Public nodenameUN As String = "下段機器:無し"
    'Public nodenameUEVT As String = "下段機器:EVT"
    'Public nodenameUVT As String = "下段機器:VT"
    'Public nodenameUVCB As String = "下段機器:VCB"
    'Public nodenameUSh As String = "下段機器:将来"
    'Public nodenameUSTR As String = "下段機器:STR"
    'Public childNodeOP As New TreeNode '6つ下の階層のノード(機器OP)
    'Public nodenameGCN As String = "機器OP:GC無し"
    'Public nodenameGCA As String = "機器OP:GC有り"
    'Public nodenameOPN As String = "機器OP:OP無し"
    'Public nodenameETN As String = "機器OP:ET無し"
    'Public nodenameETA As String = "機器OP:ET有り"
    'Public nodenameOPT As String = "機器OP:単独"
    'Public nodenameOP2 As String = "機器OP:2面連結"
    'Public pc_nodelist() As String = {nodenameTR, nodenameFi, nodenameBo, nodenameSh}
    'Public pc_nodelistHa() As String = {nodenameHLR, nodenameHRL}
    'Public pc_nodelistHi() As String = {nodenameHT, nodenameHU, nodenameHD}
    'Public pc_nodelistT() As String = {nodenameTEVT, nodenameTVT}
    'Public pc_nodelistT2() As String = {nodenameTVCB, nodenameTSh, nodenameTEVT}
    'Public pc_nodelistU() As String = {nodenameUVCB, nodenameUSh, nodenameUEVT}
    'Public pc_nodelistOP() As String = {nodenameGCN, nodenameGCA}
    'Public nodeID(,) As String = {{"TR", "Fi", "Bo", "Sh", ""}, _
    '                              {"Ha", "HaHi", "HaHiT", "HaHiTU", "HaHiTUOP"}}
    Public levelcnt As Integer '階層カウンタ("\"が見つかるごとに増え、"\"の数で階層を判断、初期値が-9なのはSKTreeフォルダで0になるようにするため)
    Public Folders() As String  'ブロックスケルトンを保存するフォルダのパスを格納(スケルトン選択ツリーのような感じ)
    Public picfiles() As String
    Public picfiles2() As String
    Public picname As String
    Public fullpath As String
    Public SKX As Integer       'ブロックスケルトン選択フォームを出す際に、ダブルクリックされたセルのX座標を記憶
    Public SKFullPath() As String     '配列基礎仕様表で各箱に設定されたブロックスケルトンのフルパス
    Public SKCopyPath As String     'SKFullPath(現在作図中の箱連番)の値

    '----------------------------------------------------------------
End Module
