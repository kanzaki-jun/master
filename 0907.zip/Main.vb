﻿Imports System.IO
Imports System.Text

Module Main



#Region "メイン"

#Region "工番、群番、JobNo.を取得"

    Sub GetKouGunJob(ByVal CmdArg() As String)


        Dim tempArr() As String

        For Each s In CmdArg

            tempArr = s.Split(",")

            If (tempArr Is Nothing) = False Then

                '工番、群番、ジョブNo.を取得
                Kouban = TrimOrder(tempArr(0))
                Gunban = tempArr(1)
                Job = CreSpace(ComDic("ジョブNo") - LenB(CStr(tempArr(2))), "0") & tempArr(2)
            End If
        Next
    End Sub
#End Region

#Region "パス関係"


    Sub SelectCSVPath()
        Dim index As String = Dic1("インデックス").Trim

        CoordPath = CoordDPath & "\自動配線後_端点座標_" & BanNo & "_" & index & ".csv"
        CSVDataPath = CSVDataDPath & "\test" & BanNo & "_" & index & ".csv"
    End Sub

    ''' <summary>
    ''' E3出力先へのパスを設定
    ''' </summary>
    ''' <remarks>パスデータはE3Pathに保存</remarks>
    Sub SetE3OutPath()
        Dim typestr As String = ""
        Dim path As String = DefE3Path

        Select Case Type

            Case "産"
                typestr = "産業\"

            Case "水"
                typestr = "水\"

            Case "鉄"
                typestr = "電鉄\"
            Case "電"
                typestr = "電力\"

            Case "道"
                typestr = "道路\"

        End Select

        path = path & typestr

        'X16-338 なら　0=X,1=16338
        Dim KI As String = Left(SepaStr(Kouban)(1), 2)

        E3Path = path & KI & "期\" & Kouban & "\" & Gunban


    End Sub

    Public Function CheckFiles(ByVal E3Path As String) As Boolean

        'データ出力先へのパスが正しいかチェック
        If CheckDir(OutPutWDPath) = True And _
            CheckDir(OutPutNCPath) = True And _
            CheckDir(OutPutLISTPath) = True Then
            'パスが正しい場合

            'E3のファイルとデータ変換のファイルを比較して、
            'E3のファイルのほうが新しければTrueを返す
            Dim E3Date As Date = System.IO.File.GetLastWriteTime(E3Path)
            Dim OutDate As Date = System.IO.File.GetLastWriteTime(OutPutWDPath)


            If E3Date > OutDate Then
                CheckFiles = True
            Else
                MsgBox("E3出力データの新規更新がないので、処理を中断します。", , "処理中断")
                CheckFiles = False
            End If
        Else
            'パスが正しくない場合
            CheckFiles = False
        End If
    End Function

    Function CheckDir(ByVal ChkPath As String) As Boolean

        Dim temp As Boolean = System.IO.Directory.Exists(ChkPath)
        CheckDir = True

        If temp = False Then
            '
            MsgBox(ChkPath & "のフォルダがありません。")

            CheckDir = False
        End If

    End Function

    'Sub CreOutDir(ByVal Path As String)
    '    Dim temppath As String = ""
    '    Dim temparr() As String

    '    If Mid(Path, 1, 2) = "\\" Then

    '        temppath = Mid(Path, 3)
    '    Else
    '        temppath = Path
    '    End If

    '    temparr = temppath.Split("\")


    '    For i = 0 To UBound(temparr)
    '        If i = 0 Then
    '            'temppathの値を変更
    '            temppath = "\\" & temparr(i)
    '        Else
    '            temppath = temppath & "\" & temparr(i)
    '        End If

    '        If System.IO.File.Exists(temppath) = True Then

    '            Dim di As System.IO.DirectoryInfo = _
    '                System.IO.Directory.CreateDirectory(temppath)
    '        End If
    '    Next i
    'End Sub


#End Region


    '前提として
    'E3出力ファイル
    'エリアとインデックスの対応表
    '端点座標のCSVファイル
    '座標名、略称、形式、端子種類、器具番号を一行とするCSVファイル
    '以下4ファイルがあると想定したうえで動作。

     Sub Main(ByVal CmdArg() As String)


        Dim Line As String                          'E3出力ファイルの一行の文字列
        Dim Header As String                        'E3出力ファイルのヘッダの値(01=ヘッダ行、02=布線行)
        Dim Place As Integer                        '現在の文字列内での位置
        Dim Max As Integer                          'For文の最大ループ数
        Dim ArrArea As New ArrayList                'インデックスとエリアの対応表に使用する仮変数
        Dim inputFile As String = ""                '入力用ファイル


        '工番、群番、JobNo.を引数から取得
        GetKouGunJob(CmdArg)

        'データベース用の工番DBKoubanを求める
        DBOrder(Kouban)

        'データベースから客先名、
        ConnectODB(DBKouban)

        'E3出力先のパスを設定
        SetE3OutPath()



        'E3データ出力先の工番と群番に一致したファイルのパスを複数取得
        Dim E3Files As String() = _
          System.IO.Directory.GetFiles(E3Path, "E3_" & Kouban & Gunban & "*" & ".*")



        If E3Files.Length = 0 Then
            'E3出力ファイルが存在しない場合
            'メッセージを出して処理を中断

            MsgBox("E3の出力データを見つけることができませんでした。" & vbCrLf _
            & "JobNo.を間違えて入力している可能性があります。" & vbCrLf & _
            "もしくは、JobNo.登録先の工番、群番の入力ミスの可能性があります。", , "エラーにより処理中断")

            Exit Sub
        End If

        'データ変換の出力先のフォルダがない、もしくはE3出力ファイルがデータ変換
        If CheckFiles(E3Files(0)) = False Then Exit Sub

        Max = UBound(E3Files)

        '取得したファイルの分だけ繰り返す
        For i As Integer = 0 To Max
            '複数ファイルのデータを１つのListに纏める

            '複数取得したファイルパスのうちの一つを選択
            inputFile = E3Files(i)

            'パスのファイルを開く
            Using reader As New StreamReader(inputFile, Encoding.Default)
                While (reader.Peek() > -1)
                    '最終行まで一行ずつ読み込む
                    Line = reader.ReadLine()
                    '読み込んだ一行をPublic listのReadListに保存
                    ReadList.Add(Line)
                End While
                reader.Close()
            End Using
        Next

        'インデックスとエリアの対応表作成
        'ArrayListに読み込み結果をArrayList型に変換して保存
        ArrArea = CType(ReadCSV(AreaCSVPath, False), System.Collections.ArrayList)

        For i = 1 To ArrArea.Count - 1
            Dim temp() As String = CType(ArrArea(i), String())
            'temp(0)=インデックス、temp(1)=エリア
            IndexToArea.Add(temp(0), temp(1))
        Next

        '隣の盤がどの盤かを示すNextBanDicを作成
        CreNextBanDic()

        'ListをFor文でまわす
        For i = 0 To ReadList.Count - 1
            '1データの読み込み
            Line = ReadList(i)
            '左から2文字はHeader行
            Header = Left(Line, 2)
            '開始位置を初期値へ
            Place = 3

            'データとして最終行の場合、最終行フラグを立てる
            If i <> 0 And i <> ReadList.Count - 1 Then
                If Left(ReadList(i + 1), 2) = "01" Then
                    'ヘッダが切り替わったとき
                    LastFlg = True
                End If
            ElseIf i = ReadList.Count - 1 Then
                '最後のデータの場合
                LastFlg = True
            End If


            Select Case Header
                Case "01"
                    'ヘッダ行の時

                    If i <> 0 Then
                        'i≠0のときで、頭二文字が01の時
                        '初回以外のヘッダ行の時

                        SortedRec3_4_Data = Sort_Dic_L(Rec3_4_Data)
                        SortedRec6_Data = Sort_Dic_L(Rec6_Data)

                        CreRec3() : CreRec4() : CreRec6() : CreRec7()
                        CreFLP() : CreTEABWAT()
                        OutPutDATFiles()
                    End If


                    'キーと値の削除
                    Dic1.Clear()

                    'ヘッダ行に関するDictionaryを作成
                    CreDic(Dic1, Area1, AreaName1, Line, Place)

                    '盤No.
                    BanNo = Dic1("盤No").Trim()

                    If i = 0 Then
                        AllBanNo.Add(BanNo)
                    ElseIf AllBanNo.Contains(BanNo) = False Then
                        AllBanNo.Add(BanNo)
                        SetPartHON()
                    End If

                    '前背
                    FB = IndexToArea(Dic1("インデックス").Trim)


                    '群番(Space付)
                    Dim arr As String() = SepaStr(Gunban)
                    Gun = arr(0) & " " & arr(1)

                    SelectCSVPath()

                    'CSVファイルを読み込み、座標名＋分割名をArrCoordに保存
                    CreCoord(CType(ReadCSV(CoordPath, True), System.Collections.ArrayList))
                    '座標名,分割名,略称,形式,端子種類,器具番号のCSVデータを読み込み
                    'キー:座標名+分割名
                    '値  :{略称,形式,端子種類,器具番号}
                    'CSVDataDicを作成
                    ParseCSVData(CType(ReadCSV(CSVDataPath, True), System.Collections.ArrayList))



                    'レコードNo.1　作成
                    CreRec1()

                    'レコードNo.2　作成
                    CreRec2()

                    'レコードNo.5　作成
                    CreRec5()

                    'ZWD05KIK.job 作成
                    CreKIK()
                Case "02"

                    '布線行の時

                    'キーと値の削除
                    Dic2.Clear()

                    '布線行に関するDictionaryを作成
                    CreDic(Dic2, Area2, AreaName2, Line, Place)

                    SQ = Dic2("線サイズ")          '線サイズ(太さ)(空白付)
                    LnKnd = Dic2("線種")           '線種=電線種(空白付)
                    Color = Dic2("色")             'カラー=線色(空白付)

                    'Dim a As String = CStr(Val(SQ.Trim))

                    CreRoot()

                    'レコードNo.3　作成
                    'CreRec3(job)

                    '非特殊電線ならレコードNo.4を、特殊電線ならレコードNo.6を作成
                    Select Case SPCCheck(SQ.Trim, LnKnd.Trim)

                        Case "非特殊電線"
                            'レコードNo.4　作成
                            'CreRec4(job)

                            CreRec3_4_Data()
                        Case "特殊電線"
                            'レコードNo.6　作成
                            CreRec6_Data()
                    End Select

                    CreRec7_Data()

                    'レコードNo.9作成
                    CreRec9()
                    CreHON()
            End Select
        Next

        SortedRec3_4_Data = Sort_Dic_L(Rec3_4_Data)
        SortedRec6_Data = Sort_Dic_L(Rec6_Data)
        CreRec3()
        CreRec4()
        CreRec6()
        CreRec7()
        CreFLP()
        SetTotalHON()
        CreTEABWAT()
        OutPutDATFiles()
        OutPutZWDFiles()
    End Sub


#End Region






    ''' <summary>
    ''' アルファべットと数字を分けた配列を返す
    ''' </summary>
    ''' <param name="str">対象文字列</param>
    ''' <returns>
    ''' (0):アルファべット,(1):数字　　
    ''' </returns>
    ''' <remarks></remarks>
    Function SepaStr(ByVal str As String) As String()
        Dim temp As String
        Dim ret(1) As String
        For i = 1 To str.Length
            temp = Mid(str, i, 1)
            Select Case temp
                Case "a" To "z", "A" To "Z"
                    ret(0) = ret(0) & temp
                Case "0" To "9"
                    ret(1) = ret(1) & temp
            End Select
        Next

        Return ret
    End Function


End Module
