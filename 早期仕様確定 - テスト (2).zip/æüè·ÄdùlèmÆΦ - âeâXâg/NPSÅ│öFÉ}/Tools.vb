﻿Module Tools

    '---------------------------------------------------------------------

    Public Function CalPosition(ByVal HakoNo As String) As Integer
        '-----------------------------------------------
        ' 箱番号から配列内の保管場所Noを取得する
        '-----------------------------------------------
        '   HakoNo      : 配列の位置を調べる箱No(ex 101)
        '   戻り値      : 配列内の位置(ex 1)
        '-----------------------------------------------

        Dim i As Integer
        CalPosition = 0         '初期値

        i = 1
        Do Until (Trim(H_CubNo(i)) = "")
            If Trim(H_CubNo(i)) = Trim(HakoNo) Then
                CalPosition = i
                Exit Function
            End If
            i = i + 1
        Loop
    End Function

    Public Sub ClearCom()
        '-----------------------------------------------
        '  データ格納配列の初期化
        '-----------------------------------------------
        Dim i As Integer

        ReDim ExtCubNo(conNum)      'エラー回避

        For i = 0 To conNum
            On Error Resume Next
            '共通事項
            CubNo(i) = ""
            ExtCubNo(i) = ""
            BaseCubNo(i) = ""
            BaseBunkatu(i) = ""
            '個別事項
            H_CubNo(i) = ""
            H_Hz(i) = ""
            H_Zetuen(i) = ""
            H_Kata1(i) = ""
            H_Kata2(i) = ""
            H_DenAtu(i) = ""
            H_Hogo1(i) = ""
            H_Hogo2(i) = ""
            H_TNP(i) = ""
            H_DRZuban(i) = ""
            H_DoorZuban(i) = ""
            H_NP1(i) = ""
            H_NP2(i) = ""
            H_NP3(i) = ""
            H_NP4(i) = ""
            H_Jyotai(i) = ""
            H_WakuType(i) = ""
            H_D(i) = ""
            H_H(i) = ""
            H_W(i) = ""
            H_Totte(i) = ""
            H_DoorOpen(i) = ""
            H_Jyuryo(i) = ""
            H_PowerFreq(i) = ""
            H_Impulse(i) = ""
        Next
        '共通事項
        D_Name = ""
        DoorType = ""
        IO = ""
        KeshoType = ""
        FntSunpo = ""
        BckSunpo = ""
        'BaseH = ""
        'SeigyoAna = ""
        Zumen = ""
        For i = 0 To 20
            BunkatuSE(i, 0) = ""
            BunkatuSE(i, 1) = ""
        Next
    End Sub


    '
    '盤データ保存ファイル作成(対象の工群番の保存データがない場合)
    '
    'Public Sub MakeBanFile(ByVal RowCnt As Integer)

    '    'Dim i As Integer, j As Integer


    '    ' フォルダが存在しているかどうか確認する
    '    If System.IO.Directory.Exists("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\") Then

    '    Else                'フォルダが存在しない場合
    '        '保存用フォルダ(○○期)を作成
    '        System.IO.Directory.CreateDirectory("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\")
    '    End If
    '    If System.IO.Directory.Exists("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\") Then

    '    Else                'フォルダが存在しない場合、処理を終了する(別なシステムでフォルダは先に作ってあるはずなので)
    '        MsgBox("指定された工番のフォルダがありません。")
    '        MsgBox("盤データの読み込みを中止しました。", MsgBoxStyle.Critical)
    '        BReadflg = False
    '        Exit Sub
    '    End If
    '    If System.IO.Directory.Exists("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\") Then

    '    Else                'フォルダが存在しない場合、名前が群番のフォルダを作成
    '        System.IO.Directory.CreateDirectory("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\")
    '    End If


    '    ' ファイルが存在しているかどうか確認する
    '    If System.IO.File.Exists("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtNam) Then
    '        Exit Sub
    '    Else                'ファイルが存在しない場合
    '        If frmkisoflg = True Then
    '            MsgBox("盤データがありません。設定してから作図してください。")
    '            BReadflg = False
    '            Exit Sub
    '        Else
    '            '保存用ファイルを作成
    '            Call MakeBantxt(RowCnt)
    '        End If
    '    End If
    'End Sub

    ''盤データ保存用ファイルを作成
    'Public Sub MakeBantxt(ByVal RowCnt As Integer)
    '    Dim hStream As System.IO.FileStream                 ' 戻り値を格納する変数
    '    Dim j As Integer

    '    ' hStream が破棄されることを保証するために Try ～ Finally を使用する
    '    Try
    '        ' hStream が閉じられることを保証するために Try ～ Finally を使用する
    '        Try
    '            ' 指定したパスのファイルを作成する
    '            hStream = System.IO.File.Create("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtNam)
    '        Finally
    '            ' 作成時に返される FileStream を利用して閉じる
    '            If Not hStream Is Nothing Then
    '                hStream.Close()
    '            End If
    '        End Try
    '        Dim writer As System.IO.StreamWriter

    '        'Shift-JISのテキストファイルを作成
    '        '第２パラメータは既存ファイルが存在する場合の振る舞い
    '        'false：上書き、true：追記
    '        writer = New System.IO.StreamWriter("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtNam, False, System.Text.Encoding.Default)

    '        j = 0
    '        For i = 0 To 1                      '1盤分の盤データファイルを作成
    '            For j = 0 To RowCnt
    '                If i = 0 Then                           '1行目なら
    '                    Select Case j
    '                        Case 0
    '                            writer.Write("1,")        '盤数
    '                        Case 1
    '                            writer.Write("屋内,")     '屋内外
    '                        Case 2, 3, 4, 5
    '                            writer.Write("無,")       '扉型番、側面化粧板、製缶方式、制御ケーブル穴
    '                        Case 6
    '                            writer.Write("50,")       '基礎ベース突出寸法
    '                        Case 7, 8
    '                            writer.Write("0,")        '機器引出所要寸法(前後)
    '                        Case Else
    '                            If j <> RowCnt Then
    '                                writer.Write(",")
    '                            End If
    '                    End Select

    '                ElseIf i = 1 And j = 0 Then                         '2行目の最初の区切り(盤No)
    '                    writer.Write("101,")                            '文字列の書き込み
    '                ElseIf j = RowCnt - 26 Or j = RowCnt - 21 Or j = RowCnt - 20 Or j = RowCnt - 19 Or j = RowCnt - 14 Or j = RowCnt - 9 Or j = RowCnt - 4 Then
    '                    '型名、奥行枠の項目
    '                    writer.Write("無,")
    '                ElseIf RowCnt - 26 < j And j < RowCnt - 21 Then     '補強枠の寸法
    '                    writer.Write("0,")
    '                ElseIf RowCnt - 19 < j And j < RowCnt - 14 Then     '1つめの引込穴の寸法
    '                    writer.Write("0,")
    '                ElseIf RowCnt - 14 < j And j < RowCnt - 9 Then      '2つめの引込穴の寸法
    '                    writer.Write("0,")
    '                ElseIf RowCnt - 9 < j And j < RowCnt - 4 Then       '3つめの引込穴の寸法
    '                    writer.Write("0,")
    '                ElseIf j = RowCnt Then                              '行の最後の値(4つ目の引込穴のY寸法)
    '                    writer.Write("0")
    '                ElseIf RowCnt - 4 < j Then                          '4つ目の引込穴のA、B、X寸法
    '                    writer.Write("0,")
    '                Else                         'その他
    '                    writer.Write(",")        '文字列の書き込み
    '                End If

    '            Next
    '            writer.Write(vbCrLf)
    '        Next
    '        writer.Close()

    '    Finally
    '        ' hStream を破棄する
    '        If Not hStream Is Nothing Then
    '            Dim cDisposable As System.IDisposable = hStream
    '            cDisposable.Dispose()
    '        End If
    '    End Try
    'End Sub

    ''基礎図作成ウィンドウ(frmkiso)での設定を保存するファイルの作成
    'Public Sub MakeKisotxt()
    '    Dim hStream As System.IO.FileStream                 ' 戻り値を格納する変数
    '    Dim j As Integer
    '    Dim sZbn As String = P_sKbn : Mid(sZbn, 4, 1) = "P" '工番に部門追加
    '    Dim SetubiNam As String = ""
    '    Dim Syubetu As String = ""
    '    Dim Kumitate As String = ""
    '    Dim MaxBunkatu As String = ""
    '    'マスターファイルの項目の配列(工番群番、設備名称、製品種別、図番、組立方法、分割位置)
    '    Dim koumoku() As String = {P_sKbnNam & P_sGbn, "", "", Trim(Mid(sZbn, 1, 6) & "-" & Mid(sZbn, 7)) & "-BB" & Mid(P_sGbn, Len(P_sGbn), 1) & "01", "", ""}



    '    ' hStream が破棄されることを保証するために Try ～ Finally を使用する
    '    Try
    '        ' hStream が閉じられることを保証するために Try ～ Finally を使用する
    '        Try
    '            ' 指定したパスのファイルを作成する
    '            hStream = System.IO.File.Create("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtkisoNam)
    '        Finally
    '            ' 作成時に返される FileStream を利用して閉じる
    '            If Not hStream Is Nothing Then
    '                hStream.Close()
    '            End If
    '        End Try
    '        Dim writer As System.IO.StreamWriter

    '        'Shift-JISのテキストファイルを作成
    '        '第２パラメータは既存ファイルが存在する場合にどうするか
    '        'false：上書き、true：追記
    '        writer = New System.IO.StreamWriter("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtkisoNam, False, System.Text.Encoding.Default)

    '        j = 0
    '        For i = 0 To (koumoku.Length - 1) * 2 - 1
    '            'データファイルを作成
    '            If i Mod 2 = 0 Then             'iが偶数のとき
    '                writer.Write(koumoku(j))    '文字列の書き込み
    '                j += 1
    '            Else                            '奇数
    '                writer.Write(vbCrLf)        '改行
    '            End If

    '            'writer.Write(vbCrLf)
    '        Next
    '        writer.Close()

    '    Finally
    '        ' hStream を破棄する
    '        If Not hStream Is Nothing Then
    '            Dim cDisposable As System.IDisposable = hStream
    '            cDisposable.Dispose()
    '        End If
    '    End Try
    'End Sub

    ''基礎図作成ウィンドウ(frmkiso)で入力した内容をマスターファイルに書き込む
    'Public Sub WriteKisoData()
    '    Dim i As Integer
    '    Dim sw As New System.IO.StreamWriter("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtkisoNam, _
    '    False, _
    '    System.Text.Encoding.GetEncoding("shift_jis"))

    '    For i = 0 To 5
    '        sw.Write(kisodata(i))        'txtファイルに書き込み(上書き)
    '        If i <> 5 Then
    '            sw.Write(vbCrLf)        'txtファイルに書き込み(改行)
    '        End If
    '    Next
    '    sw.Close()
    'End Sub


    'マスターファイルから基礎図全体の情報を読み込む(frmkiso用)
    'Public Sub ReadKisoData()
    '    Dim txtBan As String
    '    Dim i As Integer
    '    Dim koumoku(5) As String
    '    'Dim siyou As New DataGridView

    '    ArrayBan = {}
    '    txtBan = ""

    '    'fileNumber = FreeFile()                 'ファイル番号設定
    '    'FileOpen(fileNumber, BlockPath2 + txtPath, OpenMode.Input)

    '    ' ファイルが存在しているかどうか確認する
    '    If Not System.IO.File.Exists("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtkisoNam) Then
    '        'ファイルが存在しない場合
    '        '保存用ファイルを作成
    '        Call MakeKisotxt()
    '    End If

    '    fileNumber = FreeFile()                 'ファイル番号設定
    '    FileOpen(fileNumber, "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtkisoNam, OpenMode.Input)

    '    i = 0

    '    'txtファイルから情報を読み込む
    '    Do While Not EOF(fileNumber)                        'ファイルの末尾まで処理
    '        kisodata(i) = LineInput(fileNumber)                  'txtファイルの現在の行の文字を代入
    '        i += 1
    '    Loop
    '    FileClose(fileNumber)
    'End Sub

    ''マスターファイルから盤データを読み込む(配列基礎仕様用)
    'Public Sub ReadBanData()
    '    Dim txtBan As String
    '    Dim i As Integer, j As Integer, k As Integer, l As Integer
    '    'Dim siyou As New DataGridView

    '    ArrayBan = {}
    '    txtBan = ""

    '    'fileNumber = FreeFile()                 'ファイル番号設定
    '    'FileOpen(fileNumber, BlockPath2 + txtPath, OpenMode.Input)


    '    fileNumber = FreeFile()                 'ファイル番号設定
    '    FileOpen(fileNumber, "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtNam, OpenMode.Input)

    '    i = 0

    '    'txtファイルから配列基礎仕様を読み込む
    '    Do While Not EOF(fileNumber)                        'ファイルの末尾まで処理
    '        txtBan = LineInput(fileNumber)                  'txtファイルの現在の行の文字を代入
    '        ArrayBan = Split(txtBan, ",")                   '取り出した1行分の文字列を , 区切りで配列にする
    '        If i = 0 Then                                   '1回目(1行目)の処理の場合、
    '            ReDim P_sBanDat(ArrayBan(0) - 1, ArrayBan.Length - 1)    '配列のサイズ確定
    '            ReDim P_sBanDat_cp(ArrayBan(0) - 1, ArrayBan.Length - 1)
    '            InOut = ArrayBan(1)         '屋内外
    '            IO = ArrayBan(1)
    '            Door = ArrayBan(2)          '扉型番
    '            p_DoorTyp = ArrayBan(2)
    '            Kesho = ArrayBan(3)
    '            KeshoType = ArrayBan(3)
    '            Seikan = ArrayBan(4)
    '            P_SeikanTyp = ArrayBan(4)
    '            SeigyoK = ArrayBan(5)
    '            SeigyoAna = ArrayBan(5)
    '            BaseH = ArrayBan(6)
    '            TFntSunpo = ArrayBan(7)
    '            TBckSunpo = ArrayBan(8)
    '        Else
    '            For j = 0 To ArrayBan.Length - 1
    '                P_sBanDat(i - 1, j) = ArrayBan(j)               '二次元配列(P_sBanDat)のi行目に1次元配列(ArrayBan)の要素を1つずつ代入
    '            Next
    '        End If
    '        i = i + 1
    '    Loop
    '    For k = 0 To UBound(P_sBanDat, 1)
    '        For l = 0 To UBound(P_sBanDat, 2)
    '            P_sBanDat_cp(k, l) = P_sBanDat(k, l)                            '編集リセット用にコピーする
    '        Next
    '    Next

    '    'P_sBanDat_cp = P_sBanDat                            '編集リセット用にコピーする

    '    FileClose(fileNumber)
    'End Sub

    

    '
    '引込穴のサムネイル用の画像の読み込み
    '
    Public Sub KPicLoad()
        Dim dirP As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\kiso\画像\引込穴\" '画像があるディレクトリ
        Dim pngFiles As String() = System.IO.Directory.GetFiles(dirP, "*.PNG")
        Dim intCnt As Integer
        Dim i As Integer
        intCnt = 0
        i = 0

        '指定したフォルダのpngファイルを数える
        For Each strFilePath As String In _
            System.IO.Directory.GetFiles(dirP, "*.PNG", System.IO.SearchOption.TopDirectoryOnly)
            intCnt += 1
        Next

        ReDim Preserve Kpics(intCnt - 1)
        ReDim Preserve Kpicname(intCnt - 1)

        For Each png As String In pngFiles
            Using fs As System.IO.FileStream = System.IO.File.OpenRead(png)

                '画像の読み込み
                Dim orig As Image = Image.FromStream(fs, False, False)

                '配列にサムネイルを追加
                Kpics(i) = orig
                Kpicname(i) = png.Substring(dirP.Length, png.Length - dirP.Length - 4)  'パス部分と拡張子部分を除く(型名のみになる)
                i += 1

                'orig.Dispose()
                'thumbnail.Dispose()
            End Using
        Next

    End Sub

    '
    '補強枠のサムネイル用の画像の読み込み
    '
    Public Sub HPicLoad()
        Dim dirP As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\kiso\画像\補強枠\" '画像があるディレクトリ
        Dim pngFiles As String() = System.IO.Directory.GetFiles(dirP, "*.PNG")
        Dim intCnt As Integer
        Dim i As Integer
        intCnt = 0
        i = 0

        '指定したフォルダのpngファイルを数える
        For Each strFilePath As String In _
            System.IO.Directory.GetFiles(dirP, "*.PNG", System.IO.SearchOption.TopDirectoryOnly)
            intCnt += 1
        Next

        ReDim Preserve Hpics(intCnt - 1)
        ReDim Preserve Hpicname(intCnt - 1)

        For Each png As String In pngFiles
            Using fs As System.IO.FileStream = System.IO.File.OpenRead(png)

                '画像の読み込み
                Dim orig As Image = Image.FromStream(fs, False, False)

                '配列にサムネイルを追加
                Hpics(i) = orig         '画像用配列
                Hpicname(i) = png.Substring(dirP.Length, png.Length - dirP.Length - 4)  '画像名用配列(パスと拡張子を抜いた値(=型名))
                i += 1

                'orig.Dispose()
                'thumbnail.Dispose()
            End Using
        Next

    End Sub

    '
    '引込穴の既定の型のブロックを読み込む
    '
    Public Sub KataLoad()
        'Dim dirK As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\NPS承認図テスト用\ブロック\" 'dwgファイルがあるディレクトリ
        Dim dirK As String = BlockPath3 & "\" 'dwgファイルがあるディレクトリ



        Dim dwgFiles As String() = System.IO.Directory.GetFiles(dirK, "*.dwg")
        Dim intCnt As Integer
        Dim i As Integer
        intCnt = 0
        i = 0
        ReDim Preserve dwges(dwgFiles.Length - 1)
        ReDim Preserve dwgname(dwgFiles.Length - 1)

        '指定したフォルダのpngファイルを数える
        For Each strFilePath As String In _
            System.IO.Directory.GetFiles(dirK, "*.dwg", System.IO.SearchOption.TopDirectoryOnly)
            dwges(intCnt) = strFilePath
            dwgname(intCnt) = strFilePath.Substring(dirK.Length, strFilePath.Length - dirK.Length - 4)
            intCnt += 1
        Next

    End Sub



    '
    '納入外CUB.で図示しないものがあればCubNo配列から取り除く
    '
    Public Sub DelCubNo(ByVal DelNo() As String)
        '納入外CubNo配列      CubNo配列のｺﾋﾟｰ
        Dim CubCnt As Integer
        Dim DelCnt As Integer
        Dim tmp(conNum) As String
        tmp(0) = ""

        'CubNo配列のｺﾋﾟｰ
        For CubCnt = 0 To conNum
            tmp(CubCnt) = CubNo(CubCnt)
        Next

        DelCnt = 0
        While DelNo(DelCnt) <> ""
            CubCnt = 0
            While CubNo(CubCnt) <> ""
                If DelNo(DelCnt) = CubNo(CubCnt) Then
                    While CubNo(CubCnt + 1) <> "" '納入外CubNoをCubNo配列から削除
                        CubNo(CubCnt) = CubNo(CubCnt + 1)
                        CubCnt = CubCnt + 1
                    End While
                    CubNo(CubCnt) = ""
                End If
                CubCnt = CubCnt + 1
            End While
            DelNo(DelCnt) = "" '納入外CubNoを納入外CubNo配列から削除
            DelCnt = DelCnt + 1
        End While
        H_CubNo = CubNo
    End Sub


    Public Sub AcadStart()

        'Dim cmd As String
        'Dim preferences As AcadPreferences  '基本設定
        'Dim newActiveProfile As String  'プロファイル用

        '
        '-----------------------------------------------
        '  AutoCADを起動する
        '-----------------------------------------------

        'On Error Resume Next
        '起動中メッセージフォームの表示
        'frmAcadStartMassage.Show()     ←フォーム作成次第フォーム名変更

        'AutoCADアプリケーションオブジェクトの取得
        'Err.Clear()

        'VB2010ではErrの扱いが少し変わったためエラー処理のやり方を変更
        Try
            acadApp = GetObject(, "BricscadApp.AcadApplication")
        Catch
            Call sSetProfile()
            acadApp = CreateObject("BricscadApp.Application")
            MsgBox(Err.Description)
            Err.Clear()
        End Try


        'Set acadApp = GetObject(, "AutoCAD.Application")
        '↑Bricscad対応の為以下のように修正 '13.4.16 松本
        'acadApp = GetObject(, "BricscadApp.AcadApplication")
        'If Err() Then
        'Err.Clear()
        'Call sSetProfile() 'ﾌﾟﾛﾌｧｲﾙを"shounin"にする '13.5.9 松本追加(Bricscad対応)

        '   Set acadApp = CreateObject("AutoCAD.Application")
        '↑Bricscad対応の為以下のように修正 '13.4.16 松本
        'acadApp = CreateObject("BricscadApp.AcadApplication")

        'If Err() Then
        'MsgBox(Err.Description)
        'End If
        'End If

        'カレント図面取得
        acadDoc = acadApp.ActiveDocument

        'ユーティリティーオブジェクト取得
        acadUtl = acadDoc.Utility

        'モデル空間オブジェクト取得
        moSpace = acadDoc.ModelSpace

        'AutoCADを非可視化する
        'acadApp.Visible = acOff
        'acadApp.Visible = acOn

        'acadApp.Visible = False

        '↓Bricscadで動作しない為全てｺﾒﾝﾄｱｳﾄ '13.5.9 松本
        'プロファイルの変更
        'Set preferences = acadApp.preferences
        'newActiveProfile = "承認図"
        'newActiveProfile = "shounin"
        'preferences.Profiles.ActiveProfile = newActiveProfile

        'シングルドキュメントモードに設定する
        acadDoc.SendCommand("SDI" & vbCrLf & 0 & vbCrLf)
        'メッセージフォームを閉じる
        'Unload(frmAcadStartMassage)
        'frmAcadStartMassage.close()    'フォーム作成次第フォーム名変更

    End Sub

    Public Sub SetActiveLayer(ByVal A_Lay As String)
        '-----------------------------------------------
        '指定されたレイヤーをアクティブにする
        '-----------------------------------------------
        '   A_Lay     : アクティブにするレイヤー名(ex 自動作成）
        '-----------------------------------------------

        acadDoc.SendCommand("-layer" & vbCr & "S" & vbCr & A_Lay & vbCr & vbCr)

    End Sub

    Public Sub SetRectang(ByVal Zahyo1 As String, ByVal Zahyo2 As String)
        '-----------------------------------------------
        '四角形で作図する
        '-----------------------------------------------
        '   Zahyo1     : 始点
        '   Zahyo2     : 対角
        '-----------------------------------------------

        acadDoc.SendCommand("'_-color" & vbCrLf & "_green" & vbCr)                  '次の図形からは緑色で作図
        acadDoc.SendCommand("rectang" & vbCrLf & Zahyo1 & vbCr & Zahyo2 & vbCr)     '四角形で作図
        acadDoc.SendCommand("'_-color" & vbCrLf & "_white" & vbCr)                  '次の図形からは白色で作図

    End Sub



    '-----------------------------------------------
    'ブロックを削除する
    '-----------------------------------------------
    Public Sub Del_Block_Obj(ByVal bobj As String)
        'ループ変数
        'Dim Cnt As Integer
        'Dim i As Integer
        'Dim J As Integer
        'ブロック内ブロックオブジェクト
        'Dim ZksObj As Object

        For Each Ent In acadDoc.ModelSpace
            'ブロックオブジェクトを処理
            'If Ent.EntityType = acBlockReference Then   'ブロックオブジェクトの場合
            '↑Bricscad対応の為以下のように修正 '13.4.5 松本
            If TypeOf Ent Is AcadBlockReference Then      'ﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄの場合
                If UCase(Ent.Name) = UCase(bobj) Then
                    Ent.Erase()
                    '盤面で把手を複数個消去する為に１つ見つけてもループを抜けないようにする
                    '          Exit For
                End If
            End If
        Next
    End Sub


    '
    '図面名称を記入する
    '
    Public Sub WrtMeisho(ByVal TxtStyle As String, ByVal Scl As Double)
        'ｽﾀｲﾙ名              ｽｹｰﾙ
        Dim MObj As AcadMText
        Dim Pnt(0 To 2) As Double
        Dim tWid As Double

        Call SetActiveLayer("自動作成") 'アクティブレイヤーの変更
        Call SetActiveTextStyle(TxtStyle)
        Pnt(0) = SetScale(Meisho_X, Scl)
        Pnt(1) = SetScale(Meisho_Y, Scl)
        Pnt(2) = 0.0#
        tWid = SetScale(Meisho_W, Scl)
        MObj = moSpace.AddMText(Pnt, tWid, Meisho)
        'MObj.Color = acGreen
        MObj.color = ACAD_COLOR.acGreen
        MObj.Height = acadDoc.ActiveTextStyle.Height
    End Sub


    Public Sub CreZudairan(ByVal Z_Type As String, ByVal Z_Maisu As Integer, ByVal T_Scale As Double)
        '-----------------------------------------------
        ' 図面枠を読込、文字列をセットする
        '-----------------------------------------------
        '   Z_Type    : 図面のタイプ("配列","基礎","平面","盤面","側面")
        '   Z_Maisu   : 対象となるページ番号(ex 1)
        '   T_Scale   : 縮尺(ex 25)
        '-----------------------------------------------

        Dim T_String1 As String
        Dim T_String2 As String
        Dim Block As String
        'Dim WakuObj As Object
        Dim X As Double, Y As Double, Z As Double
        Dim T_Pos As Integer
        'Dim ExFile As String

        Dim Chk As Object

        X = 0.0#
        Y = 0.0#
        Z = 0.0#

        'アクティブ寸法スタイルの変更
        'If Z_Type = "配列" Then
        '    SetActiveDim("配列１")
        'ElseIf Z_Type = "基礎" Then
        '    SetActiveDim("基礎")
        'ElseIf Z_Type = "平面" Then
        '    SetActiveDim("平面")
        'ElseIf Z_Type = "盤面" Then
        '    SetActiveDim("盤面")
        'ElseIf Z_Type = "側面" Then
        '    SetActiveDim("側面")
        'Else
        '    MsgBox("図面種類の誤りです。", 48, "図面種類エラー")
        'End If


        '図番名＆群番＆図題欄のセット(ZUBAN & GUNBAN & ZUDAI)
        T_Pos = InStr(KoubanName, "-")
        T_String1 = Left(KoubanName, T_Pos - 3) 'X or P
        T_String2 = Mid(KoubanName, T_Pos - 2, Len(KoubanName) - (T_Pos - 3)) '99-9999
        Call SetKbnGbnZdi(T_String1, T_String2, Z_Type, X, Y)
        TL_Gunban = UCase(GunbanName)

        '枠外のセット(WAKUGAI)
        If Z_Type = "側面" Then
            If JobMode = "UNIT" Then
                TL_Wakugai = "S$" & UnitCode & "$P1"
            Else
                TL_Wakugai = "S_" & KoubanName & GunbanName & "P" & Format(CR_PageNum(CR_NowNum))
            End If
        Else
            TL_Wakugai = UCase(KoubanName) & "(" & UCase(GunbanName) & ")" & "     " & D_Name
        End If

        '日付のセット(NEN & TUKI & HI)
        'T_String1 = Date
        'TL_Year = Right(Year(T_String1), 2)
        'TL_Month = Month(T_String1)
        'TL_Day = Day(T_String1)
        '↑データ型の不一致の為修正↓ '15.8.28 松本
        'TL_Year = Format(Date, "YY") '←ここから
        'TL_Month = Format(Date, "M")
        'TL_Day = Format(Date, "DD")  '←ここまで
        'TL_Year = Format(Now, "YY") '←ここから
        'TL_Month = Format(Now, "MM")
        'TL_Day = Format(Now, "DD")
        TL_Year = Format(Now, "yy") '月のみ大文字
        TL_Month = Format(Now, "MM")
        TL_Day = Format(Now, "dd")

        'ページ数のセット(PAGE)
        TL_NMaisu = Z_Maisu '現在のページ

        '製品種別(frmkisoの最初で宣言)

        'アクティブレイヤーの変更
        Call SetActiveLayer("枠")

        'ブロックの挿入
        'If Zumen = "英文" Then
        '    Select Case Z_Type
        '      Case "配列", "基礎", "側面"
        Block = "2c"
        '      Case "盤面"
        '        Block = "2D"
        '    End Select
        'Else
        'Block = "4c"
        'End If
        If Zumen = "英文" Then
            '    Select Case Z_Type
            '      Case "配列", "基礎", "側面"
            Block = "4c"
            '      Case "盤面"
            '        Block = "2D"
            '    End Select
        Else
            Block = "2c"
        End If
        Chk = FunInsertBlock(Block, X, Y, Z, T_Scale, T_Scale, 0.0#, "図枠")
    End Sub

    Public Sub SetKbnGbnZdi(ByVal T_String1 As String, ByVal T_String2 As String, ByVal Z_Type As String, ByVal X As Double, ByVal Y As Double)
        '図番名＆群番＆図題欄のセット(ZUBAN & GUNBAN & ZUDAI)

        If Z_Type = "配列" Then
            TL_Kouban = T_String1 & "P" & T_String2 & "-BA"
            TL_Meisho = "配列図"
        ElseIf Z_Type = "基礎" Then
            Dim ZBN As String
            Dim ZBN2 As String
            Dim Pages As Integer
            Pages = Right(frmkiso.txtZbn.Text, 1)
            ZBN2 = frmkiso.txtZbn.Text.Substring(frmkiso.txtZbn.Text.Length - 1)
            ZBN = Left(frmkiso.txtZbn.Text, frmkiso.txtZbn.Text.Length - 1) & Str(PCnt - 1 + Pages)

            'TL_Kouban = T_String1 & "P" & T_String2 & "-BB"
            TL_Kouban = ZBN
            TL_Syubetu = frmkiso.txtSyubetu.Text
            TL_Meisho = "基礎図"
        ElseIf Z_Type = "平面" Then
            TL_Kouban = T_String1 & "P" & T_String2 & "-BB"
            TL_Meisho = "平面図"
        ElseIf Z_Type = "盤面" Then
            'SendKeys "+{F10}", True                            'ｼｮｰﾄｶｯﾄﾒﾆｭｰ表示
            '↑ここで処理が止まってしまうのでｺﾒﾝﾄｱｳﾄ    '13.4.16 松本
            TL_Kouban = T_String1 & "P" & T_String2 & "-BC"
            TL_Meisho = "盤面図"
        ElseIf Z_Type = "側面" Then
            If CR_Zuban(CR_NowNum) = "" Then
                TL_Kouban = T_String1 & "P" & T_String2 & "-BD"
            Else
                TL_Kouban = CR_Zuban(CR_NowNum)
            End If
            TL_Meisho = "側面図"
            X = CR_Ins_X
            Y = CR_Ins_Y
        End If
    End Sub

    Public Function MesureCompare(ByVal HK As String)
        Dim BlkObj3 As AcadEntity
        Dim BlkObj4 As AcadSelectionSet
        Dim Mesure As String                '尺度
        Dim Attribs As Object

        Dim sset As AcadSelectionSet
        Dim gpCode(0) As Integer, dataValue(0) As Object
        Dim f_type As Object, f_data As Object
        Dim mode As Integer
        Dim point1(0 To 2) As Double, point2(0 To 2) As Double



        Mesure = "1:0"              '変数の初期値設定
        Dim dInsPnt(2) As Double
        dInsPnt = {1000, 25, 0}       'オブジェクトが図枠しかない位置



        BlkObj4 = acadDoc.SelectionSets.Add("1234")     'とりあえず名前は適当です。
        BlkObj4.SelectAtPoint(dInsPnt, , )

        For Each BlkObj3 In BlkObj4                     '
            Attribs = BlkObj3.GetAttributes             'ブロックの要素を取得
            For i = LBound(Attribs) To UBound(Attribs)  '要素数分ループ
                If Attribs(i).tagstring = "SCALE" Then  '要素名が"SCALE"なら
                    Mesure = Attribs(i).TextString
                    Exit For
                End If
            Next
        Next

        BlkObj4.Delete()

        If Mesure <> "1:0" Then           '図枠に縮尺が記載されていれば
            If Mesure <> "1:" & frmkiso.cmbsScale.SelectedItem Then   '保存されている図面と尺度が異なる場合
                MesureCompare = "継続（枠有り）"

                Call SelectionClear("SS1")
                sset = acadDoc.SelectionSets.Add("SS1") '選択セットSS1を作成
                'mode = acSelectionSetAll '全てを選択
                mode = AcSelect.acSelectionSetAll   '全てを選択
                point1(0) = 0.0# : point1(1) = 0.0# : point1(2) = 0.0#  'ダミーの点
                point2(0) = 1.0# : point2(1) = 1.0# : point2(2) = 0.0#  'ダミーの点
                gpCode(0) = 8 'DXFグループコード=レイヤー名
                f_type = gpCode


                dataValue(0) = "枠" 'レイヤー名
                sset.Clear()
                f_data = dataValue
                sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
                sset.Erase()  'selectionsetの消去

                dataValue(0) = "ZUWAKU" 'レイヤー名
                sset.Clear()
                f_data = dataValue
                sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
                sset.Erase()  'selectionsetの消去

                dataValue(0) = "ZUWAKU2" 'レイヤー名
                sset.Clear()
                f_data = dataValue
                sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
                sset.Erase()  'selectionsetの消去

                If HK = "基礎" Then
                    Call sCreZwk()
                ElseIf HK = "配列" Then
                    Dim sSetubi As String                                   '設備名称
                    Dim sSyubetu As String                                  '製品種別
                    Dim sPage As String                                     'ﾍﾟｰｼﾞ
                    Dim sZbn As String                                      '図番
                    Dim sDate As String                                     '日付
                    Dim sSiz As String                                      '図面ｻｲｽﾞ

                    If frmHairetu.fGetIptDat(sSetubi, sSyubetu, sPage, sZbn, sDate, sSiz) = False Then Exit Function
                    Call sCreZwkH("配列図", sSetubi, sSyubetu, sPage, sZbn, sDate, sSiz, "JPN")
                End If


            Else                                        '同じ場合
                MesureCompare = "継続（枠なし）"
            End If
        Else                            '図枠に縮尺が記載されていない場合
            MesureCompare = "継続（枠有り）"
        End If

    End Function



    Public Sub CreDwfFil(ByVal FilNam As String)
        Dim Plot As AcadPlot
        Dim result As Boolean
        Dim ACADLayout As AcadLayout
        Dim originalValue As Integer
        Dim Pos As Integer              'ﾌｧｲﾙ名中の"."位置
        Dim DwfFil As String            'DWFﾌｧｲﾙ名
        Dim FilFnd As String            'ﾌｧｲﾙ検索結果
        'Dim sset As AcadSelectionSet    '選択ｾｯﾄ

        Pos = InStr(FilNam, ".")
        DwfFil = Left(FilNam, Pos - 1) + ".dwf"
        FilFnd = Dir(DwfFil)
        If FilFnd <> "" Then Kill(DwfFil) '既にﾌｧｲﾙがあれば削除
        '    DwfFil = Left(DwfFil, Pos - 1)

        ACADLayout = acadDoc.ActiveLayout

        '現在の印刷領域を退避する
        originalValue = ACADLayout.PlotType

        '印刷領域をオブジェクト範囲にする
        'ACADLayout.PlotType = acExtents
        ACADLayout.PlotType = AcPlotType.acExtents

        Plot = acadDoc.Plot
        '印刷枚数を1枚に設定する
        Plot.NumberOfCopies = 1
        'DWFファイルを作成する
        result = acadDoc.Plot.PlotToFile(DwfFil, "PublishToWeb DWF.pc3")

        '印刷領域を元に戻す
        ACADLayout.PlotType = originalValue
    End Sub

    'AutoCADに対してLISPコマンドを発行する
    Public Sub AcadCommand(ByVal cmd As String)
        Dim OldStr As String
        Dim NewStr As String
        NewStr = ""

        Select Case UCase(cmd)
            Case "外形分解"          '最後に作成された図形を分解する
                acadDoc.SendCommand("explode" & vbCr & "last" & vbCr & vbCr)
            Case "標準盤面機器配置"   '標準盤面機器配置コマンドを実行する
                acadDoc.SendCommand("sethbmk" & vbCr)
            Case "外形配置"          '機器配置コマンドを実行する
                acadDoc.SendCommand("bmkexplode" & vbCr)
            Case "PURGEALL"          '不要なブロック定義を全て削除する
                'acadDoc.SendCommand "purge" & vbCr & "b" & vbCr & vbCr & "n" & vbCr 2002対応に修正 松本
                acadDoc.SendCommand("-purge" & vbCr & "b" & vbCr & vbCr & "n" & vbCr)
            Case "SOKUMEN"           '側面テンプレートを再定義しながら挿入する
                OldStr = P_BlkPath
                Call AddStr(NewStr, OldStr)
                '2002対応に修正 松本
                'acadDoc.SendCommand "insert" & vbCr & "*" & NewStr & "\\sokumen\\sokumen" & vbCr & "0,0" & vbCr & vbCr & vbCr
                acadDoc.SendCommand("-insert" & vbCr & "*" & OldStr & "\sokumen\sokumen" & vbCr & "0,0" & vbCr & vbCr & vbCr)
            Case "BANMEN"            '盤面テンプレートを再定義しながら挿入する
                OldStr = P_BlkPath
                Call AddStr(NewStr, OldStr)
                '2002対応に修正 松本
                'acadDoc.SendCommand "insert" & vbCr & "*" & NewStr & "\\banmen\\banmen" & vbCr & "0,0" & vbCr & vbCr & vbCr
                acadDoc.SendCommand("-insert" & vbCr & "*" & OldStr & "\banmen\banmen" & vbCr & "0,0" & vbCr & vbCr & vbCr)
            Case Else                '引数のブロック定義を削除する
                'acadDoc.SendCommand "purge" & vbCr & "b" & vbCr & cmd & vbCr & "n" & vbCr 2002対応に修正
                acadDoc.SendCommand("-purge" & vbCr & "b" & vbCr & cmd & vbCr & "n" & vbCr)
        End Select

    End Sub

    Public Sub SetActiveDim(ByVal A_Dim As String)
        '-----------------------------------------------
        '指定された寸法スタイルをアクティブにする
        '-----------------------------------------------
        '   A_Dim   : アクティブにする寸法スタイル(ex 配列１)
        '-----------------------------------------------

        'Dim DimObj As Object
        'Dim DimName As String
        Dim i As Integer
        i = 0

        acadDoc.SendCommand("-dimstyle" & vbCr & "R" & vbCr & A_Dim & vbCr)
        'SendKeys("{F2}", True) '飛び出してきたﾃｷｽﾄｳｨﾝﾄﾞｳを閉じる
        'SendKeys.SendWait("{F2}")
    End Sub

    '"\"が存在する場合"\\"にする
    Sub AddStr(ByVal NewS As String, ByVal OldS As String)
        Dim i As Integer
        Dim St As String

        NewS = ""
        For i = 1 To Len(OldS)
            St = Mid(OldS, i, 1)
            If St = "\" Then
                NewS = NewS & St & "\"
            Else
                NewS = NewS & St
            End If
        Next i

    End Sub

    '-----------------------------------------------
    '指定された文字スタイルをアクティブにする
    '-----------------------------------------------
    '   A_Style     : アクティブにする文字スタイル(ex 配列１）
    '-----------------------------------------------
    Public Sub SetActiveTextStyle(ByVal A_Style As String)

        acadDoc.SendCommand("textstyle" & vbCr & A_Style & vbCr)

    End Sub
    Public Sub SetActiveLine(ByVal A_Lin As String)
        '-----------------------------------------------
        '指定された線種をアクティブにする
        '-----------------------------------------------
        '   A_Lin     : アクティブにする線種名(ex 点線）
        '-----------------------------------------------

        acadDoc.SendCommand("-linetype" & vbCrLf & "S" & vbCrLf & A_Lin & vbCrLf & vbCrLf)

    End Sub


    Private Const HKEY_CURRENT_USER = &H80000001    '現在のユーザーの設定に対するHKEY_USERのリンク
    Private Const REG_SZ = 1                        'NULLで終わる文字列
    Private Const KEY_SET_VALUE = &H2               'サブキーの書き込みを許可

    Private Declare Function RegOpenKeyEx Lib "advapi32.dll" Alias "RegOpenKeyExA" (ByVal hKey As Long, ByVal lpSubKey As String, ByVal ulOptions As Long, ByVal samDesired As Long, ByVal phkResult As Long) As Long
    Private Declare Function RegCloseKey Lib "advapi32.dll" (ByVal hKey As Long) As Long
    Private Declare Function RegSetValueEx Lib "advapi32.dll" Alias "RegSetValueExA" (ByVal hKey As Long, ByVal lpValueName As String, ByVal Reserved As Long, ByVal dwType As Long, ByVal lpData As Integer, ByVal cbData As Long) As Long


    '
    'ﾌﾟﾛﾌｧｲﾙを"shounin"にする '13.5.9 松本追加(BJ-Softに教えてもらった方法)
    '
    Sub sSetProfile()
        'Dim nRet As Long
        Dim nRet As Integer

        ' オープンするサブキーの設定
        Dim strSubKey As String
        strSubKey = "Software\Bricsys\Bricscad\V12\ja_JP\Profiles" & Chr(0)
        Dim hSubKey As Long                      'キーハンドル
        nRet = RegOpenKeyEx(HKEY_CURRENT_USER, strSubKey, 0, KEY_SET_VALUE, hSubKey)
        If nRet <> 0& Then
            Exit Sub
        End If

        ' カレントプロファイルを "shounin" に変更
        Dim strValue As String
        'strValue = "shounin" + String(10, Chr$(0))
        strValue = "shounin" + Strings.StrDup(10, Chr(0))
        Dim lenValue As Long
        lenValue = System.Text.Encoding.GetEncoding("shift-jis").GetByteCount(StrConv("shounin", 128)) + 5
        'nRet = RegSetValueEx(hSubKey, "CurProfile" + Chr(0), 0, REG_SZ, ByVal strValue, lenValue)
        nRet = RegSetValueEx(hSubKey, "CurProfile" + Chr(0), 0, REG_SZ, strValue, lenValue)
        If nRet <> 0& Then
            Call RegCloseKey(hSubKey)
            Exit Sub
        End If
        Call RegCloseKey(hSubKey)
    End Sub

    '
    'ﾌｧｲﾙの保存先を返す
    'sZmnTyp:図面種類
    '
    Public Function fCreSavPath(ByVal sZmnTyp As String) As String
        Dim sKi As String                                                           '期ﾌｫﾙﾀﾞ名
        Dim sPath As String                                                         'ﾊﾟｽ

        sKi = "\" & Mid(P_sKbnNam, InStr(P_sKbnNam, "-") - 2, 2) & "期\"             '期ﾌｫﾙﾀﾞ名作成
        Select Case P_sSegment                                                      'ｾｸﾞﾒﾝﾄ
            Case P_sSangyoSeg                                                       '産業
                sPath = P_sDatFld & P_sSegment & sKi & P_sKbnNam & P_sSangyoFld     '産業用ﾊﾟｽ設定
            Case P_sMizuSeg                                                         '水
                sPath = P_sDatFld & P_sSegment & sKi & P_sKbnNam & P_sMizuFld       '水用ﾊﾟｽ設定
            Case P_sDentetuSeg                                                      '電鉄
                sPath = P_sDatFld & P_sSegment & sKi & P_sKbnNam & P_sDentetuFld    '電鉄用ﾊﾟｽ設定
            Case P_sDenryokuSeg                                                     '電力
                sPath = P_sDatFld & P_sSegment & sKi & P_sKbnNam & P_sDenryokuFld   '電力用ﾊﾟｽ設定
            Case P_sDouroSeg                                                        '道路
                sPath = P_sDatFld & P_sSegment & sKi & P_sKbnNam & P_sDouroFld      '道路用ﾊﾟｽ設定
            Case Else                                                               'それ以外の場合
                sPath = ""                                                          'ﾊﾟｽを設定しない
        End Select
        fCreSavPath = sPath.Replace("[Gunban]", P_sGbn)                             '群番を置き換えてﾊﾟｽを返す
    End Function

    Public Function CalZenCho()
        '-----------------------------------------------
        '箱巾から列番全長を計算
        '-----------------------------------------------
        ' 戻り値    : 全長寸法(ex 7000)
        '-----------------------------------------------

        Dim i As Integer, J As Integer, Nagasa As Integer

        i = 0
        J = 0
        Nagasa = 0
        Do Until (CubNo(i) = "")
            'Nagasa = Nagasa + Int(H_W(J))
            Nagasa = Nagasa + Integer.Parse(H_W(J))
            i = i + 1
            J = J + 1
        Loop
        CalZenCho = Nagasa
    End Function

    Public Function OpenAcadFile(ByVal sel As String, ByVal A_Page As Integer)
        '-----------------------------------------------
        '  自動作成時のAcadFileのOpen
        '-----------------------------------------------
        ' Sel     :開く図面のタイプ（"配列"or"基礎"）
        ' A_Page  :対象となるページ
        '戻り値    :次の処理への命令（"継続（枠なし）"or "継続（枠有り）"or"中止"）
        '-----------------------------------------------

        'Dim ExFile As String
        'Dim hpos As Integer  '"-"を表示する位置
        'Dim ppos, ppos1 As Integer  'ページを表示する位置
        'Dim kpos, kpos1 As Integer  '改訂番号を表示する位置
        'Dim dpos, dpos1 As Integer   '拡張子を表示する位置
        'Dim astName As String  '検索用図面名
        'Dim npName As String  '各ページ図面名
        'Dim pknum(0 To 1000) As Integer 'ページ履歴
        'Dim tmp As String
        'Dim sset As AcadSelectionSet
        'Dim mode As Integer
        'Dim point1(0 To 2) As Double, point2(0 To 2) As Double
        'Dim gpCode(0) As Integer, dataValue(0) As Object
        'Dim f_type As Object, f_data As Object
        'Dim Ent As Object
        'Dim OAC_Block As String
        'Dim TmpFil As String  'ﾃﾝﾌﾟﾚｰﾄ名
        'Dim lin_obj As Object
        'Dim iCnt As Integer
        'Dim Cnt As Integer
        'Dim blockObj As Object
        'Dim K As Integer
        'Dim P As Integer

        Dim rtnOAF As String = ""   'OpenAcadFileの返り値用変数
        OpenAcadFile = ""           '初期値

        'Static Ans2 As String
        KoubanName = P_sKbnNam
        GunbanName = P_sGbn
        'Template10 = BlockPath2 & "kiso.dwt"   'テスト用
        Template10 = BlockPath3 & "M_20.dwt"   'テスト用

        Select Case sel
            Case "配列"
                OpenAcadFile = OpenAcadFile_Hairetu(sel, A_Page)
            Case "基礎"
                OpenAcadFile = OpenAcadFile_Kiso(sel, A_Page)
            Case "側面"
                OpenAcadFile = OpenAcadFile_Sokumen(sel, A_Page)
            Case "盤面箱"
                OpenAcadFile = OpenAcadFile_Banmenhako(sel)
            Case "盤面枠"
                OpenAcadFile = OpenAcadFile_Banmenwaku(sel, A_Page)
        End Select
    End Function

    Public Function OpenAcadFile_Hairetu(ByVal sel As String, ByVal A_Page As Integer)
        Dim Ans As String
        Dim ExFile As String
        Dim TmpFil As String  'ﾃﾝﾌﾟﾚｰﾄ名
        Dim astName As String   '検索用図面名
        Dim waku As String

        '自動作成(配列)

        'ExFile = Sea_Dir_Hairetu & "\H_" & KoubanName & GunbanName & "*.dwg" 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.26 松本
        'ExFile = MkKiPath(Sea_Dir_Hairetu, P_sKbnNam) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\H_" & P_sKbnNam & GunbanName & "P" & A_Page & "*.dwg"
        ExFile = MkKiPath(Sea_Dir_Hairetu, P_sKbnNam) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & Strings.Mid(frmHairetu.txtZbn.Text, 1, frmHairetu.txtZbn.Text.Length - 1) & A_Page & "_R0.dwg"
        Ans = Dir(ExFile)
        If Ans <> "" Then  'ファイルが存在している
            '
            '1ページはメッセージを表示それ以外はメッセージなしに自動作図をする
            '
            If A_Page = 1 Then
                '   .Show()  'ﾒｯｾｰｼﾞが一番上に表示されるようにﾌｫｰﾑを表示する
                Ans = MsgBox("既にファイルが存在しています。" & Chr(13) & Chr(10) & _
                              "本当に自動作成してもよろしいですか？" _
                              , vbQuestion + vbYesNo + vbDefaultButton2, "自動作成開始の確認")
            Else
                Ans = vbYes
            End If
            If Ans = vbYes Then  '自動作図を実行
                '
                'ファイルをopenしてuserレイヤー以外を消す
                '
                'ppath = Sea_Dir_Hairetu & "\"    'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.26 松本
                'ppath = MkKiPath(Sea_Dir_Hairetu, KoubanName) & "\"
                'astName = "H_" & KoubanName & GunbanName & "*.dwg"
                ppath = MkKiPath(Sea_Dir_Hairetu, P_sKbnNam) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & P_sGbn & "\"
                'astName = "H_" & P_sKbnNam & GunbanName & "P" & A_Page & "*.dwg"
                astName = Strings.Mid(frmHairetu.txtZbn.Text, 1, frmHairetu.txtZbn.Text.Length - 1) & iPage & "_R0.dwg"
                '          TmpFil = BlockPath1 + Sel + "図" + EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                TmpFil = BlockPath8 + "hairetu" + EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定

                'GoTo Flg_Set '既設ファイルを配列にセット
                Call Flg_Set(astName)

                '改訂番号を上げるかどうか指示さす
                'If A_Page = 1 Then '1ページ目のみ実行
                '  Ans2 = MsgBox("改訂番号を上げますか？" _
                '   , vbQuestion + vbYesNo + vbDefaultButton2, "改訂番号処理の確認")
                'End If

                If pkname(A_Page) <> "" Then '既設図面に対象となるページが存在している
                    'Hairetuzu = Sea_Dir_Hairetu & "\" & pkname(A_Page) 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.26 松本
                    Hairetuzu = MkKiPath(Sea_Dir_Hairetu, P_sKbnNam) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & P_sGbn & "\" & pkname(A_Page)
                    'Set acadDoc = acadDoc.Open(Hairetuzu)  '既設ファイルのOpen
                    '↑Bricscadでは動かないので以下のように修正 '13.2.5 松本
                    acadDoc = acadApp.Documents.Open(Hairetuzu)

                    'モデル空間オブジェクト取得
                    moSpace = acadDoc.ModelSpace

                    waku = MesureCompare(sel)

                    'GoTo Flg_Eraser  '[User]レイヤー以外を消去
                    Call Flg_Eraser(sel, TmpFil)

                    'アクティブレイヤーの変更
                    Call SetActiveLayer("自動作成")
                    'OAC_Block = "配列図"
                    '            OAC_Block = "hairetu"
                    '            inspnt(0) = 0#
                    '            inspnt(1) = 0#
                    '            inspnt(2) = 0#
                    '            Chk = FunInsertBlock(OAC_Block, inspnt(0), inspnt(1), inspnt(2), 1#, 1#, 0#, "配列")
                    OpenAcadFile_Hairetu = waku
                    'OpenAcadFile_Hairetu = "継続（枠なし）"
                Else
                    'Set acadDoc = acadDoc.New(Template1)  ' 新規ファイルを開く(テンプレート付き）
                    '↑Bricscad対応の為↓のように修正 '13.4.8 松本
                    'acadDoc = acadApp.Documents.Add(Template1) '新規ﾌｧｲﾙを開く(ﾃﾝﾌﾟﾚｰﾄ付き)
                    acadDoc = acadApp.Documents.Add(Tmpnam)
                    'モデル空間オブジェクト取得
                    moSpace = acadDoc.ModelSpace
                    OpenAcadFile_Hairetu = "継続（枠有り）"
                End If
            Else
                OpenAcadFile_Hairetu = "中止"
            End If
        Else  'ファイルが存在していない
            ' 新規ファイルを開く(テンプレート付き）
            'Set acadDoc = acadDoc.New(Template1)
            '↑Bricscad対応の為↓のように修正 '13.4.8 松本
            'acadDoc = acadApp.Documents.Add(Template1)
            acadDoc = acadApp.Documents.Add(Tmpnam)
            OpenAcadFile_Hairetu = "継続（枠有り）"
            'モデル空間オブジェクト取得
            moSpace = acadDoc.ModelSpace
        End If
        'acadApp.Visible = False
    End Function

    Public Function OpenAcadFile_Kiso(ByVal sel As String, ByVal A_Page As Integer)
        Dim Ans As String
        Dim ExFile As String
        Dim TmpFil As String  'ﾃﾝﾌﾟﾚｰﾄ名
        Dim astName As String   '検索用図面名
        Dim waku As String
        'Dim sCreFilNam As String
        'Dim sWakDWGNam As String
        'Dim i As Integer

        '自動作成(基礎)

        'ExFile = Sea_Dir_Kiso & "\K_" & KoubanName & GunbanName & "*.*" 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.27 松本
        'ExFile = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\K_" & KoubanName & GunbanName & "*.*"
        ExFile = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & Strings.Mid(frmkiso.txtZbn.Text, 1, frmkiso.txtZbn.Text.Length - 1) & A_Page & "_R0.dwg"

        Ans = Dir(ExFile)
        If Ans <> "" Then  'ファイルが存在している
            'If A_Page = 1 Then
            '    '     .Show()  'ﾒｯｾｰｼﾞが一番上に表示されるようにﾌｫｰﾑを表示する
            '    '作成しようとしているﾌｧｲﾙが開いていた場合
            '    For i = 1 To TL_ZMaisu
            '        For iDocCnt = 1 To acadApp.Documents.Count - 1
            '            sWakDWGNam = "K_" & P_sKbnNam & P_sGbn & "P" & i & "K0.dwg"
            '            sCreFilNam = UCase(Mid(sWakDWGNam, InStrRev(sWakDWGNam, "\") + 1))  '作成するﾌｧｲﾙ名(ﾊﾟｽ無し)取得
            '            If UCase(acadApp.Documents.Item(iDocCnt).Name) = sCreFilNam Then
            '                'ｴﾗｰﾒｯｾｰｼﾞ表示
            '                MsgBox("BricsCAD上で作成しようとしているファイルが既に開いています。" & vbCrLf & _
            '                "ファイル名：" & sWakDWGNam, vbOKOnly + vbExclamation, "処理中断")
            '                sWakDWGNam = ""                                     'ﾌｧｲﾙ名をｸﾘｱする
            '                MsgBox("処理を終了します。")
            '                Ovrlapflg = True
            '                'Exit Function
            '            End If

            '        Next
            '    Next
            '    Ans = MsgBox("既にファイルが存在しています。" & Chr(13) & Chr(10) & _
            '                  "本当に自動作成してもよろしいですか？" _
            '                  , vbQuestion + vbYesNo + vbDefaultButton2, "自動作成開始の確認")
            'Else
            '    Ans = vbYes
            'End If
            Ans = vbYes
            If Ans = vbYes Then  '自動作図を実行

                '自動作図を実行
                'ファイルをopenしてuserレイヤー以外を消す

                'ppath = Sea_Dir_Kiso & "\" 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.27 松本
                ppath = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\" & KoubanName & "\20 構造設計\20 図面\20 構造図\" & P_sGbn & "\"

                'astName = "K_" & KoubanName & GunbanName & "P" & A_Page & "*.dwg"
                astName = Strings.Mid(frmkiso.txtZbn.Text, 1, frmkiso.txtZbn.Text.Length - 1) & PCnt & "_R0.dwg"

                'GoTo Flg_Set '既設ファイルを配列にセット
                Call Flg_Set(astName)

                If pkname(A_Page) <> "" Then '既設図面に対象となるページが存在している

                    'Kisozu = Sea_Dir_Kiso & "\" & pkname(A_Page) 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.27 松本
                    Kisozu = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\" & KoubanName & "\20 構造設計\20 図面\20 構造図\" & P_sGbn & "\" & pkname(A_Page)
                    'Set acadDoc = acadDoc.Open(Kisozu)  '既設ファイルのOpen
                    '↑Bricscad対応の為↓のように修正 '13.4.4 松本
                    acadDoc = acadApp.Documents.Open(Kisozu)
                    'モデル空間オブジェクト取得
                    moSpace = acadDoc.ModelSpace
                    'TmpFil = BlockPath3 + Sel + "図" + EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                    TmpFil = BlockPath3 & "kiso" & EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定

                    'GoTo Flg_Eraser  '[User]レイヤー以外を消去
                    'Call Flg_Eraser(sel, TmpFil)

                    waku = MesureCompare(sel)

                    Call Flg_Eraser("kiso", TmpFil)     'kiso.dwg


                    'OpenAcadFile_Kiso = "継続（枠なし）"
                    OpenAcadFile_Kiso = waku
                Else
                    'Set acadDoc = acadDoc.New(Template2)  ' 新規ファイルを開く(テンプレート付き）
                    '↑Bricscad対応の為↓のように修正 '13.4.8 松本
                    'acadDoc = acadApp.Documents.Add(Template2)  '新規ﾌｧｲﾙを開く(ﾃﾝﾌﾟﾚｰﾄ付き)
                    acadDoc = acadApp.Documents.Add(Template10)  '新規ﾌｧｲﾙを開く(ﾃﾝﾌﾟﾚｰﾄ付き)(テスト用)
                    'モデル空間オブジェクト取得
                    moSpace = acadDoc.ModelSpace
                    OpenAcadFile_Kiso = "継続（枠有り）"
                End If
            Else
                OpenAcadFile_Kiso = "中止"
            End If
        Else  'ファイルが存在していない
            ' 新規ファイルを開く(テンプレート付き）
            'Set acadDoc = acadDoc.New(Template2)
            '↑Bricscad対応の為↓のように修正 '13.4.8 松本
            'acadDoc = acadApp.Documents.Add(Template2)
            acadDoc = acadApp.Documents.Add(Template10)  '新規ﾌｧｲﾙを開く(ﾃﾝﾌﾟﾚｰﾄ付き)(テスト用)

            'モデル空間オブジェクト取得
            moSpace = acadDoc.ModelSpace
            OpenAcadFile_Kiso = "継続（枠有り）"
        End If
        'acadApp.Visible = False
    End Function

    Public Function OpenAcadFile_Sokumen(ByVal sel As String, ByVal A_Page As Integer)
        Dim Ans As String
        Dim ExFile As String
        Dim TmpFil As String  'ﾃﾝﾌﾟﾚｰﾄ名
        Dim astName As String   '検索用図面名

        '自動作成(側面)

        If JobMode = "UNIT" Then
            ExFile = Sea_Dir_SokumenH & "\S$" & UnitCode & "$P1K" & "*.dwg"
        Else
            'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.28 松本
            'ExFile = Sea_Dir_Sokumen & "\S_" & KoubanName & GunbanName & "P" & Format(A_Page) & "*.dwg"
            ExFile = MkKiPath(Sea_Dir_Sokumen, KoubanName) & "\S_" & KoubanName & GunbanName & "P" & Format(A_Page) & "*.dwg"
        End If
        Ans = Dir(ExFile)
        If Ans <> "" Then  'ファイルが存在している
            '
            '1ページはメッセージを表示それ以外はメッセージなしに自動作図をする
            '
            'frmSokumenMain.Show() 'ﾒｯｾｰｼﾞが一番上に表示されるようにﾌｫｰﾑを表示する　フォーム作ったら(ry
            Ans = MsgBox("既にファイルが存在しています。" & Chr(13) & Chr(10) & _
                            "本当に自動作成してもヨロシイですか？" _
                            , vbQuestion + vbYesNo + vbDefaultButton2, "自動作成開始の確認")
            If Ans = vbYes Then  'ファイルが存在している
                '自動作図を実行
                'ファイルをopenしてuserレイヤー以外を消す
                If JobMode = "UNIT" Then                      '標準作業
                    ExFile = GetMaxKHFil(ExFile)
                    'Set acadDoc = acadDoc.Open(ExFile)          '既設ﾌｧｲﾙのOpen
                    '↑Bricscad対応の為↓のように修正 '13.4.4 松本
                    acadDoc = acadApp.Documents.Open(ExFile)
                    'モデル空間オブジェクト取得
                    moSpace = acadDoc.ModelSpace
                    TmpFil = BlockPath4 + "sokumen" + EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                    Call Del_Block_Obj("sokumen")

                    'GoTo Flg_Eraser                            '[User]ﾚｲﾔｰ以外を消去
                    Call Flg_Eraser(sel, TmpFil)

                    OpenAcadFile_Sokumen = "継続（枠なし）"
                Else                                          '工番作業 or 検討図
                    'ppath = Sea_Dir_Sokumen & "\" 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.28 松本
                    ppath = MkKiPath(Sea_Dir_Sokumen, KoubanName) & "\"
                    astName = "S_" & KoubanName & GunbanName & "P" & Format(A_Page) & "*.dwg"

                    'GoTo Flg_Set '既設ファイルを配列にセット
                    Call Flg_Set(astName)

                    If pkname(A_Page) <> "" Then '既設図面に対象となるページが存在している
                        'Sokumenzu = Sea_Dir_Sokumen & "\" & pkname(A_Page) 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.28 松本
                        Sokumenzu = MkKiPath(Sea_Dir_Sokumen, KoubanName) & "\" & pkname(A_Page)
                        'Set acadDoc = acadDoc.Open(Sokumenzu)  '既設ファイルのOpen
                        '↑Bricscad対応の為↓のように修正 '13.4.4 松本
                        acadDoc = acadApp.Documents.Open(Sokumenzu)
                        'モデル空間オブジェクト取得
                        moSpace = acadDoc.ModelSpace
                        TmpFil = BlockPath4 + "sokumen" + EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                        Call Del_Block_Obj("sokumen")

                        'GoTo Flg_Eraser  '[User]レイヤー以外を消去
                        Call Flg_Eraser(sel, TmpFil)

                        'アクティブレイヤーの変更
                        '               Call SetActiveLayer("自動作成")
                        '               OAC_Block = "sokumen"
                        '               inspnt(0) = 0#
                        '               inspnt(1) = 0#
                        '               inspnt(2) = 0#
                        '               Chk = FunInsertBlock(OAC_Block, inspnt(0), inspnt(1), inspnt(2), 1#, 1#, 0#, "側面")
                        OpenAcadFile_Sokumen = "継続（枠なし）"
                    Else
                        'Set acadDoc = acadDoc.New(Template3)  ' 新規ファイルを開く(テンプレート付き）
                        '↑Bricscad対応の為↓のように修正 '13.4.8 松本
                        acadDoc = acadApp.Documents.Add(Template3)  '新規ﾌｧｲﾙを開く(ﾃﾝﾌﾟﾚｰﾄ付き)
                        'モデル空間オブジェクト取得
                        moSpace = acadDoc.ModelSpace
                        OpenAcadFile_Sokumen = "継続（枠有り）"
                    End If
                End If
            Else
                OpenAcadFile_Sokumen = "中止"
            End If
        Else  'ファイルが存在していない
            ' 新規ファイルを開く(テンプレート付き）
            'Set acadDoc = acadDoc.New(Template3)
            '↑Bricscad対応の為↓のように修正 '13.4.8 松本
            acadDoc = acadApp.Documents.Add(Template3)
            'モデル空間オブジェクト取得
            moSpace = acadDoc.ModelSpace
            OpenAcadFile_Sokumen = "継続（枠有り）"
        End If
        acadApp.Visible = False
    End Function

    Public Function OpenAcadFile_Banmenhako(ByVal sel As String)
        Dim Ans As String
        Dim ExFile As String
        Dim TmpFil As String  'ﾃﾝﾌﾟﾚｰﾄ名

        '自動作成(盤面箱)

        If JobMode = "" Then
            '本社と九条に別々に盤面図(１面毎)を保存する為の一時的な措置   01/12/06 by ehiro
            '        ExFile = Sea_Dir_Banmen & "\door\B_" & KoubanName & GunbanName & BMNowName & ".dwg"
            '        ExFile = P_PrgPath & "\banmen\door\B_" & KoubanName & GunbanName & BMNowName & ".dwg"
            '１面毎の盤面ﾃﾞｰﾀについては梅津で管理するように統一 '04.10.14 松本
            'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.29 松本
            'ExFile = Sea_Dir_Banmen & "\door\B_" & KoubanName & GunbanName & BMNowName & ".dwg"
            ExFile = MkKiPath(Sea_Dir_Banmen & "\door", KoubanName) & "\B_" & KoubanName & GunbanName & BMNowName & ".dwg"
        Else
            '本社と九条に別々に盤面図(１面毎)を保存する為の一時的な措置   01/12/06 by ehiro
            '        ExFile = Sea_Dir_BanmenH & "\" & BMNowName & "$P1K" & "*.dwg"
            '        ExFile = P_PrgPath & "\hyojun\unit\banmen\" & BMNowName & "$P1K" & "*.dwg"
            '１面毎の盤面ﾃﾞｰﾀについては梅津で管理するように統一 '04.10.14 松本
            ExFile = Sea_Dir_BanmenH & "\" & BMNowName & "$P1K" & "*.dwg"
        End If
        Ans = Dir(ExFile)
        If Ans <> "" Then  'ファイルが存在している
            '
            '1ページはメッセージを表示それ以外はメッセージなしに自動作図をする
            '
            If JobMode = "UNITPK" Then
                AppActivate("unit")
                Ans = MsgBox("既にファイルが存在しています。" & Chr(13) & Chr(10) & _
                              "本当に自動作成してもヨロシイですか？" & Chr(13) & Chr(10) & _
                              "盤面器具リストNo.:" & UnitCode & " コードNo.:" & UnitKind & " " & UnitCode & UnitKind & Right(BMNowName, 2) _
                              , vbQuestion + vbYesNo + vbDefaultButton2, "自動作成開始の確認")
            Else
                AppActivate("banmen")
                acadApp.Visible = False
                Ans = MsgBox("既にファイルが存在しています。" & Chr(13) & Chr(10) & _
                              "本当に自動作成してもヨロシイですか？" & Chr(13) & Chr(10) & _
                              "工番:" & KoubanName & " 群番:" & GunbanName & " 箱番:" & BMNowName _
                              , vbQuestion + vbYesNo + vbDefaultButton2 + vbMsgBoxSetForeground, "自動作成開始の確認")
                acadApp.Visible = False
            End If
            If Ans = vbYes Then  'ファイルが存在している
                '自動作図を実行
                'ファイルをopenしてuserレイヤー以外を消す
                If JobMode = "" Then '工番作業
                    'Set acadDoc = acadDoc.Open(ExFile)  '既設ファイルのOpen
                    '↑Bricscad対応の為↓のように修正 '13.4.4 松本
                    acadDoc = acadApp.Documents.Open(ExFile)
                    'モデル空間オブジェクト取得
                    moSpace = acadDoc.ModelSpace
                    TmpFil = BlockPath6 + "banmen" + EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                    Call Del_Block_Obj("banmen")

                    'GoTo Flg_Eraser  '[User]レイヤー以外を消去
                    Call Flg_Eraser(sel, TmpFil)

                    '            Call Del_Block_Obj("banmen")
                    OpenAcadFile_Banmenhako = "継続（枠なし）"
                Else                                          '標準作業
                    ExFile = GetMaxKHFil(ExFile)
                    'Set acadDoc = acadDoc.Open(ExFile)          '既設ﾌｧｲﾙのOpen
                    '↑Bricscad対応の為↓のように修正 '13.4.4 松本
                    acadDoc = acadApp.Documents.Open(ExFile)
                    'モデル空間オブジェクト取得
                    moSpace = acadDoc.ModelSpace
                    TmpFil = BlockPath6 + "banmen" + EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                    Call Del_Block_Obj("banmen")

                    'GoTo Flg_Eraser                            '[User]ﾚｲﾔｰ以外を消去
                    Call Flg_Eraser(sel, TmpFil)

                    OpenAcadFile_Banmenhako = "継続（枠なし）"
                End If
            Else
                OpenAcadFile_Banmenhako = "中止"
            End If
        Else  'ファイルが存在していない
            ' 新規ファイルを開く(テンプレート付き）
            If JobMode = "UNITPK" Then
                AppActivate("unit")
            Else
                AppActivate("banmen")
            End If
            'Set acadDoc = acadDoc.New(Template4)
            '↑Bricscad対応の為↓のように修正 '13.4.8 松本
            acadDoc = acadApp.Documents.Add(Template4)

            'モデル空間オブジェクト取得
            moSpace = acadDoc.ModelSpace
            OpenAcadFile_Banmenhako = "継続（枠有り）"
        End If
    End Function

    Public Function OpenAcadFile_Banmenwaku(ByVal sel As String, ByVal A_Page As Integer)
        Dim Ans As String
        Dim ExFile As String
        Dim TmpFil As String  'ﾃﾝﾌﾟﾚｰﾄ名

        '自動作成(盤面枠)

        If JobMode = "" Then
            'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.29 松本
            'ExFile = Sea_Dir_Banmen & "\B_" & KoubanName & GunbanName & "P" & Format(A_Page) & "K" & BM_Nkaitei & ".dwg"
            ExFile = MkKiPath(Sea_Dir_Banmen, KoubanName) & "\B_" & KoubanName & GunbanName & _
                "P" & Format(A_Page) & "K" & BM_Nkaitei & ".dwg"
        Else
            ExFile = Sea_Dir_BanmenH & "\B$" & UnitCode & "$P1K" & "*.dwg"
        End If
        Ans = Dir(ExFile)
        If Ans <> "" Then  'ファイルが存在している
            '
            '1ページはメッセージを表示それ以外はメッセージなしに自動作図をする
            '
            AppActivate("banmen")
            'Ans = MsgBox("既にファイルが存在しています。" & Chr(13) & Chr(10) & _
            '    "本当に自動作成してもよろしいですか？" _
            '    , vbQuestion + vbYesNo + vbDefaultButton2, "自動作成開始の確認")
            'If Ans = vbYes Then  'ファイルが存在している
            '自動作図を実行
            'ファイルをopenしてuserレイヤー以外を消す
            If JobMode = "" Then '工番作業
                'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.29 松本
                'ppath = Sea_Dir_Banmen & "\"
                ppath = MkKiPath(Sea_Dir_Banmen, KoubanName) & "\"
                '            astName = "B_" & KoubanName & GunbanName & "P" & Format(A_Page) & "K" & BM_Nkaitei & ".dwg"
                '            GoSub Flg_Set '既設ファイルを配列にセット
                '            If pkname(A_Page) <> "" Then '既設図面に対象となるページが存在している
                '                banmenzu = Sea_Dir_Banmen & "\" & pkname(A_Page)
                '                Set acadDoc = acadDoc.Open(banmenzu)  '既設ファイルのOpen
                'Set acadDoc = acadDoc.Open(ExFile)  '既設ファイルのOpen
                '↑Bricscad対応の為↓のように修正 '13.4.4 松本
                acadDoc = acadApp.Documents.Open(ExFile)
                'モデル空間オブジェクト取得
                moSpace = acadDoc.ModelSpace
                TmpFil = BlockPath6 & "banmen" & EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                '                Call Del_Block_Obj("banmen")

                'GoTo Flg_Eraser  '[User]レイヤー以外を消去
                Call Flg_Eraser(sel, TmpFil)

                OpenAcadFile_Banmenwaku = "継続（枠なし）"
                '            Else
                '                Set acadDoc = acadDoc.New(Template4)  ' 新規ファイルを開く(テンプレート付き）
                '                OpenAcadFile = "継続（枠有り）"
                '            End If
            Else                                          '標準作業
                ExFile = GetMaxKHFil(ExFile)
                'Set acadDoc = acadDoc.Open(ExFile)          '既設ﾌｧｲﾙのOpen
                '↑Bricscad対応の為↓のように修正 '13.4.4 松本
                acadDoc = acadApp.Documents.Open(ExFile)
                'モデル空間オブジェクト取得
                moSpace = acadDoc.ModelSpace
                TmpFil = BlockPath6 & "banmen" & EndString 'ﾃﾝﾌﾟﾚｰﾄ名設定
                Call Del_Block_Obj("banmen")

                'GoTo Flg_Eraser                            '[User]ﾚｲﾔｰ以外を消去
                Call Flg_Eraser(sel, TmpFil)

                OpenAcadFile_Banmenwaku = "継続（枠なし）"
            End If
            'Else
            '  OpenAcadFile = "中止"
            'End If
        Else  'ファイルが存在していない
            ' 新規ファイルを開く(テンプレート付き）
            'Set acadDoc = acadDoc.New(Template4)
            '↑Bricscad対応の為↓のように修正 '13.4.8 松本
            acadDoc = acadApp.Documents.Add(Template4)
            'モデル空間オブジェクト取得
            moSpace = acadDoc.ModelSpace
            OpenAcadFile_Banmenwaku = "継続（枠有り）"
        End If
        'acadApp.Visible = False
    End Function

    Public Sub Flg_Set(ByVal astName As String)
        '
        '最新の図面情報を配列にセット
        '
        Dim hpos As Integer  '"-"を表示する位置
        Dim ppos As Integer  'ページを表示する位置
        Dim kpos As Integer  '改訂番号を表示する位置
        Dim dpos As Integer   '拡張子を表示する位置
        Dim npName As String    '各ページ図面名
        Dim pknum(0 To 1000) As Integer 'ページ履歴
        Dim Cnt As Integer
        Dim K As Integer, P As Integer

        For iCnt = 0 To 1000
            pknum(iCnt) = 0
            pkname(iCnt) = ""
        Next iCnt

        'npName = UCase(Dir(ppath & astName))    '念の為大文字に変換 '04.6.17 松本
        npName = Dir(ppath & astName)
        Cnt = 1


        'ファイル名変更により、改訂を参照する必要がなくなったことと、ページを示す数字の位置が変わったのでエラーなく動くように変更
        If IsNumeric(npName(14)) = True Then    '図番15文字目(XP99-9999-BA99○_R0 の○の場所がページ番号を示す)が数値なら、ページ番号として取得
            P = Val(npName(14))                 'この方法は場所を指定しているため再びファイル名の変更があった場合は、コードの修正が必要
            pkname(P) = npName
        Else
            '最新図面のみを選択可能にする(ファイル名変更前の処理)
            Do While npName <> ""
                hpos = InStr(2, npName, "-", 1)
                'ppos = InStr(hpos, npName, "P", 1) '群番がPの場合がある為以下のように修正 '04.6.17 松本
                On Error Resume Next
                ppos = KposSea(npName, "P")
                'kpos = InStr(2, npName, "K", 1)
                'kpos = InStr(hpos, npName, "K", 1)
                kpos = KposSea(npName, "K")
                dpos = InStr(2, npName, ".", 1)
                P = Val(Mid(npName, ppos + 1, kpos - ppos - 1))
                K = Val(Mid(npName, kpos + 1, dpos - kpos - 1))

                '改訂番号が大きい場合保存する
                If pknum(P) <= K Then
                    pknum(P) = K
                    pkname(P) = npName
                    Cnt = Cnt + 1
                End If
                npName = Dir()
            Loop
        End If


        
    End Sub


    Public Sub Flg_Eraser(ByVal sel As String, ByVal TmpFil As String)
        '
        '[User]レイヤー以外を消去
        '
        Dim sset As AcadSelectionSet
        Dim gpCode(0) As Integer, dataValue(0) As Object
        Dim f_type As Object, f_data As Object
        Dim mode As Integer
        Dim point1(0 To 2) As Double, point2(0 To 2) As Double
        Dim blockObj As Object

        '選択セットを削除する
        Call SelectionClear("SS1")
        sset = acadDoc.SelectionSets.Add("SS1") '選択セットSS1を作成
        'mode = acSelectionSetAll '全てを選択
        mode = AcSelect.acSelectionSetAll   '全てを選択
        point1(0) = 0.0# : point1(1) = 0.0# : point1(2) = 0.0#  'ダミーの点
        point2(0) = 1.0# : point2(1) = 1.0# : point2(2) = 0.0#  'ダミーの点
        gpCode(0) = 8 'DXFグループコード=レイヤー名
        f_type = gpCode
        'dataValue(0) = "自動作成" 'レイヤー名
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去
        If sel = "側面" Then
            dataValue(0) = "R" 'レイヤー名
            f_data = dataValue
            sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
            sset.Erase()  'selectionsetの消去
            Call AcadCommand("purgeall")  '消去したブロックを消す
            acadApp.Visible = False
            '      acadDoc.PurgeAll  '消去したブロックを完全に消す
        ElseIf sel = "盤面箱" Then
            dataValue(0) = "箱外形" 'レイヤー名
            f_data = dataValue
            sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
            sset.Erase()  'selectionsetの消去
            dataValue(0) = "機器寸法" 'レイヤー名
            f_data = dataValue
            sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
            sset.Erase()  'selectionsetの消去
            dataValue(0) = "詳細" 'レイヤー名
            f_data = dataValue
            sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
            sset.Erase()  'selectionsetの消去
            '把手の消去
            Call Del_Block_Obj(BM_TotteWapNoIR & "_W")
            Call Del_Block_Obj(BM_TotteWapNoIR3 & "_W")
            Call Del_Block_Obj(BM_TotteWapNoIL & "_W")
            Call Del_Block_Obj(BM_TotteWapNoIL3 & "_W")
            Call Del_Block_Obj(BM_TotteWapNoIWL & "_W")
            Call Del_Block_Obj(BM_TotteWapNoOR & "_W")
            Call Del_Block_Obj(BM_TotteWapNoOL & "_W")
            Call Del_Block_Obj(BM_TotteWapNoOWR & "_W")
            Call Del_Block_Obj(BM_TotteWapNoSHL & "_W")
            Call Del_Block_Obj(BM_TotteWapNoSHR & "_W")
            Call Del_Block_Obj(BM_TotteWapNoSBL & "_W")
            Call Del_Block_Obj(BM_TotteWapNoSBR & "_W")
        ElseIf sel = "盤面枠" Then
            dataValue(0) = "箱外形" 'レイヤー名
            f_data = dataValue
            sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
            sset.Erase()  'selectionsetの消去
            dataValue(0) = "機器寸法" 'レイヤー名
            f_data = dataValue
            sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
            sset.Erase()  'selectionsetの消去
            '再作図時に画層をpurgeallコマンドで消去しない為に追加
            'Add by ehiro 99/8/4
            '      insPntS(0) = 0: insPntS(1) = 0: insPntS(2) = 0
            '      insPntE(0) = 0.1: insPntE(1) = 0: insPntE(2) = 0
            '      Set lin_obj = moSpace.AddLine(insPntS, insPntE)
            '      lin_obj.Layer = "機器寸法"
            dataValue(0) = "詳細" 'レイヤー名
            f_data = dataValue
            sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
            sset.Erase()  'selectionsetの消去

            '再作図時に画層をpurgeallコマンドで消去しない為に追加
            'Add by ehiro 99/8/4
            '      insPntS(0) = 0: insPntS(1) = 0: insPntS(2) = 0
            '      insPntE(0) = 0.1: insPntE(1) = 0: insPntE(2) = 0
            '      Set lin_obj = moSpace.AddLine(insPntS, insPntE)
            '      lin_obj.Layer = "詳細"
            '      Set lin_obj = moSpace.AddLine(insPntS, insPntE)
            '      lin_obj.Layer = "自動作成"
            Call AcadCommand("purgeall")  '消去したブロックを消す
            '      acadDoc.PurgeAll  '消去したブロックを消す
        End If
        'Call AcadCommand("purgeall")  '消去したブロックを完全に消す

        'dataValue(0) = "1.SUNPOU_MOJI_HATTINGU" 'レイヤー名
        'sset.Clear()
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去
        'dataValue(0) = "3.TYUUSINSEN" 'レイヤー名
        'sset.Clear()
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去
        'dataValue(0) = "0" 'レイヤー名
        'sset.Clear()
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去


        'dataValue(0) = "WIRE" 'レイヤー名
        'sset.Clear()
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去
        'dataValue(0) = "01.Dimension line. Text" 'レイヤー名
        'sset.Clear()
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去

        'dataValue(0) = "WIRE" 'レイヤー名
        'sset.Clear()
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去
        'dataValue(0) = "01.Dimension line. Text" 'レイヤー名
        'sset.Clear()
        'f_data = dataValue
        'sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
        'sset.Erase()  'selectionsetの消去

        Dim i As Integer, j As Integer
        i = 0 : j = 0
        Dim t(acadDoc.Layers.Count - 1) As AcadLayer
        For i = 0 To acadDoc.Layers.Count - 1
            If acadDoc.Layers.Item(i).Name = "USER" Then
                '消さない
            Else
                t(j) = acadDoc.Layers.Item(i)

                sset.Clear()
                dataValue(0) = t(j).Name
                f_data = dataValue
                sset.Select(mode, point1, point2, f_type, f_data) 'document内の全てから指定したレイヤー選択
                sset.Erase()  'selectionsetの消去
                j = j + 1
            End If

        Next
        Call AcadCommand("purgeall")  '消去したブロックを完全に消す

        blockObj = moSpace.InsertBlock(point1, TmpFil, 1, 1, 1, 0) 'ﾃﾝﾌﾟﾚｰﾄ追加
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")
    End Sub

    '
    '元のﾊﾟｽに期毎のﾌｫﾙﾀﾞ名を追加したﾊﾟｽを返す(期のﾌｫﾙﾀﾞが無ければ作成する)
    '
    Public Function MkKiPath(ByVal OldPath As String, ByVal Kbn As String) As String
        '元のﾊﾟｽ            工番
        Dim Ki As String    '期

        Ki = Mid(Kbn, InStr(1, Kbn, "-") - 2, 2)                '期取得
        MkKiPath = OldPath & Ki & "期"                          '期ﾌｫﾙﾀﾞを追加したﾊﾟｽを返す
        'MkKiPath = OldPath                           '期ﾌｫﾙﾀﾞを追加したﾊﾟｽを返す
        If Dir(MkKiPath, vbDirectory) = "" Then MkDir(MkKiPath) '期ﾌｫﾙﾀﾞが無ければ作成
    End Function

    '
    '標準図のﾌｧｲﾙで改訂番号の一番大きい（最新）ﾌｧｲﾙ名の取得
    '
    Public Function GetMaxKHFil(ByVal OFilNam As String) As String
        '*付きﾌｧｲﾙ名
        Dim MaxKaitei As Integer    '最大改訂番号
        Dim FilNam As String        'ﾌｧｲﾙ名
        Dim Pos As Integer          '文字位置
        Dim Kaitei As Integer       '改訂番号

        MaxKaitei = 0               '最大改訂番号初期化
        FilNam = Dir(OFilNam)       '*付きﾌｧｲﾙ検索
        While FilNam <> ""
            Pos = InStr(3, FilNam, "$")                     '区切り文字位置取得
            Pos = InStr(Pos + 1, FilNam, "K")               '改訂番号位置取得
            Kaitei = Val(Mid(FilNam, Pos + 1))              '改訂番号取得
            If Kaitei > MaxKaitei Then MaxKaitei = Kaitei '最大改訂番号取得
            FilNam = Dir()                                    '次のﾌｧｲﾙ名取得
        End While
        Pos = InStr(1, OFilNam, "*")                                        '*位置取得
        GetMaxKHFil = Left(OFilNam, Pos - 1) + Format(MaxKaitei) + ".dwg"   '最新ﾌｧｲﾙ名作成
    End Function

    Public Function SetScale(ByVal I_Data As Double, ByVal I_Scale As Double) As Double
        '-----------------------------------------------
        '縮尺に合わせて引数の値を変える
        '-----------------------------------------------
        '   I_Data      : 入力データ(ex 100)
        '   I_Scale     : 入力スケール(ex 25)
        '   戻り値      : 計算結果(ex 2500)
        '-----------------------------------------------

        SetScale = I_Data * I_Scale

    End Function

    Public Function FunInsertBlock(ByVal Block As String, ByVal X As Double, ByVal Y As Double, ByVal Z As Double, ByVal XScale As Double, ByVal YScale As Double, ByVal Rotate As Double, ByVal sel As String) As String
        '-------------------------------------------
        'スクリプトファイルを作成してブロックを挿入する
        '-------------------------------------------
        '   Block     : 挿入するブロック名(ex I_1000)
        '   X         : 挿入X座標(ex 100)
        '   Y         : 挿入Y座標(ex 200)
        '   Z         : 挿入Z座標(ex 0)
        '   XScale    : X座標のスケール(ex 25)
        '   YScale    : Y座標のスケール(ex 25)
        '   Rotate    : 回転角度(ex 0)
        '   Sel       : 分類(属性を持たない場合は"配列","基礎"のどちらか）
        '   戻り値    : OK
        '-------------------------------------------
        Dim insBlock As String, blockObj As Object
        Dim Attribs As Object
        Dim i As Integer
        Dim lZscale As Double

        InsPnt(0) = X : InsPnt(1) = Y : InsPnt(2) = Z
        lZscale = 1
        Select Case sel
            Case "図枠"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                For i = LBound(Attribs) To UBound(Attribs)
                    Select Case Attribs(i).TagString
                        Case "ZUBAN"
                            Attribs(i).TextString = TL_Kouban
                        Case "GUNBAN"
                            Attribs(i).TextString = TL_Gunban
                        Case "NEN"
                            Attribs(i).TextString = TL_Year
                        Case "TUKI"
                            Attribs(i).TextString = TL_Month
                        Case "HI"
                            Attribs(i).TextString = TL_Day
                        Case "WAKUGAI"
                            Attribs(i).TextString = TL_Wakugai
                        Case "SEIHINSYUBETU"
                            Attribs(i).TextString = TL_Syubetu
                        Case "ZUDAI"
                            Attribs(i).TextString = TL_Meisho
                        Case "PAGE"
                            Attribs(i).TextString = "(" & TL_NMaisu & "/" & TL_ZMaisu & ")"
                        Case "MESURE1"
                            Attribs(i).TextString = TL_Mesure1
                        Case "MESURE2"
                            Attribs(i).TextString = TL_Mesure2
                    End Select
                Next
            Case "扉構造図"
                insBlock = BlockPath1 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Attribs(0).TextString = HM_MPKT
            Case "D_SUNPO"
                insBlock = BlockPath1 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Attribs(0).TextString = CSD_OD_Sunpo
            Case "KIKI_SUNPO"
                insBlock = BlockPath1 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Attribs(0).TextString = CSD_KM_Sunpo
            Case "配列図定格欄"
                insBlock = BlockPath1 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Call SetZokusei(Attribs)
            Case "基礎図箱番号"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Attribs(0).TextString = HAKO_No
            Case "基礎図ボルト文字"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Attribs(0).TextString = Z_TEXT
            Case "基礎図合符号"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Attribs(0).TextString = T_Fugo
            Case "基礎図制御穴", "屋外基礎図締付ボルト", "屋外基礎図アンカーボルト", _
                 "基礎図アンカーボルト２"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                Attribs(0).TextString = Mult_String
            Case "屋内基礎図締付ボルト"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                For i = LBound(Attribs) To UBound(Attribs)
                    Select Case Attribs(i).TagString
                        Case "SIME1"
                            Attribs(i).TextString = Mult_String
                        Case "SIME2"
                            Attribs(i).TextString = Mult_String2
                    End Select
                Next
            Case "屋内基礎図アンカーボルト"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                For i = LBound(Attribs) To UBound(Attribs)
                    Select Case Attribs(i).TagString
                        Case "A_ANKA1"
                            Attribs(i).TextString = Mult_String
                        Case "A_ANKA2"
                            Attribs(i).TextString = Mult_String2
                    End Select
                Next
            Case "改定up", "改定down"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
                Attribs = blockObj.GetAttributes '属性を全て取り出し配列にセット
                For i = LBound(Attribs) To UBound(Attribs)
                    Attribs(i).TextString = Mult_String
                Next
            Case "配列"
                'insBlock = BlockPath1 & Block & EndString
                insBlock = P_HBlkPath & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
            Case "基礎"
                insBlock = BlockPath3 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
            Case "側面"
                insBlock = BlockPath4 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
            Case "ブロックスケルトン"
                insBlock = BlockPath7 & Block & EndString
                blockObj = moSpace.InsertBlock(InsPnt, insBlock, XScale, YScale, lZscale, Rotate)
        End Select
        FunInsertBlock = "OK"

        '-------------------------------------------
        'スクリプトファイルを作成してブロックを挿入する
        '-------------------------------------------
        'Const W_File = "c:\subinsertblock.lsp"
        'Const Chk_File = "c:\end.txt"
        'Dim Cmd As String, T_String As String


        'T_String = ""
        'LISPファイルの作成
        'Open W_File For Output As #1
        'ブロック挿入
        'Print #1, "(defun subinsertblock()"
        'Print #1, "(command ""insert"""
        'Print #1, """" & Block & """"
        'Print #1, """" & CStr(X) & ", " & CStr(Y) & ", " & CStr(Z) & """"
        'Print #1, """" & CStr(XScale) & """"
        'Print #1, """" & CStr(YScale) & """"
        'Print #1, """" & CStr(Rotate) & """"
        '属性設定
        'Select Case Sel
        '  Case "図枠"
        '    Print #1, """" & TL_Kouban & """"
        '    Print #1, """" & TL_Gunban & """"
        '    Print #1, """" & TL_Year & """"
        '    Print #1, """" & TL_Month & """"
        '    Print #1, """" & TL_Day & """"
        '    Print #1, """" & TL_Wakugai & """"
        '    Print #1, """" & TL_Meisho & """"
        '    Print #1, """" & "(" & TL_NMaisu & "/" & TL_ZMaisu & ")" & """"
        ' Case "扉構造図"
        '    Print #1, """" & HM_MPKT & """"
        ' Case "D_SUNPO"
        '    Print #1, """" & CSD_OD_Sunpo & """"
        ' Case "KIKI_SUNPO"
        '    Print #1, """" & CSD_KM_Sunpo & """"
        ' Case "配列図定格欄"
        '    Print #1, """" & S_DOORZUBAN & """"
        '    Print #1, """" & S_DRZUBAN & """"
        '    Print #1, """" & S_DOOROPEN & """"
        '    Print #1, """" & S_JYOTAI & """"
        '    Print #1, """" & S_DENATU & """"
        '    Print #1, """" & S_TNP & """"
        '    Print #1, """" & S_ZETUEN & """"
        '    Print #1, """" & S_HZ & """"
        '    Print #1, """" & S_KATA & """"
        '    Print #1, """" & S_HOGO & """"
        '    Print #1, """" & S_HOGO2 & """"
        '    Print #1, """" & S_CUBNO & """"
        '    Print #1, """" & S_JYURYO & """"
        '    Print #1, """" & S_NP1 & """"
        '    Print #1, """" & S_NP2 & """"
        '    Print #1, """" & S_NP3 & """"
        '    Print #1, """" & S_NP4 & """"
        ' Case "基礎図箱番号"
        '    Print #1, """" & HAKO_NO & """"
        ' Case "基礎図ボルト文字"
        '    Print #1, """" & Z_TEXT & """"
        ' Case "基礎図合符号"
        '    Print #1, """" & T_Fugo & """"
        ' Case "基礎図制御穴"
        '    Print #1, """" & Mult_String & """"
        ' Case "屋内基礎図締付ボルト"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String2 & """"
        ' Case "屋外基礎図締付ボルト"
        '    Print #1, """" & Mult_String & """"
        ' Case "屋内基礎図アンカーボルト"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String2 & """"
        ' Case "屋外基礎図アンカーボルト"
        '    Print #1, """" & Mult_String & """"
        ' Case "基礎図アンカーボルト２"
        '    Print #1, """" & Mult_String & """"
        ' Case "改定up"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String & """"
        ' Case "改定down"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String & """"
        '    Print #1, """" & Mult_String & """"
        'End Select
        '
        'Print #1, ")"
        'Print #1, ")"
        'Close #1


        'DDE通信の実行
        'If Sel = "図枠" Then '初めてLispを動かす場合
        '  Cmd = "(load " & Chr(34) & ProgPath1 & "insertblock.lsp" & Chr(34) & ")"
        'frmtest.acadtext.LinkExecute Cmd & Chr(13)
        '  frmMain.acadtext.LinkExecute Cmd & Chr(13)
        'End If

        'Cmd = "(InsertBlock)"
        'frmtest.acadtext.LinkExecute Cmd & Chr(13)
        'frmMain.acadtext.LinkExecute Cmd & Chr(13)

        'DDE処理終了のチェック
        'ChkEnd = ""
        'Do Until (ChkEnd <> "")
        '   Sleep (1000)
        '  ChkEnd = Dir(Chk_File)
        'Loop
        '不要ファイルの削除
        'Kill Chk_File
        'FunInsertBlock = "OK"
    End Function

    Public Sub SetZokusei(ByVal Attribs As Object)
        '配列図定格欄の属性セット
        For i = LBound(Attribs) To UBound(Attribs)
            Select Case Attribs(i).TagString
                Case "S_DOORZUBAN"
                    Attribs(i).TextString = S_DOORZUBAN
                Case "S_DRZUBAN"
                    Attribs(i).TextString = S_DRZUBAN
                Case "S_DOOROPEN"
                    Attribs(i).TextString = S_DOOROPEN
                Case "S_JYOTAI"
                    Attribs(i).TextString = S_JYOTAI
                Case "S_DENATU"
                    Attribs(i).TextString = S_DENATU
                Case "S_TNP"
                    Attribs(i).TextString = S_TNP
                Case "S_ZETUEN"
                    Attribs(i).TextString = S_ZETUEN
                Case "S_HZ"
                    Attribs(i).TextString = S_HZ
                Case "S_KATA"
                    Attribs(i).TextString = S_KATA
                Case "S_HOGO"
                    Attribs(i).TextString = S_HOGO
                Case "S_HOGO2"
                    Attribs(i).TextString = S_HOGO2
                Case "S_CUBNO"
                    Attribs(i).TextString = S_CUBNO
                Case "S_JYURYO"
                    Attribs(i).TextString = S_JYURYO
                Case "S_NP1"
                    Attribs(i).TextString = S_NP1
                Case "S_NP2"
                    Attribs(i).TextString = S_NP2
                Case "S_NP3"
                    Attribs(i).TextString = S_NP3
                Case "S_NP4"
                    Attribs(i).TextString = S_NP4
                Case "S_POWERFREQUENCY"
                    Attribs(i).TextString = S_POWERFREQUENCY
                Case "S_LIGHTNINGIMPULSE"
                    Attribs(i).TextString = S_LIGHTNINGIMPULSE
            End Select
        Next
    End Sub

    Public Function StringGet(ByVal InpString As String, ByVal SetMoji As String, ByVal SetKugiri As String)
        '-----------------------------------------------
        'SetKugiriで区切られて文字を変数にセットする
        '-----------------------------------------------
        ' InpString   : 入力文字列(ex 101;102;103)
        ' SetMoji     : 取出された文字(ex 101)
        ' SetKugiri   : 文字列の区切り記号(ex ;)
        ' 戻り値      : 残りの文字列(102;103)
        '-----------------------------------------------

        Dim Pos, Leng As Integer

        Pos = InStr(InpString, SetKugiri)
        Leng = Len(InpString)

        If Pos <> 0 Then
            T_Hako = Left(InpString, Pos - 1)
            StringGet = Right(InpString, (Leng - Pos))
        Else  '区切り文字が見つからなかった場合
            T_Hako = InpString
            StringGet = ""
        End If
    End Function

    'ファイル名等から改訂番号を表す"K"やページ番号を表す"P"の位置を返す
    Public Function KposSea(ByVal StrName As String, ByVal SeaStr As String)
        Dim i As Integer
        KposSea = ""

        For i = InStr(1, StrName, ".", 1) To 1 Step -1
            If Mid(StrName, i, 1) = SeaStr Then
                KposSea = i
                Exit For
            End If
        Next i
    End Function

    Public Function ChkExtHakoNo(ByVal Cnt As Integer, ByVal sel As String) As String
        '-----------------------------------------------
        '  納入外の箱かどうかチェックするプログラム
        '-----------------------------------------------
        ' Cnt     : H_CubNo上の配列位置
        ' Sel     : 比較対象（配列、基礎）
        ' 戻り値  : 結果("納入外"or"")
        '-----------------------------------------------


        Dim Dummy As String
        Dim i As Integer
        ChkExtHakoNo = ""                   '初期値
        Dummy = ""
        T_Hako = ""

        '納入外箱Noを文字列に格納する
        Select Case sel
            Case "配列"
                i = 1
                Dummy = ExtCubNo(0)
                Do Until ExtCubNo(i) = ""
                    Dummy = Dummy + "," + ExtCubNo(i)
                    i = i + 1
                Loop
            Case "基礎"
                i = 1
                Dummy = BaseCubNo(0)
                Do Until BaseCubNo(i) = ""
                    Dummy = Dummy + "," + BaseCubNo(i)
                    i = i + 1
                Loop
        End Select

        'チェック
        i = 1
        Do Until Dummy = ""
            Dummy = StringGet(Dummy, T_Hako, ",")
            If T_Hako = H_CubNo(Cnt) Then
                'If T_Hako = H_CubNo(Cnt) Then
                ChkExtHakoNo = "納入外"
                Exit Function
            End If
        Loop
    End Function

    '選択セットを削除する
    Public Sub SelectionClear(ByVal SelName As String)
        'Dim selCnt As Integer           '選択セットカウンター
        Dim selCnt As Long              '選択セットカウンター   '11.03.23 ↑ﾃﾞｰﾀ型が正しくなかったので修正 by 松本
        Dim ssetDel As AcadSelectionSet '選択セットオブジェクト
        Dim i As Integer                'ループカウンター

        'selCnt = acadDoc.SelectionSets.Count
        selCnt = CLng(acadDoc.SelectionSets.Count)  '11.03.23 ﾃﾞｰﾀ型をあわせる為に修正 by 松本
        For i = 0 To selCnt - 1
            ssetDel = acadDoc.SelectionSets.Item(i)
            If ssetDel.Name = SelName Then
                acadDoc.SelectionSets.Item(i).Delete()
                Exit For
            End If
        Next i

    End Sub

    Public Function CalSam(ByVal T_Moji As String, ByVal Kugiri As String) As Integer
        '-----------------------------------------------
        '  引数の中身を合計する
        '-----------------------------------------------
        '   T_Moji      : 対象となる文字列(ex 101,102,103)
        '   Kugiri      : 区切り記号(ex ;)
        '   戻り値      : 合計数(ex 3)
        '-----------------------------------------------

        Dim T_Data As String
        Dim i As Integer
        Dim Dummy As String
        T_Data = ""
        Dummy = T_Moji
        i = 0
        Do Until Dummy = ""
            Dummy = StringGet(Dummy, T_Data, Kugiri)
            i = i + 1
        Loop
        CalSam = i
    End Function

    Public Sub BanNoErrChk()
        '箱番の重複エラーチェック
        'エラー番号:1
        Dim i As Integer, j As Integer, k As Integer
        i = 0
        j = 0
        k = 0

        For i = 0 To UBound(P_sBanDat, 1) - 1           '最終行以外の盤を調べる
            For j = i + 1 To UBound(P_sBanDat, 1)
                If P_sBanDat(i, pc_BanNoRow) = P_sBanDat(j, pc_BanNoRow) Then
                    k = k + 1
                    If k = 1 Then                       '最初にエラーが見つかったとき
                        '見つかったエラーを表示するフォームに、項目名を示すラベルと、その箱が左から何番目か(箱連番)をテキストボックスに表示
                        ErrCell(0) = P_sBanDat(i, pc_BanNoRow)
                        My.Forms.frmErrorList.lblEJBanNo = New System.Windows.Forms.Label()
                        My.Forms.frmErrorList.lblEJBanNo.Name = "lblENBanNo"
                        My.Forms.frmErrorList.lblEJBanNo.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.lblEJBanNo.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                        My.Forms.frmErrorList.lblEJBanNo.Text = "重複している箱番名"
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEJBanNo)
                        My.Forms.frmErrorList.txtEJBanNo = New System.Windows.Forms.TextBox()
                        My.Forms.frmErrorList.txtEJBanNo.Name = "txtENBanNo"
                        My.Forms.frmErrorList.txtEJBanNo.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.txtEJBanNo.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                        My.Forms.frmErrorList.txtEJBanNo.ReadOnly = True
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEJBanNo)
                        lblCnt = lblCnt + 1
                    Else
                        ErrCell(0) = ErrCell(0) & "," & P_sBanDat(i, pc_BanNoRow)
                    End If
                    My.Forms.frmErrorList.txtEJBanNo.Text = ErrCell(0)
                End If
                If i = UBound(P_sBanDat, 1) And j + 1 = UBound(P_sBanDat, 1) Then
                    Exit For
                End If
            Next
        Next

        If k <> 0 Then
            My.Forms.frmErrorList.txtEJBanNo.Text = ErrCell(0)
            'Stopflg = True      '箱番の重複はDBへの保存にも影響を及ぼすので、保存を中断する(作図時は当然中断)
            ErrNum = 1          '箱番のエラー番号
            Call ErrorCheck()
            Exit Sub
        End If



        'If Stopflg = False Then     'DBへ保存するとき
        '    For i = 0 To frm配列基礎仕様.gridHairetuKiso.ColumnCount - 2            '最終行以外の盤を調べる
        '        For j = i + 1 To frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1
        '            If frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanNoRow).Cells(i).Value = frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanNoRow).Cells(j).Value Then
        '                ErrNum = 1          '箱番のエラー番号
        '                Call ErrorCheck()
        '                Exit Sub
        '            End If
        '            If i = frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1 And j + 1 = frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1 Then
        '                Exit For
        '            End If
        '        Next
        '    Next
        'Else                        '作図するとき
        '    For i = 0 To UBound(P_sBanDat, 1) - 1           '最終行以外の盤を調べる
        '        For j = i + 1 To UBound(P_sBanDat, 1)
        '            If P_sBanDat(i, pc_BanNoRow) = P_sBanDat(j, pc_BanNoRow) Then
        '                ErrNum = 1          '箱番のエラー番号
        '                Call ErrorCheck()
        '                Exit Sub
        '            End If
        '            If i = UBound(P_sBanDat, 1) And j + 1 = UBound(P_sBanDat, 1) Then
        '                Exit For
        '            End If
        '        Next
        '    Next
        'End If
        


    End Sub

    Public Sub IsNumericErrChk()
        '数値のみで入力されているかのチェック
        '(箱番、質量、扉角度、箱幅、高さ、奥行)
        'エラー番号:2

        Dim i As Integer, j As Integer, k As Integer, l As Integer, n As Integer
        Dim a As Integer, b As Integer, c As Integer, d As Integer, f As Integer, g As Integer
        'Dim ErrCell2 As String
        i = 0
        j = 0       'エラーカウンタ
        k = 0
        l = 0
        ErrCellList = ""


        '数値のみ入力が通る行のエラーチェック(数値になっているか)
        If IsNumeric(Bunkatu) = False Then  '最大分割位置
            j = j + 1
        End If
        For i = 0 To UBound(P_sBanDat, 1)
            'If IsNumeric(P_sBanDat(i, pc_BanNoRow)) = False Then   '箱番
            '    'ErrCell(0, a) = "(" & i & "," & pc_BanNoRow & ")"

            '    a = a + 1
            '    j = j + 1
            '    If a = 1 Then
            '        ErrCell(1) = i + 1
            '        My.Forms.frmErrorList.lblENBanNo = New System.Windows.Forms.Label()
            '        My.Forms.frmErrorList.lblENBanNo.Name = "lblENBanNo"
            '        My.Forms.frmErrorList.lblENBanNo.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
            '        My.Forms.frmErrorList.lblENBanNo.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
            '        My.Forms.frmErrorList.lblENBanNo.Text = "箱番に数値以外の入力がある箱"
            '        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblENBanNo)
            '        My.Forms.frmErrorList.txtENBanNo = New System.Windows.Forms.TextBox()
            '        My.Forms.frmErrorList.txtENBanNo.Name = "txtENBanNo"
            '        My.Forms.frmErrorList.txtENBanNo.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
            '        My.Forms.frmErrorList.txtENBanNo.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
            '        My.Forms.frmErrorList.txtENBanNo.ReadOnly = True
            '        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtENBanNo)
            '        lblCnt = lblCnt + 1
            '    Else
            '        ErrCell(1) = ErrCell(1) & "," & (i + 1)
            '    End If
            '    My.Forms.frmErrorList.txtENBanNo.Text = ErrCell(1)
            'End If
            If IsNumeric(P_sBanDat(i, pc_DoorOpnRow)) = False And nps = False Then '扉解放角度
                'ErrCell(1, b) = "(" & i & "," & pc_DoorOpnRow & ")"
                b = b + 1
                j = j + 1
                If b = 1 Then

                    ErrCell(2) = i + 1
                    My.Forms.frmErrorList.lblEDoor = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblEDoor.Name = "lblEDoor"
                    My.Forms.frmErrorList.lblEDoor.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblEDoor.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblEDoor.Text = "扉解放角度に数値以外の入力がある箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEDoor)
                    My.Forms.frmErrorList.txtEDoor = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtEDoor.Name = "txtEDoor"
                    My.Forms.frmErrorList.txtEDoor.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtEDoor.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtEDoor.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEDoor)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(2) = ErrCell(2) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtEDoor.Text = ErrCell(2)
            End If
            If IsNumeric(P_sBanDat(i, pc_JyuryoRow)) = False Then  '盤概略質量
                'ErrCell(2, c) = "(" & i & "," & pc_JyuryoRow & ")"
                c = c + 1
                j = j + 1
                If c = 1 Then

                    ErrCell(3) = i + 1
                    My.Forms.frmErrorList.lblEJuryo = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblEJuryo.Name = "lblEJuryo"
                    My.Forms.frmErrorList.lblEJuryo.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblEJuryo.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblEJuryo.Text = "盤概略質量に数値以外の入力がある箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEJuryo)
                    My.Forms.frmErrorList.txtEJuryo = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtEJuryo.Name = "txtEJuryo"
                    My.Forms.frmErrorList.txtEJuryo.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtEJuryo.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtEJuryo.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEJuryo)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(3) = ErrCell(3) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtEJuryo.Text = ErrCell(3)
            End If
            If IsNumeric(P_sBanDat(i, pc_BanWRow)) = False Then   '幅
                'ErrCell(3, d) = "(" & i & "," & pc_BanWRow & ")"
                d = d + 1
                j = j + 1
                If d = 1 Then

                    ErrCell(4) = i + 1
                    My.Forms.frmErrorList.lblENBanW = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblENBanW.Name = "lblENBanW"
                    My.Forms.frmErrorList.lblENBanW.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblENBanW.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblENBanW.Text = "箱幅に数値以外の入力がある箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblENBanW)
                    My.Forms.frmErrorList.txtENBanW = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtENBanW.Name = "txtENBanW"
                    My.Forms.frmErrorList.txtENBanW.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtENBanW.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtENBanW.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtENBanW)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(4) = ErrCell(4) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtENBanW.Text = ErrCell(4)
            End If
            If IsNumeric(P_sBanDat(i, pc_BanHRow)) = False Then '高さ
                'ErrCell(4, f) = "(" & i & "," & pc_BanHRow & ")"
                f = f + 1
                j = j + 1
                If f = 1 Then

                    ErrCell(5) = i + 1
                    My.Forms.frmErrorList.lblENBanH = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblENBanH.Name = "lblENBanH"
                    My.Forms.frmErrorList.lblENBanH.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblENBanH.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblENBanH.Text = "箱高さに数値以外の入力がある箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblENBanH)
                    My.Forms.frmErrorList.txtENBanH = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtENBanH.Name = "txtENBanH"
                    My.Forms.frmErrorList.txtENBanH.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtENBanH.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtENBanH.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtENBanH)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(5) = ErrCell(5) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtENBanH.Text = ErrCell(5)
            End If
            If IsNumeric(P_sBanDat(i, pc_BanDRow)) = False Then  '奥行
                'ErrCell(5, g) = "(" & i & "," & pc_BanDRow & ")"
                g = g + 1
                j = j + 1
                If g = 1 Then

                    ErrCell(6) = i + 1
                    My.Forms.frmErrorList.lblENBanD = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblENBanD.Name = "lblENBanD"
                    My.Forms.frmErrorList.lblENBanD.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblENBanD.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblENBanD.Text = "箱奥行に数値以外の入力がある箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblENBanD)
                    My.Forms.frmErrorList.txtENBanD = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtENBanD.Name = "txtENBanNo"
                    My.Forms.frmErrorList.txtENBanD.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtENBanD.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtENBanD.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtENBanD)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(6) = ErrCell(6) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtENBanD.Text = ErrCell(6)
            End If


            'If k <> 0 Then          'エラーがあったら
            '    ErrNum = 6
            '    Stopflg = True
            '    Call ErrorCheck()
            '    Exit Sub
            'End If


            'For n = a To g
            '    If n <> 0 Then

            '    End If

            'Next

            
        Next
        
        If j <> 0 Then          'エラーがあったら
            'MsgBox("以下の箱番は数値以外の入力があります。")
            ErrNum = 2
            If Sakuzuflg = True Then
                Stopflg = True
            End If
            Call ErrorCheck()

        End If

        'If Stopflg = False Then     'DBへ保存するとき

        '    '数値のみ入力が通る行のエラーチェック(数値になっているか)
        '    For i = 0 To frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1
        '        If IsNumeric(frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanNoRow).Cells(i).Value) = False Then   '箱番
        '            ErrCell(j) = "(" & i & "," & pc_BanNoRow & ")"
        '            j = j + 1


        '            'MsgBox(i + 1 & "列目の「盤No.」に数値以外の文字が含まれています。")


        '        End If
        '        If IsNumeric(frm配列基礎仕様.gridHairetuKiso.Rows(pc_DoorOpnRow).Cells(i).Value) = False Then '扉解放角度
        '            ErrCell(j) = "(" & i & "," & pc_DoorOpnRow & ")"
        '            j = j + 1

        '            'MsgBox(i + 1 & "列目の「扉解放角度」に数値以外の文字が含まれています。")


        '        End If
        '        If IsNumeric(frm配列基礎仕様.gridHairetuKiso.Rows(pc_JyuryoRow).Cells(i).Value) = False Then  '盤概略質量
        '            ErrCell(j) = "(" & i & "," & pc_JyuryoRow & ")"
        '            j = j + 1

        '            'MsgBox(i + 1 & "列目の「盤概略質量」に数値以外の文字が含まれています。")


        '        End If

        '    Next
        '    If IsNumeric(Bunkatu) = False Then  '最大分割位置
        '        'MsgBox("最大分割位置に数値以外の文字が含まれています。")

        '        ErrCell(j) = "最大分割位置"
        '        j = j + 1
        '    End If

        'Else                        '作図するとき
        '    i = 0
        '    '数値のみ入力が通る行のエラーチェック(数値になっているか)
        '    For i = 0 To frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1
        '        If IsNumeric(frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanNoRow).Cells(i).Value) = False Then   '箱番
        '            ErrCell(j) = "(" & i & "," & pc_BanNoRow & ")"
        '            j = j + 1

        '            'MsgBox(i + 1 & "列目の「盤No.」に数値以外の文字が含まれています。")


        '        End If
        '        If IsNumeric(frm配列基礎仕様.gridHairetuKiso.Rows(pc_DoorOpnRow).Cells(i).Value) = False Then '扉解放角度
        '            ErrCell(j) = "(" & i & "," & pc_BanNoRow & ")"
        '            j = j + 1

        '            'MsgBox(i + 1 & "列目の「扉解放角度」に数値以外の文字が含まれています。")


        '        End If
        '        If IsNumeric(frm配列基礎仕様.gridHairetuKiso.Rows(pc_JyuryoRow).Cells(i).Value) = False Then  '盤概略質量
        '            ErrCell(j) = "(" & i & "," & pc_BanNoRow & ")"
        '            j = j + 1

        '            'MsgBox(i + 1 & "列目の「盤概略質量」に数値以外の文字が含まれています。")


        '        End If
        '        If IsNumeric(Bunkatu) = False Then  '最大分割位置
        '            ErrCell(j) = "最大分割位置入力欄"
        '            j = j + 1

        '            'MsgBox("最大分割位置に数値以外の文字が含まれています。")


        '        End If


        '    Next


        'End If
        'If j <> 0 Then          'エラーがあったら
        '    '↓とりあえずは問題があることだけを表示
        '    'For l = 0 To j - 1  'メッセージで出力するために、問題があるセルを列挙
        '    '    If l = 0 Or l Mod 10 = 0 Then   '行のはじめ
        '    '        ErrCellList = ErrCellList & ErrCell(l)
        '    '    Else
        '    '        ErrCellList = ErrCellList & "," & ErrCell(l)
        '    '    End If
        '    '    If l <> 0 And l Mod 9 = 0 Then             '10こごとに改行
        '    '        ErrCellList = ErrCellList & vbCrLf
        '    '    End If
        '    'Next
        '    ErrNum = 2
        '    If Sakuzuflg = True Then
        '        Stopflg = True
        '    End If
        '    Call ErrorCheck()
        'End If

    End Sub

    Public Sub Mesure0Chk()
        '寸法が0になっていないかのチェック
        '(箱幅、高さ、奥行)
        '(基礎図表は現在は見ない(配列のみのパターンも考慮した処理だが変更の可能性あり))
        'エラー番号:3

        Dim a As Integer, b As Integer, c As Integer
        Dim i As Integer, j As Integer
        a = 0
        b = 0
        c = 0
        i = 0
        j = 0       'エラーカウンタ

        For i = 0 To UBound(P_sBanDat, 1)
            If P_sBanDat(i, pc_BanWRow) = "0" Then   '幅
                a = a + 1
                j = j + 1
                If a = 1 Then
                    ErrCell(7) = i + 1
                    My.Forms.frmErrorList.lblBanW0 = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblBanW0.Name = "lblBanW0"
                    My.Forms.frmErrorList.lblBanW0.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblBanW0.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblBanW0.Text = "箱幅が0の箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblBanW0)
                    My.Forms.frmErrorList.txtBanW0 = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtBanW0.Name = "txtBanW0"
                    My.Forms.frmErrorList.txtBanW0.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtBanW0.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtBanW0.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtBanW0)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(7) = ErrCell(7) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtBanW0.Text = ErrCell(7)
            End If
            If P_sBanDat(i, pc_BanHRow) = "0" Then  '高さ

                b = b + 1
                j = j + 1
                If b = 1 Then
                    ErrCell(8) = i + 1
                    My.Forms.frmErrorList.lblBanH0 = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblBanH0.Name = "lblBanH0"
                    My.Forms.frmErrorList.lblBanH0.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblBanH0.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblBanH0.Text = "箱の高さが0の箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblBanH0)
                    My.Forms.frmErrorList.txtBanH0 = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtBanH0.Name = "txtBanH0"
                    My.Forms.frmErrorList.txtBanH0.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtBanH0.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtBanH0.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtBanH0)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(8) = ErrCell(8) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtBanH0.Text = ErrCell(8)
            End If
            If P_sBanDat(i, pc_BanDRow) = "0" Then  '奥行
                c = c + 1
                j = j + 1
                If c = 1 Then
                    ErrCell(9) = i + 1
                    My.Forms.frmErrorList.lblBanD0 = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblBanD0.Name = "lblBanD0"
                    My.Forms.frmErrorList.lblBanD0.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblBanD0.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblBanD0.Text = "箱の奥行が0の箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblBanD0)
                    My.Forms.frmErrorList.txtBanD0 = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtBanD0.Name = "txtBanD0"
                    My.Forms.frmErrorList.txtBanD0.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtBanD0.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtBanD0.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtBanD0)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(9) = ErrCell(9) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtBanH0.Text = ErrCell(9)


            End If
            
        Next

        If j <> 0 Then          'エラーがあったら
            ErrNum = 3
            If Sakuzuflg = True Then
                Stopflg = True
            End If
            Call ErrorCheck()
        End If

    End Sub

    Public Sub HokyoSizeChk()
        '補強枠が箱をはみださないかのチェック
        'エラー番号:4

        Dim a As Integer, b As Integer, c As Integer
        Dim i As Integer, j As Integer
        a = 0
        b = 0
        c = 0
        i = 0
        j = 0       'エラーカウンタ

        For i = 0 To UBound(P_sBanDat, 1)
            If P_sBanDat(i, pc_HokyoKataRow2) <> "無" Then               '補強枠が選択されている場合
                'A寸法/2 + X寸法(箱センター線からのずれ)の絶対値 と 箱幅/2 との比較
                If Val(P_sBanDat(i, pc_HokyoARow2)) / 2 + System.Math.Abs(Val(P_sBanDat(i, pc_HokyoXRow2))) > P_sBanDat(i, pc_BanWRow) / 2 Then

                    a = a + 1
                    j = j + 1
                    If a = 1 Then
                        ErrCell(10) = i + 1
                        My.Forms.frmErrorList.lblHokyoWOvr = New System.Windows.Forms.Label()
                        My.Forms.frmErrorList.lblHokyoWOvr.Name = "lblHokyoWOvr"
                        My.Forms.frmErrorList.lblHokyoWOvr.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.lblHokyoWOvr.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                        My.Forms.frmErrorList.lblHokyoWOvr.Text = "補強枠が箱幅より長い箱"
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblHokyoWOvr)
                        My.Forms.frmErrorList.txtHokyoWOvr = New System.Windows.Forms.TextBox()
                        My.Forms.frmErrorList.txtHokyoWOvr.Name = "txtHokyoWOvr"
                        My.Forms.frmErrorList.txtHokyoWOvr.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.txtHokyoWOvr.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                        My.Forms.frmErrorList.txtHokyoWOvr.ReadOnly = True
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtHokyoWOvr)
                        lblCnt = lblCnt + 1
                    Else
                        ErrCell(10) = ErrCell(10) & "," & (i + 1)
                    End If
                    My.Forms.frmErrorList.txtHokyoWOvr.Text = ErrCell(10)
                End If
                If Val(P_sBanDat(i, pc_HokyoBRow2)) / 2 > Val(P_sBanDat(i, pc_HokyoYRow2)) Then
                    'B/2 > Y : 下にはみ出るパターン
                    b = b + 1
                    j = j + 1
                    If b = 1 Then
                        ErrCell(11) = i + 1
                        My.Forms.frmErrorList.lblHokyoUOvr = New System.Windows.Forms.Label()
                        My.Forms.frmErrorList.lblHokyoUOvr.Name = "lblHokyoUOvr"
                        My.Forms.frmErrorList.lblHokyoUOvr.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.lblHokyoUOvr.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                        My.Forms.frmErrorList.lblHokyoUOvr.Text = "補強枠が箱の正面側にはみ出る箱"
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblHokyoUOvr)
                        My.Forms.frmErrorList.txtHokyoUOvr = New System.Windows.Forms.TextBox()
                        My.Forms.frmErrorList.txtHokyoUOvr.Name = "txtHokyoUOvr"
                        My.Forms.frmErrorList.txtHokyoUOvr.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.txtHokyoUOvr.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                        My.Forms.frmErrorList.txtHokyoUOvr.ReadOnly = True
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtHokyoUOvr)
                        lblCnt = lblCnt + 1
                    Else
                        ErrCell(11) = ErrCell(11) & "," & (i + 1)
                    End If
                    My.Forms.frmErrorList.txtHokyoUOvr.Text = ErrCell(11)
                End If

                'B/2 <= Y 'and Y + B / 2 > Y寸法

                If Val(P_sBanDat(i, pc_HokyoBRow2)) / 2 + Val(P_sBanDat(i, pc_HokyoYRow2)) > Val(P_sBanDat(i, pc_BanDRow)) Then
                    c = c + 1
                    j = j + 1
                    If c = 1 Then
                        ErrCell(12) = i + 1
                        My.Forms.frmErrorList.lblHokyoTOvr = New System.Windows.Forms.Label()
                        My.Forms.frmErrorList.lblHokyoTOvr.Name = "lblHokyoTOvr"
                        My.Forms.frmErrorList.lblHokyoTOvr.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.lblHokyoTOvr.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                        My.Forms.frmErrorList.lblHokyoTOvr.Text = "補強枠が箱の背面側にはみ出る箱"
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblHokyoTOvr)
                        My.Forms.frmErrorList.txtHokyoTOvr = New System.Windows.Forms.TextBox()
                        My.Forms.frmErrorList.txtHokyoTOvr.Name = "txtHokyoTOvr"
                        My.Forms.frmErrorList.txtHokyoTOvr.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.txtHokyoTOvr.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                        My.Forms.frmErrorList.txtHokyoTOvr.ReadOnly = True
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtHokyoTOvr)
                        lblCnt = lblCnt + 1
                    Else
                        ErrCell(12) = ErrCell(12) & "," & (i + 1)
                    End If
                    My.Forms.frmErrorList.txtHokyoTOvr.Text = ErrCell(12)

                End If

            End If
        Next

        'エラーが１つでもあった場合
        If j <> 0 Then
            ErrNum = 4
            Call ErrorCheck()
        End If


    End Sub

    Public Sub HikiSizeChk()
        '引込穴が枠からはみ出ないか確認
        'エラー番号:5

        Dim a As Integer, b As Integer, c As Integer, d As Integer
        Dim i As Integer, j As Integer, k As Integer
        a = 0
        b = 0
        c = 0
        d = 0
        i = 0
        j = 0
        ErrCell(14) = ""
        For i = 0 To UBound(P_sBanDat, 1)
            'A寸法/2 + X寸法(箱センター線からのずれ)の絶対値 と 箱幅/2 との比較
            If Val(P_sBanDat(i, pc_HokyoARow2)) / 2 + System.Math.Abs(Val(P_sBanDat(i, pc_HokyoXRow2))) > P_sBanDat(i, pc_BanWRow) / 2 Then

                a = a + 1
                j = j + 1
                If a = 1 Then
                    ErrCell(13) = i + 1
                    My.Forms.frmErrorList.lblHokyoWOvr = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblHokyoWOvr.Name = "lblHokyoWOvr"
                    My.Forms.frmErrorList.lblHokyoWOvr.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblHokyoWOvr.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblHokyoWOvr.Text = "引込穴が箱幅より長い箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblHokyoWOvr)
                    My.Forms.frmErrorList.txtHokyoWOvr = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtHokyoWOvr.Name = "txtHokyoWOvr"
                    My.Forms.frmErrorList.txtHokyoWOvr.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtHokyoWOvr.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtHokyoWOvr.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtHokyoWOvr)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(13) = ErrCell(13) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtHokyoWOvr.Text = ErrCell(13)
            End If

            For k = 0 To 3

                If Val(P_sBanDat(i, pc_Hiki1Row2 + 2 + 5 * k)) / 2 > Val(P_sBanDat(i, pc_Hiki1Row2 + 4 + 5 * k)) Then
                    'B/2 > Y : 下にはみ出るパターン
                    b = b + 1
                    j = j + 1
                    If b = 1 Then
                        ErrCell(14) = (i + 1) & "(引込穴" & (k + 1) & ")"
                        My.Forms.frmErrorList.lblHikiUOvr = New System.Windows.Forms.Label()
                        My.Forms.frmErrorList.lblHikiUOvr.Name = "lblHikiUOvr"
                        My.Forms.frmErrorList.lblHikiUOvr.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.lblHikiUOvr.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                        My.Forms.frmErrorList.lblHikiUOvr.Text = "引込穴が箱の正面側にはみ出る箱"
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblHikiUOvr)
                        My.Forms.frmErrorList.txtHikiUOvr = New System.Windows.Forms.TextBox()
                        My.Forms.frmErrorList.txtHikiUOvr.Name = "txtHikiUOvr"
                        My.Forms.frmErrorList.txtHikiUOvr.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.txtHikiUOvr.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                        My.Forms.frmErrorList.txtHikiUOvr.ReadOnly = True
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtHikiUOvr)
                        lblCnt = lblCnt + 1
                    Else
                        ErrCell(14) = ErrCell(14) & "," & (i + 1) & "(引込穴" & (k + 1) & ")"
                    End If
                    My.Forms.frmErrorList.txtHikiUOvr.Text = ErrCell(14)
                End If

                'B/2 <= Y 'and Y + B / 2 > Y寸法

                If Val(P_sBanDat(i, pc_Hiki1Row2 + 2 + 5 * k)) / 2 + Val(P_sBanDat(i, pc_Hiki1Row2 + 4 + 5 * k)) > Val(P_sBanDat(i, pc_BanDRow)) Then
                    c = c + 1
                    j = j + 1
                    If c = 1 Then
                        ErrCell(15) = (i + 1) & "(引込穴" & (k + 1) & ")"
                        My.Forms.frmErrorList.lblHikiTOvr = New System.Windows.Forms.Label()
                        My.Forms.frmErrorList.lblHikiTOvr.Name = "lblHikiTOvr"
                        My.Forms.frmErrorList.lblHikiTOvr.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.lblHikiTOvr.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                        My.Forms.frmErrorList.lblHikiTOvr.Text = "引込穴が箱の背面側にはみ出る箱"
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblHikiTOvr)
                        My.Forms.frmErrorList.txtHikiTOvr = New System.Windows.Forms.TextBox()
                        My.Forms.frmErrorList.txtHikiTOvr.Name = "txtHokyoTOvr"
                        My.Forms.frmErrorList.txtHikiTOvr.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.txtHikiTOvr.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                        My.Forms.frmErrorList.txtHikiTOvr.ReadOnly = True
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtHikiTOvr)
                        lblCnt = lblCnt + 1
                    Else
                        ErrCell(15) = ErrCell(15) & "," & (i + 1) & "(引込穴" & (k + 1) & ")"
                    End If

                    My.Forms.frmErrorList.txtHikiTOvr.Text = ErrCell(15)

                End If
            Next


        Next

        If j <> 0 Then
            ErrNum = 5
            Call ErrorCheck()
        End If

    End Sub


    Public Sub DoorSelectChk()
        '扉の型の組み合わせ(扉形状)エラー確認
        'エラー番号:6

        Dim a As Integer
        Dim i As Integer, j As Integer
        a = 0
        i = 0
        j = 0

        For i = 0 To UBound(P_sBanDat, 1)
            If fCreDoorTyp(P_sBanDat(i, pc_FDoorRow), P_sBanDat(i, pc_RDoorRow)) = "" Then
                a = a + 1
                j = j + 1
                If a = 1 Then
                    ErrCell(16) = i + 1
                    My.Forms.frmErrorList.lblEDoorPtn = New System.Windows.Forms.Label()
                    My.Forms.frmErrorList.lblEDoorPtn.Name = "lblEDoorPtn"
                    My.Forms.frmErrorList.lblEDoorPtn.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.lblEDoorPtn.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                    My.Forms.frmErrorList.lblEDoorPtn.Text = "扉形状及び化粧板タイプが正しくない箱"
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEDoorPtn)
                    My.Forms.frmErrorList.txtEDoorPtn = New System.Windows.Forms.TextBox()
                    My.Forms.frmErrorList.txtEDoorPtn.Name = "txtEDoorPtn"
                    My.Forms.frmErrorList.txtEDoorPtn.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                    My.Forms.frmErrorList.txtEDoorPtn.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                    My.Forms.frmErrorList.txtEDoorPtn.ReadOnly = True
                    My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEDoorPtn)
                    lblCnt = lblCnt + 1
                Else
                    ErrCell(16) = ErrCell(16) & "," & (i + 1)
                End If
                My.Forms.frmErrorList.txtEDoorPtn.Text = ErrCell(16)
            End If
        Next
        If frm配列基礎仕様.cmbKeshoTyp.SelectedItem = "無" Then
            a = a + 1
            If a = 1 Then
                ErrCell(16) = "側面化粧板"
                My.Forms.frmErrorList.lblEDoorPtn = New System.Windows.Forms.Label()
                My.Forms.frmErrorList.lblEDoorPtn.Name = "lblEDoorPtn"
                My.Forms.frmErrorList.lblEDoorPtn.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                My.Forms.frmErrorList.lblEDoorPtn.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                My.Forms.frmErrorList.lblEDoorPtn.Text = "扉形状及び側面化粧板が正しくない箱"
                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEDoorPtn)
                My.Forms.frmErrorList.txtEDoorPtn = New System.Windows.Forms.TextBox()
                My.Forms.frmErrorList.txtEDoorPtn.Name = "txtEDoorPtn"
                My.Forms.frmErrorList.txtEDoorPtn.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                My.Forms.frmErrorList.txtEDoorPtn.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                My.Forms.frmErrorList.txtEDoorPtn.ReadOnly = True
                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEDoorPtn)
                lblCnt = lblCnt + 1
            Else
                ErrCell(16) = ErrCell(16) & ",側面化粧板"
            End If
            My.Forms.frmErrorList.txtEDoorPtn.Text = ErrCell(16)


        End If
        
        If j <> 0 Then
            ErrNum = 6
            Call ErrorCheck()
        End If

    End Sub


    '数値で入力されているか
    Public Sub DataErrChk()

        Dim i As Integer, j As Integer, k As Integer
        
        i = 0
        j = 0

        If IsNumeric(FntSunpo) = False Then
            j = j + 1
            If j = 1 Then
                Call DataErrChk_Hyouji("機器引出所要寸法(前)")
            Else
                ErrCell(17) = ErrCell(17) & ",機器引出所要寸法(前)"
            End If
            My.Forms.frmErrorList.txtEZentai.Text = ErrCell(17)
        End If
        If IsNumeric(BckSunpo) = False Then
            j = j + 1
            If j = 1 Then
                Call DataErrChk_Hyouji("機器引出所要寸法(後)")
            Else
                ErrCell(17) = ErrCell(17) & ",機器引出所要寸法(後)"
            End If
            My.Forms.frmErrorList.txtEZentai.Text = ErrCell(17)
        End If
        If IsNumeric(BaseH) = False Then
            j = j + 1
            If j = 1 Then
                Call DataErrChk_Hyouji("基礎ベース突出寸法")
            Else
                ErrCell(17) = ErrCell(17) & ",基礎ベース突出寸法"
            End If
            My.Forms.frmErrorList.txtEZentai.Text = ErrCell(17)
        End If
        If IsNumeric(Bunkatu) = False Then
            j = j + 1
            If j = 1 Then
                Call DataErrChk_Hyouji("最大分割位置")
            Else
                ErrCell(17) = ErrCell(17) & ",最大分割位置"
            End If
            My.Forms.frmErrorList.txtEZentai.Text = ErrCell(17)
        End If

        If j <> 0 Then
            ErrNum = 7
            Call ErrorCheck()
        End If

        
    End Sub

    
    Public Sub DataErrChk_Hyouji(ByVal Data As String)

        ErrCell(17) = Data
        My.Forms.frmErrorList.lblEZentai = New System.Windows.Forms.Label()
        My.Forms.frmErrorList.lblEZentai.Name = "lblEZentai"
        My.Forms.frmErrorList.lblEZentai.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
        My.Forms.frmErrorList.lblEZentai.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
        My.Forms.frmErrorList.lblEZentai.Text = "DBのデータ型と合わない箇所(NUMBER型)"
        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEZentai)
        My.Forms.frmErrorList.txtEZentai = New System.Windows.Forms.TextBox()
        My.Forms.frmErrorList.txtEZentai.Name = "txtEZentai"
        My.Forms.frmErrorList.txtEZentai.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
        My.Forms.frmErrorList.txtEZentai.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
        My.Forms.frmErrorList.txtEZentai.ReadOnly = True
        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEZentai)
        lblCnt = lblCnt + 1

    End Sub

    Public Sub KisoErrorChk()
        Dim a As Integer, b As Integer, c As Integer
        Dim i As Integer, k As Integer
        a = 0
        b = 0
        c = 0
        
        i = 0
        k = 0

        For i = 0 To UBound(P_sBanDat, 1)
            If P_sBanDat(i, pc_HokyoKataRow2) <> "無" Then               '補強枠が選択されている場合
                Select Case P_sBanDat(i, pc_HokyoKataRow2)
                    Case "Ⅱ字型"
                        Call HokyoErrChk(i, "A")
                    Case "一字型"
                        Call HokyoErrChk(i, "Y")
                    Case "二字型"
                        Call HokyoErrChk(i, "B")
                        Call HokyoErrChk(i, "Y")
                    Case "Ｔ字型"
                        Call HokyoErrChk(i, "Y")
                    Case "逆Ｔ字型"
                        Call HokyoErrChk(i, "Y")
                    Case "Π字型"
                        Call HokyoErrChk(i, "A")
                        Call HokyoErrChk(i, "Y")
                    Case "逆Π字型"
                        Call HokyoErrChk(i, "A")
                        Call HokyoErrChk(i, "Y")
                    Case "井型"
                        Call HokyoErrChk(i, "A")
                        Call HokyoErrChk(i, "B")
                        Call HokyoErrChk(i, "Y")
                End Select

                For k = 0 To 3
                    If P_sBanDat(i, pc_Hiki1Row2 + 5 * k) <> "無" Then
                        If Val(P_sBanDat(i, pc_Hiki1Row2 + 1 + 5 * k)) <= 0 Then

                            a = a + 1
                            If a = 1 Then
                                ErrCell(21) = (i + 1) & "(引込穴" & (k + 1) & ")"
                                My.Forms.frmErrorList.lblEHikiA = New System.Windows.Forms.Label()
                                My.Forms.frmErrorList.lblEHikiA.Name = "lblEHikiA"
                                My.Forms.frmErrorList.lblEHikiA.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                                My.Forms.frmErrorList.lblEHikiA.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                                My.Forms.frmErrorList.lblEHikiA.Text = "引込穴のA寸法がが0以下の箱"
                                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEHikiA)
                                My.Forms.frmErrorList.txtEHikiA = New System.Windows.Forms.TextBox()
                                My.Forms.frmErrorList.txtEHikiA.Name = "txtEHikiA"
                                My.Forms.frmErrorList.txtEHikiA.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                                My.Forms.frmErrorList.txtEHikiA.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                                My.Forms.frmErrorList.txtEHikiA.ReadOnly = True
                                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEHikiA)
                                lblCnt = lblCnt + 1
                            Else
                                ErrCell(21) = ErrCell(21) & "," & (i + 1) & "(引込穴" & (k + 1) & ")"
                            End If
                            My.Forms.frmErrorList.txtEHikiA.Text = ErrCell(21)
                        End If

                        If Val(P_sBanDat(i, pc_Hiki1Row2 + 2 + 5 * k)) <= 0 Then
                            b = b + 1
                            If b = 1 Then
                                ErrCell(22) = (i + 1) & "(引込穴" & (k + 1) & ")"
                                My.Forms.frmErrorList.lblEHikiB = New System.Windows.Forms.Label()
                                My.Forms.frmErrorList.lblEHikiB.Name = "lblEHikiB"
                                My.Forms.frmErrorList.lblEHikiB.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                                My.Forms.frmErrorList.lblEHikiB.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                                My.Forms.frmErrorList.lblEHikiB.Text = "引込穴のB寸法がが0以下の箱"
                                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEHikiB)
                                My.Forms.frmErrorList.txtEHikiB = New System.Windows.Forms.TextBox()
                                My.Forms.frmErrorList.txtEHikiB.Name = "txtEHikiB"
                                My.Forms.frmErrorList.txtEHikiB.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                                My.Forms.frmErrorList.txtEHikiB.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                                My.Forms.frmErrorList.txtEHikiB.ReadOnly = True
                                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEHikiB)
                                lblCnt = lblCnt + 1
                            Else
                                ErrCell(22) = ErrCell(22) & "," & (i + 1) & "(引込穴" & (k + 1) & ")"
                            End If
                            My.Forms.frmErrorList.txtEHikiB.Text = ErrCell(22)

                        End If
                        If Val(P_sBanDat(i, pc_Hiki1Row2 + 4 + 5 * k)) <= 0 Then
                            c = c + 1
                            If c = 1 Then
                                ErrCell(23) = (i + 1) & "(引込穴" & (k + 1) & ")"
                                My.Forms.frmErrorList.lblEHikiY = New System.Windows.Forms.Label()
                                My.Forms.frmErrorList.lblEHikiY.Name = "lblEHikiY"
                                My.Forms.frmErrorList.lblEHikiY.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                                My.Forms.frmErrorList.lblEHikiY.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                                My.Forms.frmErrorList.lblEHikiY.Text = "引込穴のY寸法がが0以下の箱"
                                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEHikiY)
                                My.Forms.frmErrorList.txtEHikiY = New System.Windows.Forms.TextBox()
                                My.Forms.frmErrorList.txtEHikiY.Name = "txtEHikiY"
                                My.Forms.frmErrorList.txtEHikiY.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                                My.Forms.frmErrorList.txtEHikiY.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                                My.Forms.frmErrorList.txtEHikiY.ReadOnly = True
                                My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEHikiY)
                                lblCnt = lblCnt + 1
                            Else
                                ErrCell(23) = ErrCell(23) & "," & (i + 1) & "(引込穴" & (k + 1) & ")"
                            End If
                            My.Forms.frmErrorList.txtEHikiY.Text = ErrCell(23)
                        End If
                    End If
                    

                Next



            End If


        Next

        If ACnt <> 0 Then
            ErrNum = 8
            Call ErrorCheck()
        End If
        If BCnt <> 0 Then
            ErrNum = 9
            Call ErrorCheck()
        End If
        If YCnt <> 0 Then
            ErrNum = 10
            Call ErrorCheck()
        End If

        If a <> 0 Then
            ErrNum = 11
            Call ErrorCheck()
        End If
        If b <> 0 Then
            ErrNum = 12
            Call ErrorCheck()
        End If
        If c <> 0 Then
            ErrNum = 13
            Call ErrorCheck()
        End If


    End Sub


    Public Sub HokyoErrChk(ByVal Hako As Integer, ByVal Sunpo As String)
        '補強枠の寸法エラーチェック
        '必要な寸法(X寸法を除く)が0になっていないか
        'Hako → 何番目の箱か              ex)1
        'Sunpo → A寸法かB寸法かY寸法      ex)"A"

        Select Case Sunpo
            Case "A"
                If IsNumeric(P_sBanDat(Hako, pc_HokyoARow2)) = True Then
                    If P_sBanDat(Hako, pc_HokyoARow2) <= 0 Then
                        ACnt = ACnt + 1
                        If ACnt = 1 Then
                            ErrCell(18) = Hako + 1
                            My.Forms.frmErrorList.lblEHokyoA = New System.Windows.Forms.Label()
                            My.Forms.frmErrorList.lblEHokyoA.Name = "lblEZentai"
                            My.Forms.frmErrorList.lblEHokyoA.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                            My.Forms.frmErrorList.lblEHokyoA.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                            My.Forms.frmErrorList.lblEHokyoA.Text = "補強枠のA寸法が0以下の箱"
                            My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEHokyoA)
                            My.Forms.frmErrorList.txtEHokyoA = New System.Windows.Forms.TextBox()
                            My.Forms.frmErrorList.txtEHokyoA.Name = "txtEHokyoA"
                            My.Forms.frmErrorList.txtEHokyoA.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                            My.Forms.frmErrorList.txtEHokyoA.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                            My.Forms.frmErrorList.txtEHokyoA.ReadOnly = True
                            My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEHokyoA)
                            lblCnt = lblCnt + 1
                        Else
                            ErrCell(18) = ErrCell(18) & "," & Hako + 1
                        End If
                        My.Forms.frmErrorList.txtEHokyoA.Text = ErrCell(18)
                    End If
                End If
                


            Case "B"
                'If IsNumeric(P_sBanDat(Hako, pc_HokyoBRow2)) = True Then
                If Val(P_sBanDat(Hako, pc_HokyoBRow2)) <= 0 Then
                    BCnt = BCnt + 1
                    If BCnt = 1 Then
                        ErrCell(19) = Hako + 1
                        My.Forms.frmErrorList.lblEHokyoB = New System.Windows.Forms.Label()
                        My.Forms.frmErrorList.lblEHokyoB.Name = "lblEHokyoB"
                        My.Forms.frmErrorList.lblEHokyoB.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.lblEHokyoB.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                        My.Forms.frmErrorList.lblEHokyoB.Text = "補強枠のB寸法が0以下の箱"
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEHokyoB)
                        My.Forms.frmErrorList.txtEHokyoB = New System.Windows.Forms.TextBox()
                        My.Forms.frmErrorList.txtEHokyoB.Name = "txtEHokyoB"
                        My.Forms.frmErrorList.txtEHokyoB.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                        My.Forms.frmErrorList.txtEHokyoB.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                        My.Forms.frmErrorList.txtEHokyoB.ReadOnly = True
                        My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEHokyoB)
                        lblCnt = lblCnt + 1
                    Else
                        ErrCell(19) = ErrCell(19) & "," & Hako + 1
                    End If
                    My.Forms.frmErrorList.txtEHokyoB.Text = ErrCell(19)
                End If
                'Else

                'End If

            Case "Y"
                If IsNumeric(P_sBanDat(Hako, pc_HokyoYRow2)) = True Then
                    If P_sBanDat(Hako, pc_HokyoYRow2) <= 0 Then
                        YCnt = YCnt + 1
                        If YCnt = 1 Then
                            ErrCell(20) = Hako + 1
                            My.Forms.frmErrorList.lblEHokyoY = New System.Windows.Forms.Label()
                            My.Forms.frmErrorList.lblEHokyoY.Name = "lblEHokyoY"
                            My.Forms.frmErrorList.lblEHokyoY.Location = New Point(lblitiX, lblitiY + (NextY * lblCnt))
                            My.Forms.frmErrorList.lblEHokyoY.Size = New System.Drawing.Size(lblSizeX, lblSizeY)
                            My.Forms.frmErrorList.lblEHokyoY.Text = "補強枠のY寸法が0以下の箱"
                            My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.lblEHokyoY)
                            My.Forms.frmErrorList.txtEHokyoY = New System.Windows.Forms.TextBox()
                            My.Forms.frmErrorList.txtEHokyoY.Name = "txtEHokyoY"
                            My.Forms.frmErrorList.txtEHokyoY.Location = New Point(txtitiX, txtitiY + (NextY * lblCnt))
                            My.Forms.frmErrorList.txtEHokyoY.Size = New System.Drawing.Size(txtSizeX, txtSizeY)
                            My.Forms.frmErrorList.txtEHokyoY.ReadOnly = True
                            My.Forms.frmErrorList.Controls.Add(My.Forms.frmErrorList.txtEHokyoY)
                            lblCnt = lblCnt + 1
                        Else
                            ErrCell(20) = ErrCell(20) & "," & Hako + 1
                        End If
                        My.Forms.frmErrorList.txtEHokyoY.Text = ErrCell(20)
                    End If
                End If

        End Select
        

    End Sub




    Public Sub ErrorCheck()
        '--------------------------------------------------
        'エラー判定プログラム
        '-------------------------------------------------
        '   0:エラーなし(初期値)
        '   1:箱番の重複によるエラー
        '   2:数値以外の文字列の入力によるエラー
        '   3:寸法値0によるエラー
        '   4:補強枠の大きさによるエラー
        '   5:引込穴の大きさによるエラー



        '   6:DBのカラム情報の型と一致しないことによるエラー


        '   3:DBのカラム情報の型と一致しないことによるエラー
        '   4:補強枠の大きさによるエラー
        '   5:引込穴の大きさによるエラー
        '
        '
        '


        MsgBox(ErrList(ErrNum), MsgBoxStyle.Exclamation, ErrTitle(ErrNum))
        'If ErrNum = 2 Then
        '    'MsgBox(ErrCellList)        'どのセルがエラーなのかを表示(今は報告はしない)
        '    MsgBox("盤No、扉解放角度、質量、各寸法と" & vbCrLf & "「最大分割位置」は数値のみの入力です。", MsgBoxStyle.Exclamation, "入力形式エラー")
        'End If

        If lblCnt = 1 Then          '最初に見つかったエラーのときのみ表示
            If Stopflg = False Then
                MsgBox("保存処理は続行しますが、作図前には修正してください。")
            Else
                If Sakuzuflg = True Then
                    MsgBox(EMsg, MsgBoxStyle.Exclamation, "作図中断")            '作図処理中メッセージ
                Else
                    MsgBox(EMsg2, MsgBoxStyle.Exclamation, "保存中断")           '保存処理中メッセージ
                End If

                'Exit Sub
            End If
        End If
        


    End Sub



End Module