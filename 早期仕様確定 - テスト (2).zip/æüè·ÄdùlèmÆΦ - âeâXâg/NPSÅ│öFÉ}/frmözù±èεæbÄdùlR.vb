﻿Public Class frm配列基礎仕様R

    '配列基礎仕様の表に似たものが表示される。
    '各列の下にある「追加」ボタンを押すことでその列(盤)を、現在編集中の配列基礎の表に追加できる。
    '追加するときに箱番を設定する。このとき箱番が重複しないようにする必要がある。

    Private Sub frm配列基礎仕様R_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim iRowNum As Integer, iRowNum2 As Integer ', iRowCnt As Integer      '行数/行ｶｳﾝﾀｰ
        Dim a As Integer, i As Integer, j As Integer
        Dim iColNum As Integer ', iColCnt As Integer      '列数/列ｶｳﾝﾀｰ
        Dim k As Integer, l As Integer
        Dim HakoNo2 As String



        '----------------------------------------------------------------
        'データベース移行後に使用
        KoubanName = frmRyuyo.txtRKouban.Text                    'DBとの接続時に用いる変数に流用元の工番を代入
        GunbanName = frmRyuyo.txtRGunban.Text                       'DBとの接続時に用いる変数に流用元の群番を代入
        LoadCnt = 0


        'データベースから情報をとってくる
        'stat = DB_配列基礎共通("select")

        If DB_配列基礎共通("select") = True Then
            stat = DB_配列図箱別("select")
            stat = DB_基礎図箱別("select")
        End If

        '--------------------------------------------------------------------


        'Dim Haba As Integer
        HakoNo2 = ""
        BReadflg = True
        Loadflg = True
        frmkisoflg = False
        Lflg = False
        Dim ColW As Integer
        'sScale2 = ""

        iRowNum = UBound(frm配列基礎仕様.pc_HeaderTxt) - 3              '行数取得
        gridHairetuKisoR.RowCount = iRowNum + 2  'ｸﾞﾘｯﾄﾞの行数定義

        Call HeaderTitle()          '表題表記


        Call sSetGrdDat()           'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(配列基礎仕様表)

        '列幅調整
        gridHairetuKisoR.AutoResizeRowHeadersWidth( _
            DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders)   'ﾍｯﾀﾞｰ
        gridHairetuKisoR.AutoResizeColumns()                            '内容

        If iColNum = 0 Then                             '表が1列しかない場合
            gridHairetuKisoR.Columns(0).Width = 100      '1列目の幅設定(表に値がない場合、ボタンにサイズを合わせるので列幅が狭いため)
        Else                                            '2列目以降、値の長さによってセルの幅が100を超えればその列幅を記憶
            For k = 1 To iColNum
                If gridHairetuKisoR.Columns(k - 1).Width <= gridHairetuKisoR.Columns(k).Width Then
                    ColW = gridHairetuKisoR.Columns(k).Width
                End If
            Next
            For l = 0 To iColNum
                gridHairetuKisoR.Columns(l).Width = ColW             '各列の幅を上で記憶した値に設定
            Next
        End If


        '---------------------------
        '列内でｿｰﾄできないようにする
        For Each c As DataGridViewColumn In gridHairetuKisoR.Columns
            c.SortMode = DataGridViewColumnSortMode.NotSortable
        Next c
        gridHairetuKisoR.AllowUserToAddRows = False                      '行が追加されないようにする


        'ReDim HakoNoData(iColNum)                               '要素数再定義


        'For i = 0 To iColNum
        '    If i + 1 < 10 Then
        '        HakoNo2 = "10" & (i + 1).ToString
        '    ElseIf i + 1 >= 10 Then
        '        HakoNo2 = "1" & (i + 1).ToString
        '    End If
        '    HakoNoData(i) = HakoNo2
        '    'cmbHakoNo.Items.Add(HakoNo2)
        'Next

        For a = 1 To iColNum + 1
            CubNo(a - 1) = a.ToString
        Next

        'iColNum = UBound(P_sBanDat, 1)
        'gridSyukairoR.ColumnCount = iColNum + 1          'ｸﾞﾘｯﾄﾞの列数定義
        'iRowNum2 = UBound(frm配列基礎仕様.pc_HeaderTxt2)
        'gridSyukairoR.RowCount = iRowNum2 - 1              'ｸﾞﾘｯﾄﾞの行数定義


        Call sSetGrdDat2()                              'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(基礎図表)

        '列内でｿｰﾄできないようにする
        For Each c2 As DataGridViewColumn In gridSyukairoR.Columns
            c2.SortMode = DataGridViewColumnSortMode.NotSortable
        Next c2
        gridSyukairoR.AllowUserToAddRows = False                      '行が追加されないようにする
        '列幅調整
        gridSyukairoR.AutoResizeRowHeadersWidth( _
            DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders)   'ﾍｯﾀﾞｰ
        'gridSyukairo.AutoResizeColumns()                             '内容


        'gridHairetuKisoの列の幅をユーザーが変更できないようにする
        gridHairetuKisoR.AllowUserToResizeColumns = False
        'gridHairetuKisoの行の高さをユーザーが変更できないようにする
        gridHairetuKisoR.AllowUserToResizeRows = False
        'gridSyukairoの列の幅をユーザーが変更できないようにする
        gridSyukairoR.AllowUserToResizeColumns = False
        'gridSyukairoの行の高さをユーザーが変更できないようにする
        gridSyukairoR.AllowUserToResizeRows = False

        gridHairetuKisoR.AutoGenerateColumns = False

        For i = 0 To gridHairetuKisoR.ColumnCount - 1
            For j = 0 To gridHairetuKisoR.RowCount - 1
                gridHairetuKisoR.Rows(j).Cells(i).ReadOnly = True
            Next

        Next
        gridSyukairoR.Enabled = False


        ReDim CopyBan(gridHairetuKisoR.ColumnCount - 1)

    End Sub

    '表題表記
    Private Sub HeaderTitle()
        Dim iRowNum As Integer, iRowCnt As Integer      '行数/行ｶｳﾝﾀｰ
        iRowNum = UBound(frm配列基礎仕様.pc_HeaderTxt) - 3              '行数取得

        For iRowCnt = 0 To iRowNum
            gridHairetuKisoR.Rows(iRowCnt).HeaderCell.Value = frm配列基礎仕様.pc_HeaderTxt(iRowCnt)

            Select Case iRowCnt
                Case pc_BanNoRow To pc_NP3Row, pc_KikakuNoRow, pc_BoxTypRow, pc_JyuryoRow
                    gridHairetuKisoR.Rows(iRowCnt).HeaderCell.Style.BackColor = Color.LightGreen      'セルカラー変更(NPS承認図で表として表示される項目)
                Case pc_NoHairetuRow, pc_NoKisoRow                                                  '納入外指定
                    'gridHairetuKiso.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
                    gridHairetuKisoR.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
                    'ﾁｪｯｸﾎﾞｯｸｽは中央寄せ
                    'gridHairetuKiso.Rows(iRowCnt).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                Case pc_BanWRow To pc_BanDRow                                                       '盤寸法行
                    gridHairetuKisoR.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LemonChiffon 'ｾﾙ色変更
                    gridHairetuKisoR.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.OrangeRed      'ﾍｯﾀﾞ文字色変更
                    gridHairetuKisoR.Rows(iRowCnt).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    'Case Is >= pc_KankiRow                                                              '換気箱行以降
                    '    gridHairetuKiso.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.OrangeRed      'ﾍｯﾀﾞ文字色変更

            End Select

        Next iRowCnt

    End Sub

    '
    'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(配列基礎仕様表)
    '
    Private Sub sSetGrdDat()
        Dim iRowNum As Integer, iColNum As Integer  '行/列数
        Dim iRowCnt As Integer, iColCnt As Integer  '行/列ｶｳﾝﾀｰ
        'Dim i As Integer

        '--------------
        '盤情報取得

        '--------------
        'iRowNum = UBound(P_sBanDat, 2) - 24                   '盤の並びは列ﾍｯﾀﾞｰに記述
        iRowNum = frm配列基礎仕様.pc_HeaderTxt.Length - 4
        iColNum = UBound(P_sBanDat, 1)
        gridHairetuKisoR.ColumnCount = iColNum + 1                   '列数定義
        '--------------
        'ReDim BanDataArray(iRowNum)
        'ReDim BanDataArray2(frm配列基礎仕様.pc_HeaderTxt2.Length - 3)


        'ﾃﾞｰﾀ表示
        For iRowCnt = 0 To iRowNum
            For iColCnt = 0 To iColNum
                If iRowCnt = 0 Then                                 '1行目の処理時
                    gridHairetuKisoR.Columns(iColCnt).HeaderText = iColCnt + 1
                    '列ﾍｯﾀﾞｰは中央寄せ
                    gridHairetuKisoR.Columns(iColCnt).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                End If
                If iRowCnt = iRowNum Then
                    gridHairetuKisoR.Rows(iRowCnt).Cells(iColCnt) = frm配列基礎仕様.fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                    gridHairetuKisoR.Rows(iRowCnt).Cells(iColCnt).Value = "追加"
                Else
                    gridHairetuKisoR.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, iRowCnt)
                End If


            Next iColCnt
        Next iRowCnt
    End Sub

    '
    'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(基礎図表)
    '
    Private Sub sSetGrdDat2()
        Dim iRowNum As Integer, iColNum As Integer  '行/列数
        Dim iRowCnt As Integer, iColCnt As Integer  '行/列ｶｳﾝﾀｰ
        Dim i As Integer


        iColNum = UBound(P_sBanDat, 1)
        gridSyukairoR.ColumnCount = iColNum + 1          'ｸﾞﾘｯﾄﾞの列数定義
        iRowNum = UBound(frm配列基礎仕様.pc_HeaderTxt2) - 2
        gridSyukairoR.RowCount = iRowNum + 1             'ｸﾞﾘｯﾄﾞの行数定義

        'ReDim P_sBanDatK(gridSyukairoR.ColumnCount - 1, gridSyukairoR.RowCount - 3)

        'For j = 0 To gridHairetuKiso.ColumnCount - 1
        '    gridHairetuKiso.Columns(j).Name = j
        'Next

        'データグリッドビュー設定
        For iRowCnt = 0 To iRowNum
            For iColCnt = 0 To iColNum
                If iRowCnt = 0 Then
                    gridSyukairoR.Columns(iColCnt).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter    '列ﾍｯﾀﾞｰは中央寄せ
                    gridSyukairoR.Columns(iColCnt).HeaderText = iColCnt + 1
                    gridSyukairoR.Columns(iColCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
                    gridSyukairoR.Columns(iColCnt).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
                    gridSyukairoR.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, 0)         '盤No.
                End If
                If iRowCnt = pc_HokyoKataRow Then
                    gridSyukairoR.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, iRowCnt + UBound(P_sBanDat, 2) - 27)   '初期値設定
                    For i = iRowCnt + 1 To iRowCnt + 4
                        gridSyukairoR.Rows(i).Cells(iColCnt).Value = P_sBanDat(iColCnt, pc_HokyoKataRow2 + (i - iRowCnt))
                    Next
                ElseIf iRowCnt = pc_LOkuyukiRow Or iRowCnt = pc_ROkuyukiRow Or iRowCnt = pc_BunkatuRow Then                    '奥行枠行なら
                    gridSyukairoR.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, iRowCnt + UBound(P_sBanDat, 2) - 27)   '初期値設定
                ElseIf iRowCnt = pc_Hiki1Row Or iRowCnt = pc_Hiki2Row Or iRowCnt = pc_Hiki3Row Or iRowCnt = pc_Hiki4Row Then    '引込穴の行なら
                    gridSyukairoR.Rows(iRowCnt).Cells(iColCnt).Value = _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 1) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 2) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 3) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 4)
                    gridSyukairoR.Rows(iRowCnt).Cells(iColCnt).ReadOnly = True
                End If

            Next iColCnt
            gridSyukairoR.Rows(iRowCnt).HeaderCell.Value = frm配列基礎仕様.pc_HeaderTxt2(iRowCnt)        'ヘッダーセル設定
            gridSyukairoR.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
            gridSyukairoR.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
        Next
        For l = 0 To iColNum
            gridSyukairoR.Columns(l).Width = 100                          '各列の幅設定
        Next
        gridSyukairoR.CurrentCell = Nothing
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Diversionflg = True
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        'Diversionflg = False
        Me.Close()
    End Sub

    Private Sub gridHairetuKisoR_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridHairetuKisoR.CellClick
        'If e.RowIndex = -1 Then
        '    If gridHairetuKisoR.CurrentCell.Style.ForeColor = Color.Cyan Then
        '        gridHairetuKisoR.CurrentCell.Style.ForeColor = Color.Empty
        '        CopyBan(e.ColumnIndex) = 0
        '    Else
        '        gridHairetuKisoR.CurrentCell.Style.ForeColor = Color.Cyan
        '        CopyBan(e.ColumnIndex) = 1
        '    End If
        'End If

        Dim i As Integer, j As Integer, k As Integer, l As Integer, n As Integer, o As Integer
        Dim Col As Integer
        Dim No As String
        Dim BanNoflg As Boolean
        BanNoflg = False
        No = ""

        If 0 <= e.ColumnIndex And 0 <= e.RowIndex Then
            If e.RowIndex = pc_BanDataCopy Then
                Do Until BanNoflg = True
                    No = InputBox("追加する箱の箱番を入力してください。(重複する番号は設定できません)", "箱番入力")
                    If No = "" Then
                        MsgBox("中止しました。")
                        Exit Sub
                    End If
                    If IsNumeric(No) = False Then
                        MsgBox("数値以外の文字が入力されました。")
                    Else
                        For i = 0 To frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1
                            If No = frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanNoRow).Cells(i).Value Then '入力された工番が編集中の表にすでにあるなら
                                MsgBox("既に存在している箱番です。")
                                Exit For
                            Else
                                If i = frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1 Then
                                    No = StrConv(No, VbStrConv.Narrow)      '入力された工番を半角へ変換
                                    BanNoflg = True
                                End If
                            End If
                        Next
                    End If
                Loop
                

                ReDim P_sBanDatR(0, UBound(P_sBanDat, 2))
                For j = 0 To UBound(P_sBanDat, 2)
                    P_sBanDatR(0, j) = P_sBanDat(e.ColumnIndex, j)
                Next
                frm配列基礎仕様.gridHairetuKiso.ColumnCount = frm配列基礎仕様.gridHairetuKiso.ColumnCount + 1   '列の追加
                frm配列基礎仕様.gridSyukairo.ColumnCount = frm配列基礎仕様.gridHairetuKiso.ColumnCount          '列の追加
                Col = frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1         '追加した列の番号

                frm配列基礎仕様.gridHairetuKiso.Columns(Col).HeaderText = Col + 1     '列ヘッダーの値
                frm配列基礎仕様.gridHairetuKiso.Columns(Col).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                For l = 0 To gridHairetuKisoR.RowCount - 1
                    Select Case l                                          '選択行番号
                        Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_BanDataDelete        'ｺﾝﾎﾞﾎﾞｯｸｽ行
                            If TypeOf frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) Is DataGridViewTextBoxCell Then   'ﾃｷｽﾄﾎﾞｯｸｽｾﾙの場合
                                Select Case l
                                    Case pc_KikakuNoRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelKikakuNo)  'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_BoxTypRow
                                        'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                        Call frm配列基礎仕様.sCrecmbBoxTyp(frm配列基礎仕様.gridHairetuKiso.Rows(pc_KikakuNoRow).Cells(Col).Value, l, Col)
                                    Case pc_HogoBoxRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelHogoBox)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_HogoItaRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelHogoIta)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_TeikakuVRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelTeikakuV)  'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_FreqRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelFreq)      'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_ComFreqRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelComFreq)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_ImplsRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelImpls)     'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_ClsRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelCls)       'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_NPRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelNP)        'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_KankyouRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelKankyou)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_NoHairetuRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelNoHairetu) 'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_NoKisoRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelNoKiso)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_KankiRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelKanki)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_FDoorRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelFDoor)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_RDoorRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelRDoor)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Case pc_FTotteRow
                                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelTotte)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                End Select
                            End If
                    End Select
                    If l = pc_BanNoRow Then
                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col).Value = No
                    Else
                        frm配列基礎仕様.gridHairetuKiso.Rows(l).Cells(Col).Value = P_sBanDatR(0, l)
                    End If

                Next
                frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanDataCopy).Cells(Col) = frm配列基礎仕様.fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanDataCopy).Cells(Col).Value = "保存"
                frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanDataPaste).Cells(Col) = frm配列基礎仕様.fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanDataPaste).Cells(Col).Value = "貼り付け"
                frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanDataDelete).Cells(Col) = frm配列基礎仕様.fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                frm配列基礎仕様.gridHairetuKiso.Rows(pc_BanDataDelete).Cells(Col).Value = "削除"

                '主回路ケーブル穴の表にも1列追加
                Dim iRowNum As Integer
                iRowNum = UBound(frm配列基礎仕様.pc_HeaderTxt2)
                For iRowCnt = 0 To iRowNum
                    'For iColCnt = 0 To iColNum
                    If iRowCnt = 0 Then
                        frm配列基礎仕様.gridSyukairo.Columns(Col).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter    '列ﾍｯﾀﾞｰは中央寄せ
                        frm配列基礎仕様.gridSyukairo.Columns(Col).HeaderText = Col + 1
                        frm配列基礎仕様.gridSyukairo.Columns(Col).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
                        frm配列基礎仕様.gridSyukairo.Columns(Col).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).Value = P_sBanDatR(0, 0)         '盤No.
                    End If
                    If iRowCnt = pc_HokyoKataRow Then
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelHokyoKata)         '2行目のセルをコンボボックスに
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).Value = P_sBanDatR(0, iRowCnt + UBound(P_sBanDat, 2) - 27)   '初期値設定
                        frm配列基礎仕様.gridSyukairo.CurrentCell = frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col)        'コンボボックスを選択
                        Lflg = True                                                                 '一時的にフラグをロード終了に(CellEndEditでこのフラグがTrueである必要があるため)
                        frm配列基礎仕様.gridSyukairo.BeginEdit(False)                                               'コンボボックスを編集状態に
                        frm配列基礎仕様.gridSyukairo.EndEdit()                                                      '編集終了(CellEndEditを誘発して型によって寸法がいらないセルをReadOnlyに)
                        Lflg = False                                                                'フラグを戻す
                        For k = iRowCnt + 1 To iRowCnt + 4
                            If frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).Value = "無" Then
                                frm配列基礎仕様.gridSyukairo.Rows(k).Cells(Col).Value = P_sBanDatR(0, pc_HokyoKataRow2 + (k - iRowCnt))
                                frm配列基礎仕様.gridSyukairo.Rows(k).Cells(Col).ReadOnly = True                     '最初の選択肢が"無"なので、
                                frm配列基礎仕様.gridSyukairo.Rows(k).Cells(Col).Style.BackColor = Color.Gray        '4つの寸法を記入できないようにする
                            Else
                                frm配列基礎仕様.gridSyukairo.Rows(k).Cells(Col).Value = P_sBanDatR(0, pc_HokyoKataRow2 + (k - iRowCnt))
                            End If
                        Next
                    ElseIf iRowCnt = pc_LOkuyukiRow Or iRowCnt = pc_ROkuyukiRow Or iRowCnt = pc_BunkatuRow Then          '奥行枠、分割点行なら
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col) = frm配列基礎仕様.fCreCmb(frm配列基礎仕様.p_SelUmu)               '5,6行目のセルをコンボボックスに
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).Value = P_sBanDatR(0, iRowCnt + UBound(P_sBanDat, 2) - 27)   '初期値設定
                    ElseIf iRowCnt = pc_Hiki1Row Or iRowCnt = pc_Hiki2Row Or iRowCnt = pc_Hiki3Row Or iRowCnt = pc_Hiki4Row Then          '引込穴の行なら
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).Value = _
                        P_sBanDat(0, 5 * (iRowCnt - 9) + pc_Hiki1Row2) & "," & _
                        P_sBanDat(0, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 1) & "," & _
                        P_sBanDat(0, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 2) & "," & _
                        P_sBanDat(0, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 3) & "," & _
                        P_sBanDat(0, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 4)
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).ReadOnly = True
                    ElseIf iRowCnt = iRowNum - 1 Then
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col) = frm配列基礎仕様.fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).Value = "保存"
                    ElseIf iRowCnt = iRowNum Then
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col) = frm配列基礎仕様.fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                        frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).Cells(Col).Value = "貼り付け"
                    End If

                    'Next iColCnt
                    frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).HeaderCell.Value = frm配列基礎仕様.pc_HeaderTxt2(iRowCnt)        'ヘッダーセル設定
                    frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
                    frm配列基礎仕様.gridSyukairo.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
                Next
                ReDim P_sBanDatK(frm配列基礎仕様.gridSyukairo.ColumnCount - 1, frm配列基礎仕様.gridSyukairo.RowCount - 3)
                For n = 0 To frm配列基礎仕様.gridSyukairo.ColumnCount - 1
                    For o = 0 To frm配列基礎仕様.gridSyukairo.RowCount - 3
                        P_sBanDatK(n, o) = frm配列基礎仕様.gridSyukairo.Rows(o).Cells(n).Value
                    Next
                Next


                '列内でｿｰﾄできないようにする
                For Each c As DataGridViewColumn In frm配列基礎仕様.gridHairetuKiso.Columns
                    c.SortMode = DataGridViewColumnSortMode.NotSortable
                Next c
                frm配列基礎仕様.gridHairetuKiso.AllowUserToAddRows = False                      '行が追加されないようにする
                'gridHairetuKisoの列の幅をユーザーが変更できないようにする
                frm配列基礎仕様.gridHairetuKiso.AllowUserToResizeColumns = False
                'gridHairetuKisoの行の高さをユーザーが変更できないようにする
                frm配列基礎仕様.gridHairetuKiso.AllowUserToResizeRows = False
                frm配列基礎仕様.gridHairetuKiso.AutoGenerateColumns = False

                '列内でｿｰﾄできないようにする
                For Each c2 As DataGridViewColumn In frm配列基礎仕様.gridSyukairo.Columns
                    c2.SortMode = DataGridViewColumnSortMode.NotSortable
                Next c2
                frm配列基礎仕様.gridSyukairo.AllowUserToAddRows = False                      '行が追加されないようにする
                '列幅調整
                frm配列基礎仕様.gridSyukairo.AutoResizeRowHeadersWidth( _
                    DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders)   'ﾍｯﾀﾞｰ
                'gridSyukairoの列の幅をユーザーが変更できないようにする
                frm配列基礎仕様.gridSyukairo.AllowUserToResizeColumns = False
                'gridSyukairoの行の高さをユーザーが変更できないようにする
                frm配列基礎仕様.gridSyukairo.AllowUserToResizeRows = False

                Lflg = True

                frm配列基礎仕様.gridHairetuKiso.FirstDisplayedScrollingColumnIndex = frm配列基礎仕様.gridHairetuKiso.Columns.Count - 1
            End If
        End If
    End Sub
End Class