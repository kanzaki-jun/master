﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBlkSK
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tvBlkSK = New System.Windows.Forms.TreeView()
        Me.btnTuika = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.picSK = New System.Windows.Forms.PictureBox()
        Me.lstSK = New System.Windows.Forms.ListBox()
        Me.lblPrev = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.picSK, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "ブロックスケルトン選定ツリー"
        '
        'tvBlkSK
        '
        Me.tvBlkSK.Location = New System.Drawing.Point(23, 27)
        Me.tvBlkSK.Name = "tvBlkSK"
        Me.tvBlkSK.Size = New System.Drawing.Size(343, 320)
        Me.tvBlkSK.TabIndex = 3
        '
        'btnTuika
        '
        Me.btnTuika.Location = New System.Drawing.Point(292, 361)
        Me.btnTuika.Name = "btnTuika"
        Me.btnTuika.Size = New System.Drawing.Size(75, 23)
        Me.btnTuika.TabIndex = 4
        Me.btnTuika.Text = "表に追加"
        Me.btnTuika.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(292, 396)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'picSK
        '
        Me.picSK.ImageLocation = ""
        Me.picSK.Location = New System.Drawing.Point(387, 29)
        Me.picSK.Name = "picSK"
        Me.picSK.Size = New System.Drawing.Size(130, 350)
        Me.picSK.TabIndex = 6
        Me.picSK.TabStop = False
        '
        'lstSK
        '
        Me.lstSK.FormattingEnabled = True
        Me.lstSK.HorizontalScrollbar = True
        Me.lstSK.ItemHeight = 12
        Me.lstSK.Location = New System.Drawing.Point(23, 353)
        Me.lstSK.Name = "lstSK"
        Me.lstSK.Size = New System.Drawing.Size(259, 52)
        Me.lstSK.TabIndex = 7
        '
        'lblPrev
        '
        Me.lblPrev.AutoSize = True
        Me.lblPrev.Location = New System.Drawing.Point(427, 394)
        Me.lblPrev.Name = "lblPrev"
        Me.lblPrev.Size = New System.Drawing.Size(49, 12)
        Me.lblPrev.TabIndex = 8
        Me.lblPrev.Text = "プレビュー"
        Me.lblPrev.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(89, 413)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(131, 12)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "フォルダ内のスケルトン一覧"
        '
        'frmBlkSK
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(587, 478)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblPrev)
        Me.Controls.Add(Me.lstSK)
        Me.Controls.Add(Me.picSK)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnTuika)
        Me.Controls.Add(Me.tvBlkSK)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmBlkSK"
        Me.Text = "ブロックスケルトン選択"
        CType(Me.picSK, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tvBlkSK As System.Windows.Forms.TreeView
    Friend WithEvents btnTuika As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents picSK As System.Windows.Forms.PictureBox
    Friend WithEvents lstSK As System.Windows.Forms.ListBox
    Friend WithEvents lblPrev As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
