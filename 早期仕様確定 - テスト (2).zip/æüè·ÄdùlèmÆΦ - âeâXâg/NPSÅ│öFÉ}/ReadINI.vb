﻿Module ReadINI


    Dim INIFil As String 'INIﾌｧｲﾙ名(ﾌﾙﾊﾟｽ)

    Private Declare Function GetPrivateProfileString _
      Lib "kernel32" _
      Alias "GetPrivateProfileStringA" _
      (ByVal strSection As String, _
       ByVal strKeyName As String, _
       ByVal strDefault As String, _
       ByVal strReturned As System.Text.StringBuilder, _
       ByVal lngSize As Integer, _
       ByVal strFileName As String) _
    As Integer

    '
    'INIﾌｧｲﾙからﾊﾟｽを読み込み変数をｾｯﾄする
    '
    Public Sub SetINI()
        INIFil = "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\setup\shounin_2016.ini"       'INIﾌｧｲﾙ名設定
        If FileIO.FileSystem.FileExists(INIFil) = False Then    'INIﾌｧｲﾙがない場合
            'ｴﾗｰﾒｯｾｰｼﾞ表示
            MsgBox("ローカルINIファイルがありません", vbOKOnly + vbEmpty, "システムファイルが足りません")
            End                                                 '処理中断
        End If
        Call ReadINI()                                          'INIﾌｧｲﾙからPathを取得
        'Call CpyINI()                                     'INIﾌｧｲﾙの日付をﾁｪｯｸし、古ければｻｰﾊﾞｰからｺﾋﾟｰ
        P_sBlkPath = Mid(P_sPrgPath, 1, InStrRev(P_sPrgPath, "\", Len(P_sPrgPath) - 1)) & "block\"   'ﾌﾞﾛｯｸ保存場所

        P_sWakPath = P_sBlkPath & "waku\"                       '枠関連ﾌｧｲﾙ保存場所

        '        Sea_Dir = P_DatPath & "\sokumi"                 'データ格納場所
        '        Sea_Dir_Hairetu = P_DatPath & "\hairetu"        'データ格納場所（配列図）
        '        Sea_Dir_Kiso = P_DatPath & "\kiso"              'データ格納場所（基礎図）
        '        Sea_Dir_Sokumen = P_DatPath & "\sokumen"        'データ格納場所（側面図）
        '        Sea_Dir_Banmen = P_DatPath & "\banmen"          'データ格納場所（盤面図）
        '        Sea_Dir_Heimen = P_DatPath & "\heimen"          'データ格納場所（平面図）
        '        Sea_Dir_Other = P_DatPath & "\other"            'データ格納場所（その他）
        '        Sea_Dir_Tmp = P_TmpPath                         '一時データ格納場所
        '        Sea_Dir_SokumenH = P_HjnPath & "\unit\sokumen"  '標準図ﾃﾞｰﾀ格納場所(側面図)
        '        Sea_Dir_BanmenH = P_HjnPath & "\unit\banmen"    '標準図ﾃﾞｰﾀ格納場所(盤面図)
        '        Sea_Dir_Rimen = P_RmnPath
        '        Sea_Dir_NC = P_NC_Path
        '        BlockPath1 = P_BlkPath & "\hairetu\"
        '        BlockPath3 = P_BlkPath & "\kiso\"
        '        BlockPath4 = P_BlkPath & "\sokumen\"
        '        BlockPath5 = P_BlkPath & "\wappen\"
        '        BlockPath6 = P_BlkPath & "\banmen\"
        '        Template2 = BlockPath2 & "基礎図.dwt"
        '        Template3 = BlockPath2 & "側面図.dwt"
        '        Template4 = BlockPath2 & "banmen.dwt"
        '        ProgPath1 = P_PrgPath & "\program" & P_sAcadVer & "\"   'ActiveX用
        '        sfld = P_BlkPath
        '        lfld = P_TmpPath
        '        wfld = P_BlkPath & "\wappen"
        '        kai_path = P_BlkPath & "\waku\"                 '枠、改訂ブロック保存場所
        '        hpath = P_DatPath & "\hairetu\"                 '配列図保存場所
        '        kpath = P_DatPath & "\kiso\"                    '基礎図保存場所
        '        spath = P_DatPath & "\sokumen\"                 '側面図保存場所
        '        bpath = P_DatPath & "\banmen\"                  '盤面図保存場所
        '        opath = P_DatPath & "\other\"                   'その他の図面保存場所
        '        wpath = P_BlkPath & "\waku\"                    '図面枠保存場所
        '        tpath = P_TmpPath & "\"                         '保存しない場合の図面保存場所
        '        tmppath = P_BlkPath & "\waku\"                  'テンポラリー図面保存場所
    End Sub
    '
    'INIﾌｧｲﾙからPathを取得
    '
    Private Sub ReadINI()
        'INIﾌｧｲﾙからPathを取得
        P_sPrgPath = INIGetSettingString("Path", "ini_sPrgPath", INIFil)            'ｼｽﾃﾑﾃﾞｰﾀ保存場所
        P_sDatFld = INIGetSettingString("Path", "ini_sDatFld", INIFil)              'ﾃﾞｰﾀ保存場所(共通)
        P_sSangyoFld = INIGetSettingString("Path", "ini_sSangyoFld", INIFil)        '産業ﾃﾞｰﾀ保存場所
        P_sMizuFld = INIGetSettingString("Path", "ini_sMizuFld", INIFil)            '水ﾃﾞｰﾀ保存場所(未定)
        P_sDentetuFld = INIGetSettingString("Path", "ini_sDentetuFld", INIFil)      '電鉄ﾃﾞｰﾀ保存場所(未定)
        P_sDenryokuFld = INIGetSettingString("Path", "ini_sDenryokuFld", INIFil)    '電力ﾃﾞｰﾀ保存場所
        P_sDouroFld = INIGetSettingString("Path", "ini_sDouroFld", INIFil)          '道路ﾃﾞｰﾀ保存場所
    End Sub

    ' 解説        : 指定されたINIファイルからString型の値を返します。
    ' パラメータ  : strSection -  参照するセクション
    '              strKeyName -  見つけるキーの名前
    '              strFile-  参照するINIファイルのパスと名前
    ' 戻り値      : String値
    ' 作成者      : Total VB SourceBook 6
    '
    Public Function INIGetSettingString(strSection As String, strKeyName As String, strFile As String) As String
        Dim strBuffer As New System.Text.StringBuilder
        Dim intSize As Integer
        Dim strDefault As String = "失敗"

        On Error GoTo PROC_ERR

        strBuffer.Capacity = 256
        intSize = GetPrivateProfileString(strSection, strKeyName, strDefault, strBuffer, 256, strFile)

        'INIGetSettingString = Left$(strBuffer, intSize)
        INIGetSettingString = strBuffer.ToString()
PROC_EXIT:
        Exit Function

PROC_ERR:
        MsgBox("Error: " & Err.Number & ". " & Err.Description, , _
          "INIGetSettingString")
        Resume PROC_EXIT

    End Function

    '
    'INIﾌｧｲﾙの日付をﾁｪｯｸし、古ければｻｰﾊﾞｰからｺﾋﾟｰ
    '
    Sub CpyINI()
        Dim CpyFil As String                                    'ｻｰﾊﾞｰのINIﾌｧｲﾙ名(Path付き)
        Dim CpyDay                                              'ｻｰﾊﾞｰのINIﾌｧｲﾙの日付
        Dim INIDay                                              'ﾁｪｯｸするINIﾌｧｲﾙの日付

        CpyFil = P_sPrgPath & "\shounin_2016.ini"               'ｺﾋﾟｰ元INIﾌｧｲﾙ名設定
        If FileIO.FileSystem.FileExists(CpyFil) = False Then    'ｺﾋﾟｰ元ﾌｧｲﾙが無い場合
            'ｴﾗｰﾒｯｾｰｼﾞ表示
            MsgBox("サーバーINIﾌｧｲﾙがありません", vbOKOnly + vbExclamation, "システムファイル不足")
            End                                                 '処理中断
        End If
        CpyDay = FileDateTime(CpyFil)                           'ｺﾋﾟｰ元ﾌｧｲﾙの日付取得
        INIDay = FileDateTime(INIFil)                           'INIﾌｧｲﾙの日付取得
        If INIDay < CpyDay Then                                 'INIﾌｧｲﾙの日付が古い場合
            FileCopy(CpyFil, INIFil)                            '新しいINIﾌｧｲﾙをｺﾋﾟｰ
            Call ReadINI()                                      '新しいINIﾌｧｲﾙからPathを取得
        End If
    End Sub

End Module
