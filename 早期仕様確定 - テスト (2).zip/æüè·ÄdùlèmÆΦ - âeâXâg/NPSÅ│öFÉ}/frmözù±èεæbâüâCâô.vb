﻿
Imports System
Imports System.IO
Imports System.Collections.Generic

Public Class frm配列基礎メイン

    Private Sub btnHairetuKiso_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHairetuKiso.Click
        If txtKbnNam.Text = "" Then
            MsgBox("工番が入力されていません。")
            Exit Sub
        End If
        If txtGbn.Text = "" Then
            MsgBox("群番が入力されていません。")
            Exit Sub
        End If
        P_sSegment = cmbSegment.SelectedItem
        frm配列基礎仕様.Show()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        frm共通仕様.Show()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.Close()
    End Sub



    '
    '配列図作成ﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdCreHairetu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreHairetu.Click
        Call sGetKbnGbnSeg()                                '工番･群番･ｾｸﾞﾒﾝﾄを取得する
        If P_sKbnNam = "" Or P_sGbn = "" Then                   '工番or群番が入力されていない場合
            'ｴﾗｰﾒｯｾｰｼﾞ表示
            MsgBox("工番/群番を正しく入力して下さい", vbOKOnly + vbExclamation, "工番/群番指定エラー")
            Exit Sub                                        '処理中断
        End If
        frmHairetu.Show()
        'Call sCreHairetu(P_sKbnNam, P_sGbn, P_sSegment)    '配列図作成
    End Sub
    '
    '基礎図作成ﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdCreKiso_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreKiso.Click
        Call sGetKbnGbnSeg()                                '工番･群番･ｾｸﾞﾒﾝﾄを取得する
        If P_sKbnNam = "" Or P_sGbn = "" Then                   '工番or群番が入力されていない場合
            'ｴﾗｰﾒｯｾｰｼﾞ表示
            MsgBox("工番/群番を正しく入力して下さい", vbOKOnly + vbExclamation, "工番/群番指定エラー")
            Exit Sub                                        '処理中断
        End If
        frmkiso.Show()
        'Call sCreHairetu(P_sKbnNam, P_sGbn, P_sSegment)    '配列図作成
    End Sub
    '
    '工番･群番･ｾｸﾞﾒﾝﾄを取得する
    '
    Private Sub sGetKbnGbnSeg()
        P_sKbn = txtKbnNam.Text               '工番取得
        P_sGbn = txtGbn.Text                  '群番取得
        P_sSegment = cmbSegment.SelectedItem  'ｾｸﾞﾒﾝﾄ取得
    End Sub
    '
    'ﾌｫｰﾑﾛｰﾄﾞ時
    '
    Private Sub frm配列基礎メイン_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Kbnflg = False
        Gbnflg = False
        Stopflg = False
        txtNam = ""
        cmbSegment.SelectedIndex = 0    'ｾｸﾞﾒﾝﾄはひとまず1つめを選択しておく(産業)

        '自分自身のAssemblyを取得
        Dim asm As System.Reflection.Assembly = _
            System.Reflection.Assembly.GetExecutingAssembly()
        'バージョンの取得
        Dim ver As System.Version = asm.GetName().Version
        'バージョンの表示
        Me.Text = "NPS承認図　ver." & " " & ver.ToString

        Call SetINI()                   'INIﾌｧｲﾙからﾊﾟｽを読み込み変数をｾｯﾄする
        'BaseH = 50          'とりあえず屋内扱い
        'Hako = {}           '補強板判断配列初期化
        Okugai = False      'とりあえず屋内扱い

        'フォルダ検索してツリーを構築()
        'タブるクリックでセル選択後このフォーム表示
        'サーバーのスケルトンツリー用フォルダつくり
        Dim i As Integer, j As Integer, k As Integer, l As Integer, m As Integer, n As Integer
        i = 0 : j = 0 : k = 0 : l = 0 : m = 0 : n = 0
        Dim name As String, name2 As String     'name1とname2を合わせて階層を表し、それをノードの名前にする
        Dim knd As String
        name = ""
        name2 = ""
        knd = ""
        Dim a As Integer, b As Integer, c As Integer, d As Integer
        a = 0
        b = 0
        c = 0
        d = 0
        Dim Treename As String
        Treename = ""
        Dim Treename2 As String '1階層上の名前
        Treename2 = ""
        Dim found As Integer
        Dim found2(20) As Integer
        Dim seachword As String = "\"
        Dim PosCnt() As Integer

        Dim files As IEnumerable(Of String) _
       = Directory.EnumerateDirectories( _
           SKPath, _
          "*", _
           SearchOption.AllDirectories)
        ' Dim files As IEnumerable(Of String) _
        '= Directory.EnumerateDirectories( _
        '    "\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\skeleton\SKTree", _
        '   "*")


        ReDim Folders(files.Count - 1)
        ReDim PosCnt(10)


        ''初期化
        'rootNode = Nothing
        'rootNode = New TreeNode
        rootNode.Text = "種類"
        'rootNode.Name = "種類"


        For Each file In files
            'Console.WriteLine(file)
            Folders(a) = file
            a = a + 1
        Next



        For b = 0 To files.Count - 1
            levelcnt = -9
            found = Folders(b).IndexOf(seachword)
            'パスからフォルダ名(ツリー名)取得
            '("\"を探して、一番右の"\"の後ろにある文字を取得)
            d = 0
            While 0 <= found
                '見つかった位置を表示する
                'Console.WriteLine(found)

                '次の検索開始位置
                Dim nextIndex As Integer = found + seachword.Length
                If nextIndex < Folders(b).Length Then
                    '次の位置を探す
                    Treename = Folders(b).Substring(found + seachword.Length)
                    found2(d) = found + seachword.Length
                    If d > 1 Then
                        Treename2 = Folders(b).Substring(found2(d - 1), found - found2(d - 1))
                    End If
                    d = d + 1
                    levelcnt = levelcnt + 1
                    found = Folders(b).IndexOf(seachword, nextIndex)
                Else
                    '最後まで検索したときは終わる
                    Exit While
                End If
            End While

            'memo.text参照&Next削除
            'ブロックスケルトンのツリー作成　開始
            If levelcnt = 0 Then
                knd = Treename
                rootNode.Nodes.Add(knd, Treename)

            ElseIf levelcnt = 1 Then
                name = knd & levelcnt
                For i = 0 To rootNode.Nodes.Count - 1
                    If rootNode.Nodes(i).Text = Treename2 Then
                        rootNode.Nodes(i).Nodes.Add(name, Treename)
                        Exit For
                    End If
                Next

            ElseIf levelcnt = 2 Then
                name2 = name & levelcnt
                For j = 0 To rootNode.Nodes(i).Nodes.Count - 1
                    If rootNode.Nodes(i).Nodes(j).Text = Treename2 Then
                        rootNode.Nodes(i).Nodes(j).Nodes.Add(name, Treename)
                        Exit For
                    End If
                Next
                'rootNode.Nodes(PosCnt(0)).Nodes(PosCnt(1)).Nodes.Add(name2, Treename)
            ElseIf levelcnt = 3 Then
                name2 = name & levelcnt
                For k = 0 To rootNode.Nodes(i).Nodes(j).Nodes.Count - 1
                    If rootNode.Nodes(i).Nodes(j).Nodes(k).Text = Treename2 Then
                        rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes.Add(name, Treename)
                        Exit For
                    End If
                Next
                'rootNode.Nodes(PosCnt(0)).Nodes(PosCnt(1)).Nodes(PosCnt(2)).Nodes.Add(name2, Treename)

            ElseIf levelcnt = 4 Then
                name2 = name & levelcnt
                For l = 0 To rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes.Count - 1
                    If rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Text = Treename2 Then
                        rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Nodes.Add(name, Treename)
                        Exit For
                    End If
                Next
                'rootNode.Nodes(PosCnt(0)).Nodes(PosCnt(1)).Nodes(PosCnt(2)).Nodes(PosCnt(3)).Nodes.Add(name2, Treename)

            ElseIf levelcnt = 5 Then
                name2 = name & levelcnt
                For m = 0 To rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Nodes.Count - 1
                    If rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Nodes(m).Text = Treename2 Then
                        rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Nodes(m).Nodes.Add(name, Treename)
                        Exit For
                    End If
                Next
                'rootNode.Nodes(PosCnt(0)).Nodes(PosCnt(1)).Nodes(PosCnt(2)).Nodes(PosCnt(3)).Nodes(PosCnt(4)).Nodes.Add(name2, Treename)
            ElseIf levelcnt = 6 Then
                name2 = name & levelcnt
                For n = 0 To rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Nodes(m).Nodes.Count - 1
                    If rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Nodes(m).Nodes(n).Text = Treename2 Then
                        rootNode.Nodes(i).Nodes(j).Nodes(k).Nodes(l).Nodes(m).Nodes(n).Nodes.Add(name, Treename)
                        Exit For
                    End If
                Next
                'rootNode.Nodes(PosCnt(0)).Nodes(PosCnt(1)).Nodes(PosCnt(2)).Nodes(PosCnt(3)).Nodes(PosCnt(4)).Nodes(PosCnt(5)).Nodes.Add(name2, Treename)

            End If

            'BefCnt = levelcnt

            'MsgBox(Treename & vbCrLf & Folders(b))

        Next

        'ルートノードをTreeViewコントロールに設定
        frmBlkSK.tvBlkSK.Nodes.Add(rootNode)
        'ブロックスケルトンのツリー作成　終了

    End Sub
    '
    '工番体系を揃える
    'sTmpKbn:入力された工番　(返値:体系を揃えた工番)
    '
    Public Function fCreKbn(ByVal sTmpKbn As String) As String
        Dim sTmpStr As String, sTmpStr2 As String                           '作業文字1,2
        Dim sA As String, sB As String, sC As String, sD As String          '工番文字列(分割)

        Dim iStrLen As Integer                                              '文字数

        fCreKbn = ""                                                        '返値の初期化
        '工番種取得(11X22-3333の11部分)
        sTmpKbn = sTmpKbn.Replace("-", "")                                  '工番の"-"を除いて取得

        sTmpStr = Mid(sTmpKbn, 1, 1)                                        '作業文字は1文字目
        If IsNumeric(sTmpStr) Then                                          '1文字目が数値の場合
            If IsNumeric(Mid(sTmpKbn, 2, 1)) Then                           '2文字目も数値の場合
                sA = Mid(sTmpKbn, 1, 2)                                     'sAは最初の2文字
                sTmpKbn = Mid(sTmpKbn, 3)                                   '3文字目以降を取得
            Else                                                            '2文字目は数値以外の場合
                sA = sTmpStr & sTmpStr                                      'sAは1文字目を2つ並べる
                sTmpKbn = Mid(sTmpKbn, 2)                                   '2文字目以降を取得
            End If
        Else                                                                '1文字目は数値以外の場合
            sA = "  "                                                       'sAは2文字分のｽﾍﾟｰｽ
        End If
        '部門取得(11X 223333のX 部分)
        sTmpStr = Mid(sTmpKbn, 1, 1)                                        '作業文字1取得(1文字目)
        If sTmpStr >= "A" And sTmpStr <= "Z" Then                           '1文字目がｱﾙﾌｧﾍﾞｯﾄの場合
            sTmpStr2 = Mid(sTmpKbn, 2, 1)                                   '作業文字2取得(2文字目)
            If (sTmpStr2 >= "A" And sTmpStr2 <= "Z") Or sTmpStr2 = " " Then '2文字目はｱﾙﾌｧﾍﾞｯﾄorｽﾍﾟｰｽの場合
                sB = sTmpStr & " "                                          'sBは1文字目+ｽﾍﾟｰｽ
                sTmpKbn = Mid(sTmpKbn, 3)                                   '3文字目以降を取得
            Else                                                            '2文字目はｱﾙﾌｧﾍﾞｯﾄorｽﾍﾟｰｽ以外の場合
                sB = sTmpStr & " "                                          'sBは1文字目+ｽﾍﾟｰｽ
                sTmpKbn = Mid(sTmpKbn, 2)                                   '2文字目以降を取得
            End If
        Else                                                                '1文字目がｱﾙﾌｧﾍﾞｯﾄ以外の場合
            Exit Function                                                   '処理中断
        End If
        '期取得(11X 223333の22部分)
        sC = Mid(sTmpKbn, 1, 2)                                             'sCは2文字取得
        TKi = sC                                                            'フォルダの有無を確認するための変数
        If IsNumeric(sC) = False Then Exit Function '取得した2文字が数値でない場合は処理中断
        sTmpKbn = Mid(sTmpKbn, 3)                                           '3文字目以降を取得
        'ｼﾘｰｽﾞ番号取得(11X 223333の3333部分)
        iStrLen = Len(sTmpKbn)                                              '残りの文字数取得
        If iStrLen > 0 And iStrLen < 5 Then                                 '4文字以内の場合
            If IsNumeric(sTmpKbn) = True Then                               '全て数値の場合
                sD = sTmpKbn.PadLeft(4, "0")                                'sDは4文字ｾﾞﾛ埋めで取得
            Else                                                            '数値でない場合
                Exit Function                                               '処理中断
            End If
        Else                                                                'それ以外の場合
            Exit Function                                                   '処理中
        End If
        fCreKbn = sA & sB & sC & sD                                         '体系を揃えた工番を返す
        P_sKbnNam = Trim(sA) & Trim(sB) & sC & "-" & sD                       '体系を揃えた"-"付きの工番設定
    End Function
    '
    '工番入力後
    '
    Private Sub txtKbnNam_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtKbnNam.LostFocus
        'Dim sTmpKbn As String                   '作業用工番

        sTmpKbn = Trim(txtKbnNam.Text)          'ﾌｫｰﾑから工番取得
        If sTmpKbn = "" Then Exit Sub '工番が入力されなかった場合は処理中断
        sTmpKbn = fCreKbn(sTmpKbn) '工番体系を揃えた工番取得
        If sTmpKbn = "" Then                    '工番が正しく取得できなかった場合は
            MsgBox("工番を正しく入力してください", vbOKOnly + vbExclamation, "不正な工番") 'ｴﾗｰﾒｯｾｰｼﾞ表示
            Kbnflg = False
        Else                                    '工番を正しく取得できた場合
            TKbn = txtKbnNam.Text
            txtKbnNam.Text = sTmpKbn            'ﾃｷｽﾄ内の工番を整形後の工番に書き換える
            txtNam = P_sKbnNam & TGbn & "kiso.txt"  '盤データのマスターファイル名
            txtkisoNam = P_sKbnNam & TGbn & "kisozu.txt"  '基礎図全体情報のマスターファイル名
            Kbnflg = True
        End If
    End Sub
    '
    '群番入力後
    '
    Private Sub txtGbn_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGbn.LostFocus
        Dim sTmpGbn As String                   '作業用群番

        sTmpGbn = Trim(txtGbn.Text)             '群番取得
        If sTmpGbn = "" Then Exit Sub '群番が入力されなかった場合は処理中断
        If Len(sTmpGbn) <> 2 Then               '群番が2文字以外の場合
            MsgBox("群番を正しく入力してください", vbOKOnly + vbExclamation, "不正な群番") 'ｴﾗｰﾒｯｾｰｼﾞ表示
            Gbnflg = False
        Else
            TGbn = txtGbn.Text
            txtNam = P_sKbnNam & TGbn & "kiso.txt"  '盤データのマスターファイル名
            txtkisoNam = P_sKbnNam & TGbn & "kisozu.txt"  '基礎図全体情報のマスターファイル名
            Gbnflg = True
        End If
    End Sub


    '「図面を開く」ボタンクリック時
    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen.Click
        Dim ofd As New OpenFileDialog()
        Dim filenam As String

        If Kbnflg = False Or Gbnflg = False Then
            MsgBox("工番または群番が正しく入力されていません。")
            Exit Sub
        End If

        ofd.FileName = ""
        P_sSegment = cmbSegment.SelectedItem
        ofd.InitialDirectory = "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\"        '最初に表示されるディレクトリを入力された工群番のフォルダを指定
        ofd.Filter = "図面ファイル(*.dwg)|*.dwg"            '[ファイルの種類]に表示される選択肢を指定する
        ofd.FilterIndex = 2
        ofd.Title = "開く図面を選択してください"     'タイトルの設定
        ofd.RestoreDirectory = True                 'ダイアログボックスを閉じる前に、現在のディレクトリを復元するようにする


        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            filenam = ofd.FileName
            'Call Flg_Set(filenam)
            On Error Resume Next                                            'ｴﾗｰがあっても次へ
            acadApp = GetObject(, "BricscadApp.AcadApplication")            'BricsCADｱﾌﾟﾘｹｰｼｮﾝ取得
            If Err.Number <> 0 Then                                         '取得できなければ
                Err.Clear()                                                 'ｴﾗｰｸﾘｱ
                acadApp = CreateObject("BricscadApp.AcadApplication")       'BricsCADｱﾌﾟﾘｹｰｼｮﾝ作成
            End If
            acadDoc = acadApp.Documents.Open(filenam)
            acadDoc = acadApp.ActiveDocument                                'ｶﾚﾝﾄ図面取得
            acadDoc.ObjectSnapMode = False                                  'ｵﾌﾞｼﾞｪｸﾄｽﾅｯﾌﾟを解除しておく
            acadUtl = acadDoc.Utility                                       'ﾕｰﾃｨﾘﾃｨｰ取得
            moSpace = acadDoc.ModelSpace                                    'ﾓﾃﾞﾙ空間取得
        End If

    End Sub

End Class
