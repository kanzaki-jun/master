﻿Public Class frmRyuyo

    Private Sub frmRyuyo_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Diversionflg = True
    End Sub

    Private Sub txtRKouban_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRKouban.LostFocus

        sTmpKbn = Trim(txtRKouban.Text)          'ﾌｫｰﾑから工番取得
        If sTmpKbn = "" Then Exit Sub '工番が入力されなかった場合は処理中断
        sTmpKbn = frm配列基礎メイン.fCreKbn(sTmpKbn) '工番体系を揃えた工番取得
        If sTmpKbn = "" Then                    '工番が正しく取得できなかった場合は
            MsgBox("工番を正しく入力してください", vbOKOnly + vbExclamation, "不正な工番") 'ｴﾗｰﾒｯｾｰｼﾞ表示
        Else                                    '工番を正しく取得できた場合
            TKbn = txtRKouban.Text              '流用元の工番
            txtRKouban.Text = sTmpKbn            'ﾃｷｽﾄ内の工番を整形後の工番に書き換える
        End If
    End Sub

    Private Sub txtGbn_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRGunban.LostFocus
        Dim sTmpGbn As String                   '作業用群番

        sTmpGbn = Trim(txtRGunban.Text)             '群番取得
        If sTmpGbn = "" Then Exit Sub '群番が入力されなかった場合は処理中断
        If Len(sTmpGbn) <> 2 Then               '群番が2文字以外の場合
            MsgBox("群番を正しく入力してください", vbOKOnly + vbExclamation, "不正な群番") 'ｴﾗｰﾒｯｾｰｼﾞ表示
        Else
            TGbn = txtRGunban.Text              '流用元の群番
        End If
    End Sub

    Private Sub btnChkDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChkDB.Click
        If txtRKouban.Text = "" Then            '工番が未入力なら
            MsgBox("工番が入力されていません。")
            Exit Sub
        End If
        If txtRGunban.Text = "" Then            '群番が未入力なら
            MsgBox("群番が入力されていません。")
            Exit Sub
        End If

        KoubanName = txtRKouban.Text                    'DBとの接続時に用いる変数に流用元の工番を代入
        GunbanName = txtRGunban.Text                       'DBとの接続時に用いる変数に流用元の群番を代入
        LoadCnt = 0
        If DB_配列基礎共通("check") = True Then               'DBにデータがあれば
            frm配列基礎仕様R.ShowDialog()                     '入力された工群番の配列基礎仕様表を別フォームで表示
        Else                                                'DBにデータがなければ
            MsgBox("データベースに工番データがありません")    'DBにデータがないことを表示
        End If

    End Sub


    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    'フォームが閉じられるとき
    Private Sub f_FormClosing(ByVal sender As System.Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        TKbn = frm配列基礎メイン.txtKbnNam.Text
        sTmpKbn = TKbn '工番体系を揃えた工番取得
        TGbn = frm配列基礎メイン.txtGbn.Text
        KoubanName = sTmpKbn
        GunbanName = TGbn
        Diversionflg = False
    End Sub

End Class