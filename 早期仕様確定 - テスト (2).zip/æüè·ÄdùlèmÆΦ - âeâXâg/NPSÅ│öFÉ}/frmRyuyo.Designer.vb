﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRyuyo
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtRKouban = New System.Windows.Forms.TextBox()
        Me.txtRGunban = New System.Windows.Forms.TextBox()
        Me.btnChkDB = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "流用工番"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "流用群番"
        '
        'txtRKouban
        '
        Me.txtRKouban.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRKouban.Location = New System.Drawing.Point(80, 52)
        Me.txtRKouban.Name = "txtRKouban"
        Me.txtRKouban.Size = New System.Drawing.Size(100, 19)
        Me.txtRKouban.TabIndex = 2
        '
        'txtRGunban
        '
        Me.txtRGunban.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRGunban.Location = New System.Drawing.Point(80, 77)
        Me.txtRGunban.Name = "txtRGunban"
        Me.txtRGunban.Size = New System.Drawing.Size(100, 19)
        Me.txtRGunban.TabIndex = 3
        '
        'btnChkDB
        '
        Me.btnChkDB.Location = New System.Drawing.Point(12, 112)
        Me.btnChkDB.Name = "btnChkDB"
        Me.btnChkDB.Size = New System.Drawing.Size(86, 23)
        Me.btnChkDB.TabIndex = 4
        Me.btnChkDB.Text = "データ表示"
        Me.btnChkDB.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(109, 112)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(85, 23)
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "終了"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(194, 24)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "流用元の工番、群番を入力し、" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "「データ表示」ボタンをクリックしてください。"
        '
        'frmRyuyo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(211, 144)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnChkDB)
        Me.Controls.Add(Me.txtRGunban)
        Me.Controls.Add(Me.txtRKouban)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmRyuyo"
        Me.Text = "盤データ流用"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtRKouban As System.Windows.Forms.TextBox
    Friend WithEvents txtRGunban As System.Windows.Forms.TextBox
    Friend WithEvents btnChkDB As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
