﻿Public Class frmkiso
    '図枠関係
    Private P_iTL_ZMaisu As Integer         '全ﾍﾟｰｼﾞ数

    '配列図関係
    Private PH_sPageBanNo(0, 0) As String  'ﾍﾟｰｼﾞ毎の盤No.
    Private P_dS_X As Double                '正面図のｽﾀｰﾄ座標(X座標)

    Private Const conH_Limit = 550          '最右表示位置(X座標)
    Private Const conDou10 = 72.0#          '配列図(正面図)と配列図(側面図)との間の距離
    'Private Const sScale = 20.0#        '配列図縮尺

    '扉側面図
    Private Const conZhyX2 = 82.0#          '基準点X
    Private Const conZhyY2 = 159.0#         '基準点Y
    '正面図(2ﾍﾟｰｼﾞ目以降用)
    Private Const conZhyX3 = 90.0#          '基準点X

    '
    'ｷｬﾝｾﾙﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()    'ﾌｫｰﾑを閉じる
    End Sub
    '
    'ﾌｫｰﾑﾛｰﾄﾞ時
    '
    Private Sub frmKiso_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim sZbn As String                                      '図番
        Dim iDatNum As Integer                                  'ﾃﾞｰﾀ数
        Dim iAllW As Integer                                    '全長
        Dim iDatCnt As Integer                                  'ﾃﾞｰﾀｶｳﾝﾀｰ
        Dim i As Integer, k As Integer, l As Integer, m As Integer, n As Integer, o As Integer, p As Integer
        Dim a As Integer, b As Integer, c As Integer
        Dim cmb As New DataGridViewComboBoxCell()           '規格番号ｺﾝﾎﾞﾎﾞｯｸｽ

        'Dim cmbDef As New DataGridViewComboBoxColumn
        Dim HakoLen As Integer
        Dim Delnum() As String

        BReadflg = True
        frmkisoflg = True
        HakoLen = 0
        p = 0
        a = 0
        b = 0
        c = 0
        'Limit_Bunkatu = 4000  '分割制限（長さ）の初期値
        Platingflg = False      'メッキ不使用

        Stopflg = False
        Sakuzuflg = True           'エラーチェック用フラグ:作図処理中
        Diversionflg = False
        nps = False

        lblCnt = 0

        ReDim ErrCell(100)

        Call ClearCom()

        'データベースから情報をとってくる
        'stat = DB_配列基礎共通("select")

        KoubanName = frm配列基礎メイン.txtKbnNam.Text
        GunbanName = frm配列基礎メイン.txtGbn.Text

        If DB_配列基礎共通("select") = True Then
            stat = DB_配列図箱別("select")
            stat = DB_基礎図箱別("select")
            ReDim P_sBanDat_cp(UBound(P_sBanDat, 1), UBound(P_sBanDat, 2))
            For k = 0 To UBound(P_sBanDat, 1)
                For l = 0 To UBound(P_sBanDat, 2)
                    P_sBanDat_cp(k, l) = P_sBanDat(k, l)                            '編集リセット用にコピーする
                Next
            Next
        Else
            MsgBox("盤データが設定されていません。" & vbCrLf & "処理を中止します。")
            BReadflg = False
            Me.Close()
            Exit Sub
        End If


        'エラーチェック
        Call BanNoErrChk()          '箱番の重複
        Call IsNumericErrChk()      '数値のみ入力するセルに数値以外の入力があるか
        Call Mesure0Chk()           '寸法値が0になっていないか
        Call HokyoSizeChk()
        Call HikiSizeChk()
        Call DoorSelectChk()
        Call DataErrChk()
        Call KisoErrorChk()
        If lblCnt <> 0 Then
            frmErrorList.Show()
            MsgBox("正しく作図できないので、各データを修正してから再作図してください。", , "作図中断")
            Me.Close()
            Exit Sub
        End If

        

        '---------------------------------------------------------------------------------------------------------------
        'Call MakeBanFile(frm配列基礎仕様.pc_HeaderTxt.Length - 4 + frm配列基礎仕様.pc_HeaderTxt2.Length - 4 + 4 * 4)
        'If BReadflg = False Then
        '    Me.Close()
        '    Exit Sub
        'End If
        'Call ReadKisoData()
        'Call ReadBanData()
        '------------------------------------------------------------------------------------------------------------------
        'Dim P_sBanDatcp(,) As String

        'If BReadflg = True Then
        lblKbn.Text = P_sKbnNam                                 '基礎図作成ﾌｫｰﾑに工番表示
        lblGbn.Text = P_sGbn                                    '基礎図作成ﾌｫｰﾑに群番表示
        sZbn = P_sKbn : Mid(sZbn, 4, 1) = "P"                   '工番に部門追加
        For i = 0 To 5
            Select Case i       '0は工番群番で入力して変えられる値ではないので無視
                Case 1
                    txtSetubi.Text = Meisho            '設備名称
                Case 2
                    txtSyubetu.Text = Syubetu           '製品種別
                Case 3
                    'txtZbn.Text = kisodata(i)               '図番
                    txtZbn.Text = Trim(Mid(sZbn, 1, 6) & "-" & Mid(sZbn, 7)) & "-BB" & Mid(P_sGbn, Len(P_sGbn), 1) & "01"
                Case 4
                    'cmbKumitate.SelectedText = kisodata(i)  '組立方法
                Case 5
                    'txtBunkatu.Text = kisodata(i)           '分割位置
            End Select
        Next
        'If txtSyubetu.Text = "" Then                            '製品種別が空文字列なら
        '    txtSyubetu.Text = fGetMaxV() & "高圧ＳＷＧ"   '(以前のテンプレート？を使用)
        'End If


        '基礎図作成ﾌｫｰﾑに図番表示
        'txtZbn.Text = Trim(Mid(sZbn, 1, 6) & "-" & Mid(sZbn, 7)) & "-BA" & Mid(P_sGbn, Len(P_sGbn), 1) & "01"
        lblSegment.Text = P_sSegment & "セグメント"              '基礎図作成ﾌｫｰﾑにｾｸﾞﾒﾝﾄ表示
        iDatNum = UBound(P_sBanDat, 1)                          'ﾃﾞｰﾀ数取得

        'ReDim Preserve SyukairoData(frm配列基礎仕様.pc_HeaderTxt2.Length - 1 + 4 * 4, iDatNum)
        ReDim KijunX(iDatNum)
        ReDim DrowBase(iDatNum)
        ReDim Delnum(iDatNum)
        ReDim DelNo(iDatNum)

        ReDim Preserve Bunkatuiti(iDatNum)
        For m = 0 To DelNo.Length - 1
            DelNo(m) = -1                                       '初期値が0だと1箱目のことかデータがないのか判断できないので
        Next

        Dim CubNo2(iDatNum) As String
        'ReDim CntOvr(iDatNum)
        iAllW = 0                                               '全長初期化
        k = 0
        l = 0

        '
        '↓(試験中)先に非表示の箱を省いておいて各パラメータ(幅、電圧等)配列に代入するようにしてみる
        'For iDatCnt = 0 To iDatNum - 1                             '全箱分
        '    CubNo(iDatCnt) = P_sBanDat(iDatCnt, pc_BanNoRow)
        '    If P_sBanDat(iDatCnt, pc_NoKisoRow) = "納入外（表示）" Or P_sBanDat(iDatCnt, pc_NoKisoRow) = "納入外（非表示）" Then
        '        If P_sBanDat(iDatCnt, pc_NoKisoRow) = "納入外（非表示）" Then
        '            DrowBase(iDatCnt) = False
        '            Delnum(k) = CubNo(iDatCnt)      '非表示の箱番号を記憶
        '            DelNo(k) = iDatCnt              '何番目の箱が非表示なのかを記憶
        '            k = k + 1
        '        Else
        '            BaseCubNo(l) = P_sBanDat(iDatCnt, pc_BanNoRow)
        '            l = l + 1
        '        End If
        '    End If
        'Next
        'l = 0
        'For k = 0 To iDatNum - 1
        '    If k = DelNo(l) Then
        '        For o = k To iDatNum
        '            For n = 0 To UBound(P_sBanDat, 2) - 1
        '                If o = iDatNum Then
        '                    P_sBanDat(o - l, n) = Nothing
        '                Else
        '                    P_sBanDat(o - l, n) = P_sBanDat_cp(o + 1, n)
        '                End If
        '            Next
        '        Next
        '        l += 1
        '    End If
        'Next
        '↑ここまで(計算ルーチン的に問題あるなら以前に戻す(上記のコードが下にコメントアウトしてある))
        '

        For iDatCnt = 0 To iDatNum                             '全箱分
            iAllW = iAllW + Val(P_sBanDat(iDatCnt, pc_BanWRow)) '全長計算

            'H_W(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanWRow))
            'H_H(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanHRow))
            'If P_sBanDat(iDatCnt, pc_RDoorRow) = "背板" Or P_sBanDat(iDatCnt, pc_RDoorRow) = "背板（中MCB）" Or P_sBanDat(iDatCnt, pc_RDoorRow) = "背板（中MCB）2" Then
            '    H_D(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanDRow)) - 50
            'Else
            '    H_D(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanDRow)) - 100
            'End If
            'H_Zetuen(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_ClsRow))
            'H_Kata1(iDatCnt) = ""
            'H_Kata2(iDatCnt) = ""
            'If P_sBanDat(iDatCnt, pc_BanDRow) = "JEM1265" Then
            '    H_Kata1(iDatCnt) = "JEM-1265"
            'ElseIf P_sBanDat(iDatCnt, pc_BanDRow) = "JEM1425" Then
            '    H_Kata2(iDatCnt) = "JEM-1425"
            'End If
            'H_DenAtu(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_TeikakuVRow))
            'H_Hogo1(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_HogoBoxRow))
            'H_Hogo2(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_HogoItaRow))
            'H_Hz(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_FreqRow))
            CubNo(iDatCnt) = P_sBanDat(iDatCnt, pc_BanNoRow)
            'CubNo2(iDatCnt) = P_sBanDat(iDatCnt, pc_BanNoRow)
            DrowBase(iDatCnt) = True
            If P_sBanDat(iDatCnt, pc_NoKisoRow) = "納入外（表示）" Or P_sBanDat(iDatCnt, pc_NoKisoRow) = "納入外（非表示）" Then
                If P_sBanDat(iDatCnt, pc_NoKisoRow) = "納入外（非表示）" Then
                    DrowBase(iDatCnt) = False
                    Delnum(k) = CubNo(iDatCnt)      '非表示の箱番号を記憶
                    DelNo(k) = iDatCnt              '何番目の箱が非表示なのかを記憶
                    k = k + 1
                Else
                    BaseCubNo(l) = P_sBanDat(iDatCnt, pc_BanNoRow)
                    'BaseBunkatu(l) = P_sBanDat(iDatCnt, pc_BanNoRow)
                    l = l + 1

                    RBox = CubNo(iDatCnt)       '右端の箱番更新
                End If
            Else
                RBox = CubNo(iDatCnt)           '右端の箱番更新
            End If
        Next iDatCnt


        'Do Until (CubNo(a) = "")            '将来の箱の最右端箱の箱番を取得
        '    'If a = 0 Then
        '    '    NoRBox = BaseCubNo(0)
        '    'Else
        '    '    If BaseCubNo(a - 1) < BaseCubNo(a) Then

        '    RBox = BaseCubNo(a)
        '    '    End If
        '    'End If
        '    a = a + 1
        'Loop


        Do Until (BaseBunkatu(b) = "")
            b = b + 1
        Loop
        If 1 < iDatNum And 0 < l Then                         '2箱以上あり、将来の箱がある場合
            If CubNo(0) < CubNo(1) Then             '箱番が昇順で並んでいるか、降順かを判断
                For p = 0 To iDatNum           '(箱数-1)回
                    If BaseBunkatu(b) < BaseCubNo(p) Then     '表示する納入外の箱で一番右端の箱番を探す
                        BaseBunkatu(b) = BaseCubNo(p)
                        BaseBunkatu(b + 1) = RBox
                    End If
                Next
            Else
                For p = 0 To iDatNum             '(箱数-1)回
                    If BaseBunkatu(b) > BaseCubNo(p) Then     '表示する納入外の箱で一番右端の箱番を探す
                        BaseBunkatu(b) = BaseCubNo(p)
                        BaseBunkatu(b + 1) = RBox
                    End If
                Next
            End If
        ElseIf l = 1 Then                           '1箱のみ、かつ将来の場合
            BaseBunkatu(a) = BaseCubNo(0)
        End If


        If BaseBunkatu(0) <> "" Then
            Do While (BaseBunkatu(c) <> "")
                c = c + 1
            Loop
        End If

        a = 0
        If Bunkatuiti(0) <> "" Then
            Do While (Bunkatuiti(a) <> "")
                BaseBunkatu(c + a) = Bunkatuiti(a)
                a = a + 1
            Loop
        End If
        If a <> 0 Then
            BaseBunkatu(c + a) = P_sBanDat(UBound(P_sBanDat, 1), pc_BanNoRow)
        End If
        a = 0
        c = 0
        For a = 0 To BanCnt.Length - 1
            If P_sBanDat(a, pc_BanNoRow) = Bunkatuiti(c) Then
                P_sBanDat(a, pc_BunkatuRow2) = "有"
                c = c + 1
            End If
        Next
        
        Call DelCubNo(Delnum)           '納入外の箱で表示しないものを箱版配列から削除
        l = 0
        For k = 0 To iDatNum
            If k = DelNo(l) Then        '納入外(非表示)の箱なら
                For o = k To iDatNum    '該当箱よりあと(表での右)の箱分ループ(k番目より前は詰める処理が終わっているので)
                    For n = 0 To UBound(P_sBanDat, 2) - 1   '
                        If o = iDatNum Then                 '最後の箱なら
                            P_sBanDat(o - l, n) = Nothing   '次の箱がないのでその列のデータを消す
                        Else
                            P_sBanDat(o - l, n) = P_sBanDat_cp(o + 1, n)    '1箱分詰める
                        End If
                    Next
                Next
                l += 1      '次の非表示の箱をセット(DelNo)
            End If
        Next
        For iDatCnt = 0 To iDatNum - l
            H_W(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanWRow))
            H_H(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanHRow))
            If P_sBanDat(iDatCnt, pc_RDoorRow) = "背板" Or P_sBanDat(iDatCnt, pc_RDoorRow) = "背板（中MCB）" Or P_sBanDat(iDatCnt, pc_RDoorRow) = "背板（中MCB）2" Then
                H_D(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanDRow)) - 50
            Else
                H_D(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_BanDRow)) - 100
            End If
            H_Zetuen(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_ClsRow))
            H_Kata1(iDatCnt) = ""
            H_Kata2(iDatCnt) = ""
            If P_sBanDat(iDatCnt, pc_BanDRow) = "JEM1265" Then
                H_Kata1(iDatCnt) = "JEM-1265"
            ElseIf P_sBanDat(iDatCnt, pc_BanDRow) = "JEM1425" Then
                H_Kata2(iDatCnt) = "JEM-1425"
            End If
            H_DenAtu(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_TeikakuVRow))
            H_Hogo1(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_HogoBoxRow))
            H_Hogo2(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_HogoItaRow))
            H_Hz(iDatCnt) = Val(P_sBanDat(iDatCnt, pc_FreqRow))
        Next


        'If k > 0 Then
        '    For iDatCnt = 0 To iDatNum
        '        For m = 0 To k
        '            If Delnum(m) <> Nothing And iDatCnt = Delnum(m) Then
        '                If iDatCnt = iDatNum Then
        '                    CubNo2(iDatCnt) = Nothing
        '                Else
        '                    CubNo2(iDatCnt) = CubNo2(iDatCnt + 1)
        '                End If
        '            End If
        '        Next
        '    Next
        'End If
        'For iDatCnt = 0 To iDatNum
        '    If CubNo2(iDatCnt) = CubNo2(iDatCnt) Then
        '        CubNo2(iDatCnt + 1) = CubNo2(iDatCnt + 2)
        '    End If
        'Next
        'CubNo = CubNo2

        lblAllHako.Text = "全" & CStr(iDatNum + 1) & "箱　" & CStr(iAllW) & "mm"   '箱数･全長表示
        txtPage.Text = "1" : txtAllPage.Text = "1"              'ﾍﾟｰｼﾞ数表示
        'txtSyubetu.Text = fGetMaxV() & "高圧スイッチギヤ"       '製品種別
        txtY.Text = Now.ToString("yy")                          '現在の年表示
        txtM.Text = CStr(Now.Month)                             '現在の月表示
        txtD.Text = CStr(Now.Day)                               '現在の日表示
        'txtsScale2.Text = "20"                                    '縮尺初期値表示

        FileClose(fileNumber)
        'End If


    End Sub

    Function fCreCmb2(ByVal sSelDat() As String) As DataGridViewComboBoxCell
        Dim iDatCnt As Integer                              'ﾃﾞｰﾀｶｳﾝﾀｰ    
        Dim cmb As New DataGridViewComboBoxCell()           '規格番号ｺﾝﾎﾞﾎﾞｯｸｽ

        For iDatCnt = 0 To UBound(sSelDat)                  '全選択肢
            cmb.Items.Add(sSelDat(iDatCnt))                 '選択肢追加
        Next iDatCnt

        Return cmb                                          'ｺﾝﾎﾞﾎﾞｯｸｽを返す
    End Function
    '
    '群番内の最大定格電圧を返す
    '
    Private Function fGetMaxV() As String
        Dim iDatNum As Integer                                  'ﾃﾞｰﾀ数
        Dim dMaxV As Double, iMaxVNo As Integer                 '最大定格電圧,最大定格電圧のﾃﾞｰﾀNo.
        Dim sTmpV As String, dTmpV As Double                    '定格電圧

        iDatNum = UBound(P_sBanDat, 1)                          'ﾃﾞｰﾀ数取得
        dMaxV = 0
        For iDatCnt = 0 To iDatNum                              '全箱分
            sTmpV = UCase(P_sBanDat(iDatCnt, pc_TeikakuVRow))   '定格電圧取得
            If sTmpV = "" Then                                  '定格電圧が入力されていない場合
                dTmpV = 0                                       '数値を取得しない
            ElseIf Mid(sTmpV, Len(sTmpV) - 1, 2) = "KV" Then    '単位がkVの場合
                sTmpV = Mid(sTmpV, 1, Len(sTmpV) - 2)           '単位より前を取得
                If IsNumeric(sTmpV) = True Then                 '単位より前が数値の場合
                    dTmpV = Val(sTmpV) * 1000                   '数値を1000倍する
                End If
            ElseIf Mid(sTmpV, Len(sTmpV), 1) = "V" Then         '単位がVの場合
                sTmpV = Mid(sTmpV, 1, Len(sTmpV) - 1)           '単位より前を取得
                If IsNumeric(sTmpV) = True Then                 '単位より前が数値の場合
                    dTmpV = Val(sTmpV)                          '数値を取得
                End If
            Else                                                '単位がkV,V以外
                dTmpV = 0                                       '数値を取得しない
            End If
            If dMaxV < dTmpV Then                               'これまでの最大定格電圧の場合
                dMaxV = dTmpV                                   '定格電圧を覚えておく
                iMaxVNo = iDatCnt                               'ﾃﾞｰﾀNo.を覚えておく
            End If
        Next iDatCnt
        If dMaxV = 0 Then                                       '定格電圧が取得できなかった場合
            fGetMaxV = ""                                       '""を返す
        Else                                                    '定格電圧が取得できた場合
            fGetMaxV = P_sBanDat(iMaxVNo, pc_TeikakuVRow)       '最大定格電圧を返す
        End If
    End Function

    'Private Sub cmbKumitate_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbKumitate.SelectedIndexChanged
    '    '組立方法で分割位置の決まりがあるので、選択された項目に合う分割位置(mm)を表示する
    '    '空文字が選ばれた場合は、最大である4000を表示

    '    'If cmbKumitate.SelectedItem = "組立式" Then
    '    'txtBunkatu.Text = 3500
    '    If cmbKumitate.SelectedItem = "組立式" Then
    '        txtBunkatu.Text = 3000
    '    ElseIf cmbKumitate.SelectedItem = "溶接式" Or cmbKumitate.SelectedItem = "組立出荷" Then
    '        txtBunkatu.Text = 2000
    '    Else
    '        txtBunkatu.Text = 4000
    '    End If
    'End Sub

    ''「保存」ボタンクリック時
    'Private Sub btnkisoSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnkisoSave.Click
    '    If txtBunkatu.Text = "" Or IsNumeric(txtBunkatu.Text) = False Then          '分割位置の入力がなかったり数字ではない場合
    '        MsgBox("分割位置を正しく入力してください。", MsgBoxStyle.Exclamation)
    '        MsgBox("保存できませんでした。", MsgBoxStyle.Critical)
    '        Exit Sub
    '    End If
    '    Syubetu = txtSyubetu.Text
    '    stat = DB_配列基礎共通("update2")     'frmkisoで入力された内容をDBへ(現在は製品種別のみ)(また、frmkisoが開かれているときにDBからデータが消えるということを想定していないのでデータ更新のみ)
    '    'Call KisozuDataSave()
    '    MsgBox("保存しました。")
    'End Sub

    'frmkisoで入力された情報を保存
    'Public Sub KisozuDataSave()

    '    Me.SuspendLayout()              'コンボボックスのテキスト部分を選択する処理を見せないようにするために画面描画を一時中断
    '    cmbKumitate.SelectAll()
    '    kisodata(0) = P_sKbnNam & TGbn          '工番群番
    '    kisodata(1) = txtSetubi.Text            '設備名称
    '    kisodata(2) = txtSyubetu.Text           '製品種別
    '    kisodata(3) = txtZbn.Text               '図番
    '    kisodata(4) = cmbKumitate.SelectedText  '選択肢以外の値にも対応するためにSelectedText使用
    '    kisodata(5) = txtBunkatu.Text           '分割位置
    '    cmbKumitate.SelectionLength = 0         'テキストの選択範囲を0(無し)に
    '    Me.ResumeLayout()                       '画面描画再開

    '    Call WriteKisoData()                    'データをマスターファイルに保存する処理

    'End Sub


    '
    '基礎図作成
    'P_sKbn:工番  P_sGbn:群番  P_sSegmentｾｸﾞﾒﾝﾄ
    '
    'Sub sCreHairetu(ByVal P_sKbn As String, ByVal P_sGbn As String, ByVal P_sSegment As String)
    'Dim iPageCnt As Integer 'ﾍﾟｰｼﾞｶｳﾝﾀｰ
    '
    '   Call sCalNeedPageH()    '必要なﾍﾟｰｼﾞ数計算
    '  For iPageCnt = 1 To P_iTL_ZMaisu    '作成ﾍﾟｰｼﾞ分
    '
    '
    '
    '   Next iPageCnt
    '
    '
    '
    'End Sub
    '

    '
    '作成開始ﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Dim sPath As String                                     '基礎図保存場所
        sPath = "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\"
        'Dim sFilNam2 As String                                   '基礎図ﾌｧｲﾙ名
        'Dim sScale2 As String                                    '縮尺
        Dim sDwtFilNam As String                                'ﾃﾝﾌﾟﾚｰﾄﾌｧｲﾙ名
        'Dim sWakDWGNam As String = "K_" & P_sKbnNam & P_sGbn & "P" & "*.dwg"
        'Dim Ans As Integer                                      'はい(6)orいいえ(7)
        'Dim kisoFiles As String() = System.IO.Directory.GetFiles(sPath, sWakDWGNam)
        'Dim i As Integer, j As Integer
        Dim Openflg As Boolean = False                          '既に図面を開いていたかフラグ(True:開いている)
        AncMFlg = False                                         'レベル2寸法線を通常通り(左から右へ)作図
        Wakuflg = False

        If cmbNpsK.SelectedItem = "NPS承認図" Then
            nps = True
        Else
            nps = False
        End If
        
        'Call KisozuDataSave()                   'データをマスターファイルに保存する処理(DBがきたことによりコメントアウト　　)

        sScale = cmbsScale.SelectedItem
        H_Cnt = 0
        Ovrlapflg = False
        Limit_Bunkatu = Val(frm配列基礎仕様.txtBunkatu.Text)

        '------------------------
        '入力ﾃﾞｰﾀ取得

        'hPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory)
        sDwtFilNam = P_sWakPath & "M_" & sScale & ".dwt"        'ﾃﾝﾌﾟﾚｰﾄﾌｧｲﾙ名作成
        'sDwtFilNam = NPath + "\早期仕様確定\test\M_" & sScale2.Text & ".dwt"    'ﾃﾝﾌﾟﾚｰﾄﾌｧｲﾙ名作成(テスト用)
        If FileIO.FileSystem.FileExists(sDwtFilNam) = False Then    '指定された縮尺用のﾃﾝﾌﾟﾚｰﾄが存在しない場合
            MsgBox("指定された縮尺の図面は作成できません", vbOKOnly + vbExclamation, "縮尺非対応") 'ｴﾗｰﾒｯｾｰｼﾞ表示
            Exit Sub                                            '処理中断
        End If


        '----------------------------------------------------------------------------------------------------

        TL_Date = String.Format("{0,2} 年{1,2} 月{2,2} 日", txtY.Text, txtM.Text, txtD.Text) '日付取得
        'sPage = "(" & txtPage.Text & "/" & txtAllPage.Text & ")"    'ﾍﾟｰｼﾞ取得

        '----------------------------------------------------------------以下テスト用に一時的にコメントアウト


        'sPath = fCreSavPath("基礎")                             '基礎図保存場所取得
        '保存場所が無い場合はﾌｫﾙﾀﾞを作成する()
        'If FileIO.FileSystem.DirectoryExists(sPath) = False Then FileIO.FileSystem.CreateDirectory(sPath)
        'sFilNam2 = sPath & sFilNam2 & ".dwg"                      '基礎図ﾌｧｲﾙ名作成


        '--------------------------------------------------------------------------------------ここまで

        'sPath = NPath + "\早期仕様確定\test\"


        'sPath = "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\"

        If FileIO.FileSystem.DirectoryExists(sPath) = False Then FileIO.FileSystem.CreateDirectory(sPath)


        'sFilNam2 = "K_" & P_sKbnNam & P_sGbn & "P" & txtPage.Text & "K" & "*" ' & ".dwg"
        sFilNam2 = TL_Zuban & "_R0"

        sFilNam2 = sPath & sFilNam2 & ".dwg"                      '基礎図ﾌｧｲﾙ名作成
        'Sea_Dir_Kiso = NPath + "\早期仕様確定\設計データ\"


        Sea_Dir_Kiso = "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\"

        'ページ数計算
        Call CalPage()

        'On Error Resume Next                                    'ｴﾗｰがあっても次へ
        'acadApp = GetObject(, "BricscadApp.AcadApplication")    'BricsCADｱﾌﾟﾘｹｰｼｮﾝ取得(ちゃんとした起動はこの後でするのでひらかれていないなら無視)
        'If Err.Number <> 0 Then
        '    '取得できなければ
        '    Err.Clear()
        'Else
        '    'For i = 1 To TL_ZMaisu
        '    For iDocCnt = 0 To acadApp.Documents.Count - 1
        '        For j = 0 To kisoFiles.Length - 1
        '            kisoFiles(j) = kisoFiles(j).Substring(sPath.Length)  'パス部分と拡張子部分を除く(型名のみになる)
        '            'If UCase(acadApp.Documents.Item(iDocCnt).Name) = kisoFiles(j) Then
        '            If acadApp.Documents.Item(iDocCnt).Name = kisoFiles(j) Then
        '                'ｴﾗｰﾒｯｾｰｼﾞ表示
        '                MsgBox("BricsCAD上で作成しようとしているファイルが既に開いています。" & vbCrLf & _
        '                "ファイル名：" & kisoFiles(j), vbOKOnly + vbExclamation, "重複ファイル発見")
        '                Ans = MsgBox("作図を始めるとUSERレイヤー以外は消えてしまいます。" & vbCrLf & "自動作図を開始してもよろしいですか？", _
        '                             MsgBoxStyle.YesNo, "上書き確認")
        '                If Ans <> 6 Then    '「はい」以外なら
        '                    acadApp.Visible = True
        '                    MsgBox("処理を終了します。")
        '                    Exit Sub
        '                End If
        '                Openflg = True
        '            End If
        '        Next
        '    Next
        '    'Next
        'End If


        If FileIO.FileSystem.FileExists(sFilNam2) = True And Openflg = False Then    '既に基礎図ﾌｧｲﾙが存在する場合
            '上書き確認の結果NGの場合
            If MsgBox("既にファイルが存在しています。" & vbCrLf & "上書きしてもよろしいですか？", _
                   vbYesNo + vbQuestion, "ファイル上書き確認") = MsgBoxResult.No Then
                MsgBox("処理を中断しました", vbOKOnly + vbInformation, "処理中断")   '処理中断ﾒｯｾｰｼﾞ表示
                Exit Sub                                        '処理中断
                'Else                                 elaser               '上書き確認の結果OKの場合
                '    'ﾌｧｲﾙを開く処理とかUSERﾚｲﾔｰ以外の消去とかする
                '    MsgBox("まだ上書き処理できていません", vbOKOnly + vbInformation, "処理中断")   '処理中断ﾒｯｾｰｼﾞ表示
                '    Exit Sub                                        '処理中断
            End If
        Else                                                    '新規にﾌｧｲﾙを作成する場合
            Call sOpnBcad(sDwtFilNam)                           'BricsCAD起動
            'Call sCreZwk()
            Call AcadMain_Kiso()
        End If

        Me.Close()
        FileClose(fileNumber)
        MsgBox("終わります", MsgBoxStyle.SystemModal)
        Stopflg = False
        acadApp.Visible = True
        acadDoc = Nothing
    End Sub


    '------------------------------------------------------------------------------------------------

    

    Public Sub KisoMain()
        '-----------------------------------------------
        '  基礎図メインプログラム
        '-----------------------------------------------
        'Dim KM_BlockObj As Object 'ブロックオブジェクト
        'Dim KM_Zks_Obj As Object '属性オブジェクト
        'Dim KM_Lin_Obj As Object '線分オブジェクト
        'Dim KM_Lay_Obj As Object 'レイヤーオブジェクト
        'Dim KM_TmpStr As String '文字列テンポラリー
        'Dim KM_TmpInt As Integer '整数テンポラリー
        'Dim KM_TmpDou As Double '実数テンポラリー
        'Dim KM_TmpVar As Object 'バリアントテンポラリー
        Dim i As Integer, a As Integer, c As Integer
        a = 0 : c = 0
        'Dim J As Integer
        'Dim Dummy2 As String
        Dim IFG_Cnt As Integer  '合符号用カウンター
        Dim Ans As String

        'Dim T_Kisozu As String '一時ファイル名
        'Dim dpos As Integer '「.」の位置
        'Dim sset As AcadSelectionSet
        'Dim Exist As String '戻り値用

        '配列初期化
        Call ClearKMHairetu()

        If BaseBunkatu(0) <> "" Then
            Do While (BaseBunkatu(c) = "")
                c = c + 1
            Loop
        End If

        a = 0
        If Bunkatuiti(0) <> "" Then
            Do While (Bunkatuiti(c) = "")
                BaseBunkatu(c + a) = Bunkatuiti(a)
                a = a + 1
            Loop
        End If
        'ページ数計算
        Call CalPage()

        Call KataLoad()                             '引込穴の既定の型のブロックを読み込む

        'IFG_Cnt = 1

        '複数ページ作成
        For i = 1 To Val(TL_ZMaisu)
            If i = 1 Then
                IFG_Cnt = 1
            Else
                IFG_Cnt = IFG_Cnt2
            End If
            PCnt = i                        '図番表記用

            ' ファイルを開く
            Ans = OpenAcadFile("基礎", i)
            If Ovrlapflg = True Then                            '作図するファイルと同名ファイルが開かれていたら
                'Exit Sub                                        '処理終了
            End If
            If Ans = "中止" Then Exit Sub

            'メッセージフォームの表示
            'frmContiMassage.Show()

            'アイコン変更(砂時計）
            'Screen.MousePointer = vbHourglass
            System.Windows.Forms.Cursor.Current = Cursors.WaitCursor

            ' OSNAPのオフ
            acadDoc.ObjectSnapMode = False

            'アクティブレイヤーの変更
            Call SetActiveLayer("自動作成")

            ' 図面枠の読込＆図題欄の作成
            If Ans = "継続（枠有り）" Then
                Call sCreZwk()
                'Call CreZudairan("基礎", i, sScale)
            End If

            acadDoc.SendCommand("'_zoom" & vbCrLf & "_e" & vbCr)                        '全体ズーム
            acadDoc.SendCommand("-dimstyle" & vbCrLf & vbCrLf & "基礎2" & vbCrLf)     '寸法スタイル変更
            'acadDoc.SendCommand("-dimstyle" & vbCrLf & vbCrLf & "14_STD2" & vbCrLf)
            'acadDoc.SendCommand("-style" & vbCrLf & "14_H2" & vbCrLf & "KELF1-K.shx" & vbCrLf & "31.36" & vbCrLf & "0.8" & vbCrLf & "0" & vbCrLf & "いいえ" & vbCrLf & "いいえ" & vbCrLf & "いいえ" & vbCrLf)

            If nps = False Then
                'A部詳細参照・B部詳細参照ﾌﾞﾛｯｸを挿入する位置(CUB.番号)を取得
                Call GetShosaiCub()
            End If
            

            ' ブロックの読込（Ｂ部詳細図）
            'If I = 1 Then
            '  insPnt(0) = SetScale(HconDou1, sScale)
            '  insPnt(1) = SetScale(HconDou2, sScale)
            '  insPnt(2) = 0#
            '  If IO = "屋内" Then
            '    KM_Block = "K_B_SHOSAI"
            '  Else
            '    KM_Block = "K_O_B_SHOSAI"
            '  End If
            '  Chk = FunInsertBlock(KM_Block, insPnt(0), insPnt(1), insPnt(2), 1#, 1#, 0#, "基礎")
            'End If
            ' ブロックの読込（Ａ部詳細図）
            'If I = TL_ZMaisu Then
            '  insPnt(0) = SetScale(HconDou3, sScale)
            '  insPnt(1) = SetScale(HconDou2, sScale)
            '  insPnt(2) = 0#
            '  If IO = "屋内" Then
            '    KM_Block = "K_A_SHOSAI"
            '  Else
            '    KM_Block = "K_O_A_SHOSAI"
            '  End If
            '  Chk = FunInsertBlock(KM_Block, insPnt(0), insPnt(1), insPnt(2), 1#, 1#, 0#, "基礎")
            'End If

            ' 列番左端位置の計算
            KM_ZahyoX = CalRetuLeft(i)
            KM_ZahyoY = HconZhyY1



            ' 平面図の作成
            Call CreUpDrw(i, IFG_Cnt)

            ' 正面図の作成
            Call CreFrontDrw(i)

            '図面名称の記入
            'Call WrtMeisho("30_H2", sScale)    '枠が青の図枠なら必要(現在紫)

            ' 図面のフィット
            ViewPort = acadDoc.ActiveViewport
            acadApp.ZoomAll()

            ' OSNAPのオン
            acadDoc.ObjectSnapMode = True

            ' 図面の再表示（再作図）
            'acadDoc.Regen(acActiveViewport)
            acadDoc.Regen(AcRegenType.acActiveViewport)

            'アクティブレイヤーの変更
            Call SetActiveLayer("USER")

            ' ファイル名の決定
            'If Ans = "継続（枠有り）" Then
            ''Kisozu = Sea_Dir_Kiso & "\K_" & KoubanName & GunbanName & "P" & i & "K0.dwg" 'ﾌｫﾙﾀﾞを期毎に分ける為以下のように修正 '08.2.27 松本
            'Kisozu = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\K_" & KoubanName & GunbanName & "P" & i & "K0.dwg"
            'End If

            'ファイル名の決定(BricsCADで同名ファイルを開いている状態だと保存時にエラーが発生するので、そのエラーの回避を追加)
            If Ans = "継続（枠有り）" Then
                'Kisozu = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\K_" & KoubanName & GunbanName & "P" & i & "K0.dwg" '保存場所の変更
                'Kisozu = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\K_" & KoubanName & GunbanName & "P" & i & "K0.dwg"
                Kisozu = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & TL_Zuban & "_R0.dwg"
                'If FileIO.FileSystem.FileExists(Kisozu) = True Then    '作図するファイルと同名ファイルが保存先に存在する場合
                'System.IO.File.Delete(Kisozu)
                'MsgBox("既に同じファイルをbricscadで開いています。")
                'MsgBox("処理を中止します。")
                'Exit Sub
                'End If
            End If

            ' 基礎図を工番名にて保存
            '    acadDoc.SaveAs (Kisozu) 次ﾍﾟｰｼﾞ作成時にﾒｯｾｰｼﾞが出るのでDWFﾌｧｲﾙを作成してから保存する
            ' 基礎図用dwfファイルの作成
            Call CreDwfFil(Kisozu)
            '2002対応の為下記は上記のように修正 '04.3.18 松本
            'dpos = InStr(Kisozu, ".")
            'T_Kisozu = Left(Kisozu, dpos - 1) & ".dwf"
            'Exist = Dir(T_Kisozu)
            'If Exist <> "" Then Kill Sea_Dir_Kiso & "\" & Exist  'dwfファイルが有れば消す
            '選択セットを削除する
            'Call SelectionClear("TEST")
            'Set sset = acadDoc.SelectionSets.Add("TEST")
            'T_Kisozu = Left(Kisozu, dpos - 1)
            'acadDoc.Export T_Kisozu, "DWF", sset
            'sset.Erase
            ' 基礎図を工番名にて保存
            acadDoc.SaveAs(Kisozu)
        Next i

        '基礎図ページ番号の DB 保存
        i = 1
        'Do Until PageSEHakoNo(i, 1) = ""                   'テスト時はDBなかったので
        'J = 1
        'Do Until PageSEHakoNo(i, J) = ""
        'Call DB_基礎ページ番号(PageSEHakoNo(i, J), i)
        'J = J + 1
        'Loop
        'i = i + 1
        'Loop

    End Sub

    Public Sub CreUpDrw(ByVal CUD_PageCnt As Integer, ByVal I_Cnt As Integer)
        '-----------------------------------------------
        ' 平面図の作成（基礎図用）
        '-----------------------------------------------
        '   CUD_PageCnt     : 対象となるページ番号(ex.1)
        '   I_Cnt           : 合符号用カウンター
        '-----------------------------------------------

        Dim CUD_Block As String 'ブロック名
        'Dim CUD_Lin_Obj As Object '線分オブジェクト
        Dim CUD_MainX As Double '基本座標（Ｘ座標）
        'Dim ChkExtHako As String '納入外箱Noかどうかのチェック結果
        'Dim blockObj As Object 'ブロックオブジェクト
        'Dim ExtChk As String '納入外チェックフラッグ
        'Dim CUD_ExtX As Double '納入外を含まない列番の右端位置
        'Dim LoopLimit As Integer 'ループの制限（納入箱数）
        Dim M12_Total As Integer '締付ボルトボルトの総数
        'Dim S_HakoNo As Integer, E_HakoNo As Integer
        Dim i As Integer, j As Integer, k As Integer, l As Integer
        'Dim Dummy2 As String
        Dim Ans As String
        Dim ExtNum As Integer 'ﾍﾟｰｼﾞ内の納入外箱数    '09.5.20 松本追加
        Dim inc As Integer  '非表示の箱があると箱Noの配列と配列基礎仕様で保存した配列とかみ合わなくなるので、それを調整する


        Dim Chk As Object


        CUD_Block = ""
        inc = 0

        ' 1ページ当たりの納入箱総数
        Call HakoSosu(CUD_PageCnt, ExtNum, j)
        ' 箱別データ作図
        i = 1
        j = 0
        k = 0
        CUD_MainX = KM_ZahyoX
        If PageSE(CUD_PageCnt, 0) = PageSE(CUD_PageCnt, 1) Then '現在のページに1箱しか作図しないなら
            oneboxflg = True
        Else
            oneboxflg = False
        End If
        Do Until (PageSEHakoNo(CUD_PageCnt, i) = "")
            j = CalPosition(Trim(PageSEHakoNo(CUD_PageCnt, i))) '対象箱の配列内位置
            Ans = ChkExtHakoNo(j, "基礎") '納入外かチェック
            If Ans = "納入外" Then
                ExtNum = ExtNum + 1 '納入外の場合は納入外箱数を1増やす  709.5.20 松本追加
            End If
            'If DelNo(0) <> -1 Then
            '    For m = 0 To DelNo.Length - 1
            '        If j = DelNo(m) Then
            '            inc += 1
            '        End If
            '    Next
            'End If


            KijunX(j) = CUD_MainX

            If nps = False Then
                'A、B詳細図参照ﾌﾞﾛｯｸ挿入位置それぞれのﾌﾞﾛｯｸの配置、読込
                Call Blk_LoadHaiti(CUD_PageCnt, CUD_MainX, i, j)
            End If
            



            'アクティブレイヤーの変更
            SetActiveLayer("自動作成")

            '平面図用チャンネル巾の計算
            'If IO = "屋内" Then
            '↑工番共通事項で入力された突出寸法が活かされない為
            '  以下のように変更 '08.7.1. 松本
            If BaseH = H_Okunai Then    'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋内標準ならば
                CUD_BaseH = H_Okugai
            Else
                CUD_BaseH = H_Okunai
            End If

            ' 線分の作成（外形線）

            'アクティブレイヤーの変更
            SetActiveLayer("自動作成")
            '下横線
            Call yokosen_sita(Ans, CUD_MainX, j)
            '右縦線
            Call tatesen_migi(Ans, CUD_PageCnt, CUD_MainX, i, j)
            '上横線
            Call yokosen_ue(Ans, CUD_MainX, j)
            '左縦線
            Call tatesen_hidari(Ans, CUD_PageCnt, CUD_MainX, i, j)


            ' 寸法線の作成（外形線）

            ''アクティブレイヤーの変更
            'SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
            ''線種変更
            'SetActiveLine("BYLAYER")



            ' 線分の作成（内径線）

            If Ans = "納入外" Then
                'SetActiveLine ("点線")
                SetActiveLine("破線")
            Else
                SetActiveLine("BYLAYER")
            End If

            '下横線
            Call yokosen_sita2(CUD_MainX, j)
            '上横線
            Call yokosen_ue2(CUD_MainX, j)
            '左縦線
            If P_sBanDat(j, pc_LOkuyukiRow2) = "有" Or j = 0 Then
                Call tatesen_hidari2(CUD_PageCnt, CUD_MainX, i, j)
            End If
            '右の縦線は分割処理にて処理しているので以下全てｺﾒﾝﾄｱｳﾄ  '09.5.19 松本
            '右縦線
            'If PageSEHakoNo(CUD_PageCnt, i) = PageSE(CUD_PageCnt, 1) Then
            '  insPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale) - (50# / sScale), sScale)
            '  'insPntS(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
            '  insPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
            '  insPntS(2) = 0#
            '  insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale) - (50# / sScale), sScale)
            '  'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
            '  insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
            '  insPntE(2) = 0#
            '  Set lin_obj = moSpace.AddLine(insPntS, insPntE)
            '  '線種変更
            '  lin_obj.Color = acCyan
            'End If
            If P_sBanDat(j, pc_ROkuyukiRow2) = "有" Then
                Call tatesen_migi2(CUD_MainX, j)
            End If

            ' 寸法線の作成（内径線）

            If nps = False Then     '簡略図ではないなら
                ' ブロック配置&寸法表示(盤締付用穴）
                Call Cub_HaitiMeasure(CUD_Block, CUD_PageCnt, CUD_MainX, i, j)
            End If
            

            'acadDoc.SendCommand("-style" & vbCrLf & "14_H2" & vbCrLf & "KELF1-K.shx" & vbCrLf & "31.36" & vbCrLf & "0.8" & vbCrLf & "0" & vbCrLf & "いいえ" & vbCrLf & "いいえ" & vbCrLf & "いいえ" & vbCrLf)
            'acadDoc.SendCommand("-style" & vbCrLf & "14_H2" & vbCrLf & "KELF1-K.shx" & vbCrLf & "31.36" & vbCrLf & "0.8" & vbCrLf & "0" & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf)

            'If k <> CUD_PageCnt Then
            'SetActiveDim("基礎")
            'k = CUD_PageCnt
            'End If

            'Ｗ寸法の記入
            Call WDMeasure(CUD_MainX, CUD_PageCnt, i, j)

            '寸法記入
            Call measure(CUD_PageCnt, CUD_MainX, i, j)

            'アクティブレイヤーの変更
            SetActiveLayer("3.TYUUSINSEN")
            SetActiveLine("BYLAYER")
            '線分の作成（センター線）
            'If P_sBanDat(j, pc_NoKisoRow) <> "納入外（表示）" Then
            Call tatesen_center(CUD_MainX, j)
            'End If


            'アクティブレイヤーの変更
            Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
            '線種変更
            Call SetActiveLine("BYLAYER")


            Select Case PageSEHakoNo(CUD_PageCnt, i)
                Case PageSE(CUD_PageCnt, 0)
                    '寸法表示（最左端）
                    Call SetLevelDim("Level3", "最左端", HconDou13, 0.0#, Nothing)
                    If PageSE(CUD_PageCnt, 0) = PageSE(CUD_PageCnt, 1) Then
                        insPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
                        Call SetLevelDim("Level3", "最右端", HconDou13, Val((H_W(j) / 2)), Nothing)
                    End If
                Case PageSE(CUD_PageCnt, 1)
                    '寸法表示（最右端）
                    Call SetLevelDim("Level3", "最右端", HconDou13, Val((H_W(j) / 2)), Nothing)
                Case Else
                    '寸法表示（中間）
                    Call SetLevelDim("Level3", "中間", HconDou13, 0.0#, Nothing)
            End Select

            'アクティブレイヤーの変更
            Call SetActiveLayer("自動作成")
            ' ブロック配置(箱番号）
            CUD_Block = "K_HAKO_NO"

            InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale)
            InsPnt(1) = SetScale(KM_ZahyoY - HconDou25, sScale)
            InsPnt(2) = 0.0#
            If Ans = "納入外" Then
                HAKO_No = "(" & H_CubNo(j) & ")"
            Else
                HAKO_No = H_CubNo(j)
            End If
            Chk = FunInsertBlock(CUD_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図箱番号")

            ' 制御ケーブル穴処理
            If SeigyoAna <> SeigyoAna_1 And P_sBanDat(j, pc_NoKisoRow) <> "納入外（表示）" Then
                Call SetSeigyoAna(CUD_MainX, j, i)
            End If

            '主回路ケーブル穴
            If P_sBanDat(j, pc_NoKisoRow) <> "納入外（表示）" Then
                Call SyukairoAna(CUD_MainX, j)
            End If



            '延長線
            If (CUD_PageCnt <> 1) And (TL_ZMaisu <> 1) And _
               (PageSEHakoNo(CUD_PageCnt, i) = PageSE(CUD_PageCnt, 0)) Then
                'アクティブレイヤーの変更
                SetActiveLayer("自動作成")
                '線種変更
                SetActiveLine("点線")
                '手前用
                '下横線
                Call yokosen_sita_temae(CUD_MainX, j)
                '右縦線
                Call tatesen_migi_temae(CUD_MainX, j)
                '上横線
                Call yokosen_ue_temae(CUD_MainX, j)
                '奥用
                '下横線
                Call yokosen_sita_oku(CUD_MainX, j)
                '右縦線
                Call tatesen_migi_oku(CUD_MainX, j)
                '上横線
                Call yokosen_ue_oku(CUD_MainX, j)
            End If



            '箱巾分だけ加算
            CUD_MainX = CUD_MainX + Val(H_W(j)) / sScale

            iDatNum2 = i - 1        '今何箱目か(補強枠設定用変数)

            i = i + 1
        Loop

        '延長線
        If CUD_PageCnt <> TL_ZMaisu Then
            'アクティブレイヤーの変更
            SetActiveLayer("自動作成")
            '線種変更
            SetActiveLine("点線")
            '手前用
            '下横線
            Call yokosen_sita_temae2(CUD_MainX, j)
            '右縦線
            Call tatesen_migi_temae2(CUD_MainX, j)
            '上横線
            Call yokosen_ue_temae2(CUD_MainX, j)
            '奥用
            '下横線
            Call yokosen_sita_oku2(CUD_MainX, j)
            '右縦線
            Call tatesen_migi_oku2(CUD_MainX, j)
            '上横線
            Call yokosen_ue_oku2(CUD_MainX, j)
        End If

        '線種変更
        SetActiveLine("BYLAYER")
        'If CUD_PageCnt = TL_ZMaisu Then '最終ページの場合
        ' ブロックの配置（Ａ部詳細図参照）
        'アクティブレイヤーの変更
        '    Call SetActiveLayer("自動作成")
        '    CUD_Block = "K_MOJI_A"
        '    Call SetBlock(CUD_MainX, CUD_Block, "+", 0#, _
        '                                 "+", (Val(H_D(J)) / sScale), _
        '                                 "基礎")
        'End If


        If nps = False Then
            ' ブロックの配置（盤締付ボルト文字）
            ' 締付ボルト数計算
            LoopLimit = LoopLimit - ExtNum    'ﾍﾟｰｼﾞ内の箱数から納入外の箱数を引く '09.5.20 松本追加
            M12_Total = LoopLimit * 4

            'アクティブレイヤーの変更
            Call SetActiveLayer("自動作成")

            j = CalPosition(Trim(PageSEHakoNo(CUD_PageCnt, 1))) '対象箱の配列内位置

            'ブロックの配置（盤締付ボルト文字）
            'If IO = "屋内" Then
            '↑工番共通事項で入力された突出寸法が活かされない為
            '  以下のように変更 '08.7.1. 松本
            Call BlkHaiti_BltMoji(CUD_Block, M12_Total, j)
        End If
        

        ' ブロック配置(正面文字）
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")
        CUD_Block = "K_MOJI_SHOMEN"
        'ブロック配置
        Call SetBlock(HconZhyX1, CUD_Block, "+", 0.0#, _
                                            "-", HconDou20, _
                                            "基礎")

        ' 寸法線の作成（Ｗ方向全長）
        'アクティブレイヤーの変更
        SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        'Ｗ寸法の記入(１ページ当たりの全体寸法）
        Call WMeasure(CUD_MainX)

        ' 分割処理
        Call CalBunkatu(CUD_MainX, CUD_PageCnt, I_Cnt)

        If nps = False Then
            ' アンカーボルト処理
            Call CalAnchoBolt(CUD_MainX, CUD_PageCnt)
        End If
        
        'アクティブレイヤーの変更
        SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        'If IO = "屋内" Then Call SetLevelDimD("Level1", j) 'Ｄ寸法の記入
        '↑工番共通事項で入力された突出寸法が活かされない為
        '  以下のように変更 '08.7.1. 松本
        If BaseH = H_Okunai Then Call SetLevelDimD("Level1", j) 'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋内標準ならばD寸法の記入
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")

        '補強枠設定
        'inc = 0
        For l = H_Cnt To iDatNum2 + H_Cnt       '前のページまでに作図された箱数から現在のページで作図された箱の数の分だけループ
            'If DelNo(0) <> -1 Then
            '    For m = 0 To DelNo.Length - 1
            '        If l = DelNo(m) Then
            '            inc += 1
            '        End If
            '    Next
            'End If
            If P_sBanDat(l, pc_HokyoKataRow2) <> "無" And P_sBanDat(l, pc_NoKisoRow) <> "納入外（表示）" Then
                'Call CreHokyowaku(KijunX(l), l + inc, H_Cnt)
                Call CreHokyowaku(KijunX(l), l, H_Cnt)
            End If
        Next

        H_Cnt = H_Cnt + iDatNum2 + 1            '以前のページまでに作図された箱数に現在のページで作図された箱数を足す



    End Sub

    Public Sub HakoSosu(ByVal CUD_PageCnt As Integer, ByVal ExtNum As Integer, ByVal j As Integer)
        ' 1ページ当たりの納入箱総数
        Dim Dummy2 As String

        j = 2
        Dummy2 = PageSEHakoNo(CUD_PageCnt, 1)
        Do Until PageSEHakoNo(CUD_PageCnt, j) = ""
            Dummy2 = Dummy2 + "," + PageSEHakoNo(CUD_PageCnt, j)
            j = j + 1
        Loop

        LoopLimit = CalSam(Dummy2, ",")
        ExtNum = 0            'ﾍﾟｰｼﾞ内の納入外箱数初期化
    End Sub

    Public Sub Blk_LoadHaiti(ByVal CUD_PageCnt As Integer, ByVal CUD_MainX As Double, ByVal i As Integer, ByVal j As Integer)
        'A、B詳細図参照ﾌﾞﾛｯｸ挿入位置それぞれのﾌﾞﾛｯｸの配置、読込
        Dim CUD_Block As String
        Dim Chk As Object

        If PageSEHakoNo(CUD_PageCnt, i) = BShosai Then 'B部詳細図参照ﾌﾞﾛｯｸ挿入位置の場合
            'アクティブレイヤーの変更
            Call SetActiveLayer("自動作成")
            'ブロックの配置（Ｂ部詳細図参照）
            CUD_Block = "K_MOJI_B"
            Call SetBlock(CUD_MainX, CUD_Block, "+", 0.0#, "+", (Val(H_D(j)) / sScale), _
                    "基礎")
            ' ブロックの読込（Ｂ部詳細図）
            InsPnt(0) = SetScale(HconDou1, sScale) - 200
            InsPnt(1) = SetScale(HconDou2, sScale)
            InsPnt(2) = 0.0#
            'If IO = "屋内" Then
            '↑工番共通事項で入力された突出寸法が活かされない為
            '  以下のように変更 '08.7.1. 松本
            'If BaseH = H_Okunai Then    'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋内標準ならば
            '    KM_Block = "K_B_SHOSAI"
            'Else
            '    KM_Block = "K_O_B_SHOSAI"
            'End If

            If frm配列基礎仕様.cmbKumitate.SelectedItem = "組立式" Then
                If BaseH = H_Okunai Then
                    KM_Block = "K_I_AB_K_SHOSAI"
                Else
                    KM_Block = "K_O_AB_K_SHOSAI"
                End If
            ElseIf frm配列基礎仕様.cmbKumitate.SelectedItem = "溶接式" Then
                If BaseH = H_Okunai Then
                    KM_Block = "K_I_AB_Y_SHOSAI"
                Else
                    KM_Block = "K_O_AB_Y_SHOSAI"
                End If
            End If


            Chk = FunInsertBlock(KM_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")
        End If
        If PageSEHakoNo(CUD_PageCnt, i) = AShosai Then 'A部詳細図参照ﾌﾞﾛｯｸ挿入位置の場合
            'アクティブレイヤーの変更
            Call SetActiveLayer("自動作成")
            'ブロックの配置（Ａ部詳細図参照）
            CUD_Block = "K_MOJI_A"
            Call SetBlock(CUD_MainX + (Val(H_W(j)) / sScale), CUD_Block, "+", 0.0#, "+", _
                (Val(H_D(j)) / sScale), "基礎")
            ' ブロックの読込（Ａ部詳細図）
            'InsPnt(0) = SetScale(HconDou3, sScale)
            'InsPnt(1) = SetScale(HconDou2, sScale)
            'InsPnt(2) = 0.0#
            'If IO = "屋内" Then
            '↑工番共通事項で入力された突出寸法が活かされない為
            '  以下のように変更 '08.7.1. 松本
            'If BaseH = H_Okunai Then    'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋内標準ならば
            '    KM_Block = "K_A_SHOSAI"
            'Else
            '    KM_Block = "K_O_A_SHOSAI"
            'End If
            'Chk = FunInsertBlock(KM_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")
        End If
    End Sub

    Public Sub yokosen_sita(ByVal Ans As String, ByVal CUD_MainX As Double, ByVal j As Integer)
        '下横線（平面図、外形線）
        Dim lin_Obj As Object

        If Ans = "納入外" Then
            'SetActiveLine ("点線")
            SetActiveLine("破線")
        Else
            SetActiveLine("BYLAYER")
        End If
        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_sita2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '下横線（平面図、内径線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        'If Okugai = True Then

        'End If
        insPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_sita_temae(ByVal CUD_MainX As Double, ByVal j As Integer)
        '下横線（平面図、延長線1）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX - HconDou37, sScale)
        insPntE(1) = SetScale(KM_ZahyoY, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_sita_temae2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '下横線（平面図、延長線2）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + HconDou37, sScale)
        insPntE(1) = SetScale(KM_ZahyoY, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_sita_oku(ByVal CUD_MainX As Double, ByVal j As Integer)
        '下横線（平面図、延長線1）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX - HconDou37, sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_sita_oku2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '下横線（平面図、延長線2）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + HconDou37, sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_ue(ByVal Ans As String, ByVal CUD_MainX As Double, ByVal j As Integer)
        '上横線（平面図、外形線）
        Dim lin_Obj As Object

        If Ans = "納入外" Then
            'SetActiveLine ("点線")
            SetActiveLine("破線")
        Else
            SetActiveLine("BYLAYER")
        End If
        insPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX, sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        'lin_Obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_ue2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '上横線（平面図、内径線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_ue_temae(ByVal CUD_MainX As Double, ByVal j As Integer)
        '上横線（平面図、延長線1）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX - HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_ue_temae2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '上横線（平面図、延長線2）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_ue_oku(ByVal CUD_MainX As Double, ByVal j As Integer)
        '上横線（平面図、延長線1）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX - HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_ue_oku2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '上横線（平面図、延長線2）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub tatesen_migi(ByVal Ans As String, ByVal CUD_PageCnt As Integer, ByVal CUD_MainX As Double, ByVal i As Integer, ByVal j As Integer)
        '右縦線（平面図、外形線）
        Dim lin_Obj As Object
        Dim k As Integer

        SetActiveLine("点線")
        k = 1
        Do Until (BunkatuSE(k, 1) = "")
            If PageSEHakoNo(CUD_PageCnt, i) = BunkatuSE(k, 1) Then '分割の一番右端箱の場合
                SetActiveLine("BYLAYER")
            End If
            k = k + 1
        Loop
        If Ans = "納入外" Then
            'SetActiveLine ("点線")
            SetActiveLine("破線")
        End If
        insPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        '最終ﾍﾟｰｼﾞの一番右の箱の場合 '09.5.19 松本
        If PageSEHakoNo(CUD_PageCnt, i) = PageSE(CUD_PageCnt, 1) And PageSE(CUD_PageCnt + 1, 1) = "" Then
            'lin_Obj.Color = acCyan
            If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
                lin_Obj.Color = ACAD_COLOR.acYellow
            Else
                lin_Obj.Color = ACAD_COLOR.acCyan
            End If
        Else
            If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
                lin_Obj.Color = ACAD_COLOR.acYellow
            Else
                lin_Obj.Color = ACAD_COLOR.acCyan
            End If
            'lin_Obj.Color = acCyan
        End If
    End Sub

    Public Sub tatesen_migi2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '右縦線（平面図、内径線）
        Dim lin_Obj As Object
        Dim NinsPntS(0 To 2) As Double
        Dim NinsPntE(0 To 2) As Double

        insPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale) - (50.0# / sScale), sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale) - (50.0# / sScale), sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(j) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        lin_Obj.Color = ACAD_COLOR.acCyan

        If nps = False Then
            '歯
            Call SetActiveLine("破線")
            NinsPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) - 5
            'NinsPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - CUD_BaseH
            NinsPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
            NinsPntS(2) = 0.0#
            NinsPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) - 5
            'NinsPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - CUD_BaseH - 100
            NinsPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale) - 200
            NinsPntE(2) = 0.0#
            lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
            lin_Obj.Color = ACAD_COLOR.acRed

            NinsPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) - 5
            'NinsPntS(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH
            NinsPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
            NinsPntS(2) = 0.0#
            NinsPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) - 5
            'NinsPntE(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH + 100
            NinsPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale) + 200
            NinsPntE(2) = 0.0#
            lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
            lin_Obj.Color = ACAD_COLOR.acRed
        End If
        
        Call SetActiveLine("BYLAYER")

    End Sub

    Public Sub tatesen_migi_temae(ByVal CUD_MainX As Double, ByVal j As Integer)
        '右縦線（平面図、延長線1）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX - HconDou37, sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX - HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub tatesen_migi_temae2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '右縦線（平面図、延長線2）
        Dim lin_Obj As Object

        'insPntS(0) = SetScale(CUD_MainX - HconDou37, sScale)
        insPntS(0) = SetScale(CUD_MainX + HconDou37, sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        'insPntE(0) = SetScale(CUD_MainX - HconDou37, sScale)
        insPntE(0) = SetScale(CUD_MainX + HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub tatesen_migi_oku(ByVal CUD_MainX As Double, ByVal j As Integer)
        '右縦線（平面図、延長線1）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX - HconDou37, sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX - HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub tatesen_migi_oku2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '右縦線（平面図、延長線2）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(CUD_MainX + HconDou37, sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + HconDou37, sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub tatesen_hidari(ByVal Ans As String, ByVal CUD_PageCnt As Integer, ByVal CUD_MainX As Double, ByVal i As Integer, ByVal j As Integer)
        '左縦線（平面図、外形線）
        Dim lin_Obj As Object
        Dim NinsPntS(0 To 2) As Double
        Dim NinsPntE(0 To 2) As Double

        If PageSEHakoNo(CUD_PageCnt, i) = PageSE(1, 0) Then '1ﾍﾟｰｼﾞ目の一番左の箱の場合 '09.5.19 松本(条件変更)
            SetActiveLine("BYLAYER")
        Else
            SetActiveLine("点線")
        End If
        '↑こんな風に変えたので以下はｺﾒﾝﾄｱｳﾄ    '09.5.19 松本
        'k = 1
        'Do Until (BunkatuSE(k, 0) = "")
        '  If PageSEHakoNo(CUD_PageCnt, i) = BunkatuSE(k, 0) Then '分割の一番左端箱の場合
        '    SetActiveLine ("BYLAYER")
        '  End If
        '  k = k + 1
        'Loop


        If Ans = "納入外" Then
            'SetActiveLine ("点線")
            SetActiveLine("破線")
        End If
        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX, sScale)
        insPntE(1) = SetScale(KM_ZahyoY, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        If PageSEHakoNo(CUD_PageCnt, i) = PageSE(1, 0) Then '1ﾍﾟｰｼﾞ目の一番左の箱の場合 '09.5.19 松本(条件変更)
            'lin_Obj.Color = acCyan
            If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
                lin_Obj.Color = ACAD_COLOR.acYellow
            Else
                lin_Obj.Color = ACAD_COLOR.acCyan
            End If
        Else
            'lin_Obj.Color = acCyan
            'lin_Obj.Color = ACAD_COLOR.acYellow
            If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
                lin_Obj.Color = ACAD_COLOR.acYellow
            Else
                lin_Obj.Color = ACAD_COLOR.acCyan
            End If
        End If

        If nps = False Then
            '最左端チャンネルベースの歯
            If j = 0 And P_sBanDat(j, pc_NoKisoRow) <> "納入外（表示）" Then
                SetActiveLine("破線")
                NinsPntS(0) = SetScale(CUD_MainX, sScale) + 5
                'NinsPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - CUD_BaseH
                NinsPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
                NinsPntS(2) = 0.0#
                NinsPntE(0) = SetScale(CUD_MainX, sScale) + 5
                'NinsPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - CUD_BaseH - 100
                NinsPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale) - 200
                NinsPntE(2) = 0.0#
                lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
                lin_Obj.Color = ACAD_COLOR.acRed

                NinsPntS(0) = SetScale(CUD_MainX, sScale) + 5
                'NinsPntS(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH
                NinsPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
                NinsPntS(2) = 0.0#
                NinsPntE(0) = SetScale(CUD_MainX, sScale) + 5
                'NinsPntE(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH + 100
                NinsPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale) + 200
                NinsPntE(2) = 0.0#
                lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
                lin_Obj.Color = ACAD_COLOR.acRed
                SetActiveLine("BYLAYER")
            End If
        End If
        

    End Sub

    Public Sub tatesen_hidari2(ByVal CUD_PageCnt As Integer, ByVal CUD_MainX As Double, ByVal i As Integer, ByVal j As Integer)
        '左縦線（平面図、内径線）
        Dim lin_Obj As Object
        Dim NinsPntS(0 To 2) As Double
        Dim NinsPntE(0 To 2) As Double

        'If PageSEHakoNo(CUD_PageCnt, i) = PageSE(CUD_PageCnt, 0) Then  '最初のﾍﾟｰｼﾞのみ縦線を描画するように
        'If PageSEHakoNo(CUD_PageCnt, i) = PageSE(1, 0) Then             '←このように修正 '09.5.19 松本
        insPntS(0) = SetScale(CUD_MainX + (50.0# / sScale), sScale)
        'insPntS(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
        'If Okugai = True Then
        '    insPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        'End If
        insPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (50.0# / sScale), sScale)
        'insPntE(1) = SetScale(KM_ZahyoY + Val(H_D(J) / sScale) - Val(CUD_BaseH / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_Obj.Color = acCyan
        'End If
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If

        If nps = False Then
            '歯
            Call SetActiveLine("破線")
            NinsPntS(0) = SetScale(CUD_MainX, sScale) + 5
            'NinsPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - CUD_BaseH
            NinsPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale)
            NinsPntS(2) = 0.0#
            NinsPntE(0) = SetScale(CUD_MainX, sScale) + 5
            'NinsPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - CUD_BaseH - 100
            NinsPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) - (CUD_BaseH / sScale), sScale) - 200
            NinsPntE(2) = 0.0#
            lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
            lin_Obj.Color = ACAD_COLOR.acRed

            NinsPntS(0) = SetScale(CUD_MainX, sScale) + 5
            'NinsPntS(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH
            NinsPntS(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
            NinsPntS(2) = 0.0#
            NinsPntE(0) = SetScale(CUD_MainX, sScale) + 5
            'NinsPntE(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH + 100
            NinsPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale) + 200
            NinsPntE(2) = 0.0#
            lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
            lin_Obj.Color = ACAD_COLOR.acRed
        End If
        
        Call SetActiveLine("BYLAYER")

        P_sBanDat(j, pc_LOkuyukiRow2) = "有"
    End Sub

    Public Sub tatesen_center(ByVal CUD_MainX As Double, ByVal j As Integer)
        '線分の作成（平面図、センター線）
        Dim lin_Obj As Object

        'アクティブレイヤーの変更
        Call SetActiveLine("一点鎖線")
        '縦線
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY - HconDou13 - HconDou10, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale) + HconDou9, sScale)
        insPntE(2) = 0.0#
        If P_sBanDat(j, pc_NoKisoRow) <> "納入外（表示）" Then '座標が必要なので作図のみ飛ばす
            lin_Obj = moSpace.AddLine(insPntS, insPntE)
            '線色変更
            'lin_obj.Color = acYellow   '色変更 09.5.19 松本
            'lin_obj.Color = acRed

            lin_Obj.Color = ACAD_COLOR.acRed
        End If

    End Sub

    Public Sub measure(ByVal CUD_PageCnt As Integer, ByVal CUD_MainX As Double, ByVal i As Integer, ByVal j As Integer)
        '寸法記入(平面図)
        Dim CUD_Lin_Obj As AcadDimAligned

        If PageSEHakoNo(CUD_PageCnt, i) = PageSE(CUD_PageCnt, 0) Then
            If CUD_PageCnt = 1 Then   '1ﾍﾟｰｼﾞ目の場合 '09.5.19 松本条件追加
                '側面巾寸法の記入
                insPntS(0) = SetScale(KM_ZahyoX, sScale)
                insPntS(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) / 2) / sScale), sScale)
                insPntS(2) = 0.0#
                insPntE(0) = SetScale(KM_ZahyoX + (50.0# / sScale), sScale)
                insPntE(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) / 2) / sScale), sScale)
                insPntE(2) = 0.0#
                InsPnt(0) = SetScale(KM_ZahyoX + (25.0# / sScale), sScale)
                InsPnt(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) / 2) / sScale), sScale)
                InsPnt(2) = 0.0#
                CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
            End If
            '正面巾寸法の記入
            insPntS(0) = SetScale(KM_ZahyoX + (Val(H_W(j)) * 0.7) / sScale, sScale)
            insPntS(1) = SetScale(KM_ZahyoY, sScale)
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(KM_ZahyoX + (Val(H_W(j)) * 0.7) / sScale, sScale)
            'insPntE(1) = SetScale(KM_ZahyoY + Val(CUD_BaseH / sScale), sScale)
            insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
            insPntE(2) = 0.0#
            InsPnt(0) = SetScale(KM_ZahyoX + (Val(H_W(j)) * 0.7) / sScale, sScale)
            'InsPnt(1) = SetScale(KM_ZahyoY + Val(((CUD_BaseH / 2) / 2) / sScale), sScale)
            InsPnt(1) = SetScale(KM_ZahyoY + (((CUD_BaseH / 2) / 2) / sScale), sScale)
            InsPnt(2) = 0.0#
            CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        End If
        '2ﾍﾟｰｼﾞ目移行の側面巾寸法は最後に記述するように変更 '09.5.19 松本
        If CUD_PageCnt > 1 And PageSEHakoNo(CUD_PageCnt, i) = PageSE(CUD_PageCnt, 1) Then
            '側面巾寸法の記入
            insPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale) - (50.0# / sScale), sScale)
            insPntS(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) / 2) / sScale), sScale)
            insPntS(2) = 0.0#
            insPntE(0) = insPntS(0) + 50.0#
            insPntE(1) = insPntS(1)
            insPntE(2) = 0.0#
            InsPnt(0) = insPntS(0) + 25.0#
            InsPnt(1) = insPntS(1)
            InsPnt(2) = 0.0#
            CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        End If
    End Sub

    Public Sub WMeasure(ByVal CUD_MainX As Double)
        'Ｗ寸法の記入(１ページ当たりの全体寸法、平面図）
        Dim CUD_Lin_Obj As AcadDimAligned

        insPntS(0) = SetScale(KM_ZahyoX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX, sScale)
        insPntE(1) = SetScale(KM_ZahyoY, sScale)
        insPntE(2) = 0.0#
        InsPnt(0) = (insPntE(0) - insPntS(0)) / 2
        InsPnt(1) = SetScale(KM_ZahyoY - HconDou16, sScale)
        InsPnt(2) = 0.0#
        CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
    End Sub

    Public Sub Cub_HaitiMeasure(ByVal CUD_Block As String, ByVal CUD_PageCnt As Integer, ByVal CUD_MainX As Double, ByVal i As Integer, ByVal j As Integer)
        '
        ' ブロック配置&寸法表示(盤締付用穴、平面図）
        '
        Dim pntS(2) As Double
        'Dim pntE(2) As Double



        '線種変更
        SetActiveLine("BYLAYER")

        CUD_Block = "K_ANA_M12"
        Select Case PageSEHakoNo(CUD_PageCnt, i)
            Case PageSE(CUD_PageCnt, 0)
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", (HconDou19 / sScale), _
                                                    "+", (HconDou23 / sScale), _
                                                    "基礎")

                'SetActiveDim("20_STD2")

                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                '寸法表示（最左端）
                Call SetLevelDim("Level1", "最左端", HconDou11, 0.0#, Nothing)
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", ((Val(H_W(j)) / sScale) - (HconDou21 / sScale)), _
                                                    "+", (HconDou23 / sScale), _
                                                    "基礎")
                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")

                '寸法表示（中間）
                Call SetLevelDim("Level1", "中間左", HconDou11, 0.0#, Nothing)
                If PageSE(CUD_PageCnt, 0) = PageSE(CUD_PageCnt, 1) Then
                    pntS = {InsPnt(0), InsPnt(1), InsPnt(2)}                '座標の一時保存
                    'pntE = {KM_insPntE2(0), KM_insPntE2(1), KM_insPntE2(2)} '座標の一時保存
                Else

                End If

                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", ((Val(H_W(j)) / sScale) - (HconDou21 / sScale)), _
                                                    "+", ((Val(H_D(j)) / sScale) - (HconDou23 / sScale)), _
                                                    "基礎")
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", (HconDou19 / sScale), _
                                                    "+", ((Val(H_D(j)) / sScale) - (HconDou23 / sScale)), _
                                                    "基礎")
                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                'Ｄ寸法の記入
                Call SetLevelDimD("Level2", j)

                If PageSE(CUD_PageCnt, 0) = PageSE(CUD_PageCnt, 1) Then
                    InsPnt(0) = pntS(0)
                    InsPnt(1) = pntS(1)
                    InsPnt(2) = pntS(2)
                    '寸法表示（最右端）
                    Call SetLevelDim("Level1", "最右端", HconDou11, HconDou21, Nothing)
                    'アクティブレイヤーの変更
                    Call SetActiveLayer("自動作成")
                End If
            Case PageSE(CUD_PageCnt, 1)
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", (HconDou19 / sScale), _
                                                    "+", (HconDou23 / sScale), _
                                                    "基礎")

                'Call SetActiveDim("20_STD2")

                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                '寸法表示（中間）
                Call SetLevelDim("Level1", "中間", HconDou11, 0.0#, Nothing)
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", ((Val(H_W(j)) / sScale) - (HconDou21 / sScale)), _
                                                    "+", (HconDou23 / sScale), _
                                                    "基礎")
                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                '寸法表示（中間）
                Call SetLevelDim("Level1", "中間", HconDou11, 0.0#, Nothing)
                '寸法表示（最右端）
                Call SetLevelDim("Level1", "最右端", HconDou11, HconDou21, Nothing)
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", ((Val(H_W(j)) / sScale) - (HconDou21 / sScale)), _
                                                    "+", ((Val(H_D(j)) / sScale) - (HconDou23 / sScale)), _
                                                    "基礎")
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", (HconDou19 / sScale), _
                                                    "+", ((Val(H_D(j)) / sScale) - (HconDou23 / sScale)), _
                                                    "基礎")
            Case Else
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", (HconDou19 / sScale), _
                                                    "+", (HconDou23 / sScale), _
                                                    "基礎")



                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                '寸法表示（中間）
                Call SetLevelDim("Level1", "中間", HconDou11, 0.0#, Nothing)
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", ((Val(H_W(j)) / sScale) - (HconDou21 / sScale)), _
                                                    "+", (HconDou23 / sScale), _
                                                    "基礎")
                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                Call SetLevelDim("Level1", "中間", HconDou11, 0.0#, Nothing)
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", ((Val(H_W(j)) / sScale) - (HconDou21 / sScale)), _
                                                    "+", ((Val(H_D(j)) / sScale) - (HconDou23 / sScale)), _
                                                    "基礎")
                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
                'ブロック配置
                Call SetBlock(CUD_MainX, CUD_Block, "+", (HconDou19 / sScale), _
                                                    "+", ((Val(H_D(j)) / sScale) - (HconDou23 / sScale)), _
                                                    "基礎")
        End Select
    End Sub

    Public Sub WDMeasure(ByVal CUD_MainX As Double, ByVal CUD_PageCnt As Integer, ByVal i As Integer, ByVal j As Integer)
        'Ｗ寸法の記入(平面図、外形線)
        Dim CUD_Lin_Obj As AcadDimAligned

        'アクティブレイヤーの変更
        SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = SetScale(KM_ZahyoY, sScale)
        insPntE(2) = 0.0#
        InsPnt(0) = SetScale(CUD_MainX + Val((H_W(j) / 2) / sScale), sScale)
        InsPnt(1) = SetScale(KM_ZahyoY - HconDou14, sScale)
        InsPnt(2) = 0.0#
        CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        If (CUD_PageCnt = 1) And (i = 1) Then
            'Ｄ寸法の記入
            Call SetLevelDimD("Level3", j)
            'アクティブレイヤーの変更
            'Call SetActiveLayer("自動作成")
            'ブロックの配置（Ｂ部詳細図参照）
            'CUD_Block = "K_MOJI_B"
            'Call SetBlock(CUD_MainX, CUD_Block, "+", 0#, _
            '                          "+", (Val(H_D(J)) / sScale), _
            '                          "基礎")
        End If
    End Sub

    Public Sub BlkHaiti_BltMoji(ByVal CUD_Block As String, ByVal M12_Total As Integer, ByVal j As Integer)
        ' ブロックの配置（盤締付ボルト文字）

        If BaseH = H_Okunai Then    'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋内標準ならば
            CUD_Block = "K_I_MOJI_SHIME"
            Mult_String = Str(M12_Total) & I_SHIME1
            Mult_String2 = Str(M12_Total) & I_SHIME2
            Call SetBlock(KM_ZahyoX, CUD_Block, "+", (HconDou19 / sScale), _
                                                "+", (Val(H_D(j)) / sScale), _
                                                "屋内基礎図締付ボルト")
        Else
            CUD_Block = "K_O_MOJI_SHIME"
            Mult_String = Str(M12_Total) & O_SHIME
            Call SetBlock(KM_ZahyoX, CUD_Block, "+", (HconDou19 / sScale), _
                                                "+", (Val(H_D(j)) / sScale), _
                                                "屋外基礎図締付ボルト")
        End If
    End Sub

    

    

    Public Sub CreFrontDrw(ByVal CFD_PageCnt As Integer)
        '-----------------------------------------------
        ' 正面図の作成（基礎図用）
        '-----------------------------------------------
        '   CFD_PageCnt     : 対象となるページ番号
        '-----------------------------------------------

        'Dim Anka_Total As Integer 'アンカーボルトの総数
        'Dim Kanki_Chk As String, ExtChk As String
        'Dim Dummy2 As String
        Dim i As Integer, J As Integer
        Dim Ans As String
        Dim TmpX As Double
        Dim T_baseH As String

        Dim KankiCnt As Integer     '換気文字挿入状況確認用カウンタ
        'KankiCnt = 0 → まだ換気文字を挿入していない状態
        '         = 1 → 換気文字挿入箱決定
        '         = 2 → 換気文字挿入済み

        'Dim inc As Integer

        'Dim lin_Obj As Object
        Dim Chk As Object

        'inc = 0

        ' 線分の作成（基礎ベース）

        TmpX = KM_ZahyoX
        i = 1
        'S_Ans = ""
        Chk = ""
        KankiCnt = 0

        'アクティブレイヤーの変更
        SetActiveLayer("自動作成")

        'ベース巾のセット
        'If IO = "屋内" Then
        '  T_baseH = H_Okunai
        'Else
        '  T_baseH = H_Okugai
        'End If
        '↑工番共通事項で入力された突出寸法が読み込めていないので
        '  以下のように変更 '08.7.1. 松本
        T_baseH = BaseH

        If IO = "屋内" Then
            T_baseH = H_Okunai
        Else
            T_baseH = H_Okugai
        End If
        If T_baseH <> 50 And T_baseH <> 100 Then            '空文字の場合0に
            T_baseH = BaseH
        End If

        Do Until (PageSEHakoNo(CFD_PageCnt, i) = "")
            J = CalPosition(Trim(PageSEHakoNo(CFD_PageCnt, i))) '対象箱の配列内位置

            '線種変更
            Ans = ChkExtHakoNo(J, "基礎") '納入外かチェック
            If Ans = "納入外" Then
                'SetActiveLine ("点線")
                SetActiveLine("破線")
            Else
                SetActiveLine("BYLAYER")
            End If
            'If DelNo(0) <> -1 Then
            '    For m = 0 To DelNo.Length - 1
            '        If J = DelNo(m) Then
            '            inc += 1
            '        End If
            '    Next
            'End If
            '下横線
            Call yokosen_sita3(TmpX, J)
            '上横線
            Call yokosen_ue3(TmpX, T_baseH, J)

            If i = 1 Then
                '縦線（左端）
                Call tatesen_hidari3(TmpX, T_baseH, J)

                'If IO = "屋外" Then
                '↑工番共通事項で入力された突出寸法が活かされない為
                '  以下のように変更 '08.7.1. 松本
                'If T_baseH = H_Okugai Then    'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋外標準ならば
                '    '換気文字の挿入
                '    Call kankimoji(TmpX, T_baseH, Chk, J)
                'End If
            End If
            If P_sBanDat(J, pc_NoKisoRow) <> "納入外（表示）" And KankiCnt <> 2 Then   '左端の納入外の箱は換気文字がいらないので
                KankiCnt = 1                '換気文字を挿入する箱の決定
            End If
            If KankiCnt = 1 Then
                If T_baseH = H_Okugai Then    'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋外標準ならば
                    '換気文字の挿入
                    Call kankimoji(TmpX, T_baseH, Chk, J)
                End If
                KankiCnt = 2                '換気文字は不要になったので残りの箱には適用しないようにする
            End If

            '縦線（右端）

            'Call tatesen_migi4(TmpX, T_baseH, J)

            '屋外時の処理（上下線を２重化）
            'If IO = "屋外" Then
            '↑工番共通事項で入力された突出寸法が活かされない為
            '  以下のように変更 '08.7.1. 松本
            If T_baseH = H_Okugai Then  'ﾁｬﾝﾈﾙﾍﾞｰｽの高さが屋外標準ならば
                '下横線
                Call yokosen_sita4(TmpX, J)
                '上横線
                Call yokosen_ue4(TmpX, T_baseH, J)
                '換気穴の挿入
                Call kankiana(Ans, TmpX, T_baseH, Chk, J)
            End If

            '延長線
            If (CFD_PageCnt <> 1) And (TL_ZMaisu <> 1) And _
               (PageSEHakoNo(CFD_PageCnt, i) = PageSE(CFD_PageCnt, 0)) Then
                '線種変更
                SetActiveLine("点線")
                '横線（上）
                Call yokosen_ue5(TmpX, T_baseH, J)
                '横線（下）
                Call yokosen_sita5(TmpX, J)
                '縦線（右端）
                Call tatesen_migi5(TmpX, T_baseH, J)
            End If

            TmpX = TmpX + (Val(H_W(J)) / sScale)
            i = i + 1
        Loop

        '縦線（右端）
        'Call tatesen_migi4(TmpX, T_baseH, J)

        '延長線
        If CFD_PageCnt <> TL_ZMaisu Then
            '線種変更
            SetActiveLine("点線")
            '横線（上）
            Call yokosen_ue6(TmpX, T_baseH, J)
            '横線（下）
            Call yokosen_sita6(TmpX, J)
            '縦線（右端）
            Call tatesen_migi6(TmpX, T_baseH, J)

        End If

        'アクティブレイヤーの変更
        SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")

        ' 寸法線の作成（基礎ベース)
        Call Measure_kiso(T_baseH)

        If nps = False Then
            If frm配列基礎仕様.cmbKumitate.SelectedItem = "組立式" Then
                Call BlkKumitate()
            End If
        End If
        

        acadDoc.SendCommand("LTSCALE" & vbCrLf & "150" & vbCrLf)    '線種尺度の調整(一点鎖線や破線がただの直線に見えるため追加)

    End Sub

    Public Sub yokosen_sita3(ByVal TmpX As Double, ByVal j As Integer)
        '下横線(基礎ベース、共通）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_sita4(ByVal TmpX As Double, ByVal j As Integer)
        '下横線(基礎ベース、屋外時）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4 + HconDou34, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + HconDou34, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_sita5(ByVal TmpX As Double, ByVal j As Integer)
        '下横線(基礎図、延長線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX - HconDou37, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_sita6(ByVal TmpX As Double, ByVal j As Integer)
        '下横線(基礎図、延長線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX + HconDou37, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_ue3(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '下横線(基礎図、ベース）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX + (Val(H_W(j)) / sScale), sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_ue4(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '下横線(基礎図、屋外）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX + (Val(H_W(j)) / sScale), sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale) - HconDou34, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale) - HconDou34, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub yokosen_ue5(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '下横線(基礎図、延長線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX - HconDou37, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub yokosen_ue6(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '下横線(基礎図、延長線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX + HconDou37, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub tatesen_hidari3(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '左縦線(基礎図、ベース）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4 + Val(T_baseH / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If
    End Sub

    Public Sub tatesen_migi4(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '右縦線(基礎図）
        Dim lin_Obj As Object

        'insPntS(0) = SetScale(TmpX - HconDou37, sScale)
        insPntS(0) = SetScale(TmpX + (Val(H_W(j)) / sScale), sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#
        'insPntE(0) = SetScale(TmpX - HconDou37, sScale)
        insPntE(0) = SetScale(TmpX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(j, pc_NoKisoRow) = "納入外（表示）" Then
            lin_Obj.Color = ACAD_COLOR.acYellow
        Else
            lin_Obj.Color = ACAD_COLOR.acCyan
        End If

    End Sub

    Public Sub tatesen_migi5(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '右縦線(基礎図、延長線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub tatesen_migi6(ByVal TmpX As Double, ByVal T_baseH As String, ByVal j As Integer)
        '右縦線(基礎図、延長線）
        Dim lin_Obj As Object

        insPntS(0) = SetScale(TmpX + HconDou37, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(TmpX + HconDou37, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        lin_Obj.Color = ACAD_COLOR.acCyan
    End Sub

    Public Sub kankimoji(ByVal TmpX As Double, ByVal T_baseH As String, ByVal Chk As Object, ByVal j As Integer)

        '換気文字の挿入(基礎図、屋外)
        InsPnt(0) = SetScale(TmpX - HconDou35, sScale) + (Val(H_W(j)) / 2)
        InsPnt(1) = SetScale(HconZhyY2 + HconDou4 + HconDou36, sScale) + Val(T_baseH) / 2
        InsPnt(2) = 0.0#
        KM_Block = "K_MOJI_KANKIANA"
        Chk = FunInsertBlock(KM_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")

    End Sub

    Public Sub kankiana(ByVal Ans As String, ByVal TmpX As Double, ByVal T_baseH As String, ByVal Chk As Object, ByVal j As Integer)
        Dim x As String = ""

        '換気穴の挿入(基礎図、屋外)
        If H_W(j) > 1000 Then
            x = "14"
        End If

        'If Ans = "納入外" Then                
        '    KM_Block = "K_O_KANKIANA" + x
        'Else
        '    KM_Block = "K_I_KANKIANA" + x
        'End If
        If Ans <> "納入外" Then            '納入外(表示)の箱は表示しないように変更
            KM_Block = "K_I_KANKIANA" + x
            InsPnt(0) = SetScale(TmpX, sScale) + (Val(H_W(j)) / 2)
            InsPnt(1) = SetScale(HconZhyY2 + HconDou4, sScale) + Val(T_baseH) / 2
            InsPnt(2) = 0.0#
            Chk = FunInsertBlock(KM_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")
        End If
    End Sub

    Public Sub Measure_kiso(ByVal T_baseH As String)
        Dim lin_Obj As AcadDimAligned
        ' 寸法線の作成（基礎ベース)
        '線種変更
        SetActiveLine("BYLAYER")

        insPntS(0) = SetScale(KM_ZahyoX, sScale)
        insPntS(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(KM_ZahyoX, sScale)
        insPntE(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntE(2) = 0.0#
        InsPnt(0) = SetScale(KM_ZahyoX - HconDou17, sScale)
        InsPnt(1) = SetScale(HconZhyY2 + HconDou4 + (Val(T_baseH) / sScale) / 2, sScale)
        InsPnt(2) = 0.0#
        lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
    End Sub

    Public Sub SetTmpBaseBunkatu(ByVal Chk As String)
        '-----------------------------------------------
        '納入外基礎ベース箱Ｎｏを分割箱Noに追加する
        '-----------------------------------------------
        '   Chk     : 納入外基礎ベースNoをベース分割に追加したかどうか用
        '              ="in" 追加した
        '              ="" 追加してない
        '-----------------------------------------------

        Dim i As Integer, J As Integer, k As Integer    ', L As Integer       'ループ変数
        Dim m As Integer, N As Integer
        Dim a As Integer, b As Integer
        Dim tmp(conNum) As String, Max1 As String, Max2 As String
        'Mod by khn 99-11-1
        'Dim Min As Integer, Tmp1 As Integer
        Dim Min As String, Tmp1 As Integer
        Dim flgs As Boolean
        flgs = False
        Chk = ""


        '最大箱Ｎｏ＆Ｎｏ２のゲット
        Do Until CubNo(i) = ""
            i = i + 1
        Loop
        Max1 = CubNo(i - 1)
        If i = 1 Then '1箱しかない場合
            Max2 = Max1
        Else
            Max2 = CubNo(i - 2)
        End If
        i = 0
        J = 0
        If BaseCubNo(0) <> "" Then  '納入外基礎ベースがある場合
            '納入外基礎ベースを配列にセット
            Do Until (BaseCubNo(J) = "")
                If BaseCubNo(J) = Max1 Then  '納入外基礎ベースが列番の一番右端の場合
                    If J >= 1 Then
                        'Call baseset(Tmp1, i, J, k, m, N)
                        'Tmp1 = Val(BaseCubNo(j)) - Val(BaseCubNo(j - 1))
                        Tmp1 = GetArrNo(BaseCubNo(J)) - GetArrNo(BaseCubNo(J - 1))
                        If Tmp1 = 1 Then  '納入外の箱が続いている場合
                            m = CalPosition(BaseCubNo(J))
                            N = 1
                            Do While J - N >= 0                             '納入外CUB.がある間
                                If J = N Then                               '納入外CUB.配列の先頭
                                    m = m - N - 1                            '納入外CUB.の１つ前のCUB.
                                    If m >= 0 Then BoxNo(i) = H_CubNo(m) '納入外CUB.のみの場合は分割しない
                                Else
                                    Tmp1 = Val(BaseCubNo(J - N)) - Val(BaseCubNo(J - N - 1))
                                    If Tmp1 <> 1 Then                       '納入外の箱が続いていない場合
                                        m = m - N - 1                       '納入外CUB.の１つ前のCUB.
                                        If m > 0 Then BoxNo(i) = H_CubNo(m) '納入外CUB.のみの場合は分割しない
                                        Exit Do
                                    End If
                                End If
                                N = N + 1
                            Loop
                        Else  '納入外の箱が続いていない場合は一つの分割と見なす
                            i = i + 1
                            m = CalPosition(BaseCubNo(J))
                            BoxNo(i) = H_CubNo(m - 1)
                            'tmp(I) = Max2 '一つ前の箱と交換
                        End If
                    Else  '唯一の納入外が列番の一番右端の場合
                        m = CalPosition(BaseCubNo(J))
                        BoxNo(i) = H_CubNo(m - 1)
                    End If
                Else                        '納入外基礎ベースが列番の一番右端ではない場合
                    If J >= 1 Then
                        'Tmp1 = Val(BaseCubNo(j)) - Val(BaseCubNo(j - 1))
                        Tmp1 = GetArrNo(BaseCubNo(J)) - GetArrNo(BaseCubNo(J - 1))
                        If Tmp1 = 1 Then  '納入外の箱が続いている場合
                            BoxNo(i) = BaseCubNo(J)
                        Else  '納入外の箱が続いていない場合は一つの分割と見なす
                            i = i + 1
                            BoxNo(i) = BaseCubNo(J)
                        End If
                    Else
                        BoxNo(i) = BaseCubNo(J)
                    End If
                End If
                J = J + 1
            Loop

            J = i + 1
            i = 0
            '分割指示箱Ｎｏを配列に追加
            Do Until (BaseBunkatu(i) = "")
                BoxNo(J) = BaseBunkatu(i)
                i = i + 1
                J = J + 1
            Loop
            a = 0
            b = 0
            Do Until (BoxNo(a) = "")
                For b = 0 To UBound(P_sBanDat, 1)
                    If BoxNo(a) = P_sBanDat(b, pc_BanNoRow) Then
                        flgs = True
                        Exit Do
                    End If
                Next
                a = a + 1
            Loop
            If flgs = False And BaseCubNo(0) <> "" Then
                BoxNo(a) = P_sBanDat(UBound(P_sBanDat, 1), pc_BanNoRow)
            End If

            
            '配列を昇順に並びかえる()
            k = 0
            For i = 0 To UBound(BoxNo) - 1
                If BoxNo(i) <> "" Then
                    Min = Int(BoxNo(i))
                    For J = i + 1 To UBound(BoxNo)
                        If BoxNo(J) <> "" Then
                            If Int(BoxNo(J)) < Min Then
                                BoxNo(i) = BoxNo(J)
                                BoxNo(J) = Min
                                Min = BoxNo(i)
                            End If
                        Else
                            Exit For
                        End If
                    Next
                    KM_BaseBunkatu(k) = LTrim(Str(Min))
                    k = k + 1
                Else
                    Exit For
                End If
            Next
            ''箱の並びが昇順か降順か調べ、配列を昇順又は降順に並びかえる
            ''Mod by khn '99-11-1 intを外す
            'flg = 0
            'If BoxNo(1) <> "" Then flg = StrComp(CubNo(0), CubNo(1), vbBinaryCompare)
            'k = 0
            'For i = 0 To UBound(BoxNo) - 1
            '    If BoxNo(i) <> "" Then
            '        'Min = Int(tmp(i))
            '        Min = BoxNo(i)
            '        For J = i + 1 To UBound(BoxNo)
            '            If BoxNo(J) <> "" Then
            '                Select Case flg
            '                    Case -1, 0
            '                        '                            If Int(tmp(j)) < Min Then '配列を昇順に並びかえる
            '                        If BoxNo(J) < Min Then '配列を昇順に並びかえる
            '                            BoxNo(i) = BoxNo(J)
            '                            BoxNo(J) = Min
            '                            Min = BoxNo(i)
            '                        End If
            '                    Case 1
            '                        '                            If Int(tmp(j)) > Min Then '配列を降順に並びかえる
            '                        If BoxNo(J) > Min Then '配列を降順に並びかえる
            '                            BoxNo(i) = BoxNo(J)
            '                            BoxNo(J) = Min
            '                            Min = BoxNo(i)
            '                        End If
            '                End Select
            '            Else
            '                Exit For
            '            End If
            '        Next
            '        KM_BaseBunkatu(k) = LTrim(Min)
            '        k = k + 1
            '    Else
            '        Exit For
            '    End If
            'Next

            'For i = 0 To UBound(BoxNo) - 1
            '    If BoxNo(i) <> "" Then
            '        Min = BoxNo(i)
            '        For J = i + 1 To UBound(BoxNo)
            '            If BoxNo(J) <> "" Then
            '                If GetArrNo(BoxNo(J)) < GetArrNo(Min) Then
            '                    BoxNo(i) = BoxNo(J)
            '                    BoxNo(J) = Min
            '                    Min = BoxNo(i)
            '                End If
            '            Else
            '                Exit For
            '            End If
            '        Next
            '        KM_BaseBunkatu(k) = LTrim(Min)
            '        k = k + 1
            '    Else
            '        Exit For
            '    End If
            'Next

            '------------------------------
            '箱名が同じものがあれば取り除く
            i = 0
            Call rm_SameHakoName(i, J)
            Chk = "in"
        Else  '納入外基礎ベースがなかった場合
            Do Until (BaseBunkatu(i) = "")
                KM_BaseBunkatu(k) = BaseBunkatu(i)
                k = k + 1
                i = i + 1
                Chk = ""
            Loop
        End If
    End Sub

    '
    '指定されたCubNo.が左から何番目にあるかを返す
    '
    Function GetArrNo(ByVal HakoBan As String) As Integer
        'Dim HakoCnt As Integer  'CubNo,ｶｳﾝﾀｰ

        GetArrNo = 0
        Do Until (CubNo(GetArrNo) = "")
            If CubNo(GetArrNo) = HakoBan Then
                GetArrNo = GetArrNo + 1
                Exit Do
            End If
            GetArrNo = GetArrNo + 1
        Loop
    End Function

    'Public Sub baseset(ByVal Tmp1 As Integer, ByVal i As Integer, ByVal j As Integer, ByVal k As Integer, ByVal m As Integer, ByVal N As Integer)

    '    'Tmp1 = Val(BaseCubNo(j)) - Val(BaseCubNo(j - 1))
    '    Tmp1 = GetArrNo(BaseCubNo(j)) - GetArrNo(BaseCubNo(j - 1))
    '    If Tmp1 = 1 Then  '納入外の箱が続いている場合
    '        m = CalPosition(BaseCubNo(j))
    '        N = 1
    '        Do While j - N >= 0                             '納入外CUB.がある間
    '            If j = N Then                               '納入外CUB.配列の先頭
    '                m = m - N - 1                            '納入外CUB.の１つ前のCUB.
    '                If m > 0 Then BoxNo(i) = H_CubNo(m) '納入外CUB.のみの場合は分割しない
    '            Else
    '                Tmp1 = Val(BaseCubNo(j - N)) - Val(BaseCubNo(j - N - 1))
    '                If Tmp1 <> 1 Then                       '納入外の箱が続いていない場合
    '                    m = m - N - 1                       '納入外CUB.の１つ前のCUB.
    '                    If m > 0 Then BoxNo(i) = H_CubNo(m) '納入外CUB.のみの場合は分割しない
    '                    Exit Do
    '                End If
    '            End If
    '            N = N + 1
    '        Loop
    '    Else  '納入外の箱が続いていない場合は一つの分割と見なす
    '        i = i + 1
    '        m = CalPosition(BaseCubNo(j))
    '        BoxNo(i) = H_CubNo(m - 1)
    '        'tmp(I) = Max2 '一つ前の箱と交換
    '    End If
    'End Sub

    Public Sub rm_SameHakoName(ByVal i As Integer, ByVal j As Integer)
        '箱名が同じものがあれば取り除く
        While KM_BaseBunkatu(i + 1) <> ""
            If KM_BaseBunkatu(i) = KM_BaseBunkatu(i + 1) Then
                j = i + 1
                While KM_BaseBunkatu(j + 1) <> ""
                    KM_BaseBunkatu(j) = KM_BaseBunkatu(j + 1)
                    j = j + 1
                End While
                KM_BaseBunkatu(j) = ""
            Else
                i = i + 1
            End If
        End While
    End Sub

    Public Sub BlkKumitate()
        '「注）本ベースは現地組立式ベースです。」ブロックの配置
        Dim Chk As Object
        Dim CB_Block As String

        If Kumitate = "組立式" Then
            CB_Block = "K_MOJI_KUMITATE"
        ElseIf Kumitate = "溶接式" Then
            CB_Block = "K_MOJI_YOUSETU"
        End If

        InsPnt(0) = KumiBlkX * sScale           '480*尺度 
        InsPnt(1) = KumiBlkY * sScale            '80*尺度
        InsPnt(2) = 0.0#

        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")

    End Sub

    Public Sub CalBunkatu(ByVal R_limit As Double, ByVal CB_PageCnt As Integer, ByVal I_Cnt As Integer)
        '-----------------------------------------------
        '  基礎図分割処理プログラム
        '-----------------------------------------------
        '   R_Limit      : 対象ページ内の箱の一番右端のＸ座標
        '   CB_PageCnt   : 作成対象となる図面のページ番号
        '   I_Cnt        : 合符号用カウンター
        '-----------------------------------------------

        Dim CB_Block As String 'ブロック名
        'Dim CB_Lin_Obj As Object '線分オブジェクト
        Dim i As Integer, cnt As Integer
        Dim S_Cnt As Integer, E_Cnt As Integer
        Dim B_Cnt As Integer
        Dim CB_MainX As Double '基本座標（Ｘ座標）
        Dim Ans As String

        'Dim Dummy As String, T_Cubno As String
        Dim T_Len, TT_Len As Double
        Dim T_insPnt(0 To 2) As Double '座標
        Dim T_insPntS(0 To 2) As Double 'スタート座標
        Dim T_insPntE(0 To 2) As Double 'エンド座標
        Dim Cnt1 As Integer, Cnt2 As Integer

        Dim Chk As Object
        'Dim lin_obj As Object

        Chk = Nothing
        CB_Block = ""           '初期値
        CB_MainX = KM_ZahyoX
        TT_Len = 0

        '
        'ブロック配置(左端合符号）
        '
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")

        If CB_PageCnt = 1 Then    '1ﾍﾟｰｼﾞ目のみ表示するように変更 '09.5.19 松本
            '合符号文字の設定、ブロック配置
            Call BlkHaiti_LGoHugo_1(CB_MainX, CB_Block, I_Cnt, Chk)
        Else                      '↑2ﾍﾟｰｼﾞ目以降はElseで処理 '09.5.19 松本
            CB_Block = "K_L_MOJI_BUNKATU"
            Call SetBlock(CB_MainX, CB_Block, _
                                  "+", 0.0#, _
                                  "+", (Val(H_D(0)) / sScale), _
                                  "基礎")
        End If

        '初期値設定
        cnt = 1
        i = 1
        '分割数の計算
        Do Until (i = 32767)
            If BunkatuSE(i, 0) = PageSEHakoNo(CB_PageCnt, 1) Then
                B_Cnt = i
                Exit Do
            End If
            i = i + 1
        Loop
        Do Until PageSEHakoNo(CB_PageCnt, cnt) = ""
            '分割間の長さ(左端からの距離)
            Cnt1 = CalPosition(Trim(BunkatuSE(B_Cnt, 0))) '対象箱の配列内位置（開始箱）
            Cnt2 = CalPosition(Trim(BunkatuSE(B_Cnt, 1))) '対象箱の配列内位置（終了箱）
            If Cnt1 < Cnt2 Then '昇順に並んでいる(ex 101,102,103)
                S_Cnt = Cnt1
                E_Cnt = Cnt2
            Else  '降順に並んでいる(ex 103,102,101)
                S_Cnt = Cnt2
                E_Cnt = Cnt1
            End If
            i = S_Cnt
            T_Len = 0

            Ans = ChkExtHakoNo(E_Cnt, "基礎") '納入外かチェック
            Do Until H_CubNo(i) = H_CubNo(E_Cnt) '1つの分割内の長さ計算
                T_Len = T_Len + Val(H_W(i))
                cnt = cnt + 1
                i = i + 1
            Loop
            T_Len = T_Len + Val(H_W(i))
            '分割線の記入

            'アクティブレイヤーの変更
            SetActiveLayer("自動作成")
            '線種の変更
            If Ans = "納入外" Then
                'SetActiveLine ("点線")
                SetActiveLine("破線")
            Else
                SetActiveLine("BYLAYER")
            End If
            '縦線（平面図用）'09.5.19 既に縦線は描画されているのでこの部分はｺﾒﾝﾄｱｳﾄ by 松本
            'insPntS(0) = (CB_MainX * sScale) + T_Len
            'insPntS(1) = (KM_ZahyoY * sScale)
            'insPntS(2) = 0#
            'insPntE(0) = insPntS(0)
            'insPntE(1) = (KM_ZahyoY * sScale) + Val(H_D(i))
            'insPntE(2) = 0#
            'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
            ''色変更
            'lin_obj.Color = acCyan
            '縦線（平面図用）
            Call tatesen_heimen(CB_MainX, T_Len, i)

            '縦線（正面図用）
            Call tatesen_syomen(CB_MainX, T_Len, i)
            'アクティブレイヤーの変更
            Call SetActiveLayer("自動作成")

            If (PageSEHakoNo(CB_PageCnt, cnt) <> PageSE(CB_PageCnt, 1)) And _
               (PageSE(CB_PageCnt, 1) <> BunkatuSE(B_Cnt, 1)) Then 'ページ内で最右端の場合以外
                'ブロックの配置（分割点文字）
                CB_Block = "K_R_MOJI_BUNKATU"
                Call SetBlock(CB_MainX + (T_Len / sScale), CB_Block, _
                                  "+", 0.0#, _
                                  "+", (Val(H_D(i)) / sScale), _
                                  "基礎")


                'ブロック配置(中間合符号）
                I_Cnt = I_Cnt + 1                       '合符号カウンタ
                CB_Block = "K_IFUGO"
                Call BlkHaiti_CGoHugo(CB_MainX, T_Len, CB_Block, I_Cnt, Chk, i)


                '寸法表示(分割位置）

                'アクティブレイヤーの変更
                SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                '線種の変更
                SetActiveLine("BYLAYER")
                Call HyoujiMeasure(T_insPntS, T_insPntE, T_insPnt, T_Len, TT_Len, CB_PageCnt, CB_MainX, B_Cnt)
            End If
            CB_MainX = CB_MainX + (T_Len / sScale)
            cnt = cnt + 1
            B_Cnt = B_Cnt + 1
        Loop


        '寸法表示(分割位置）

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        '線種の変更
        SetActiveLine("BYLAYER")
        Call HyoujiMeasure2(T_insPntS, T_insPntE, T_insPnt, T_Len, TT_Len)

        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")
        'ブロックの配置（分割点文字）
        If PageSEHakoNo(CB_PageCnt + 1, 1) <> "" Then '次ページがある場合    KNS
            CB_Block = "K_R_MOJI_BUNKATU"
            Call SetBlock(CB_MainX, CB_Block, _
                                  "+", 0.0#, _
                                  "+", (Val(H_D(i)) / sScale), _
                                  "基礎")
        End If

        'ブロック配置(右端合符号）
        I_Cnt = I_Cnt + 1
        IFG_Cnt2 = I_Cnt
        CB_Block = "K_IFUGO"
        '合符号
        T_Fugo = CalFugo(I_Cnt, "前")
        'ブロック配置
        InsPnt(0) = SetScale(R_limit, sScale)
        InsPnt(1) = SetScale(KM_ZahyoY - HconDou24, sScale)
        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図合符号")
        If CB_PageCnt > 1 Then    '2ﾍﾟｰｼﾞ目以降の場合は最後に[合符号]文字を表示 '09.5.19 松本追加
            CB_Block = "K_MOJI_IFUGO2"
            Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")
        End If
        CB_Block = "K_IFUGO"
        '合符号
        T_Fugo = CalFugo(I_Cnt, "後")
        'ブロック配置
        InsPnt(0) = SetScale(R_limit, sScale)
        InsPnt(1) = SetScale(KM_ZahyoY + (Val(H_D(i)) / sScale) + HconDou32, sScale)
        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図合符号")
    End Sub

    Public Sub tatesen_heimen(ByVal CB_MainX As Double, ByVal T_Len As Double, ByVal i As Integer)
        '縦線（平面図用）
        Dim lin_obj As Object
        Dim k As Integer, m As Integer

        insPntS(0) = (CB_MainX * sScale) + T_Len - 50.0#
        insPntS(1) = (KM_ZahyoY * sScale) + CUD_BaseH
        insPntE(0) = insPntS(0)
        insPntE(1) = (KM_ZahyoY * sScale) + Val(H_D(i)) - CUD_BaseH
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(i, pc_NoKisoRow) = "納入外（表示）" Then
            lin_obj.Color = ACAD_COLOR.acYellow
        Else
            lin_obj.Color = ACAD_COLOR.acCyan

            If nps = False Then
                '歯
                Call SetActiveLine("破線")
                insPntS(0) = (CB_MainX * sScale) + T_Len - 5.0#
                insPntS(1) = (KM_ZahyoY * sScale) + CUD_BaseH
                insPntE(0) = insPntS(0)
                insPntE(1) = (KM_ZahyoY * sScale) + CUD_BaseH + 200
                lin_obj = moSpace.AddLine(insPntS, insPntE)
                '色変更
                'lin_obj.Color = acCyan
                lin_obj.Color = ACAD_COLOR.acRed
                insPntS(0) = (CB_MainX * sScale) + T_Len - 5.0#
                insPntS(1) = (KM_ZahyoY * sScale) + Val(H_D(i)) - CUD_BaseH
                insPntE(0) = insPntS(0)
                insPntE(1) = (KM_ZahyoY * sScale) + Val(H_D(i)) - CUD_BaseH - 200
                lin_obj = moSpace.AddLine(insPntS, insPntE)
                '色変更
                'lin_obj.Color = acCyan
                lin_obj.Color = ACAD_COLOR.acRed
                Call SetActiveLine("BYLAYER")
            End If
        End If

        P_sBanDat(i, pc_ROkuyukiRow2) = "有"

        k = 0
        m = -1
        Do Until (CubNo(k) = "")
            k = k + 1               '箱の数分足す
            m = m + 1
        Loop

        If i <> m Then
            insPntS(0) = (CB_MainX * sScale) + T_Len + 50.0#
            insPntS(1) = (KM_ZahyoY * sScale) + CUD_BaseH
            insPntE(0) = insPntS(0)
            insPntE(1) = (KM_ZahyoY * sScale) + Val(H_D(i + 1)) - CUD_BaseH
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '色変更
            'lin_obj.Color = acCyan
            If P_sBanDat(i + 1, pc_NoKisoRow) = "納入外（表示）" Then
                lin_obj.Color = ACAD_COLOR.acYellow
            Else
                lin_obj.Color = ACAD_COLOR.acCyan
                If nps = True Then
                    '歯
                    Call SetActiveLine("破線")
                    insPntS(0) = (CB_MainX * sScale) + T_Len + 5.0#
                    insPntS(1) = (KM_ZahyoY * sScale) + CUD_BaseH
                    insPntE(0) = insPntS(0)
                    insPntE(1) = (KM_ZahyoY * sScale) + CUD_BaseH + 200
                    lin_obj = moSpace.AddLine(insPntS, insPntE)
                    '色変更
                    'lin_obj.Color = acCyan
                    lin_obj.Color = ACAD_COLOR.acRed
                    insPntS(0) = (CB_MainX * sScale) + T_Len + 5.0#
                    insPntS(1) = (KM_ZahyoY * sScale) + Val(H_D(i + 1)) - CUD_BaseH
                    insPntE(0) = insPntS(0)
                    insPntE(1) = (KM_ZahyoY * sScale) + Val(H_D(i + 1)) - CUD_BaseH - 200
                    lin_obj = moSpace.AddLine(insPntS, insPntE)
                    '色変更
                    'lin_obj.Color = acCyan
                    lin_obj.Color = ACAD_COLOR.acRed
                    Call SetActiveLine("BYLAYER")
                End If
                
            End If

            P_sBanDat(i + 1, pc_LOkuyukiRow2) = "有"
        End If


    End Sub

    Public Sub tatesen_syomen(ByVal CB_MainX As Double, ByVal T_Len As Double, ByVal i As Integer)
        '縦線（正面図用）
        Dim lin_obj As Object

        SetActiveLine("BYLAYER")
        insPntS(0) = CB_MainX * sScale + T_Len
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = insPntS(0)
        If IO = "屋内" Then
            insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(H_Okunai) / sScale), sScale)
        Else
            insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(H_Okugai) / sScale), sScale)
        End If
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '色変更
        'lin_obj.Color = acCyan
        If P_sBanDat(i, pc_NoKisoRow) = "納入外（表示）" Then
            lin_obj.Color = ACAD_COLOR.acYellow
        Else
            lin_obj.Color = ACAD_COLOR.acCyan
        End If

    End Sub

    Public Sub HyoujiMeasure(ByVal T_insPntS() As Double, ByVal T_insPntE() As Double, ByVal T_insPnt() As Double, _
                             ByVal T_Len As Double, ByVal TT_Len As Double, ByVal CB_PageCnt As Integer, ByVal CB_MainX As Double, ByVal B_Cnt As Integer)
        'ページ内で最右端の場合以外の寸法表示(分割位置）

        Dim CB_Lin_Obj As AcadDimAligned '線分オブジェクト

        If BunkatuSE(B_Cnt, 0) = PageSE(CB_PageCnt, 0) Then '各ページの最初の寸法
            T_insPntS(0) = SetScale(CB_MainX, sScale)
            T_insPntS(1) = SetScale(KM_ZahyoY, sScale)
            T_insPntS(2) = 0.0#
            T_insPntE(0) = SetScale(CB_MainX + (T_Len / sScale), sScale)
            T_insPntE(1) = T_insPntS(1)
            T_insPntE(2) = 0.0#
            T_insPnt(0) = T_insPntE(0) - T_insPntS(0)
            T_insPnt(1) = SetScale(KM_ZahyoY - HconDou15, sScale)
            T_insPnt(2) = 0.0#
            CB_Lin_Obj = moSpace.AddDimAligned(T_insPntS, T_insPntE, T_insPnt)
        Else
            T_insPntS(0) = T_insPntE(0)
            T_insPntS(1) = T_insPntE(1)
            T_insPntS(2) = 0.0#
            T_insPntE(0) = T_insPntS(0) + (T_Len - TT_Len)
            T_insPntE(1) = T_insPntS(1)
            T_insPntE(2) = 0.0#
            T_insPnt(0) = T_insPntE(0) - T_insPntS(0)
            T_insPnt(1) = SetScale(KM_ZahyoY - HconDou15, sScale)
            T_insPnt(2) = 0.0#
            CB_Lin_Obj = moSpace.AddDimAligned(T_insPntS, T_insPntE, T_insPnt)
        End If
    End Sub

    Public Sub HyoujiMeasure2(ByVal T_insPntS() As Double, ByVal T_insPntE() As Double, ByVal T_insPnt() As Double, ByVal T_Len As Double, ByVal TT_Len As Double)
        '寸法表示(分割位置）

        Dim CB_Lin_Obj As AcadDimAligned '線分オブジェクト

        If T_insPntS(0) = 0 Then 'T_insPntS(0)=0は分割する必要のない場合発生する
            T_insPntS(0) = SetScale(KM_ZahyoX, sScale)
            T_insPntS(1) = SetScale(KM_ZahyoY, sScale)
            T_insPntS(2) = 0.0#
            T_insPntE(0) = SetScale(KM_ZahyoX + (T_Len / sScale), sScale)
            T_insPntE(1) = T_insPntS(1)
            T_insPntE(2) = 0.0#
            T_insPnt(0) = T_insPntE(0) - T_insPntS(0)
            T_insPnt(1) = SetScale(KM_ZahyoY - HconDou15, sScale)
            T_insPnt(2) = 0.0#
            CB_Lin_Obj = moSpace.AddDimAligned(T_insPntS, T_insPntE, T_insPnt)
        Else
            T_insPntS(0) = T_insPntE(0)
            T_insPntS(1) = T_insPntE(1)
            T_insPntS(2) = 0.0#
            T_insPntE(0) = T_insPntS(0) + (T_Len - TT_Len)
            T_insPntE(1) = T_insPntS(1)
            T_insPntE(2) = 0.0#
            T_insPnt(0) = T_insPntE(0) - T_insPntS(0)
            T_insPnt(1) = SetScale(KM_ZahyoY - HconDou15, sScale)
            T_insPnt(2) = 0.0#
            CB_Lin_Obj = moSpace.AddDimAligned(T_insPntS, T_insPntE, T_insPnt)
        End If
    End Sub

    Public Sub BlkHaiti_LGoHugo_1(ByVal CB_MainX As Double, ByVal CB_Block As String, ByVal I_Cnt As Integer, ByVal Chk As Object)

        CB_Block = "K_IFUGO"
        '合符号文字の設定
        T_Fugo = CalFugo(I_Cnt, "前")
        InsPnt(0) = SetScale(CB_MainX - HconDou31, sScale)
        InsPnt(1) = SetScale(KM_ZahyoY - HconDou24, sScale)
        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図合符号")
        '合符号
        T_Fugo = CalFugo(I_Cnt, "後")
        'ブロック配置
        InsPnt(0) = SetScale(CB_MainX - HconDou31, sScale)

        'InsPnt(1) = SetScale(KM_ZahyoY + (Val(H_D(1)) / sScale) + HconDou32, sScale)   '←1箱だけの場合、ブロックの位置がおかしくなってしまうので修正
        InsPnt(1) = SetScale(KM_ZahyoY + (Val(H_D(0)) / sScale) + HconDou32, sScale)

        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図合符号")
        I_Cnt = I_Cnt + 1
        '合符号文字
        'ブロック配置
        CB_Block = "K_MOJI_IFUGO"
        InsPnt(0) = SetScale(CB_MainX - HconDou31, sScale)
        InsPnt(1) = SetScale(KM_ZahyoY - HconDou24 + 5.0#, sScale)
        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")
        'If CB_PageCnt <> 1 Then '２ページ目以降の左側「分割点」文字
    End Sub

    Public Sub BlkHaiti_CGoHugo(ByVal CB_MainX As Double, ByVal T_Len As Double, ByVal CB_Block As String, ByVal I_Cnt As Integer, ByVal Chk As Object, ByVal i As Integer)

        '合符号
        T_Fugo = CalFugo(I_Cnt, "前")
        InsPnt(0) = SetScale(CB_MainX + (T_Len / sScale) - HconDou31, sScale)
        InsPnt(1) = SetScale(KM_ZahyoY - HconDou24, sScale)
        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図合符号")
        '合符号
        T_Fugo = CalFugo(I_Cnt, "後")
        InsPnt(0) = SetScale(CB_MainX + (T_Len / sScale) - HconDou31, sScale)
        InsPnt(1) = SetScale(KM_ZahyoY + (Val(H_D(i)) / sScale) + HconDou32, sScale)
        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(CB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図合符号")
    End Sub

    Public Function CalFugo(ByVal i As Integer, ByVal sel As String) As String
        '-----------------------------------------------
        '合符号の作成
        '-----------------------------------------------
        '   i     : 合符号通し番号(ex 1)
        '   Sel   : 合符号表示位置("前","後")
        '-----------------------------------------------
        Dim End_Fugo As String
        Dim T_Gunban As String
        CalFugo = ""            '初期値

        'T_Gunban = Right(GunbanName, 1)      '群番号の右から1桁目
        T_Gunban = Strings.Right(GunbanName, 1)      '群番号の右から1桁目
        If T_Gunban = "0" Then T_Gunban = "" '群番号の右から１桁目が０なら無視する

        If sel = "前" Then
            End_Fugo = "1"
        Else
            End_Fugo = "2"
        End If
        Select Case i
            Case 1
                CalFugo = T_Gunban & "A" & End_Fugo
            Case 2
                CalFugo = T_Gunban & "B" & End_Fugo
            Case 3
                CalFugo = T_Gunban & "C" & End_Fugo
            Case 4
                CalFugo = T_Gunban & "D" & End_Fugo
            Case 5
                CalFugo = T_Gunban & "E" & End_Fugo
            Case 6
                CalFugo = T_Gunban & "F" & End_Fugo
            Case 7
                CalFugo = T_Gunban & "G" & End_Fugo
            Case 8
                CalFugo = T_Gunban & "H" & End_Fugo
            Case 9
                CalFugo = T_Gunban & "I" & End_Fugo
            Case 10
                CalFugo = T_Gunban & "J" & End_Fugo
        End Select
    End Function

    Public Sub SetBlock(ByVal X As Double, ByVal Block As String, ByVal T0_PN As String, ByVal T0_length As Double, ByVal T1_PN As String, ByVal T1_length As Double, ByVal sel As String)
        '-----------------------------------------------
        ' ブロック配置
        '-----------------------------------------------
        '   X         : Ｘ方向ブロック挿入基点(ex 500)
        '   Block     : 挿入するブロック名(ex K_MOJI_B)
        '   TO_PN     : Ｘ方向に対する加減算記号("+","-")
        '   T0_length : Ｘ方向に対する加減算寸法(ex 40)
        '   T1_PN     : Ｙ方向に対する加減算記号("+","-")
        '   T1_length : Ｙ方向に対する加減算寸法(ex 40)
        '   Sel       : 振り分け記号("配列"or"基礎")
        '-----------------------------------------------

        Dim T0_Val As Double
        Dim T1_Val As Double

        Dim Chk As Object

        If T0_PN = "+" Then
            T0_Val = X + T0_length
        Else
            T0_Val = X - T0_length
        End If
        If T1_PN = "+" Then
            T1_Val = KM_ZahyoY + T1_length
        Else
            T1_Val = KM_ZahyoY - T1_length
        End If
        InsPnt(0) = SetScale(T0_Val, sScale)
        InsPnt(1) = SetScale(T1_Val, sScale)
        InsPnt(2) = 0.0#
        Chk = FunInsertBlock(Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, sel)
    End Sub

    Public Sub CalAnchoBolt(ByVal R_Limit As Double, ByVal CAB_PageCnt As Integer)
        '-----------------------------------------------
        ' アンカーボルト処理
        '-----------------------------------------------
        '   R_Limit      : 対象ページ内の箱の一番右端のＸ座標
        '   CAB_PageCnt  : 作成対象となる図面のページ番号
        '-----------------------------------------------

        Dim CAB_Block As String 'ブロック名
        'Dim blockObj As Object
        'Dim SPO As Integer, EPO As Integer
        'Dim Add_ANC As Integer, ANC(0 To 20) As Integer,ANC_CHK As Integer
        'Dim ES As Integer
        Dim i As Integer, cnt As Integer, j As Integer, l As Integer, m As Integer
        Const Limit_ANC_Pitch As Integer = 1400
        Const ANC_Offset As Integer = 110
        'Dim LoopLimit As Integer 'ループの制限（分割数）
        Dim BNKT As Integer
        'Dim M1 As Integer, M2 As Integer, M3 As Integer
        'Dim L_P_1 As Integer, L_P_2 As Integer, H_P_1 As Integer, H_P_2 As Integer
        'Dim Hosei_Error As Integer
        Dim ANK_Total As Integer
        Dim dmAncNam(iDatNum2 + 1) As String

        Dim W_Pos As Integer
        'Dim AncNum As Integer   'ｱﾝｶｰﾎﾞﾙﾄ列数
        'Dim AncNam As String = ""   'ｱﾝｶｰﾎﾞﾙﾄ名
        'Dim AncBlk As AcadBlock = Nothing 'ｱﾝｶｰﾎﾞﾙﾄﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
        'Dim AncPnt(0 To 2) As Double

        'Dim lin_obj As Object
        Dim Chk As Object
        l = 0
        m = 0
        insPntB = 0

        '後に設定するアンカーボルトブロックの名前と重複するブロックの削除をする処理
        'For l = 1 To iDatNum2 + 1
        '    dmAncNam(l) = "ANC_" + Format(l)
        'Next
        'Do While m < acadDoc.Blocks.Count
        '    BlkObj = acadDoc.Blocks.Item(m)
        '    For l = 1 To iDatNum2 + 1
        '        If BlkObj.Name = dmAncNam(l) Then
        '            BlkObj.Delete()
        '        End If
        '    Next
        '    m = m + 1
        'Loop

        '初期値設定
        AncNum = 1

        '分割数の計算(Start,End)
        Call BunkatuCal(CAB_PageCnt)

        ' 分割数計算
        ANK_Total = 0
        j = 1

        'ブロック配置(「アンカーボルト位置」)
        Call BlkANCIti()

        For cnt = S_End To LoopLimit  '1ページに含まれる分割数だけループ
            '基礎図の始点、終点の計算（分割毎）
            BNKT = CalSEPoint(cnt, j)
            'アンカーボルト配置位置計算
            ES = EPO - SPO - 200
            Add_ANC = 0

            If P_sBanDat(BNKT, pc_NoKisoRow) = "納入外（表示）" And cnt = 1 Then       '将来が左側にある場合
                InsPnt(0) = SetScale(KM_ZahyoX, sScale)
                Do Until (l > BNKT)
                    InsPnt(0) = InsPnt(0) + P_sBanDat(l, pc_BanWRow)
                    insPntB = insPntB + P_sBanDat(l, pc_BanWRow)                        'アンカーボルト取付穴ブロックの位置
                    l = l + 1
                Loop
                InsPnt(1) = SetScale(KM_ZahyoY, sScale)


                Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                Call SetLevelDim("Level2", "最左端", HconDou12, 0.0#, Nothing)     '箱の左端から

                KM_insPntE2(1) = KM_insPntE2(1) + HconDou23

                'アクティブレイヤーの変更
                Call SetActiveLayer("自動作成")
            ElseIf P_sBanDat(BNKT, pc_NoKisoRow) = "納入外（表示）" And cnt <> 1 Then  '将来が右側にある場合

                '最右端寸法の表示
                AncMFlg = True
                Call SetLevelDim("Level2", "最右端", HconDou12, HconDou8, Nothing)
                AncMFlg = False
            Else
                '配置計算
                If ES <= Limit_ANC_Pitch Then 'アンカーボルトの制限距離内に収まっている場合
                    Add_ANC% = 0
                ElseIf ES - Int(ES / Limit_ANC_Pitch) * Limit_ANC_Pitch = 0 Then
                    'ANC_Pitchの倍数かどうかチェックし倍数の場合
                    Add_ANC = ES / Limit_ANC_Pitch - 1
                Else '倍数でない場合
                    Add_ANC = Int(ES / Limit_ANC_Pitch)
                End If

                'アンカーボルト位置及び数の計算
                Call L_1125(ANC_Offset)
                'アンカーボルト微調整
                Call L_7500(ANC_Offset, BNKT, cnt)

                'ブロック配置＆寸法表示
                'If Okugai = False Then
                If IO = "屋内" Then
                    CAB_Block = "K_I_ANA_ANKA"
                Else
                    CAB_Block = "K_O_ANA_ANKA"
                End If

                

                i = 1
                Do While i <= ANC_CHK 'ANC_CHK=表示するアンカーボルトのセット数

                    'ブロック配置（アンカーボルト）(上部)
                    Call BlkHaiti_ANC_ue(CAB_Block, i)
                    'ブロック配置（アンカーボルト）（下部）←上部にまとめた
                    'Call BlkHaiti_ANC_sita(AncBlk, CAB_Block, i)

                    'アクティブレイヤーの変更
                    Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                    '寸法表示
                    Select Case i
                        Case 1
                            If j = 1 Then
                                Call SetLevelDim("Level2", "最左端", HconDou12, 0.0#, Nothing)
                            Else
                                Call SetLevelDim("Level2", "中間", HconDou12, 0.0#, Nothing)
                            End If
                            'Case 2
                            ' Call SetLevelDim("Level2", "中間左", HconDou12, 0#)
                        Case Else
                            Call SetLevelDim("Level2", "中間", HconDou12, 0.0#, Nothing)
                    End Select

                    'アクティブレイヤーの変更
                    Call SetActiveLayer("自動作成")
                    'If Okugai = False Then
                    If IO = "屋内" Then
                        'アンカーボルト周辺の縦線(下部)
                        Call tatesen_sita_ANC(i)
                    End If
                    '正面図用アンカーボルト
                    Call ANC_Syomen(i)

                    i = i + 1
                    'ｱﾝｶｰﾎﾞﾙﾄﾌﾞﾛｯｸ挿入
                    'BlkObj = moSpace.InsertBlock(AncPnt, AncNam, 1, 1, 1, 0)
                    AncNum = AncNum + 1
                Loop
                'アクティブレイヤーの変更
                Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")




                InsPnt(1) = insPntA
                '
                '最右端寸法の表示
                AncMFlg = True
                Call SetLevelDim("Level2", "最右端", HconDou12, HconDou8, Nothing)
                AncMFlg = False

            End If
            '↓分割内の最初の箱が納入外の場合はｱﾝｶｰﾎﾞﾙﾄの数はｶｳﾝﾄしないように変更 '09.5.19 松本
            If ChkExtHakoNo(CalPosition(Trim(BunkatuSE(cnt, 0))), "基礎") <> "納入外" Then
                ANK_Total = ANK_Total + i - 1
            End If
            j = j + 1
        Next

        Dim Pos As String
        Pos = 0

        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")
        ' ブロックの配置（アンカーボルト文字）
        ANK_Total = ANK_Total * 2
        W_Pos = CalPosition(Trim(PageSE(CAB_PageCnt, 0))) '対象箱の配列内位置（開始箱）
        If P_sBanDat(W_Pos, pc_NoKisoRow) = "納入外（表示）" Then
            Pos = insPntB + HconDou8
        Else
            Pos = HconDou8
        End If

        If IO = "屋内" Then                               '屋内なら、
            CAB_Block = "K_I_MOJI_ANKA"
            Mult_String = Str(ANK_Total) & I_ANKA1
            Mult_String2 = Str(ANK_Total) & I_ANKA2
            'Call SetBlock(KM_ZahyoX, CAB_Block, "+", (HconDou8 / sScale), _
            '                                    "+", (Val(H_D(W_Pos)) / sScale), _
            '                                    "屋内基礎図アンカーボルト")
            Call SetBlock(KM_ZahyoX, CAB_Block, "+", (Pos / sScale), _
                                                "+", (Val(H_D(W_Pos)) / sScale), _
                                                "屋内基礎図アンカーボルト")
        Else
            CAB_Block = "K_O_MOJI_ANKA"
            Mult_String = Str(ANK_Total) & O_ANKA
            Call SetBlock(KM_ZahyoX, CAB_Block, "+", (Pos / sScale), _
                                                "+", (Val(H_D(W_Pos)) / sScale), _
                                                "屋外基礎図アンカーボルト")
            'Call SetBlock(KM_ZahyoX, CAB_Block, "+", (HconDou8 / sScale), _
            '                                    "+", (Val(H_D(W_Pos)) / sScale), _
            '                                    "屋外基礎図アンカーボルト")
        End If

        ' ブロックの読込（アンカーボルト文字(正面図用））

        Dim k As Integer
        Dim MojiIti As Double
        k = 0
        MojiIti = 0
        For k = 0 To UBound(P_sBanDat, 1)                           '箱分ループ
            '納入外だとアンカーボルトを表示しないので、表示されるアンカーボルトまでx座標をずらす
            If P_sBanDat(k, pc_NoKisoRow) = "納入外（表示）" Then
                MojiIti = MojiIti + H_W(k)
            Else
                Exit For
            End If
        Next
        
        InsPnt(0) = SetScale(KM_ZahyoX + (HconDou8 / sScale), sScale) + MojiIti
        InsPnt(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        InsPnt(2) = 0.0#
        CAB_Block = "K_MOJI_ANKA"
        Mult_String = Str(ANK_Total) & ANKA
        Chk = FunInsertBlock(CAB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎図アンカーボルト２")

        'Exit Sub

        ' サブルーチンプログラム→1プロシーシャの文章量を減らすためにcallで呼ぶ形に
        'L_1125:
        'アンカーボルト配置位置計算
        'ANC_CHK = Add_ANC + 2
        'Select Case ANC_CHK
        'Case "2" '２点留めの場合
        'ANC(1) = SPO + ANC_Offset
        'ANC(2) = EPO - ANC_Offset
        'ANC(3) = EPO
        'Case "3"  '３点留めの場合
        'ANC(1) = SPO + ANC_Offset
        'ANC(2) = (SPO + EPO) / 2
        'ANC(3) = EPO - ANC_Offset
        'ANC(4) = EPO
        'Case "4"  '４点留めの場合
        'ES = Int((ES / 3 + 5) / 10) * 10
        '       ANC(1) = SPO + ANC_Offset
        '       ANC(2) = SPO + ES + ANC_Offset
        '       ANC(3) = EPO - ES - ANC_Offset
        '       ANC(4) = EPO - ANC_Offset
        '       ANC(5) = EPO
        '   Case "5"  '５点留めの場合
        '       ANC(1) = SPO + ANC_Offset
        '       ES = Int((ES / 4 + 5) / 10) * 10
        '       ANC(2) = SPO + ES + ANC_Offset
        '       ANC(3) = (SPO + EPO) / 2
        '       ANC(4) = EPO - ES - ANC_Offset
        '       ANC(5) = EPO - ANC_Offset
        '       ANC(6) = EPO
        'End Select
        'Return
        'L_7500:
        'L_P_1 = 0
        'L_P_2 = 0
        '        S_Cnt = CalPosition(Trim(BunkatuSE(cnt, 0))) '対象箱の配列内位置（開始箱）
        '        'アンカーボルト微調整
        '        For M1 = 2 To ANC_CHK - 1 '比較対象となる仮アンカの位置配列（両端除く）
        'For M2 = S_Cnt To BNKT - 1 '対象となる分割領域の箱座標の配列
        'For M3 = 0 To 2
        'If ANC(M1) = KM_Box_Right(M2, M3) Then
        'GoTo LoopM1
        'End If
        'If ANC(M1) > KM_Box_Right(M2, M3) Then
        '                       L_P_1 = M2
        '                        L_P_2 = M3
        'End If
        'If ANC(M1) < KM_Box_Right(M2, M3) Then
        '                        H_P_1 = M2
        '                        H_P_2 = M3
        'GoTo L_7900
        'GoTo LoopM1
        'End If
        'Next M3
        'Next M2
        'LoopM1:
        'Next M1
        'Return
        'L_7900:
        'Hosei_Error = 0
        '        If KM_Box_Right(H_P_1, H_P_2) - ANC(M1 - 1) <= Limit_ANC_Pitch Then
        '        GoTo L_7950
        '        End If
        '       If KM_Box_Right(L_P_1, L_P_2) = 0 Then
        'Hosei_Error = 1
        'Return
        'End If
        'ANC(M1) = KM_Box_Right(L_P_1, L_P_2)
        'Return
        'L_7950:
        'If KM_Box_Right(H_P_1, H_P_2) = 0 Then
        'Hosei_Error = 1
        'Return
        'End If
        'ANC(M1) = KM_Box_Right(H_P_1, H_P_2)
        'Return

    End Sub

    'Public Function CalSEPoint(ByVal SE_Cnt As Integer, ByVal SE_sp0 As Integer, ByVal SE_ep0 As Integer, ByVal LoopCnt As Integer) As Integer
    Public Function CalSEPoint(ByVal SE_Cnt As Integer, ByVal LoopCnt As Integer) As Integer
        '-----------------------------------------------
        '基礎図の始点、終点の計算（分割毎）
        '-----------------------------------------------
        '   SE_Cnt      : 対象となる分割番号(ex 1)
        '   SE_sp0      : 始点Ｘ座標
        '   SE_ep0      : 終点Ｘ座標
        '   LoopCnt     : 1ページ内における何番目の分割か(ex 2)
        '   戻り値      : 分割内に箱数(ex 5)
        '-----------------------------------------------

        'Dim Dummy As String
        'Dim Dummy2 As String
        'Dim T_Cubno As String, Chk_YN As String
        Dim i As Integer, T_Len As Integer
        'Dim T_Data As String
        Dim Cnt1 As Integer, Cnt2 As Integer

        Dim S_Cnt As Integer, E_Cnt As Integer

        i = 1
        T_Len = 0

        '分割間の長さ(左端からの距離)
        Cnt1 = CalPosition(Trim(BunkatuSE(SE_Cnt, 0))) '対象箱の配列内位置（開始箱）
        Cnt2 = CalPosition(Trim(BunkatuSE(SE_Cnt, 1))) '対象箱の配列内位置（終了箱）

        'If P_sBanDat(Cnt1, pc_NoKisoRow) = "納入外（表示）" And P_sBanDat(Cnt2, pc_NoKisoRow) = "納入外（表示）" Then
        '    '将来が左端の場合

        'ElseIf P_sBanDat(Cnt1, pc_NoKisoRow) <> "納入外（表示）" And P_sBanDat(Cnt2, pc_NoKisoRow) = "納入外（表示）" Then
        '    '将来が右端の場合

        'Else

        'End If

        'If Cnt1 < Cnt2 Then '昇順に並んでいる(ex 101,102,103)
        '  S_Cnt = Cnt1
        '  E_Cnt = Cnt2
        'Else             '降順に並んでいる(ex 103,102,101)
        '  S_Cnt = Cnt2
        '  E_Cnt = Cnt1
        'End If
        S_Cnt = Cnt1
        E_Cnt = Cnt2

        T_Len = 0
        i = S_Cnt
        Do Until H_CubNo(i) = H_CubNo(E_Cnt) '1つの分割内の長さ計算
            T_Len = T_Len + Val(H_W(i))
            If LoopCnt = 1 Then  '1つのページ内に置ける一番左端の分割（最初の分割）の場合
                KM_Box_Right(i, 0) = (KM_ZahyoX * sScale) + T_Len - HconDou8
                KM_Box_Right(i, 1) = (KM_ZahyoX * sScale) + T_Len
                KM_Box_Right(i, 2) = (KM_ZahyoX * sScale) + T_Len + HconDou8
            Else
                KM_Box_Right(i, 0) = EPO + T_Len - HconDou8
                KM_Box_Right(i, 1) = EPO + T_Len
                KM_Box_Right(i, 2) = EPO + T_Len + HconDou8
            End If
            i = i + 1
        Loop
        T_Len = T_Len + Val(H_W(i)) '最後の箱巾加算

        If LoopCnt = 1 Then  '1つのページ内に置ける一番左端の分割（最初の分割）の場合
            KM_Box_Right(i, 0) = (KM_ZahyoX * sScale) + T_Len - HconDou8
            KM_Box_Right(i, 1) = (KM_ZahyoX * sScale) + T_Len
            KM_Box_Right(i, 2) = (KM_ZahyoX * sScale) + T_Len + HconDou8
        Else
            KM_Box_Right(i, 0) = EPO + T_Len - HconDou8
            KM_Box_Right(i, 1) = EPO + T_Len
            KM_Box_Right(i, 2) = EPO + T_Len + HconDou8
        End If

        '帰り値のセット
        CalSEPoint = i

        If LoopCnt = 1 Then  '1つのページ内に置ける一番左端の分割（最初の分割）の場合
            SPO = KM_ZahyoX * sScale '基礎図始点
            EPO = SPO + T_Len '基礎図終点
        Else
            SPO = EPO '基礎図始点
            EPO = SPO + T_Len '基礎図終点
        End If
    End Function

    Public Sub BunkatuCal(ByVal CAB_PageCnt As Integer)
        '分割数の計算(Start）
        Dim i As Integer

        i = 1
        Do Until (i = 32767)
            If BunkatuSE(i, 0) = PageSE(CAB_PageCnt, 0) Then
                S_End = i
                Exit Do
            End If
            i = i + 1
        Loop

        '分割数の計算(End）
        i = 1
        Do Until (i = 32767)
            If BunkatuSE(i, 1) = PageSE(CAB_PageCnt, 1) Then
                LoopLimit = i
                Exit Do
            End If
            i = i + 1
        Loop
    End Sub



    Public Sub tatesen_sita_ANC(ByVal i As Integer)
        Dim lin_obj As Object
        'Dim Chk As Object

        'アンカーボルト周辺の縦線(下部)
        SetActiveLine("破線")
        insPntS(0) = CDbl(ANC(i)) - HconDou33 * sScale
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = insPntS(0)
        insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
        'lin_obj = AncBlk.AddLine(insPntS, insPntE)
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        'Chk = FunInsertBlock(CAB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")

        '線色変更
        'lin_obj.Color = acYellow
        lin_obj.Color = ACAD_COLOR.acYellow

        insPntS(0) = CDbl(ANC(i)) + HconDou33 * sScale
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = insPntS(0)
        insPntE(1) = SetScale(KM_ZahyoY + (CUD_BaseH / sScale), sScale)
        insPntE(2) = 0.0#
        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
        'lin_obj = AncBlk.AddLine(insPntS, insPntE)
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        'lin_obj.Color = acYellow
        lin_obj.Color = ACAD_COLOR.acYellow

        'アンカーボルト周辺の縦線(上部)
        insPntS(0) = CDbl(ANC(i)) - HconDou33 * sScale
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(0))
        insPntS(2) = 0.0#
        insPntE(0) = insPntS(0)
        insPntE(1) = SetScale(KM_ZahyoY - (CUD_BaseH / sScale), sScale) + Val(H_D(0))
        insPntE(2) = 0.0#
        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
        'lin_obj = AncBlk.AddLine(insPntS, insPntE)
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        'lin_obj.Color = acYellow
        lin_obj.Color = ACAD_COLOR.acYellow

        insPntS(0) = CDbl(ANC(i)) + HconDou33 * sScale
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(0))
        insPntS(2) = 0.0#
        insPntE(0) = insPntS(0)
        insPntE(1) = SetScale(KM_ZahyoY - (CUD_BaseH / sScale), sScale) + Val(H_D(0))
        insPntE(2) = 0.0#
        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)
        'lin_obj = AncBlk.AddLine(insPntS, insPntE)
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線色変更
        'lin_obj.Color = acYellow
        lin_obj.Color = ACAD_COLOR.acYellow
    End Sub

    Public Sub ANC_Syomen(ByVal i As Integer)
        '正面図用アンカーボルト(同じx座標のアンカーボルトのブロック化は未対応)
        'Dim lin_obj As Object
        Dim Chk As Object
        Dim BlkNam As String
        Dim pos As String, pos2 As String, pos3 As String

        SetActiveLine("BYLAYER")
        insPntS(0) = CDbl(ANC(i))
        insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        insPntS(2) = 0.0#

        pos = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        pos2 = insPntS(0).ToString & "," & (insPntS(1) + 10).ToString & "," & (insPntS(2) - 10).ToString
        pos3 = insPntS(0).ToString & "," & (insPntS(1) - 10).ToString & "," & (insPntS(2) + 10).ToString

        'insPntE(0) = insPntS(0)
        'insPntE(1) = SetScale(HconZhyY2 + HconDou4 - HconDou5, sScale)
        'insPntE(2) = 0.0#
        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)

        'lin_obj = AncBlk.AddLine(insPntS, insPntE)
        BlkNam = "K_ANKA_SITA"
        Chk = FunInsertBlock(BlkNam, insPntS(0), insPntS(1), insPntS(2), 1.0#, 1.0#, 0.0#, "基礎")

        'AncBlk = acadDoc.Blocks.Add(InsPnt, AncNam)
        '2002対応の為修正↓ '04.3.18 松本
        'Set BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + CAB_Block + EndString, 1, 1, 0)
        'BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + BlkNam + EndString, 1, 1, 1, 0)
        '線色変更
        'lin_obj.Color = acBlue
        'lin_obj.Color = ACAD_COLOR.acBlue

        SetActiveLine("一点鎖線")
        'insPntS(0) = CDbl(ANC(i))
        'insPntS(1) = SetScale(HconZhyY2 + HconDou4, sScale)
        'insPntS(2) = 0.0#
        'insPntE(0) = insPntS(0)
        'If IO = "屋内" Then
        '    insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(H_Okunai) / sScale) + HconDou6, sScale)
        'Else
        '    insPntE(1) = SetScale(HconZhyY2 + HconDou4 + (Val(H_Okugai) / sScale) + HconDou6, sScale)
        'End If
        'insPntE(2) = 0.0#
        'Set lin_obj = moSpace.AddLine(insPntS, insPntE)

        'lin_obj = AncBlk.AddLine(insPntS, insPntE)
        BlkNam = "K_ANKA_UE"
        Chk = FunInsertBlock(BlkNam, insPntS(0), insPntS(1), insPntS(2), 1.0#, 1.0#, 0.0#, "基礎")

        'AncBlk = acadDoc.Blocks.Add(InsPnt, AncNam)
        '2002対応の為修正↓ '04.3.18 松本
        'Set BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + CAB_Block + EndString, 1, 1, 0)
        'BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + BlkNam + EndString, 1, 1, 1, 0)

        acadDoc.SendCommand("-block" & vbCrLf & AncNam & vbCrLf & pos & vbCrLf & "c" & vbCrLf & pos2 & vbCrLf & pos3 & vbCrLf & vbCrLf)
        acadDoc.SendCommand("-insert" & vbCrLf & AncNam & vbCrLf & pos & vbCrLf & "1" & vbCrLf & "1" & vbCrLf & "0" & vbCrLf)

        '線色変更
        'lin_obj.Color = acYellow
        'lin_obj.Color = ACAD_COLOR.acYellow
        '線種変更
        SetActiveLine("BYLAYER")
    End Sub

    Public Sub BlkHaiti_ANC_ue(ByVal CAB_Block As String, ByVal i As Integer)
        'ブロック配置（アンカーボルト）（上部）(同じx座標のアンカーボルトのブロック化は未対応)
        Dim Chk As Object

        InsPnt(0) = CDbl(ANC(i))
        If IO = "屋内" Then
            InsPnt(1) = SetScale(KM_ZahyoY - (HconDou22 / sScale), sScale) + Val(H_D(0))
        Else
            InsPnt(1) = SetScale(KM_ZahyoY - (HconDou23 / sScale), sScale) + Val(H_D(0))
        End If
        InsPnt(2) = 0.0#

        'ｱﾝｶｰﾎﾞﾙﾄﾌﾞﾛｯｸ(X位置の同じ物の集まり)作成
        AncNam = "ANC_" + Format(AncNum)
        AncPnt(0) = InsPnt(0)
        AncPnt(1) = InsPnt(1)
        AncPnt(2) = 0

        ''既に同名のｱﾝｶｰﾎﾞﾙﾄﾌﾞﾛｯｸがあれば削除  ←アンカーボルト処理の先頭に移動
        'Do While k < acadDoc.Blocks.Count
        '    BlkObj = acadDoc.Blocks.Item(k)
        '    If BlkObj.Name = AncNam Then
        '        BlkObj.Delete()
        '        Exit Do
        '    End If
        '    k = k + 1
        'Loop


        'AncBlk = acadDoc.Blocks.Add(InsPnt, AncNam)
        '2002対応の為修正↓ '04.3.18 松本
        'Set BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + CAB_Block + EndString, 1, 1, 0)
        'BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + CAB_Block + EndString, 1, 1, 1, 0)

        Chk = FunInsertBlock(CAB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")

        '下
        If IO = "屋内" Then
            InsPnt(1) = SetScale(KM_ZahyoY + (HconDou22 / sScale), sScale)
            insPntA = InsPnt(1)
        Else
            InsPnt(1) = SetScale(KM_ZahyoY + (HconDou23 / sScale), sScale)
            insPntA = InsPnt(1)
        End If
        'AncBlk = acadDoc.Blocks.Add(InsPnt, AncNam)


        Chk = FunInsertBlock(CAB_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")


        'BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + CAB_Block + EndString, 1, 1, 1, 0)
    End Sub

    'Public Sub BlkHaiti_ANC_sita(ByVal AncBlk As AcadBlock, ByVal CAB_Block As String, ByVal i As Integer)
    '    'ブロック配置（アンカーボルト）（下部）       ※上と統合
    '    Dim BlkObj As Object

    '    InsPnt(0) = CDbl(ANC(i))
    '    If IO = "屋内" Then
    '        InsPnt(1) = SetScale(KM_ZahyoY + (HconDou22 / sScale), sScale)
    '    Else
    '        InsPnt(1) = SetScale(KM_ZahyoY + (HconDou23 / sScale), sScale)
    '    End If
    '    InsPnt(2) = 0.0#
    '    'アクティブレイヤーの変更
    '    Call SetActiveLayer("自動作成")
    '    'Chk = FunInsertBlock(CAB_Block, insPnt(0), insPnt(1), insPnt(2), 1#, 1#, 0#, "基礎")
    '    '2002対応の為修正↓ '04.3.18 松本
    '    'Set BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + CAB_Block + EndString, 1, 1, 0)
    '    BlkObj = AncBlk.InsertBlock(InsPnt, BlockPath3 + CAB_Block + EndString, 1, 1, 1, 0)
    'End Sub


    '
    '「アンカーボルト位置」ブロック挿入
    '
    Public Sub BlkANCIti()
        Dim Chk As Object
        Dim Blk As String

        Blk = "K_ANKA_ITI_" & sScale      'ブロック名

        InsPnt(0) = SetScale(KM_ZahyoX, sScale) - 110
        InsPnt(1) = SetScale(KM_ZahyoY - HconDou12, sScale)
        InsPnt(2) = 0

        Chk = FunInsertBlock(Blk, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")

    End Sub



    Public Sub L_1125(ByVal ANC_Offset As Integer)
        'アンカーボルト配置位置計算
        ANC_CHK = Add_ANC + 2
        Select Case ANC_CHK
            Case "2" '２点留めの場合
                ANC(1) = SPO + ANC_Offset
                ANC(2) = EPO - ANC_Offset
                ANC(3) = EPO
            Case "3"  '３点留めの場合
                ANC(1) = SPO + ANC_Offset
                ANC(2) = (SPO + EPO) / 2
                ANC(3) = EPO - ANC_Offset
                ANC(4) = EPO
            Case "4"  '４点留めの場合
                ES = Int((ES / 3 + 5) / 10) * 10
                ANC(1) = SPO + ANC_Offset
                ANC(2) = SPO + ES + ANC_Offset
                ANC(3) = EPO - ES - ANC_Offset
                ANC(4) = EPO - ANC_Offset
                ANC(5) = EPO
            Case "5"  '５点留めの場合
                ANC(1) = SPO + ANC_Offset
                ES = Int((ES / 4 + 5) / 10) * 10
                ANC(2) = SPO + ES + ANC_Offset
                ANC(3) = (SPO + EPO) / 2
                ANC(4) = EPO - ES - ANC_Offset
                ANC(5) = EPO - ANC_Offset
                ANC(6) = EPO
        End Select
    End Sub

    Public Sub L_7500(ByVal ANC_Offset As Integer, ByVal BNKT As Integer, ByVal cnt As Integer)

        Dim L_P_1 As Integer = 0
        Dim L_P_2 As Integer = 0
        Dim H_P_1 As Integer = 0
        Dim H_P_2 As Integer = 0
        Dim M1 As Integer, M2 As Integer, M3 As Integer
        Dim S_Cnt As Integer
        Dim Hosei_Error As Integer
        Const Limit_ANC_Pitch As Integer = 1400

        S_Cnt = CalPosition(Trim(BunkatuSE(cnt, 0))) '対象箱の配列内位置（開始箱）
        'アンカーボルト微調整
        For M1 = 2 To ANC_CHK - 1 '比較対象となる仮アンカの位置配列（両端除く）
            For M2 = S_Cnt To BNKT - 1 '対象となる分割領域の箱座標の配列
                For M3 = 0 To 2
                    If ANC(M1) = KM_Box_Right(M2, M3) Then
                        GoTo LoopM1
                    End If
                    If ANC(M1) > KM_Box_Right(M2, M3) Then
                        L_P_1 = M2
                        L_P_2 = M3
                    End If
                    If ANC(M1) < KM_Box_Right(M2, M3) Then
                        H_P_1 = M2
                        H_P_2 = M3
                        GoTo L_7900
                        GoTo LoopM1
                    End If
                Next M3
            Next M2
LoopM1:
        Next M1
        Return
L_7900:
        Hosei_Error = 0
        If KM_Box_Right(H_P_1, H_P_2) - ANC(M1 - 1) <= Limit_ANC_Pitch Then
            GoTo L_7950
        End If
        If KM_Box_Right(L_P_1, L_P_2) = 0 Then
            Hosei_Error = 1
            Return
        End If
        ANC(M1) = KM_Box_Right(L_P_1, L_P_2)
        Return
L_7950:
        If KM_Box_Right(H_P_1, H_P_2) = 0 Then
            Hosei_Error = 1
            Return
        End If
        ANC(M1) = KM_Box_Right(H_P_1, H_P_2)
        Return
    End Sub

    Public Sub SetLevelDim(ByVal Level As String, ByVal T_Type As String, ByVal H_Level As Double, ByVal R_level As Double, ByVal DistX As Double)
        '-----------------------------------------------
        '寸法表示（Ｗ方向）
        '-----------------------------------------------
        '   Level     : 寸法記入位置レベル(ex "Level1")
        '   T_Type    : 1ページ内に箱に位置(ex 左側)
        '   H_Level   : 寸法記入位置補正値(ex 28)
        '   R_level   : 右側用補正数値
        '-----------------------------------------------
        Dim CSD_Lin_Obj As AcadDimAligned
        Dim i As Integer

        Select Case Level
            Case "Level0"
                Select Case T_Type
                    Case "左側"
                        Call Sunpo_0_L(H_Level, DistX)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS0, KM_insPntE0, KM_insPnt0)
                    Case "右側"
                        Call Sunpo_0_R(H_Level, DistX)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS0, KM_insPntE0, KM_insPnt0)
                End Select
            Case "Level1"
                Select Case T_Type
                    Case "最左端"
                        Call Sunpo_1_L(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS1, KM_insPntE1, KM_insPnt1)
                    Case "中間左"
                        Call Sunpo_1_CL(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS1, KM_insPntE1, KM_insPnt1)
                    Case "中間"
                        Call Sunpo_1_C(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS1, KM_insPntE1, KM_insPnt1)
                    Case "最右端"
                        Call Sunpo_1_R(H_Level, R_level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS1, KM_insPntE1, KM_insPnt1)
                End Select
            Case "Level2"
                Select Case T_Type
                    Case "最左端"
                        Call Sunpo_2_L(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS2, KM_insPntE2, KM_insPnt2)
                    Case "中間左"
                        Call Sunpo_2_CL(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS2, KM_insPntE2, KM_insPnt2)
                    Case "中間"
                        Call Sunpo_2_C(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS2, KM_insPntE2, KM_insPnt2)
                    Case "最右端"
                        Call Sunpo_2_R(H_Level, R_level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS2, KM_insPntE2, KM_insPnt2)
                        If AncMFlg = True Then
                            KM_insPntE2(0) = InsPnt(0) + R_level
                            KM_insPntS2(0) = InsPnt(0)
                        End If
                End Select
            Case "Level3"
                Select Case T_Type
                    Case "最左端"
                        Call Sunpo_3_L(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS3, KM_insPntE3, KM_insPnt3)
                    Case "中間"
                        Call Sunpo_3_C(H_Level)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS3, KM_insPntE3, KM_insPnt3)
                    Case "最右端"
                        i = 1
                        Call Sunpo_3_R(H_Level, R_level, i)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS3, KM_insPntE3, KM_insPnt3)
                        If oneboxflg = True Then    '1箱のみの場合
                            Exit Select
                        End If
                        i = 2
                        Call Sunpo_3_R(H_Level, R_level, i)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS3, KM_insPntE3, KM_insPnt3)
                End Select
            Case "Level4"
                Select Case T_Type
                    Case "左側"
                        Call Sunpo_4_L(H_Level, DistX)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS0, KM_insPntE0, KM_insPnt0)
                    Case "右側"
                        Call Sunpo_4_R(H_Level, R_level, DistX)
                        CSD_Lin_Obj = moSpace.AddDimAligned(KM_insPntS0, KM_insPntE0, KM_insPnt0)
                End Select
        End Select
    End Sub

    Public Sub Sunpo_0_L(ByVal H_Level As Double, ByVal DistX As Double)
        '寸法記入位置レベル0、左側

        KM_insPntS0(0) = InsPnt(0)
        KM_insPntS0(1) = InsPnt(1)
        KM_insPntS0(2) = 0.0#
        KM_insPntE0(0) = InsPnt(0) - DistX
        KM_insPntE0(1) = InsPnt(1)
        KM_insPntE0(2) = 0.0#
        KM_insPnt0(0) = (KM_insPntE0(0) - KM_insPntS0(0)) / 2
        KM_insPnt0(1) = InsPnt(1) + H_Level * sScale
        KM_insPnt0(2) = 0.0#
    End Sub

    Public Sub Sunpo_0_R(ByVal H_Level As Double, ByVal DistX As Double)
        '寸法記入位置レベル0、右側

        KM_insPntS0(0) = InsPnt(0)
        KM_insPntS0(1) = InsPnt(1)
        KM_insPntS0(2) = 0.0#
        KM_insPntE0(0) = InsPnt(0) + DistX
        KM_insPntE0(1) = InsPnt(1)
        KM_insPntE0(2) = 0.0#
        KM_insPnt0(0) = (KM_insPntE0(0) - KM_insPntS0(0)) / 2
        KM_insPnt0(1) = InsPnt(1) + H_Level * sScale
        KM_insPnt0(2) = 0.0#
    End Sub

    Public Sub Sunpo_1_L(ByVal H_Level As Double)
        '寸法記入位置レベル1、最左端

        KM_insPntS1(0) = InsPnt(0)
        KM_insPntS1(1) = InsPnt(1)
        KM_insPntS1(2) = 0.0#
        KM_insPntE1(0) = SetScale(KM_ZahyoX, sScale)
        KM_insPntE1(1) = InsPnt(1)
        KM_insPntE1(2) = 0.0#
        KM_insPnt1(0) = KM_insPntS1(0) + (KM_insPntE1(0) - KM_insPntS1(0)) / 2
        KM_insPnt1(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt1(2) = 0.0#
    End Sub

    Public Sub Sunpo_1_CL(ByVal H_Level As Double)
        '寸法記入位置レベル1、中間左

        KM_insPntS1(0) = KM_insPntS1(0)
        KM_insPntS1(1) = KM_insPntS1(1)
        KM_insPntS1(2) = 0.0#
        KM_insPntE1(0) = InsPnt(0)
        KM_insPntE1(1) = InsPnt(1)
        KM_insPntE1(2) = 0.0#
        KM_insPnt1(0) = KM_insPntS1(0) + (KM_insPntE1(0) - KM_insPntS1(0)) / 2
        KM_insPnt1(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt1(2) = 0.0#
    End Sub

    Public Sub Sunpo_1_C(ByVal H_Level As Double)
        '寸法記入位置レベル1、中央

        KM_insPntS1(0) = KM_insPntE1(0)
        KM_insPntS1(1) = KM_insPntE1(1)
        KM_insPntS1(2) = 0.0#
        KM_insPntE1(0) = InsPnt(0)
        KM_insPntE1(1) = InsPnt(1)
        KM_insPntE1(2) = 0.0#
        KM_insPnt1(0) = KM_insPntS1(0) + (KM_insPntE1(0) - KM_insPntS1(0)) / 2
        KM_insPnt1(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt1(2) = 0.0#
    End Sub

    Public Sub Sunpo_1_R(ByVal H_Level As Double, ByVal R_level As Double)
        '寸法記入位置レベル1、最右端

        KM_insPntE1(0) = InsPnt(0) + R_level
        KM_insPntE1(1) = InsPnt(1)
        KM_insPntE1(2) = 0.0#
        KM_insPntS1(0) = InsPnt(0)
        KM_insPntS1(1) = InsPnt(1)
        KM_insPntS1(2) = 0.0#
        KM_insPnt1(0) = KM_insPntS1(0) + (KM_insPntE1(0) - KM_insPntS1(0)) / 2
        KM_insPnt1(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt1(2) = 0.0#
    End Sub

    Public Sub Sunpo_2_L(ByVal H_Level As Double)
        '寸法記入位置レベル2、最左端

        KM_insPntS2(0) = SetScale(KM_ZahyoX, sScale)
        KM_insPntS2(1) = InsPnt(1)
        KM_insPntS2(2) = 0.0#
        KM_insPntE2(0) = InsPnt(0)
        KM_insPntE2(1) = InsPnt(1)
        KM_insPntE2(2) = 0.0#
        KM_insPnt2(0) = KM_insPntS2(0) + (KM_insPntE2(0) - KM_insPntS2(0)) / 2
        KM_insPnt2(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt2(2) = 0.0#
    End Sub

    Public Sub Sunpo_2_CL(ByVal H_Level As Double)
        '寸法記入位置レベル2、中間左

        KM_insPntS2(0) = KM_insPntS2(0)
        KM_insPntS2(1) = KM_insPntS2(1)
        KM_insPntS2(2) = 0.0#
        KM_insPntE2(0) = InsPnt(0)
        KM_insPntE2(1) = InsPnt(1)
        KM_insPntE2(2) = 0.0#
        KM_insPnt2(0) = KM_insPntS2(0) + (KM_insPntE2(0) - KM_insPntS2(0)) / 2
        KM_insPnt2(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt2(2) = 0.0#
    End Sub

    Public Sub Sunpo_2_C(ByVal H_Level As Double)
        '寸法記入位置レベル2、中央
        KM_insPntS2(0) = KM_insPntE2(0)
        KM_insPntS2(1) = KM_insPntE2(1)
        KM_insPntS2(2) = 0.0#
        KM_insPntE2(0) = InsPnt(0)
        KM_insPntE2(1) = InsPnt(1)
        KM_insPntE2(2) = 0.0#
        KM_insPnt2(0) = KM_insPntS2(0) + (KM_insPntE2(0) - KM_insPntS2(0)) / 2
        KM_insPnt2(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt2(2) = 0.0#
    End Sub

    Public Sub Sunpo_2_R(ByVal H_Level As Double, ByVal R_level As Double)
        '寸法記入位置レベル2、最右端

        If AncMFlg = False Then             '寸法値の文字が寸法線間に入らなかった場合に右に表示(アンカーボルトの寸法値を左右に分けないと重なるので)
            KM_insPntE2(0) = InsPnt(0) + R_level
            KM_insPntS2(0) = InsPnt(0)
        Else
            KM_insPntE2(0) = InsPnt(0)
            KM_insPntS2(0) = InsPnt(0) + R_level
        End If
        KM_insPntE2(1) = InsPnt(1)
        KM_insPntE2(2) = 0.0#
        KM_insPntS2(1) = InsPnt(1)
        KM_insPntS2(2) = 0.0#
        KM_insPnt2(0) = KM_insPntS2(0) + (KM_insPntE2(0) - KM_insPntS2(0)) / 2
        KM_insPnt2(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt2(2) = 0.0#
    End Sub

    Public Sub Sunpo_3_L(ByVal H_Level As Double)
        '寸法記入位置レベル3、最左端

        KM_insPntS3(0) = SetScale(KM_ZahyoX, sScale)
        KM_insPntS3(1) = SetScale(KM_ZahyoY, sScale)
        KM_insPntS3(2) = 0.0#
        KM_insPntE3(0) = insPntS(0)
        KM_insPntE3(1) = KM_insPntS3(1)
        KM_insPntE3(2) = 0.0#
        KM_insPnt3(0) = KM_insPntS3(0) + (KM_insPntE3(0) - KM_insPntS3(0)) / 2
        KM_insPnt3(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt3(2) = 0.0#
    End Sub

    Public Sub Sunpo_3_C(ByVal H_Level As Double)
        '寸法記入位置レベル3、中央

        KM_insPntS3(0) = KM_insPntE3(0)
        KM_insPntS3(1) = KM_insPntE3(1)
        KM_insPntS3(2) = 0.0#
        KM_insPntE3(0) = insPntS(0)
        KM_insPntE3(1) = KM_insPntS3(1)
        KM_insPntE3(2) = 0.0#
        KM_insPnt3(0) = KM_insPntS3(0) + (KM_insPntE3(0) - KM_insPntS3(0)) / 2
        KM_insPnt3(1) = SetScale(KM_ZahyoY - H_Level, sScale)
        KM_insPnt3(2) = 0.0#
    End Sub

    Public Sub Sunpo_3_R(ByVal H_Level As Double, ByVal R_level As Double, ByVal i As Integer)
        '寸法記入位置レベル3、最右端

        If i = 1 Then
            KM_insPntS3(0) = KM_insPntE3(0)
            KM_insPntS3(1) = KM_insPntE3(1)
            KM_insPntS3(2) = 0.0#
            KM_insPntE3(0) = insPntS(0)
            KM_insPntE3(1) = KM_insPntS3(1)
            KM_insPntE3(2) = 0.0#
            KM_insPnt3(0) = KM_insPntS3(0) + (KM_insPntE3(0) - KM_insPntS3(0)) / 2
            KM_insPnt3(1) = SetScale(KM_ZahyoY - H_Level, sScale)
            KM_insPnt3(2) = 0.0#
        ElseIf i = 2 Then
            KM_insPntS3(0) = KM_insPntE3(0)
            KM_insPntS3(1) = KM_insPntE3(1)
            KM_insPntS3(2) = 0.0#
            KM_insPntE3(0) = insPntS(0) + R_level
            KM_insPntE3(1) = KM_insPntS3(1)
            KM_insPntE3(2) = 0.0#
            KM_insPnt3(0) = KM_insPntS3(0) + (KM_insPntE3(0) - KM_insPntS3(0)) / 2
            KM_insPnt3(1) = SetScale(KM_ZahyoY - H_Level, sScale)
            KM_insPnt3(2) = 0.0#
        End If
    End Sub

    Public Sub Sunpo_4_L(ByVal H_Level As Double, ByVal DistX As Double)
        '寸法記入位置レベル4、左側

        KM_insPntS0(0) = InsPnt(0)
        KM_insPntS0(1) = InsPnt(1)
        KM_insPntS0(2) = 0.0#
        KM_insPntE0(0) = InsPnt(0) - DistX
        KM_insPntE0(1) = InsPnt(1)
        KM_insPntE0(2) = 0.0#
        KM_insPnt0(0) = (KM_insPntE0(0) - KM_insPntS0(0)) / 2
        KM_insPnt0(1) = InsPnt(1) - H_Level * sScale
        KM_insPnt0(2) = 0.0#
    End Sub

    Public Sub Sunpo_4_R(ByVal H_Level As Double, ByVal R_level As Double, ByVal DistX As Double)
        '寸法記入位置レベル4、右側

        KM_insPntS0(0) = InsPnt(0)
        KM_insPntS0(1) = InsPnt(1)
        KM_insPntS0(2) = 0.0#
        KM_insPntE0(0) = InsPnt(0) + DistX
        KM_insPntE0(1) = InsPnt(1)
        KM_insPntE0(2) = 0.0#
        KM_insPnt0(0) = (KM_insPntE0(0) - KM_insPntS0(0)) / 2
        KM_insPnt0(1) = InsPnt(1) - H_Level * sScale
        KM_insPnt0(2) = 0.0#
    End Sub

    Public Sub SetLevelDimD(ByVal T_Level As String, ByVal i As Integer)
        '-----------------------------------------------
        'Ｄ方向寸法表示
        '-----------------------------------------------
        '   T_Level     : 寸法表示位置レベル(ex "Level1")
        '   i           : 表示対象となる箱の配列内の位置(ex 1)
        '-----------------------------------------------

        Dim Tmp1 As Double, Tmp2 As Double, Tmp3 As Double

        Dim CSD_Lin_Obj As AcadDimAligned

        Select Case T_Level
            Case "Level1" 'アンカーボルト用
                Tmp1 = HconDou8
                Tmp2 = HconDou22
                Tmp3 = HconDou7
            Case "Level2" '締付穴用
                Tmp1 = HconDou19
                Tmp2 = HconDou23
                Tmp3 = HconDou17
            Case "Level3" '全長用
                Tmp1 = 0.0#
                Tmp2 = 0.0#
                Tmp3 = HconDou18
        End Select
        insPntS(0) = SetScale(KM_ZahyoX + (Tmp1 / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY + (Tmp2 / sScale), sScale)
        insPntS(2) = 0.0#
        insPntE(0) = insPntS(0)
        insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(i)) / sScale) - (Tmp2 / sScale), sScale)
        insPntE(2) = 0.0#
        InsPnt(0) = SetScale(KM_ZahyoX - Tmp3, sScale)
        InsPnt(1) = (insPntE(1) - insPntS(1)) / 2
        InsPnt(2) = 0.0#
        CSD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        If T_Level <> "Level3" Then
            insPntE(1) = SetScale(KM_ZahyoY, sScale)
            CSD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)

            insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(i)) / sScale) - (Tmp2 / sScale), sScale)
            insPntE(0) = SetScale(KM_ZahyoX + (Tmp1 / sScale), sScale)
            insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(i)) / sScale), sScale)
            CSD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        End If
    End Sub



    Public Sub ClearKMHairetu()
        '-----------------------------------------------
        '基礎図用配列の初期化
        '-----------------------------------------------
        Dim i As Integer, J As Integer

        For i = 0 To 100
            For J = 0 To 2
                KM_Box_Right(i, J) = 0
            Next J
        Next i

        For i = 0 To conNum
            KM_BaseBunkatu(i) = ""
        Next i

        For i = 0 To 20
            For J = 0 To 1
                BunkatuSE(i, J) = ""
            Next J
        Next i

        For i = 0 To 10
            For J = 0 To 1
                PageSE(i, J) = ""
            Next J
        Next i

        For i = 0 To 10
            For J = 0 To conNum
                PageSEHakoNo(i, J) = ""
            Next J
        Next i

    End Sub

    '
    'A部詳細参照・B部詳細参照ﾌﾞﾛｯｸを挿入する位置(CUB.番号)を取得
    '（A部：取得したCUB.の右側　B部：取得したCUB.の左側）
    '
    Public Sub GetShosaiCub()
        Dim CubNum As Integer   'CUB.数
        Dim BCnt As Integer     'B部詳細ﾌﾞﾛｯｸ位置ｶｳﾝﾀｰ
        Dim ACnt As Integer     'A部詳細ﾌﾞﾛｯｸ位置ｶｳﾝﾀｰ

        'CUB.数取得
        CubNum = 0
        While CubNo(CubNum) <> ""
            CubNum = CubNum + 1
        End While
        If CubNum <> 0 Then CubNum = CubNum - 1
        'B部詳細ﾌﾞﾛｯｸ位置取得
        BCnt = 0
        While BaseCubNo(BCnt) = CubNo(BCnt)
            BCnt = BCnt + 1
            If BCnt > CubNum Then '全て納入外の場合
                BShosai = CubNo(0)
                AShosai = CubNo(CubNum)
                Exit Sub
            End If
        End While
        BShosai = CubNo(BCnt)
        'A部詳細ﾌﾞﾛｯｸ位置取得
        ACnt = BCnt + 1
        While BaseCubNo(BCnt) <> CubNo(ACnt)
            ACnt = ACnt + 1
        End While
        AShosai = CubNo(ACnt - 1)
    End Sub

    Public Sub CalPage()
        '-----------------------------------------------
        '必要なページ数を計算(基礎用）
        '-----------------------------------------------
        'Dim ChkFlag As String   '納入外基礎ベースNoをベース分割に追加したかどうか用
        ''="in" 追加した
        ''="" 追加してない

        Dim i As Integer, j As Integer, k As Integer

        ChkFlag = ""
        '納入外基礎ベースNoをベース分割と見なす
        Call SetTmpBaseBunkatu(ChkFlag)

        '分割位置指示が有るかどうかチェック

        If (BaseBunkatu(0) <> "") Then  '分割有り＆追加なし,分割有り＆追加あり
            Call CalPage_Manual(ChkFlag)
        Else  '分割なし＆追加なし,'分割なし＆追加あり
            Call CalPage_Auto("Auto", ChkFlag)
        End If


        '箱Noを配列内に羅列する
        i = 1
        k = 0
        Do Until (PageSE(i, 0) = "")
            j = 1
            Do Until (PageSE(i, 1) = CubNo(k))
                PageSEHakoNo(i, j) = CubNo(k)
                j = j + 1
                k = k + 1
            Loop
            PageSEHakoNo(i, j) = CubNo(k)
            k = k + 1
            i = i + 1
        Loop
    End Sub

    Public Sub CalPage_Manual(ByVal FChk As String)
        '-----------------------------------------------
        '指定された分割が制限に引っ掛からないかどうかチェック
        '-----------------------------------------------
        '   FChk      :納入外基礎ベースNoをベース分割に追加したかどうか用
        '               ="in" 追加した
        '               ="" 追加してない
        '-----------------------------------------------

        'Dim i As Integer, J As Integer, k As Integer, L As Integer       'ループ変数
        Dim BCnt As Integer, Pcnt As Integer '分割及びページカウンター
        'Dim Cnt As Integer, Total_Len As Integer
        Dim Chk As String
        Dim Msg1 As String, Msg2 As String
        Const Style = vbCritical + vbOKOnly
        Const Title = "分割制限エラー"

        Msg1 = "１つの分割内の箱数が多すぎます。（=最大５箱）" & Chr(13) & Chr(10) & _
               "対象箱範囲は"
        Msg2 = "１つの分割内の箱幅が長すぎます。（=最大" & Limit_Bunkatu & "mm）" & Chr(13) & Chr(10) & _
               "対象箱範囲は"
        'Msg2 = "１つの分割内の箱幅が長すぎます。（=最大4000mm）" & Chr(13) & Chr(10) & _
        '       "対象箱範囲は"


        BCnt = 1
        Pcnt = 1
        Chk = ""

        '箱の分割、分割制限エラー有無の判断
        Call Bunkatu(BCnt, Style, Title, Msg1, Msg2, FChk)


    End Sub

    Public Sub Bunkatu(ByVal BCnt As Integer, ByVal Style As String, ByVal Title As String, ByVal Msg1 As String, ByVal Msg2 As String, ByVal FChk As String)
        Dim i As Integer, J As Integer, k As Integer, L As Integer, m As Integer, n As Integer       'ループ変数
        Dim a As Integer
        Dim Total_Len As Integer, Total_Len_old As Integer, Total_Len_half As Integer, Total_Len2 As Integer
        Dim Dist As Integer
        Dim num As Integer          '分割を入れる箱No
        Dim Cnt As Integer, Cnt2 As Integer
        Dim Chk As String
        i = 0

        Do Until (KM_BaseBunkatu(i) = "")
            If i = 0 Then '一つ目の分割箱No
                

                J = 0
                Cnt = 1
                Total_Len = 0
                Total_Len_old = 0
                Total_Len_half = 0
                Total_Len2 = 0
                'Mod by khn 99-11-1
                BunkatuSE(BCnt, 0) = CubNo(0) '１つ目の分割の最初の箱No
                Do Until (CubNo(J) = KM_BaseBunkatu(i))
                    '長さ計算
                    If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then    '箱の全長が指定の最大分割位置以上か、箱の数が５より多いなら、
                        If P_sBanDat(J, pc_NoKisoRow) = "納入外（表示）" And CubNo(J) <> KM_BaseBunkatu(i) Then   '将来は分割しない
                            Cnt = Cnt + 1
                            Total_Len = Total_Len + Val(H_W(J))

                            BunkatuSE(BCnt, 1) = CubNo(J)
                        ElseIf P_sBanDat(J, pc_NoKisoRow) = "納入外（表示）" And CubNo(J) = KM_BaseBunkatu(i) Then    '将来かつ分割指示があるなら
                            If J <> 1 Then
                                J = J - 1
                                BunkatuSE(BCnt, 1) = CubNo(J)
                            End If
                            BCnt = BCnt + 1
                            BunkatuSE(BCnt, 0) = CubNo(J)
                            Total_Len = Val(H_W(J))
                            'Total_Len = 0
                            Cnt = 1
                        Else
                            For n = 0 To BaseCubNo.Length - 1
                                If CubNo(J) = BaseCubNo(n) And J <> UBound(P_sBanDat, 1) Then
                                    Exit For
                                ElseIf n = BaseCubNo.Length - 1 Then
                                    'If J = 0 Then
                                    '    BunkatuSE(BCnt, 1) = CubNo(0)
                                    'Else
                                    '    J = J - 1
                                    '    BunkatuSE(BCnt, 1) = CubNo(J)
                                    'End If
                                    J = J - 1
                                    'If J <> 1 Then
                                    If J <> 0 Then
                                        'J = J - 1
                                        BunkatuSE(BCnt, 1) = CubNo(J)
                                    End If
                                    J = J + 1
                                    BCnt = BCnt + 1
                                    BunkatuSE(BCnt, 0) = CubNo(J)
                                    Total_Len = Val(H_W(J))
                                    'Total_Len = 0
                                    Cnt = 1

                                End If
                            Next
                        End If

                    Else
                        Cnt = Cnt + 1
                        Total_Len = Total_Len + Val(H_W(J))

                        BunkatuSE(BCnt, 1) = CubNo(J)
                        ''BZencyo = BZencyo + H_W(I + 1)
                        'If i <> 0 Then Total_Len = Total_Len + Val(H_W(i)) 'i=0は既にBZencyoにｾｯﾄしてある為
                        'Cnt = Cnt + 1
                    End If
                    J = J + 1


                Loop

                '分割データの配列へのセット
                'BunkatuSE(BCnt, 0) = CubNo(0) '１つ目の分割の最初の箱No
                Total_Len = Total_Len + Val(H_W(J))
                If BCnt = 1 Then    '途中で自動分割がなかったときの処理
                    If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then   '分割位置に問題があるなら
                        If P_sBanDat(J, pc_NoKisoRow) = "納入外（表示）" And CubNo(J) <> KM_BaseBunkatu(i) Then   '将来は分割しない
                            Cnt = Cnt + 1
                            Total_Len = Total_Len + Val(H_W(J))

                            BunkatuSE(BCnt, 1) = CubNo(J)
                        ElseIf P_sBanDat(J, pc_NoKisoRow) = "納入外（表示）" And CubNo(J) = KM_BaseBunkatu(i) Then    '将来かつ分割指示があるなら
                            'BunkatuSE(BCnt, 1) = CubNo(J)
                            'BCnt = BCnt + 1
                            'BunkatuSE(BCnt, 0) = CubNo(J + 1)
                            'J = J + 1
                            'Total_Len = Val(H_W(J + 1))
                            'Cnt = 1
                        Else
                            BunkatuSE(BCnt, 1) = CubNo(J - 1)
                            BCnt = BCnt + 1
                            BunkatuSE(BCnt, 0) = CubNo(J)
                            Total_Len = Val(H_W(J))
                            Cnt = 1
                        End If

                        
                    End If
                Else
                    'Total_Len = Total_Len + Val(H_W(J))
                End If

                BunkatuSE(BCnt, 1) = CubNo(J) '１つ目の分割の最後の箱No
                BCnt = BCnt + 1
                BunkatuSE(BCnt, 0) = CubNo(J + 1)
                L = J
            Else  '二つ目以降の分割箱No
                ' 箱番号から配列内の保管場所Noを取得する
                J = 0
                k = 0
                m = 0
                Do Until (CubNo(J) = "") '開始場所
                    If CubNo(J) = KM_BaseBunkatu(i - 1) Then
                        k = J + 1
                        m = k
                        Exit Do
                    End If
                    J = J + 1
                Loop
                J = 0
                L = 0
                Do Until (CubNo(J) = "")  '終了場所
                    If CubNo(J) = KM_BaseBunkatu(i) Then
                        L = J
                        Exit Do
                    End If
                    J = J + 1
                Loop
                Cnt = 1
                Total_Len = 0
                For J = k To L      '予定分割点間の開始箱から終了箱まで
                    If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then    '箱の全長が指定の最大分割位置以上か、箱の数が５より多いなら、
                        If P_sBanDat(J, pc_NoKisoRow) <> "納入外（表示）" Or CubNo(J) = KM_BaseBunkatu(i) Then   '将来は分割しない
                            If J = k Then
                                BunkatuSE(BCnt, 1) = CubNo(J)
                            ElseIf J = L And P_sBanDat(J, pc_NoKisoRow) = "納入外（表示）" Then
                                BunkatuSE(BCnt, 1) = CubNo(J)
                                Call CalPage_Auto("Manual", FChk)
                                Exit Sub
                            Else
                                J = J - 1
                                m = J
                                BunkatuSE(BCnt, 1) = CubNo(J - 1)
                            End If
                            BunkatuSE(BCnt, 0) = CubNo(k)
                            BCnt = BCnt + 1
                            BunkatuSE(BCnt, 0) = CubNo(J)
                            Total_Len = Val(H_W(J))
                            'Total_Len = 0
                            Cnt = 1
                        End If
                        
                    Else
                        Cnt = Cnt + 1
                        Total_Len = Total_Len + Val(H_W(J))

                        BunkatuSE(BCnt, 1) = CubNo(J)
                        ''BZencyo = BZencyo + H_W(I + 1)
                        'If i <> 0 Then Total_Len = Total_Len + Val(H_W(i)) 'i=0は既にBZencyoにｾｯﾄしてある為
                        'Cnt = Cnt + 1
                    End If
                Next
                If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then
                    Do Until (BaseCubNo(a) = "")
                        a = a + 1
                    Loop
                    a = a - 1
                    If a = -1 Then                              '納入外がない場合
                        BunkatuSE(BCnt, 0) = CubNo(m) '２つ目以降の分割の最初の箱No
                        BunkatuSE(BCnt, 1) = CubNo(L - 1) '２つ目以降の分割の最後の箱No
                        BCnt = BCnt + 1
                        BunkatuSE(BCnt, 0) = CubNo(L) '２つ目以降の分割の最初の箱No
                        BunkatuSE(BCnt, 1) = CubNo(L) '２つ目以降の分割の最後の箱No
                        BCnt = BCnt + 1
                        Total_Len = Val(H_W(J))
                        Cnt = 1
                    Else
                        For n = 0 To a
                            If CubNo(J - 1) = BaseCubNo(n) And J - 1 <> UBound(P_sBanDat, 1) + 1 Then
                                BunkatuSE(BCnt, 0) = CubNo(m) '２つ目以降の分割の最初の箱No
                                Exit For
                            ElseIf n = a Then
                                BunkatuSE(BCnt, 0) = CubNo(m) '２つ目以降の分割の最初の箱No
                                BunkatuSE(BCnt, 1) = CubNo(L - 1) '２つ目以降の分割の最後の箱No
                                BCnt = BCnt + 1
                                BunkatuSE(BCnt, 0) = CubNo(L) '２つ目以降の分割の最初の箱No
                                BunkatuSE(BCnt, 1) = CubNo(L) '２つ目以降の分割の最後の箱No
                                BCnt = BCnt + 1
                                Total_Len = Val(H_W(J - 1))
                                Cnt = 1

                            End If
                        Next
                    End If
                Else
                    '分割データの配列へのセット
                    'BCnt = BCnt + 1
                    BunkatuSE(BCnt, 0) = CubNo(m) '２つ目以降の分割の最初の箱No
                    BunkatuSE(BCnt, 1) = CubNo(L) '２つ目以降の分割の最後の箱No
                    BCnt = BCnt + 1
                End If


            End If


            '以前までの
            'Do Until (KM_BaseBunkatu(i) = "")
            '    If i = 0 Then '一つ目の分割箱No
            '        J = 0
            '        Cnt = 1
            '        Total_Len = 0
            '        'Mod by khn 99-11-1
            '        Do Until (CubNo(J) = KM_BaseBunkatu(i))
            '            '      Do Until (Val(j) = KM_BaseBunkatu(i))
            '            '-------
            '            '長さ計算
            '            Cnt = Cnt + 1
            '            Total_Len = Total_Len + Val(H_W(J))
            '            J = J + 1
            '        Loop
            '        Total_Len = Total_Len + Val(H_W(J))
            '        '分割データの配列へのセット
            '        BunkatuSE(BCnt, 0) = CubNo(0) '１つ目の分割の最初の箱No
            '        BunkatuSE(BCnt, 1) = CubNo(J) '１つ目の分割の最後の箱No
            '        L = J
            '    Else  '二つ目以降の分割箱No
            '        ' 箱番号から配列内の保管場所Noを取得する
            '        J = 0
            '        k = 0
            '        Do Until (CubNo(J) = "") '開始場所
            '            If CubNo(J) = KM_BaseBunkatu(i - 1) Then
            '                k = J + 1
            '                Exit Do
            '            End If
            '            J = J + 1
            '        Loop
            '        J = 0
            '        L = 0
            '        Do Until (CubNo(J) = "")  '終了場所
            '            If CubNo(J) = KM_BaseBunkatu(i) Then
            '                L = J
            '                Exit Do
            '            End If
            '            J = J + 1
            '        Loop
            '        Cnt = 0
            '        Total_Len = 0
            '        For J = k To L
            '            Cnt = Cnt + 1
            '            Total_Len = Total_Len + Val(H_W(J))
            '        Next
            '        '分割データの配列へのセット
            '        BCnt = BCnt + 1
            '        BunkatuSE(BCnt, 0) = CubNo(k) '２つ目以降の分割の最初の箱No
            '        BunkatuSE(BCnt, 1) = CubNo(L) '２つ目以降の分割の最後の箱No
            '    End If

            '    '判断

            '    '箱数制限をチェック
            '    If (Cnt > Limit_Hako) Then
            '        MsgBox(Msg1 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
            '        Chk = "エラー"
            '    End If
            '    '全長制限ををチェック
            '    If (Total_Len > Limit_Bunkatu) Then
            '        MsgBox(Msg2 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
            '        Chk = "エラー"
            '    End If
            '    i = i + 1
            'Loop


            '判断

            ''箱数制限をチェック
            'If (Cnt > Limit_Hako) Then
            '    MsgBox(Msg1 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
            '    MsgBox("指定範囲内の分割を自動で追加します。", , Title)
            '    'J = 0
            '    'Cnt = 1
            '    'Do Until (Cnt > Limit_Hako)
            '    '    Total_Len_half = Total_Len / 2
            '    '    If i = 0 Then           '最初の分割処理の場合
            '    '        Do Until (CubNo(J) = KM_BaseBunkatu(i))
            '    '            '長さ計算
            '    '            If Cnt = 1 Then
            '    '                Total_Len2 = Total_Len_old + Val(H_W(J))
            '    '                Dist = System.Math.Abs(Total_Len2 - Total_Len_half)
            '    '                num = CubNo(J)
            '    '            Else
            '    '                Total_Len2 = Total_Len2 + Val(H_W(J))
            '    '                If System.Math.Abs(Total_Len2 - Total_Len_half) <= Dist Then
            '    '                    Dist = System.Math.Abs(Total_Len2 - Total_Len_half)
            '    '                    num = CubNo(J)
            '    '                Else
            '    '                    If Cnt > Limit_Hako Then

            '    '                    End If
            '    '                End If
            '    '            End If
            '    '            Cnt = Cnt + 1
            '    '            J = J + 1
            '    '        Loop

            '    '    Else

            '    '            End If



            '    '        Loop

            '    Chk = "エラー"
            'End If
            ''全長制限ををチェック
            'If (Total_Len > Limit_Bunkatu) Then
            '    MsgBox(Msg2 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
            '    MsgBox("指定範囲内の分割を自動で追加します。", , Title)



            '    Chk = "エラー"
            'End If
            i = i + 1
            Total_Len_old = Total_Len
        Loop









        'Do Until (KM_BaseBunkatu(i) = "")
        '    If i = 0 Then '一つ目の分割箱No


        '        J = 0
        '        Cnt = 1
        '        Total_Len = 0
        '        Total_Len_old = 0
        '        Total_Len_half = 0
        '        Total_Len2 = 0
        '        'Mod by khn 99-11-1
        '        BunkatuSE(BCnt, 0) = CubNo(0) '１つ目の分割の最初の箱No
        '        Do Until (CubNo(J) = KM_BaseBunkatu(i))
        '            '長さ計算
        '            If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then    '箱の全長が指定の最大分割位置以上か、箱の数が５より多いなら、


        '                'If J = 0 Then
        '                '    BunkatuSE(BCnt, 1) = CubNo(0)
        '                'Else
        '                '    J = J - 1
        '                '    BunkatuSE(BCnt, 1) = CubNo(J)
        '                'End If
        '                If J <> 1 Then
        '                    J = J - 1
        '                    BunkatuSE(BCnt, 1) = CubNo(J)
        '                End If
        '                BCnt = BCnt + 1
        '                BunkatuSE(BCnt, 0) = CubNo(J)
        '                Total_Len = Val(H_W(J))
        '                'Total_Len = 0
        '                Cnt = 1


        '            Else
        '                Cnt = Cnt + 1
        '                Total_Len = Total_Len + Val(H_W(J))

        '                BunkatuSE(BCnt, 1) = CubNo(J)
        '                ''BZencyo = BZencyo + H_W(I + 1)
        '                'If i <> 0 Then Total_Len = Total_Len + Val(H_W(i)) 'i=0は既にBZencyoにｾｯﾄしてある為
        '                'Cnt = Cnt + 1
        '            End If
        '            J = J + 1


        '        Loop

        '        '分割データの配列へのセット
        '        'BunkatuSE(BCnt, 0) = CubNo(0) '１つ目の分割の最初の箱No
        '        Total_Len = Total_Len + Val(H_W(J))
        '        If BCnt = 1 Then    '途中で自動分割がなかったときの処理
        '            If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then   '分割位置に問題があるなら
        '                BunkatuSE(BCnt, 1) = CubNo(J - 1)
        '                BCnt = BCnt + 1
        '                BunkatuSE(BCnt, 0) = CubNo(J)
        '                Total_Len = Val(H_W(J))
        '                Cnt = 1
        '            End If
        '        Else
        '            'Total_Len = Total_Len + Val(H_W(J))
        '        End If

        '        BunkatuSE(BCnt, 1) = CubNo(J) '１つ目の分割の最後の箱No
        '        BCnt = BCnt + 1
        '        BunkatuSE(BCnt, 0) = CubNo(J + 1)
        '        L = J
        '    Else  '二つ目以降の分割箱No
        '        ' 箱番号から配列内の保管場所Noを取得する
        '        J = 0
        '        k = 0
        '        m = 0
        '        Do Until (CubNo(J) = "") '開始場所
        '            If CubNo(J) = KM_BaseBunkatu(i - 1) Then
        '                k = J + 1
        '                m = k
        '                Exit Do
        '            End If
        '            J = J + 1
        '        Loop
        '        J = 0
        '        L = 0
        '        Do Until (CubNo(J) = "")  '終了場所
        '            If CubNo(J) = KM_BaseBunkatu(i) Then
        '                L = J
        '                Exit Do
        '            End If
        '            J = J + 1
        '        Loop
        '        Cnt = 1
        '        Total_Len = 0
        '        For J = k To L
        '            If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then    '箱の全長が指定の最大分割位置以上か、箱の数が５より多いなら、
        '                If J = k Then
        '                    BunkatuSE(BCnt, 1) = CubNo(J)
        '                Else

        '                    J = J - 1
        '                    m = J
        '                    BunkatuSE(BCnt, 1) = CubNo(J - 1)
        '                End If
        '                BunkatuSE(BCnt, 0) = CubNo(k)
        '                BCnt = BCnt + 1
        '                BunkatuSE(BCnt, 0) = CubNo(J)
        '                Total_Len = Val(H_W(J))
        '                'Total_Len = 0
        '                Cnt = 1


        '            Else
        '                Cnt = Cnt + 1
        '                Total_Len = Total_Len + Val(H_W(J))

        '                BunkatuSE(BCnt, 1) = CubNo(J)
        '                ''BZencyo = BZencyo + H_W(I + 1)
        '                'If i <> 0 Then Total_Len = Total_Len + Val(H_W(i)) 'i=0は既にBZencyoにｾｯﾄしてある為
        '                'Cnt = Cnt + 1
        '            End If

        '        Next
        '        If (Total_Len > Limit_Bunkatu) Or (Cnt > Limit_Hako) Then
        '            BunkatuSE(BCnt, 0) = CubNo(m) '２つ目以降の分割の最初の箱No
        '            BunkatuSE(BCnt, 1) = CubNo(L - 1) '２つ目以降の分割の最後の箱No
        '            BCnt = BCnt + 1
        '            BunkatuSE(BCnt, 0) = CubNo(L) '２つ目以降の分割の最初の箱No
        '            BunkatuSE(BCnt, 1) = CubNo(L) '２つ目以降の分割の最後の箱No
        '            BCnt = BCnt + 1
        '            Total_Len = Val(H_W(J))
        '            Cnt = 1
        '        Else
        '            '分割データの配列へのセット
        '            'BCnt = BCnt + 1
        '            BunkatuSE(BCnt, 0) = CubNo(m) '２つ目以降の分割の最初の箱No
        '            BunkatuSE(BCnt, 1) = CubNo(L) '２つ目以降の分割の最後の箱No
        '            BCnt = BCnt + 1
        '        End If


        '    End If


        '    '以前までの
        '    'Do Until (KM_BaseBunkatu(i) = "")
        '    '    If i = 0 Then '一つ目の分割箱No
        '    '        J = 0
        '    '        Cnt = 1
        '    '        Total_Len = 0
        '    '        'Mod by khn 99-11-1
        '    '        Do Until (CubNo(J) = KM_BaseBunkatu(i))
        '    '            '      Do Until (Val(j) = KM_BaseBunkatu(i))
        '    '            '-------
        '    '            '長さ計算
        '    '            Cnt = Cnt + 1
        '    '            Total_Len = Total_Len + Val(H_W(J))
        '    '            J = J + 1
        '    '        Loop
        '    '        Total_Len = Total_Len + Val(H_W(J))
        '    '        '分割データの配列へのセット
        '    '        BunkatuSE(BCnt, 0) = CubNo(0) '１つ目の分割の最初の箱No
        '    '        BunkatuSE(BCnt, 1) = CubNo(J) '１つ目の分割の最後の箱No
        '    '        L = J
        '    '    Else  '二つ目以降の分割箱No
        '    '        ' 箱番号から配列内の保管場所Noを取得する
        '    '        J = 0
        '    '        k = 0
        '    '        Do Until (CubNo(J) = "") '開始場所
        '    '            If CubNo(J) = KM_BaseBunkatu(i - 1) Then
        '    '                k = J + 1
        '    '                Exit Do
        '    '            End If
        '    '            J = J + 1
        '    '        Loop
        '    '        J = 0
        '    '        L = 0
        '    '        Do Until (CubNo(J) = "")  '終了場所
        '    '            If CubNo(J) = KM_BaseBunkatu(i) Then
        '    '                L = J
        '    '                Exit Do
        '    '            End If
        '    '            J = J + 1
        '    '        Loop
        '    '        Cnt = 0
        '    '        Total_Len = 0
        '    '        For J = k To L
        '    '            Cnt = Cnt + 1
        '    '            Total_Len = Total_Len + Val(H_W(J))
        '    '        Next
        '    '        '分割データの配列へのセット
        '    '        BCnt = BCnt + 1
        '    '        BunkatuSE(BCnt, 0) = CubNo(k) '２つ目以降の分割の最初の箱No
        '    '        BunkatuSE(BCnt, 1) = CubNo(L) '２つ目以降の分割の最後の箱No
        '    '    End If

        '    '    '判断

        '    '    '箱数制限をチェック
        '    '    If (Cnt > Limit_Hako) Then
        '    '        MsgBox(Msg1 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
        '    '        Chk = "エラー"
        '    '    End If
        '    '    '全長制限ををチェック
        '    '    If (Total_Len > Limit_Bunkatu) Then
        '    '        MsgBox(Msg2 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
        '    '        Chk = "エラー"
        '    '    End If
        '    '    i = i + 1
        '    'Loop


        '    '判断

        '    '箱数制限をチェック
        '    If (Cnt > Limit_Hako) Then
        '        MsgBox(Msg1 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
        '        MsgBox("指定範囲内の分割を自動で追加します。", , Title)
        '        'J = 0
        '        'Cnt = 1
        '        'Do Until (Cnt > Limit_Hako)
        '        '    Total_Len_half = Total_Len / 2
        '        '    If i = 0 Then           '最初の分割処理の場合
        '        '        Do Until (CubNo(J) = KM_BaseBunkatu(i))
        '        '            '長さ計算
        '        '            If Cnt = 1 Then
        '        '                Total_Len2 = Total_Len_old + Val(H_W(J))
        '        '                Dist = System.Math.Abs(Total_Len2 - Total_Len_half)
        '        '                num = CubNo(J)
        '        '            Else
        '        '                Total_Len2 = Total_Len2 + Val(H_W(J))
        '        '                If System.Math.Abs(Total_Len2 - Total_Len_half) <= Dist Then
        '        '                    Dist = System.Math.Abs(Total_Len2 - Total_Len_half)
        '        '                    num = CubNo(J)
        '        '                Else
        '        '                    If Cnt > Limit_Hako Then

        '        '                    End If
        '        '                End If
        '        '            End If
        '        '            Cnt = Cnt + 1
        '        '            J = J + 1
        '        '        Loop

        '        '    Else

        '        '            End If



        '        '        Loop

        '        Chk = "エラー"
        '    End If
        '    '全長制限ををチェック
        '    If (Total_Len > Limit_Bunkatu) Then
        '        MsgBox(Msg2 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
        '        MsgBox("指定範囲内の分割を自動で追加します。", , Title)



        '        Chk = "エラー"
        '    End If
        '    i = i + 1
        '    Total_Len_old = Total_Len
        'Loop
        ''最終分割データの配列へのセット       ←分割指定が1つでもあった場合は、最後の箱も自動で指定分割の対象にしたためコメントアウト
        'If (Chk = "") Then  '指定分割に問題なし
        '    i = 0
        '    Do Until (CubNo(i) = "")
        '        i = i + 1
        '    Loop
        '    'BCnt = BCnt + 1
        '    BunkatuSE(BCnt, 0) = CubNo(L + 1) '最終分割の最初の箱No
        '    BunkatuSE(BCnt, 1) = CubNo(i - 1) '最終分割の最後の箱No
        '    '最終分割のチェック
        '    Cnt = 0
        '    Total_Len = 0
        '    For J = L + 1 To i - 1
        '        Cnt = Cnt + 1
        '        'Total_Len = Total_Len + Val(H_W(j))      'ﾁｪｯｸする箱がずれているので以下のように修正 '06.11.6 松本
        '        Total_Len = Total_Len + Val(H_W(J))   '06.11.6 松本修正
        '    Next
        '    '箱数制限をチェック
        '    If (Cnt > Limit_Hako) Then
        '        MsgBox(Msg1 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
        '        Chk = "エラー"
        '    End If
        '    '全長制限ををチェック
        '    If (Total_Len > Limit_Bunkatu) Then
        '        MsgBox(Msg2 & BunkatuSE(BCnt, 0) & "～" & BunkatuSE(BCnt, 1), Style, Title)
        '        Chk = "エラー"
        '    End If
        '    If (Chk <> "") Then  '最終分割にエラーが有った場合
        '        MsgBox("指定した分割内容では分割できません。自動で分割します", vbInformation + vbOKOnly, "分割制限エラー")
        '        Call CalPage_Auto("Auto", FChk)
        '        Exit Sub
        '    Else
        Call CalPage_Auto("Manual", FChk)
        '        Exit Sub
        '    End If
        'Else  'チェックに引っ掛かったので自動分割に振る
        '    MsgBox("指定した分割内容では分割できません。自動で分割します", vbInformation + vbOKOnly, "分割制限エラー")
        '    Call CalPage_Auto("Auto", FChk)
        '    Exit Sub
        'End If
    End Sub

    Public Sub CalPage_Auto(ByVal AMflg As String, ByVal FChk As String)
        '-----------------------------------------------
        '必要なページ数を自動にて計算
        '-----------------------------------------------
        '   AMflg     : 自動か手動かの判断子("Auto"or"Manual")
        '   FChk      : 納入外基礎ベースNoをベース分割に追加したかどうか用
        '                 ="in" 追加した
        '                 ="" 追加してない
        '-----------------------------------------------

        Dim i As Integer, J As Integer, k As Integer       'ループ変数
        Dim BZencyo As Integer   '分割内の全長
        Dim PZencyo As Integer   '１ページ内の全長
        Dim BHakoCnt As Integer  '分割内箱数
        Dim Pcnt As Integer      'ページ番号
        Dim BCnt As Integer      '分割番号

        '自動分割時の計算
        If AMflg = "Auto" And (FChk = "") Then
            BCnt = 1
            i = 0
            J = 1
            BZencyo = Val(H_W(0))
            'BZencyo = Val(H_W(1))
            BHakoCnt = 1
            BunkatuSE(1, 0) = CubNo(0)  '１つ目の分割の最初の箱No
            Call HakoBunkatu(BZencyo, BHakoCnt, i, J)
        ElseIf AMflg = "Auto" And (FChk = "in") Then '納入外基礎ベース付加
            BCnt = 1
            i = 0
            J = 1
            k = 0
            BZencyo = Val(H_W(1))
            BHakoCnt = 1
            BunkatuSE(1, 0) = CubNo(0)  '１つ目の分割の最初の箱No
            Do Until (CubNo(i) = "")
                If (BZencyo > Limit_Bunkatu) Or (BHakoCnt > Limit_Hako) Then
                    If i <> 1 Then
                        'I = I - 1
                        If BHakoCnt <> 10 Then i = i - 1 '納入外CUB.処理後でない場合
                        BunkatuSE(J, 1) = CubNo(i - 1)
                    End If
                    J = J + 1
                    BunkatuSE(J, 0) = CubNo(i)
                    BZencyo = Val(H_W(i))
                    BHakoCnt = 1
                    If CubNo(i) = KM_BaseBunkatu(k) Then
                        k = k + 1
                        BHakoCnt = 10
                        BunkatuSE(J, 1) = CubNo(i)
                    End If
                Else
                    BunkatuSE(J, 1) = CubNo(i)
                    'BZencyo = BZencyo + H_W(I + 1)
                    If i <> 0 Then BZencyo = BZencyo + Val(H_W(i)) 'i=0は既にBZencyoにｾｯﾄしてある為
                    BHakoCnt = BHakoCnt + 1
                    If CubNo(i) = KM_BaseBunkatu(k) Then
                        k = k + 1
                        BHakoCnt = 10
                    End If
                End If
                i = i + 1
            Loop
        End If
        If (BZencyo > Limit_Bunkatu) Or (BHakoCnt > Limit_Hako) Then '最終箱の前で分割される場合
            If i <> 1 Then                                             'を判断する為
                i = i - 1
                BunkatuSE(J, 1) = CubNo(i - 1)
            End If
            J = J + 1
            BunkatuSE(J, 0) = CubNo(i)
        End If
        If BunkatuSE(J, 1) = "" Then  '最終箱が納入外の時 or 最終箱の前で分割される場合
            BunkatuSE(J, 1) = BunkatuSE(J, 0)
        End If

        'ページ割付
        Pcnt = 1
        BCnt = 1
        i = 1
        PZencyo = Val(H_W(1))
        Pcnt = 1
        Call PageWarituke(PZencyo, Pcnt, BCnt, i, J)

    End Sub


    Public Sub HakoBunkatu(ByVal BZencyo As Integer, ByVal BHakoCnt As Integer, ByVal i As Integer, ByVal j As Integer)
        'Do Until (CubNo(i) = "")
        Do
            If (BZencyo > Limit_Bunkatu) Or (BHakoCnt > Limit_Hako) Then    '箱の全長が指定の最大分割位置以上か、箱の数が５より多いなら、
                If i <> 1 Then
                    i = i - 1
                    BunkatuSE(j, 1) = CubNo(i - 1)
                End If
                j = j + 1
                BunkatuSE(j, 0) = CubNo(i)
                BZencyo = Val(H_W(i))
                BHakoCnt = 1
            Else
                BunkatuSE(j, 1) = CubNo(i)
                'BZencyo = BZencyo + H_W(I + 1)
                If i <> 0 Then BZencyo = BZencyo + Val(H_W(i)) 'i=0は既にBZencyoにｾｯﾄしてある為
                BHakoCnt = BHakoCnt + 1
            End If
            i = i + 1
        Loop While (CubNo(i - 1) <> "")
        BunkatuSE(j, 1) = CubNo(i - 2)
        'Loop
        'Exit Sub
        'E:
        '        MsgBox("分割位置が短すぎます。再設定してください。")
        '        Me.Close()
    End Sub

    Public Sub PageWarituke(ByVal PZencyo As Integer, ByVal PCnt As Integer, ByVal BCnt As Integer, ByVal i As Integer, ByVal j As Integer)
        'ページ割付
        PageSE(PCnt, 0) = BunkatuSE(1, 0) '1ページ目の最初の箱
        If CubNo(i) = "" Then   '１箱しかない場合
            PageSE(PCnt, 1) = CubNo(i - 1)
            TL_ZMaisu = PCnt
            Exit Sub
        End If
        If CubNo(0) = BunkatuSE(1, 1) Then '1ページ目の最初の箱にて分割
            BCnt = BCnt + 1
        End If
        Do Until CubNo(i) = ""
            If CubNo(i) <> BunkatuSE(BCnt, 1) Then
                PZencyo = PZencyo + Val(H_W(i)) '1ページ内の全長計算
            Else  '分割箱No時に置けるチェック
                PZencyo = PZencyo + Val(H_W(i)) '1ページ内の全長計算
                If (PZencyo > PageLimit) Then  '1ページ内の制限を越えた場合
                    PCnt = PCnt + 1
                    PageSE(PCnt, 0) = BunkatuSE(BCnt, 0)  '最初の箱
                    i = 0
                    Do Until (CubNo(i) = BunkatuSE(BCnt, 0))
                        i = i + 1
                    Loop
                    PZencyo = Val(H_W(i))
                    BCnt = BCnt + 1
                Else
                    PageSE(PCnt, 1) = BunkatuSE(BCnt, 1)  '最後の箱
                    BCnt = BCnt + 1
                End If
            End If
            i = i + 1
        Loop
        If PZencyo > PageLimit Then
            PageSE(PCnt, 1) = CubNo(i - 2)
            PCnt = PCnt + 1
            PageSE(PCnt, 0) = CubNo(i - 1)
            PageSE(PCnt, 1) = CubNo(i - 1)
        Else
            PageSE(PCnt, 1) = CubNo(i - 1)
        End If
        TL_ZMaisu = PCnt
    End Sub

    Function CalRetuLeft(ByVal Page As Integer) As Double
        '-----------------------------------------------
        ' 列番左端位置の計算
        '-----------------------------------------------
        '   Page      : 対象となるページ番号(ex 1)
        '   戻り値    : 1ページ内の作図開始X座標(ex 120)
        '-----------------------------------------------
        Dim j As Integer, k As Integer
        Dim HalfLen As Double

        '全長寸法の計算
        j = 1
        KM_Len = 0
        Do Until PageSEHakoNo(Page, j) = ""
            k = CalPosition(Trim(PageSEHakoNo(Page, j)))
            KM_Len = KM_Len + Val(H_W(k))
            j = j + 1
        Loop

        '全長から列番の左端位置を計算
        HalfLen = (KM_Len / 2.0#) / sScale
        If HalfLen > (HconZhyX1 - HconZhyX2) Then
            CalRetuLeft = 0
        Else
            CalRetuLeft = HconZhyX1 - HalfLen
        End If
    End Function

    Public Sub SetSeigyoAna(ByVal X As Double, ByVal i As Integer, ByVal Flg As Integer)
        'Public Sub SetSeigyoAna(ByVal X As Double, ByVal i As Integer, ByVal LoopMax As Integer(Looplimit), ByVal Flg As Integer)
        '-----------------------------------------------
        ' 制御ケーブル穴処理
        '-----------------------------------------------
        ' X        : 基点Ｘ座標
        ' i        : 対象となる箱Noの配列上の位置
        ' LoopMax  :  1ページ内の箱数
        ' Flg      : チェック(=1なら現在の箱はそのページにおける最左箱)
        '-----------------------------------------------

        Dim SSA_Block As String
        Dim T_insPnt(0 To 2) As Double '座標
        Dim DistX As Double, DistY As Double

        'Dim CUD_Lin_Obj As Object
        'Dim lin_obj As Object
        'Dim Chk As Object
        SSA_Block = ""

        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_4, SeigyoAna_5
            Case SeigyoAna_2, SeigyoAna_3
                DistX = HconDou26
                DistY = HconDou27
                'Case SeigyoAna_6, SeigyoAna_7, SeigyoAna_8, SeigyoAna_9
            Case SeigyoAna_4, SeigyoAna_5
                DistX = HconDou40
                DistY = HconDou41
                'Case SeigyoAna_10, SeigyoAna_11, SeigyoAna_12, SeigyoAna_13
            Case SeigyoAna_6, SeigyoAna_7
                DistX = HconDou44
                DistY = HconDou45
        End Select

        'アクティブ線種の変更
        SetActiveLine("BYLAYER")

        If Flg = 1 Then     '1箱目なら
            'そのページにおける最左箱の設定
            Call LHakoSettei(SSA_Block, T_insPnt, DistX, DistY, i, X)
        End If

        'ブロック配置(左側制御穴）
        Call LSeigyoAnaBlkHaiti(SSA_Block, DistX, DistY, i, X)

        If Flg = 1 And nps = False Then     '1箱目かつ、簡略図ではないなら
            '最左箱の接続線の作成
            Call LHakoSetuzokusen(T_insPnt)
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        'Ｗ寸法の記入
        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_6, SeigyoAna_7, SeigyoAna_10, SeigyoAna_11 '正面に制御穴がある
            Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_4, SeigyoAna_5, SeigyoAna_6, SeigyoAna_7 '正面に制御穴がある
                Call SetLevelDim("Level0", "左側", HconDou29, DistX, DistX)
                'Case SeigyoAna_4, SeigyoAna_5, SeigyoAna_8, SeigyoAna_9, SeigyoAna_12, SeigyoAna_13 '背面に制御穴がある(背面側はなくていいらしいのでコメントアウト)
                '    Call SetLevelDim("Level4", "左側", HconDou29, DistX, DistX)
        End Select
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")
        'ブロック配置（右側制御穴）
        Call RSeigyoAnaBlkHaiti(SSA_Block, DistX, DistY, i, X)

        If Flg = 1 And nps = False Then     '1箱目かつ、簡略図ではないなら
            '最左箱への接続線作成
            Call LHakoSetuzokusen2(T_insPnt)
        End If
        'アクティブレイヤーの変更
        SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        'Ｗ寸法の記入
        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_6, SeigyoAna_7, SeigyoAna_10, SeigyoAna_11
            Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_4, SeigyoAna_5, SeigyoAna_6, SeigyoAna_7
                Call SetLevelDim("Level0", "右側", HconDou29, DistX, DistX)
                'Case SeigyoAna_4, SeigyoAna_5, SeigyoAna_8, SeigyoAna_9, SeigyoAna_12, SeigyoAna_13
                '    Call SetLevelDim("Level4", "右側", HconDou29, DistX, DistX)
        End Select
    End Sub

    Public Sub LHakoSettei(ByVal SSA_Block As String, ByVal T_insPnt() As Double, ByVal DistX As Double, ByVal DistY As Double, ByVal i As Integer, ByVal X As Double)
        Dim Chk As Object
        Dim CUD_Lin_Obj As AcadDimAligned
        Dim SeigyoSize As String

        If nps = False Then
            Select Case SeigyoAna
                'Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_4, SeigyoAna_5
                Case SeigyoAna_2, SeigyoAna_3
                    SeigyoSize = SEIGYO
                Case SeigyoAna_4, SeigyoAna_5
                    SeigyoSize = SEIGYOF
                Case SeigyoAna_6, SeigyoAna_7
                    SeigyoSize = SEIGYOS
                Case Else
                    SeigyoSize = Nothing
            End Select


            'ブロック配置（制御ケーブル穴文字）
            Mult_String = Str(LoopLimit * 2) & SeigyoSize
            SSA_Block = "K_MOJI_SEIGYO"
            Call SetBlock(X, SSA_Block, "-", HconDou30, _
                                        "+", ((Val(H_D(i)) / sScale) / 2.0#), _
                                        "基礎図制御穴")
        End If

        T_insPnt(0) = InsPnt(0)
        T_insPnt(1) = InsPnt(1)

        If nps = False Then
            '制御ケーブル穴詳細図
            InsPnt(0) = SetScale(HconZhyX2, sScale)
            InsPnt(1) = SetScale(HconZhyY2, sScale)
            InsPnt(2) = 0.0#
            SSA_Block = "K_SEIGYO"
            Chk = FunInsertBlock(SSA_Block, InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")
        End If


        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")

        'Ｄ寸法の記入
        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_6, SeigyoAna_7, SeigyoAna_10, SeigyoAna_11 '正面に制御穴がある
            Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_4, SeigyoAna_5, SeigyoAna_6, SeigyoAna_7
                insPntE(1) = SetScale(KM_ZahyoY + (DistY / sScale), sScale)
                'Case SeigyoAna_4, SeigyoAna_5, SeigyoAna_8, SeigyoAna_9, SeigyoAna_12, SeigyoAna_13 '背面に制御穴がある
                '    insPntE(1) = SetScale(((KM_ZahyoY + (Val(H_D(i)) / sScale)) - (DistY / sScale)), sScale)
        End Select
        insPntS(0) = SetScale((X + (DistX / sScale)), sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        insPntE(0) = insPntS(0)
        insPntE(2) = 0.0#
        InsPnt(0) = SetScale(X - HconDou28, sScale)
        InsPnt(1) = (insPntE(1) - insPntS(1)) / 2
        InsPnt(2) = 0.0#
        CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
    End Sub

    Public Sub LSeigyoAnaBlkHaiti(ByVal SSA_Block As String, ByVal DistX As Double, ByVal DistY As Double, ByVal i As Integer, ByVal X As Double)

        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_4
            Case SeigyoAna_2
                SSA_Block = "K_SEIGYO_ANA1" '通常制御穴
                'Case SeigyoAna_3, SeigyoAna_5
            Case SeigyoAna_3
                SSA_Block = "K_SEIGYO_ANA2" '予備用制御穴
                'Case SeigyoAna_6, SeigyoAna_8
            Case SeigyoAna_4
                SSA_Block = "K_SEIGYO_ANA_F1" '通常制御穴
                'Case SeigyoAna_7, SeigyoAna_9
            Case SeigyoAna_5
                SSA_Block = "K_SEIGYO_ANA_F2" '予備用制御穴
                'Case SeigyoAna_10, SeigyoAna_12
            Case SeigyoAna_6
                SSA_Block = "K_SEIGYO_ANA_S1" '通常制御穴
                'Case SeigyoAna_11, SeigyoAna_13
            Case SeigyoAna_7
                SSA_Block = "K_SEIGYO_ANA_S2" '予備用制御穴
        End Select
        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_6, SeigyoAna_7, SeigyoAna_10, SeigyoAna_11 '正面に制御穴がある
            Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_4, SeigyoAna_5, SeigyoAna_6, SeigyoAna_7
                Call SetBlock(X, SSA_Block, "+", (DistX / sScale), _
                                            "+", (DistY / sScale), _
                                            "基礎")
                'Case SeigyoAna_4, SeigyoAna_5, SeigyoAna_8, SeigyoAna_9, SeigyoAna_12, SeigyoAna_13 '背面に制御穴がある
                '    Call SetBlock(X, SSA_Block, "+", (DistX / sScale), _
                '                                "+", ((Val(H_D(i)) / sScale) - (DistY / sScale)), _
                '                                "基礎")
        End Select
    End Sub

    Public Sub RSeigyoAnaBlkHaiti(ByVal SSA_Block As String, ByVal DistX As Double, ByVal DistY As Double, ByVal i As Integer, ByVal X As Double)

        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_4
            Case SeigyoAna_2
                SSA_Block = "K_SEIGYO_ANA2"
                'Case SeigyoAna_3, SeigyoAna_5
            Case SeigyoAna_3
                SSA_Block = "K_SEIGYO_ANA1"
                'Case SeigyoAna_6, SeigyoAna_8
            Case SeigyoAna_4
                SSA_Block = "K_SEIGYO_ANA_F2"
                'Case SeigyoAna_7, SeigyoAna_9
            Case SeigyoAna_5
                SSA_Block = "K_SEIGYO_ANA_F1"
                'Case SeigyoAna_10, SeigyoAna_12
            Case SeigyoAna_6
                SSA_Block = "K_SEIGYO_ANA_S2"
                'Case SeigyoAna_11, SeigyoAna_13
            Case SeigyoAna_7
                SSA_Block = "K_SEIGYO_ANA_S1"
        End Select
        Select Case SeigyoAna
            'Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_6, SeigyoAna_7, SeigyoAna_10, SeigyoAna_11
            Case SeigyoAna_2, SeigyoAna_3, SeigyoAna_4, SeigyoAna_5, SeigyoAna_6, SeigyoAna_7
                Call SetBlock(X, SSA_Block, "+", ((Val(H_W(i)) - DistX) / sScale), _
                                            "+", (DistY / sScale), _
                                            "基礎")
                '    Case SeigyoAna_4, SeigyoAna_5, SeigyoAna_8, SeigyoAna_9, SeigyoAna_12, SeigyoAna_13
                '        Call SetBlock(X, SSA_Block, "+", ((Val(H_W(i)) - DistX) / sScale), _
                '                                    "+", ((Val(H_D(i)) / sScale) - (DistY / sScale)), _
                '                                    "基礎")
        End Select
    End Sub

    Public Sub LHakoSetuzokusen(ByVal T_insPnt() As Double)
        Dim lin_obj As Object

        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")

        '最左箱への接続線作成
        insPntS(0) = T_insPnt(0)
        insPntS(1) = T_insPnt(1)
        insPntS(2) = 0.0#
        insPntE(0) = InsPnt(0)
        insPntE(1) = InsPnt(1)
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_obj.Color = acYellow
        lin_obj.Color = ACAD_COLOR.acYellow
    End Sub

    Public Sub LHakoSetuzokusen2(ByVal T_insPnt() As Double)
        Dim lin_obj As Object

        '最左箱への接続線作成
        insPntS(0) = T_insPnt(0)
        insPntS(1) = T_insPnt(1)
        insPntS(2) = 0.0#
        insPntE(0) = InsPnt(0)
        insPntE(1) = InsPnt(1)
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        'lin_obj.Color = acYellow
        lin_obj.Color = ACAD_COLOR.acYellow
    End Sub

    Public Sub SyukairoAna(ByVal CUD_MainX As Double, ByVal j As Integer)
        '-----------------------------------------------
        ' 主回路ケーブル穴処理(引込穴)
        '-----------------------------------------------
        ' CUD_MainX : '基本座標（Ｘ座標）
        ' j         : 対象となる箱Noの配列上の位置
        ' LoopMax   :  1ページ内の箱数
        ' Flg       : チェック(=1なら現在の箱はそのページにおける最左箱)
        '-----------------------------------------------

        Dim i As Integer, k As Integer, l As Integer
        'Dim lin_Obj As AcadObject
        'Dim siten As String
        'Dim taikaku As String
        'Dim CUD_Lin_Obj As AcadDimAligned
        'Dim Blocks As String
        'Dim SyPath As String
        Dim Chk As Object
        Dim HikiPath As String = "\\Nas-Server.swg.nissin.co.jp\設計データ\NPS承認図テスト用\ブロック\"
        Dim RenamKata As String

        Call SetActiveLayer("自動作成")
        'アクティブ線種の変更
        Call SetActiveLine("BYLAYER")

        For i = 0 To UBound(P_sBanDat, 1)   '箱の数分
            If i = j Then                   '箱の作図と同時に引込穴の作図
                For k = 0 To 3              '最大4つ引込穴を作図できるので

                    '5*k+35 → 1次元目における各引込穴の最初の配列の位置(形式1つに対して5つ項目があり、1つ目の引込穴が35番目から始まるのでこのような式に)
                    RenamKata = P_sBanDat(j, 5 * k + pc_Hiki1Row2)

                    If RenamKata <> Nothing Then                'エラー回避のためのif
                        If 0 < RenamKata.IndexOf("*") Then      '"*"が1つ以上型名に含まれているなら(○*○を○,○にする処理)
                            RenamKata = RenamKata.Replace("*", ",")
                        End If
                    End If
                    If P_sBanDat(j, 5 * k + pc_Hiki1Row2) = "1型任意" Then   '4-800型の場合
                        Call Hiki1(CUD_MainX, j, k)
                    ElseIf P_sBanDat(j, 5 * k + pc_Hiki1Row2) = "4型任意" Then   '1型の場合
                        Call Hiki4(CUD_MainX, j, k)
                    ElseIf P_sBanDat(j, 5 * k + pc_Hiki1Row2) = "2-" & "α型" Then   '2-α字型の場合
                        Call Hiki2a(CUD_MainX, j, k)
                    ElseIf P_sBanDat(j, 5 * k + pc_Hiki1Row2) = "2-" & "β型" Then   '2-β型の場合
                        Call Hiki2b(CUD_MainX, j, k)
                    ElseIf P_sBanDat(j, 5 * k + pc_Hiki1Row2) = "無" Then   '無の場合
                        '特に何もしない
                    Else
                        '既定の型の場合
                        If IsNothing(dwgname) = False Then
                            For l = 0 To dwgname.Length - 1         '既定の型の数だけループ
                                If RenamKata = dwgname(l) Then      '入力された既定の型名と配列の値が一致したら
                                    '既定の型を挿入する処理
                                    '挿入点
                                    '箱の左端x座標 + 箱の幅の半分 + X寸法(箱センター線に対してどれほど左右にずれているか)
                                    InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))
                                    '箱の正面側外形線y座標 + Y寸法(箱の正面側外形線と引込穴の中心のy座標との距離)
                                    InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4))
                                    InsPnt(2) = 0.0#
                                    '既定の型貼り付け
                                    Chk = FunInsertBlock(dwgname(l), InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")

                                    'アクティブレイヤーの変更
                                    Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                                    Call SetActiveLine("BYLAYER")

                                    '以下、既定の型のコード(既定の型が追加されたらif分岐で追加)
                                    If P_sBanDat(j, 5 * k + pc_Hiki1Row2) = "4型LS01" Then
                                        Dim A As Integer = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 1))     '基礎図表データ保存配列からA寸法を呼び込む(200固定)
                                        Dim X As Integer = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))     '基礎図表データ保存配列からX寸法を呼び込む
                                        Dim Y As Integer = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4))     '基礎図表データ保存配列からY寸法を呼び込む
                                        '箱の正面側外形線とケーブル穴センター線(X軸・下側)との寸法
                                        '基準点(箱の正面側外形線上)
                                        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + 800 / 2 - A / 2 - HconDou38 * 2 - 140 '800→ケーブル穴間の寸法
                                        insPntS(1) = SetScale(KM_ZahyoY, sScale)
                                        insPntS(2) = 0.0#
                                        '基準点(下側ケーブル穴センター線上)
                                        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + 800 / 2 - A / 2 - HconDou38 * 2 - 140
                                        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y - 800 / 2
                                        insPntE(2) = 0.0#
                                        '寸法記入位置
                                        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + 800 / 2 - A / 2 - HconDou38 * 2 - 140
                                        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (Y - 800 / 2) / 2
                                        InsPnt(2) = 0.0#
                                        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
                                        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
                                        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
                                        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
                                    Else            'ケーブル穴が1つのパターン(コード作成時は500*250、500*300、600*250の3つ)
                                        '箱の下(上)線と既定の型の中心点との寸法(Y寸法)
                                        '基準点(箱の外形線上)
                                        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))
                                        insPntS(1) = SetScale(KM_ZahyoY, sScale)
                                        insPntS(2) = 0.0#
                                        '基準点(中心点)
                                        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))
                                        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4))
                                        insPntE(2) = 0.0#
                                        '寸法記入位置
                                        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3)) - HconDou38 * 2
                                        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4)) / 2
                                        InsPnt(2) = 0.0#
                                        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
                                        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
                                        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
                                        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
                                    End If



                                End If
                            Next
                        End If

                    End If

                    'If RenamKata <> Nothing Then
                    '    If 0 < RenamKata.IndexOf("*") Then
                    '        RenamKata = RenamKata.Replace("*", ",")
                    '    End If
                    'End If
                    'If SyukairoData(5 * k + 8, j) = "1型任意" Then   '4-800型の場合
                    '    Call Hiki1(CUD_MainX, j, k)
                    'ElseIf SyukairoData(5 * k + 8, j) = "4型任意" Then   '1型の場合
                    '    Call Hiki4(CUD_MainX, j, k)
                    'ElseIf SyukairoData(5 * k + 8, j) = "2-" & "α型" Then   '2-α字型の場合
                    '    Call Hiki2a(CUD_MainX, j, k)
                    'ElseIf SyukairoData(5 * k + 8, j) = "2-" & "β型" Then   '2-β型の場合
                    '    Call Hiki2b(CUD_MainX, j, k)
                    'ElseIf SyukairoData(5 * k + 8, j) = "無" Then   '無の場合
                    '    '特に何もしない
                    'Else
                    '    '既定の型の場合
                    '    If IsNothing(dwgname) = False Then
                    '        For l = 0 To dwgname.Length - 1         '既定の型の数だけループ
                    '            If RenamKata = dwgname(l) Then      '入力された既定の型名と配列の値が一致したら
                    '                '既定の型を挿入する処理
                    '                '挿入点
                    '                '箱の左端x座標 + 箱の幅の半分 + X寸法(箱センター線に対してどれほど左右にずれているか)
                    '                InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(SyukairoData(5 * k + 11, j))
                    '                '箱の正面側外形線y座標 + Y寸法(箱の正面側外形線と引込穴の中心のy座標との距離)
                    '                InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(SyukairoData(5 * k + 12, j))
                    '                InsPnt(2) = 0.0#
                    '                '既定の型貼り付け
                    '                Chk = FunInsertBlock(dwgname(l), InsPnt(0), InsPnt(1), InsPnt(2), 1.0#, 1.0#, 0.0#, "基礎")

                    '                'アクティブレイヤーの変更
                    '                Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
                    '                Call SetActiveLine("BYLAYER")
                    '                '箱の下(上)線と既定の型の中心点との寸法(Y寸法)
                    '                '基準点(箱の外形線上)
                    '                insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(SyukairoData(5 * k + 11, j))
                    '                insPntS(1) = SetScale(KM_ZahyoY, sScale)
                    '                insPntS(2) = 0.0#
                    '                '基準点(中心点)
                    '                insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(SyukairoData(5 * k + 11, j))
                    '                insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(SyukairoData(5 * k + 12, j))
                    '                insPntE(2) = 0.0#
                    '                '寸法記入位置
                    '                InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + Val(SyukairoData(5 * k + 11, j)) - HconDou38 * 2
                    '                InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(SyukairoData(5 * k + 12, j)) / 2
                    '                InsPnt(2) = 0.0#
                    '                pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
                    '                pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
                    '                pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
                    '                acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

                    '            End If
                    '        Next
                    '    End If

                    'End If

                    'アクティブレイヤーの変更
                    Call SetActiveLayer("自動作成")
                    Call SetActiveLine("BYLAYER")

                Next

            End If
        Next

    End Sub

    Private Sub Hiki1(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal k As Integer)
        'k:k+1番目の引込穴

        '1型の場合
        Dim lin_Obj As AcadObject
        Dim siten As String
        Dim taikaku As String
        Dim A As Double, B As Double, X As Double, Y As Double      '引込穴設定時に図示されたA,B,X,Yに対応する変数

        A = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 1))     '基礎図表データ保存配列からA寸法を読み込む
        B = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 2))     '基礎図表データ保存配列からB寸法を読み込む
        X = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))     '基礎図表データ保存配列からX寸法を読み込む
        Y = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4))     '基礎図表データ保存配列からY寸法を読み込む

        '左下基準点
        '箱の左端x座標 + 箱の幅の半分 + X寸法(箱センター線に対してどれほど左右にずれているか) - 引込穴の幅の半分
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        '箱の正面側外形線y座標 + Y寸法(箱の正面側外形線と引込穴の中心のy座標との距離) - 引込穴の幅の半分
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y - B / 2
        insPntS(2) = 0.0#

        '右上基準点
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + B / 2
        insPntE(2) = 0.0#

        'lin_Obj = moSpace.AddLine(insPntS, insPntE)
        'lin_Obj.Color = ACAD_COLOR.acGreen

        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString

        Call SetRectang(siten, taikaku)         '長方形の作図


        Call SetActiveLine("一点鎖線")

        '主回路ケーブル穴センター線(縦)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + B / 2 + HconDou39 * (3 / 2)
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y - B / 2 - HconDou39 * (3 / 2)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow
        'AnaCLineX = lin_Obj


        '主回路ケーブル穴センター線(横)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2 + HconDou38 * 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow
        'AnaCLineY = lin_Obj

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        'センター線とケーブル穴センター線(Y軸)との寸法
        '基準点(センター線上)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + B / 2 + HconDou39 * (3 / 2)
        insPntS(2) = 0.0#
        '基準点(センター線上じゃないほう)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + B / 2 + HconDou39 * (3 / 2)
        insPntE(2) = 0.0#
        '寸法記入位置
        'If Val(SyukairoData(1, i)) < 0 Then         '②がマイナス(センター線より左)なら
        'InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) - Val(SyukairoData(1, i)) / 2
        'ElseIf Val(SyukairoData(1, i)) >= 0 Then    '②がプラス(センター線より右)なら
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X / 2
        'End If
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y + B / 2 + HconDou39 * (3 / 2) + 30
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'CLineAXCenter = CUD_Lin_Obj

        '箱の下(上)線とケーブル穴センター線(X軸)との寸法
        '基準点(箱の外形線上)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(ケーブル穴センター線上)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y / 2
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '引込穴の幅寸法
        '基準点(左下頂点)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y - B / 2
        insPntS(2) = 0.0#
        '基準点(右下頂点)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y - B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y - B / 2 - 110
        InsPnt(2) = 0.0#
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & "_endpoint" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '引込穴の奥行寸法
        '基準点(左下頂点)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y - B / 2
        insPntS(2) = 0.0#
        '基準点(左上頂点)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - 120
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y
        InsPnt(2) = 0.0#
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    Private Sub Hiki4(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal k As Integer)
        '4-800型の場合
        Dim i As Integer, l As Integer
        Dim F(15) As Boolean
        Dim lin_Obj As AcadObject
        Dim kotei As Double = 800       '固定値(引込穴のセンター線間の寸法、最終的にはマスターに記載予定)
        Dim siten As String             '穴の左下頂点
        Dim taikaku As String           '穴の右上頂点
        Dim insPntD(0 To 2) As Double   '４型全体の中心点
        Dim Cons400(0 To 15) As Double
        Dim SD As Double
        Dim SD2 As Double
        Dim A As Double, B As Double, X As Double, Y As Double      '引込穴設定時に図示されたA,B,X,Yに対応する変数

        A = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 1))     '基礎図表データ保存配列からA寸法を読み込む
        B = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 2))     '基礎図表データ保存配列からB寸法を読み込む
        X = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))     '基礎図表データ保存配列からX寸法を読み込む
        Y = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4))     '基礎図表データ保存配列からY寸法を読み込む

        'F = {False, False, False, False, True, False, True, False, True, True, True, True, False, True, False, True} '符号判定用フラグ配列
        l = 0

        '中心点算出
        insPntD(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntD(1) = SetScale(KM_ZahyoY, sScale) + Y
        insPntD(2) = 0.0#

        '4つの引込穴作図
        '作図順：左下引込穴→右下引込穴→右上引込穴→左上引込穴

        '最上段：i=0のとき,2段目：i=1のとき,・・・(中心点からどの方向に400移動するかの配列)
        Cons400 = {-(kotei / 2), -(kotei / 2), -(kotei / 2), -(kotei / 2), _
                   (kotei / 2), -(kotei / 2), (kotei / 2), -(kotei / 2), _
                   (kotei / 2), (kotei / 2), (kotei / 2), (kotei / 2), _
                   -(kotei / 2), (kotei / 2), -(kotei / 2), (kotei / 2)}        '最上段：i=0のとき,2段目：i=1のとき,・・・(中心点からどの方向に400移動するかの配列)

        For i = 0 To 3
            '引込穴の左下頂点
            insPntS(0) = insPntD(0) + Cons400(i + l) - A / 2
            l += 1
            insPntS(1) = insPntD(1) + Cons400(i + l) - B / 2
            l += 1
            insPntS(2) = 0.0#
            '引込穴の右上頂点
            insPntE(0) = insPntD(0) + Cons400(i + l) + A / 2
            l += 1
            insPntE(1) = insPntD(1) + Cons400(i + l) + B / 2
            insPntE(2) = 0.0#
            siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
            taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString
            Call SetRectang(siten, taikaku)
        Next

        'センター線作図(形：#)
        '作図順：下側横センター線→上側横センター線→左側縦センター線→右側縦センター線

        '最上段：i=0のとき,2段目：i=1のとき,・・・(中心点からどの方向に400移動するかの配列)
        Cons400 = {-(kotei / 2), -(kotei / 2), -(kotei / 2), -(kotei / 2), _
                   (kotei / 2), -(kotei / 2), (kotei / 2), -(kotei / 2), _
                   -(kotei / 2), (kotei / 2), -(kotei / 2), (kotei / 2), _
                   (kotei / 2), (kotei / 2), (kotei / 2), (kotei / 2)}         '最上段：i=0のとき,2段目：i=1のとき,・・・(中心点からどの方向に400移動するかの配列)
        SD = A / 2 + HconDou38
        SD2 = B / 2 + HconDou39
        Call SetActiveLine("一点鎖線")

        l = 0
        For i = 0 To 3
            '横センター線左端
            insPntS(0) = insPntD(0) + Cons400(l) - SD   '中心点(x)から-400(箱のセンター線と引込穴のセンター線間の距離)移動し、引込穴の幅の半分+α移動した点
            l += 1                                          'insPntD(0)                 Cons400(i + l)                          Val(SyukairoData(2, j)) + HconDou38
            insPntS(1) = insPntD(1) + Cons400(l)        '横センター線なのでy座標は上下段それぞれの引込穴の奥行の中点固定(中心点(y)から400上か下か)
            l += 1                                          '                           insPntD(1) +(-) Cons400(i + l)
            insPntS(2) = 0.0#
            '横センター線右端
            insPntE(0) = insPntD(0) + Cons400(l) + SD   '中心点(x)から400(箱のセンター線と引込穴のセンター線間の距離)移動し、引込穴の幅の半分+α移動した点
            l += 1                                          'insPntD(0)                 Cons400(i + l)                          Val(SyukairoData(2, j)) + HconDou38
            insPntE(1) = insPntD(1) + Cons400(l)        '横センター線なのでy座標は上下段それぞれの引込穴の奥行の中点固定(中心点(y)から400上か下か)
            insPntE(2) = 0.0#

            lin_Obj = moSpace.AddLine(insPntS, insPntE)
            lin_Obj.Color = ACAD_COLOR.acYellow

            l = l - 3
            '縦センター線下端
            insPntS(0) = insPntD(0) + Cons400(l)        '縦センター線なのでx座標は左右それぞれの引込穴の幅の中点固定(中心点(x)から400左か右か)
            l += 1
            insPntS(1) = insPntD(1) + Cons400(l) - SD2   '中心点(y)から-400(2本の引込穴の横センター線間の距離)移動し、引込穴の奥行の半分+α移動した点
            l += 1                                          'insPntD(0)                 Cons400(i + l)              　Val(SyukairoData(2, j)) + HconDou39
            insPntS(2) = 0.0#
            '縦センター線上端
            insPntE(0) = insPntD(0) + Cons400(l)        '縦センター線なのでx座標は左右それぞれの引込穴の幅の中点固定(中心点(x)から400左か右か)
            l += 1
            insPntE(1) = insPntD(1) + Cons400(l) + SD2   '中心点(y)から400(2本の引込穴の横センター線間の距離)移動し、引込穴の奥行の半分+α移動した点
            insPntE(2) = 0.0#                               'insPntD(0)                 Cons400(i + l)              　Val(SyukairoData(2, j)) + HconDou39
            l += 1
            lin_Obj = moSpace.AddLine(insPntS, insPntE)
            lin_Obj.Color = ACAD_COLOR.acYellow


        Next

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(正面側外形線上と４型の中心点(y))
        '基準点(正面側外形線上)
        insPntS(0) = insPntD(0) + A / 2 + HconDou38
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(中心点)
        insPntE(0) = insPntD(0) + A / 2 + HconDou38
        insPntE(1) = insPntD(1) - kotei / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0) + A / 2 + HconDou38
        InsPnt(1) = (insPntD(1) - kotei / 2 - SetScale(KM_ZahyoY, sScale)) / 2 + SetScale(KM_ZahyoY, sScale)
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(箱センター線と４型の中心点(x))
        '基準点(センター線上)
        insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + 150
        insPntS(2) = 0.0#
        '基準点(中心点の真下)
        insPntE(0) = insPntD(0)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + 150
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + 150
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        If insPntS(0) <> insPntE(0) Then        'X寸法が0なら表記しない
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        End If
        

        '寸法線(右上引込穴の奥行)
        '基準点(左下の頂点)
        insPntS(0) = insPntD(0) + kotei / 2 - A / 2
        insPntS(1) = insPntD(1) + kotei / 2 - B / 2
        insPntS(2) = 0.0#
        '基準点(左上の頂点)
        insPntE(0) = insPntD(0) + kotei / 2 - A / 2
        insPntE(1) = insPntD(1) + kotei / 2 + B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0) + kotei / 2 - A / 2 - HconDou38
        InsPnt(1) = insPntD(1) + kotei / 2
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(右上引込穴の幅)
        '基準点(左下の頂点)
        insPntS(0) = insPntD(0) + kotei / 2 - A / 2
        insPntS(1) = insPntD(1) + kotei / 2 - B / 2
        insPntS(2) = 0.0#
        '基準点(右下の頂点)
        insPntE(0) = insPntD(0) + kotei / 2 + A / 2
        insPntE(1) = insPntD(1) + kotei / 2 - B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0) + kotei / 2
        InsPnt(1) = insPntD(1) + kotei / 2 - B / 2 - 110
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(左側外形線と左側引込穴の縦センター線間)
        '基準点(左側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        insPntS(2) = 0.0#
        '基準点(左側引込穴の縦センター線の頂点(上))
        insPntE(0) = insPntD(0) - kotei / 2
        insPntE(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (((insPntD(0) - kotei / 2) - (SetScale(CUD_MainX, sScale))) / 2)  '2つの基準点(x)の中間
        InsPnt(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(2本の引込穴の縦センター線間)
        '基準点(左側引込穴の縦センター線の頂点(上))
        insPntS(0) = insPntD(0) - kotei / 2
        insPntS(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        insPntS(2) = 0.0#
        '基準点(右側引込穴の縦センター線の頂点(上))
        insPntE(0) = insPntD(0) + kotei / 2
        insPntE(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0)
        InsPnt(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(右側引込穴の縦センター線と右側外形線間)
        '基準点(右側引込穴の縦センター線の頂点(上))
        insPntS(0) = insPntD(0) + kotei / 2
        insPntS(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        insPntS(2) = 0.0#
        '基準点(右側外形線)
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) + (((insPntD(0) + kotei / 2) - (SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale))) / 2)  '2つの基準点(x)の中間
        InsPnt(1) = insPntD(1) + kotei / 2 + B / 2 + HconDou39
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)


        '寸法線(2本の引込穴の横センター線間)
        '基準点(下側引込穴の横センター線の頂点(右))
        insPntS(0) = insPntD(0) + kotei / 2 + A / 2
        insPntS(1) = insPntD(1) - kotei / 2
        insPntS(2) = 0.0#
        '基準点(上側引込穴の横センター線の頂点(右))
        insPntE(0) = insPntD(0) + kotei / 2 + A / 2
        insPntE(1) = insPntD(1) + kotei / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0) + A / 2 + HconDou38
        InsPnt(1) = insPntD(1)
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & "_endpoint" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    Private Sub Hiki2a(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal k As Integer)
        '2-α型の場合(固定値(２つの引込穴間の寸法)は500)(横並び引込穴)
        Dim lin_Obj As AcadObject
        Dim insPntD(0 To 2) As Double   '２型全体の中心点
        Dim siten As String
        Dim taikaku As String
        Dim kotei As Double = 500       '引込穴間の寸法(変更ができるように最終的にはマスターに記載の予定)
        Dim A As Double, B As Double, X As Double, Y As Double      '引込穴設定時に図示されたA,B,X,Yに対応する変数

        A = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 1))     '基礎図表データ保存配列からA寸法を読み込む
        B = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 2))     '基礎図表データ保存配列からB寸法を読み込む
        X = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))     '基礎図表データ保存配列からX寸法を読み込む
        Y = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4))     '基礎図表データ保存配列からY寸法を読み込む

        '中心点算出
        insPntD(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntD(1) = SetScale(KM_ZahyoY, sScale) + Y
        insPntD(2) = 0.0#

        '1つめの引込穴(左)
        '左下基準点
        insPntS(0) = insPntD(0) - kotei / 2 - A / 2
        insPntS(1) = insPntD(1) - B / 2
        insPntS(2) = 0.0#
        '右上基準点
        insPntE(0) = insPntD(0) - kotei / 2 + A / 2
        insPntE(1) = insPntD(1) + B / 2
        insPntE(2) = 0.0#
        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString
        Call SetRectang(siten, taikaku)

        '2つめの引込穴(右)
        '左下基準点
        insPntS(0) = insPntD(0) + kotei / 2 - A / 2
        insPntS(1) = insPntD(1) - B / 2
        insPntS(2) = 0.0#
        '右上基準点
        insPntE(0) = insPntD(0) + kotei / 2 + A / 2
        insPntE(1) = insPntD(1) + B / 2
        insPntE(2) = 0.0#
        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString
        Call SetRectang(siten, taikaku)

        Call SetActiveLine("一点鎖線")

        '左側引込穴センター線(縦)
        insPntS(0) = insPntD(0) - kotei / 2
        insPntS(1) = insPntD(1) + B / 2 + HconDou39
        insPntS(2) = 0.0#
        insPntE(0) = insPntD(0) - kotei / 2
        insPntE(1) = insPntD(1) - B / 2 - HconDou39
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow

        '右側引込穴センター線(縦)
        insPntS(0) = insPntD(0) + kotei / 2
        insPntS(1) = insPntD(1) + B / 2 + HconDou39
        insPntS(2) = 0.0#
        insPntE(0) = insPntD(0) + kotei / 2
        insPntE(1) = insPntD(1) - B / 2 - HconDou39
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow


        '横向き引込穴センター線(横(左))
        insPntS(0) = insPntD(0) - kotei / 2 - A / 2 - HconDou38 * 2
        insPntS(1) = insPntD(1)
        insPntS(2) = 0.0#
        insPntE(0) = insPntD(0) - kotei / 2 + A / 2 + HconDou38 * 2
        insPntE(1) = insPntD(1)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow

        '横向き引込穴センター線(横(右))
        insPntS(0) = insPntD(0) + kotei / 2 - A / 2 - HconDou38 * 2
        insPntS(1) = insPntD(1)
        insPntS(2) = 0.0#
        insPntE(0) = insPntD(0) + kotei / 2 + A / 2 + HconDou38 * 2
        insPntE(1) = insPntD(1)
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(正面側外形線上と引込穴横センター線)
        '基準点(正面側外形線上)
        insPntS(0) = insPntD(0) + kotei / 2 + A / 2 + HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(引込穴横センター線右端)
        insPntE(0) = insPntD(0) + kotei / 2 + A / 2 + HconDou38 * 2
        insPntE(1) = insPntD(1)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0) + kotei / 2 + A / 2 + HconDou38 * 2 + 70
        InsPnt(1) = (insPntD(1) - SetScale(KM_ZahyoY, sScale)) / 2 + SetScale(KM_ZahyoY, sScale)
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(箱センター線と２－α型の中心点(x))
        '基準点(センター線上)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + 150
        insPntS(2) = 0.0#
        '基準点(中心点のy軸線上)
        insPntE(0) = insPntD(0)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + 150
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + 150
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj

        If insPntS(0) <> insPntE(0) Then
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        End If

        '寸法線(右側引込穴の奥行)
        '基準点(左下の頂点)
        insPntS(0) = insPntD(0) + kotei / 2 - A / 2
        insPntS(1) = insPntD(1) - B / 2
        insPntS(2) = 0.0#
        '基準点(左上の頂点)
        insPntE(0) = insPntD(0) + kotei / 2 - A / 2
        insPntE(1) = insPntD(1) + B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0) + kotei / 2 - A / 2 - HconDou38 * 2
        InsPnt(1) = insPntD(1)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & "_endpoint" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(右側引込穴の幅)
        '基準点(左下の頂点)
        insPntS(0) = insPntD(0) + kotei / 2 - A / 2
        insPntS(1) = insPntD(1) - B / 2
        insPntS(2) = 0.0#
        '基準点(右下の頂点)
        insPntE(0) = insPntD(0) + kotei / 2 + A / 2
        insPntE(1) = insPntD(1) - B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0) + kotei / 2
        InsPnt(1) = insPntD(1) - B / 2 - 120
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & "_endpoint" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(左側外形線と左側引込穴の縦センター線間)
        '基準点(左側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale)
        insPntS(1) = insPntD(1) + B / 2 + HconDou39
        insPntS(2) = 0.0#
        '基準点(左側引込穴の縦センター線の頂点(上))
        insPntE(0) = insPntD(0) - kotei / 2
        insPntE(1) = insPntD(1) + B / 2 + HconDou39
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (((insPntD(0) - kotei / 2) - (SetScale(CUD_MainX, sScale))) / 2)  '2つの基準点(x)の中間
        InsPnt(1) = insPntD(1) + B / 2 + HconDou39
        'InsPnt(1) = insPntD(1) + B / 2 + 3 / 2 * HconDou39
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(2本の引込穴の縦センター線間)
        '基準点(左側引込穴の縦センター線の頂点(上))
        insPntS(0) = insPntD(0) - kotei / 2
        insPntS(1) = insPntD(1) + B / 2 + HconDou39
        insPntS(2) = 0.0#
        '基準点(右側引込穴の縦センター線の頂点(上))
        insPntE(0) = insPntD(0) + kotei / 2
        insPntE(1) = insPntD(1) + B / 2 + HconDou39
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = insPntD(0)
        InsPnt(1) = insPntD(1) + B / 2 + HconDou39
        'InsPnt(1) = insPntD(1) + B / 2 + 3 / 2 * HconDou39
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & "_endpoint" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(右側引込穴の縦センター線と右側外形線間)
        '基準点(右側引込穴の縦センター線の頂点(上))
        insPntS(0) = insPntD(0) + kotei / 2
        insPntS(1) = insPntD(1) + B / 2 + HconDou39
        insPntS(2) = 0.0#
        '基準点(右側外形線)
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale)
        insPntE(1) = insPntD(1) + B / 2 + HconDou39
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) + (((insPntD(0) + kotei / 2) - (SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale))) / 2)  '2つの基準点(x)の中間
        InsPnt(1) = insPntD(1) + B / 2 + HconDou39
        'InsPnt(1) = insPntD(1) + B / 2 + 3 / 2 * HconDou39
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & "_endpoint" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)


    End Sub

    Private Sub Hiki2b(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal k As Integer)
        '2-β型(縦並び)の場合
        Dim lin_Obj As AcadObject
        Dim kotei As Double = 800   '引込穴間の寸法(最終的にはマスターに記載の予定)
        Dim siten As String
        Dim taikaku As String
        Dim A As Double, B As Double, X As Double, Y As Double      '引込穴設定時に図示されたA,B,X,Yに対応する変数

        A = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 1))     '基礎図表データ保存配列からA寸法を読み込む
        B = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 2))     '基礎図表データ保存配列からB寸法を読み込む
        X = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 3))     '基礎図表データ保存配列からX寸法を読み込む
        Y = Val(P_sBanDat(j, 5 * k + pc_Hiki1Row2 + 4))     '基礎図表データ保存配列からY寸法を読み込む

        '1つめの引込穴(下)
        '左下基準点
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2 - B / 2
        insPntS(2) = 0.0#
        '右上基準点
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2 + B / 2
        insPntE(2) = 0.0#
        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString
        Call SetRectang(siten, taikaku)

        '2つめの引込穴(上)
        '左下基準点
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 - B / 2
        insPntS(2) = 0.0#
        '右上基準点
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 + B / 2
        insPntE(2) = 0.0#
        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString
        Call SetRectang(siten, taikaku)

        Call SetActiveLine("一点鎖線")
        '引込穴センター線(縦(上))
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 + B / 2 + HconDou39
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 - B / 2 - HconDou39
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow
        '引込穴センター線(縦(下))
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2 + B / 2 + HconDou39
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2 - B / 2 - HconDou39
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow

        '引込穴センター線(横・下側)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2 + HconDou38 * 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow

        '引込穴センター線(横・上側)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2 + HconDou38 * 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2
        insPntE(2) = 0.0#
        lin_Obj = moSpace.AddLine(insPntS, insPntE)
        lin_Obj.Color = ACAD_COLOR.acYellow

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(上側引込穴の奥行)
        '基準点(左下の頂点)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 - B / 2
        insPntS(2) = 0.0#
        '基準点(左上の頂点)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 + B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & "_endpoint" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(上側引込穴の幅)
        '基準点(左下の頂点)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 - B / 2
        insPntS(2) = 0.0#
        '基準点(右下の頂点)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X + A / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 - B / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 - B / 2 - 110
        InsPnt(2) = 0.0#
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'KLineAYCenter = CUD_Lin_Obj
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        'センター線とケーブル穴センター線(Y軸)との寸法
        '基準点(センター線上)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 + B / 2 + HconDou39
        insPntS(2) = 0.0#
        '基準点(センター線上じゃないほう)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 + B / 2 + HconDou39
        insPntE(2) = 0.0#
        '寸法記入位置
        'If Val(SyukairoData(1, i)) < 0 Then         '②がマイナス(センター線より左)なら
        'InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) - Val(SyukairoData(1, i)) / 2
        'ElseIf Val(SyukairoData(1, i)) >= 0 Then    '②がプラス(センター線より右)なら
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X / 2
        'End If
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2 + B / 2 + HconDou39 * (3 / 2)
        InsPnt(2) = 0.0#

        If insPntS(0) <> insPntE(0) Then                'X寸法が0以外なら、X寸法も図面に記載
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        End If
        
        'CUD_Lin_Obj = moSpace.AddDimAligned(insPntS, insPntE, InsPnt)
        'CLineAXCenter = CUD_Lin_Obj

        '箱の正面側外形線とケーブル穴センター線(X軸・下側)との寸法
        '基準点(箱の正面側外形線上)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(ケーブル穴センター線上)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2 - 110
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + kotei / 2
        InsPnt(2) = 0.0#
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        'ケーブル穴センター線(X軸・下側)とケーブル穴センター線(X軸・上側)との寸法
        '基準点(下側ケーブル穴センター線上)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Y - kotei / 2
        insPntS(2) = 0.0#
        '基準点(上側ケーブル穴センター線上)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2 - 110
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y '- kotei / 4
        InsPnt(2) = 0.0#
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '箱の背面側外形線とケーブル穴センター線(X軸・上側)との寸法
        '基準点(箱の背面側外形線)
        insPntS(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale)
        insPntS(2) = 0.0#
        '基準点(ケーブル穴センター線上)
        insPntE(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Y + kotei / 2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX + ((Val(H_W(j)) / 2) / sScale), sScale) + X - A / 2 - HconDou38 * 2 - 110
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Y '- kotei / 4
        InsPnt(2) = 0.0#
        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & "_endpoint" & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    '
    '補強枠作図
    '
    Public Sub CreHokyowaku(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal H_Cnt As Integer)
        '
        'CUD_MainX:各箱の左下頂点
        'j        :今何番目の箱か
        '
        LX = 0
        RX = 0


        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")
        Call SetActiveLine("BYLAYER")

        If P_sBanDat(j, pc_LOkuyukiRow2) = "有" Then
            LX = 50
        End If
        If P_sBanDat(j, pc_ROkuyukiRow2) = "有" Then
            RX = 50
        End If


        '補強枠設定

        If P_sBanDat(j, pc_HokyoKataRow2) = "Ⅰ字型" Then          'Ⅰ字型の場合
            Call HokyoI(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "Ⅱ字型" Then      'Ⅱ字型の場合
            Call HokyoII(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "一字型" Then      '一字型の場合
            Call Hokyo_(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "二字型" Then      '二字型の場合
            Call Hokyoni(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "Ｔ字型" Then      'Ｔ字型の場合
            Call HokyoT(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Then     '逆Ｔ字型の場合
            Call HokyoT2(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "Π型" Then
            Call HokyoTT(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
            Call HokyoTT2(CUD_MainX, j)

        ElseIf P_sBanDat(j, pc_HokyoKataRow2) = "井型" Then
            Call Hokyoigata(CUD_MainX, j)

        End If
        'アクティブレイヤーの変更
        Call SetActiveLayer("自動作成")
        Call SetActiveLine("BYLAYER")



    End Sub

    '
    '各箱の左右の補強枠が繋がるのかを判断する(図面での横向きの補強の奥行の位置の判断)
    '(繋がる場合(間に分割がなく、奥行の位置が同じ場合)は1本の補強に見えるようにする必要がある)
    Public Sub Ycompare(ByVal j As Integer, ByVal Y1 As Double, ByVal Y2 As Double)
        Dim BefY As Double, BefY2 As Double
        Dim NexY As Double, NexY2 As Double

        tateumu = 0
        tateumu2 = 0
        BefY = 0
        BefY2 = 0
        NexY = 0
        NexY2 = 0

        If LX = 0 Then  '左奥行枠がないなら
            If P_sBanDat(j - 1, pc_HokyoKataRow2) = "二字型" Or P_sBanDat(j - 1, pc_HokyoKataRow2) = "井型" Then
                BefY = P_sBanDat(j - 1, pc_HokyoYRow2) + P_sBanDat(j - 1, pc_HokyoBRow2) / 2
                BefY2 = P_sBanDat(j - 1, pc_HokyoYRow2) - P_sBanDat(j - 1, pc_HokyoBRow2) / 2
            Else
                BefY = P_sBanDat(j - 1, pc_HokyoYRow2)
            End If
            If Y1 = BefY Or Y1 = BefY2 Then
                tateumu = 1
            End If
            If P_sBanDat(j, pc_HokyoKataRow2) = "二字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "井型" Then
                If Y2 = BefY Or Y2 = BefY2 Then
                    tateumu2 = 1
                End If
            End If
        End If

        If RX = 0 Then

            If P_sBanDat(j + 1, pc_HokyoKataRow2) = "二字型" Or P_sBanDat(j + 1, pc_HokyoKataRow2) = "井型" Then
                NexY = P_sBanDat(j + 1, pc_HokyoYRow2) + P_sBanDat(j + 1, pc_HokyoBRow2) / 2
                NexY2 = P_sBanDat(j + 1, pc_HokyoYRow2) - P_sBanDat(j + 1, pc_HokyoBRow2) / 2
            Else
                NexY = P_sBanDat(j + 1, pc_HokyoYRow2)
            End If
            If Y1 = NexY Or Y1 = NexY2 Then
                If tateumu = 0 Then
                    tateumu = 2
                ElseIf tateumu = 1 Then
                    tateumu = 3

                End If

            End If
            If P_sBanDat(j, pc_HokyoKataRow2) = "二字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "井型" Then
                If Y2 = NexY Or Y2 = NexY2 Then
                    If tateumu2 = 0 Then
                        tateumu2 = 2
                    ElseIf tateumu2 = 1 Then
                        tateumu2 = 3
                    End If

                End If
            End If

        End If

        'If LX = 0 Then  '左奥行枠がないなら
        '    If SyukairoData(j - 1, j - 1) = "二字型" Or SyukairoData(1, j - 1) = "井型" Then
        '        BefY = SyukairoData(5, j - 1) + SyukairoData(3, j - 1) / 2
        '        BefY2 = SyukairoData(5, j - 1) - SyukairoData(3, j - 1) / 2
        '    Else
        '        BefY = SyukairoData(5, j - 1)
        '    End If
        '    If Y1 = BefY Or BefY2 Then
        '        tateumu = 1
        '    End If
        '    If SyukairoData(1, j) = "二字型" Or SyukairoData(1, j) = "井型" Then
        '        If Y2 = BefY Or BefY2 Then
        '            tateumu2 = 1
        '        End If
        '    End If
        'End If

        'If RX = 0 Then

        '    If SyukairoData(1, j + 1) = "二字型" Or SyukairoData(1, j + 1) = "井型" Then
        '        NexY = SyukairoData(5, j + 1) + SyukairoData(3, j + 1) / 2
        '        NexY2 = SyukairoData(5, j + 1) - SyukairoData(3, j + 1) / 2
        '    Else
        '        NexY = SyukairoData(5, j + 1)
        '    End If
        '    If Y1 = NexY Or NexY2 Then
        '        If tateumu = 0 Then
        '            tateumu = 2
        '        ElseIf tateumu = 1 Then
        '            tateumu = 3

        '        End If

        '    End If
        '    If SyukairoData(1, j) = "二字型" Or SyukairoData(1, j) = "井型" Then
        '        If Y2 = NexY Or NexY2 Then
        '            If tateumu2 = 0 Then
        '                tateumu2 = 2
        '            ElseIf tateumu2 = 1 Then
        '                tateumu2 = 3
        '            End If

        '        End If
        '    End If

        'End If
    End Sub


    Public Sub HokyoI(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(Ⅰ字型)
        Dim x As Double             '左側外形線と奥行方向の補強枠(図で見た場合の縦向きの枠)の左下基準点との距離
        Dim y As Double             '奥行方向の補強枠の長さ

        '横向き補強枠を線分で作図した場合に作図しなくていい縦線を判断するための変数
        '(0:省略無し(四角で作図),1:左縦線省略,2:右縦線省略,3:両縦線省略)


        x = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) - CUD_BaseH / 2
        y = Val(H_D(j)) - CUD_BaseH

        Call hokyowaku2(CUD_MainX, j, x, y)

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        ''寸法線(補強枠の中心と箱センター線(X寸法))
        ''基準点(補強枠の中心点)
        'insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH / 2
        'insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'insPntS(2) = 0.0#
        ''基準点(箱センター線)
        'insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        'insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'insPntE(2) = 0.0#
        ''寸法記入位置
        'InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + SyukairoData(4, j) / 2
        'InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'InsPnt(2) = 0.0#

        'If insPntS(0) <> insPntE(0) Then
        'pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        'pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        'pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        'End if

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (x + CUD_BaseH)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (x + CUD_BaseH / 2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    Public Sub HokyoII(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(Ⅱ字型) 
        Dim x As Double             '奥行方向の補強枠(図で見た場合の縦向きの枠)の左下基準点のx座標
        Dim x2 As Double            '奥行方向の補強枠の左下基準点のx座標(2本目用)
        Dim y As Double             '奥行方向の補強枠の長さ(高さ)

        x = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) - P_sBanDat(j, pc_HokyoARow2) / 2 - CUD_BaseH
        x2 = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + P_sBanDat(j, pc_HokyoARow2) / 2
        y = Val(H_D(j)) - CUD_BaseH

        Call hokyowaku2(CUD_MainX, j, x, y)
        Call hokyowaku2(CUD_MainX, j, x2, y)

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(2本の補強枠の間隔(A寸法))
        '基準点(左補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntS(2) = 0.0#
        '基準点(右補強枠の中心点)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)


        ''寸法線(2本の補強枠の間隔(A寸法))
        ''基準点(左補強枠の中心点)
        'insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH / 2
        'insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'insPntS(2) = 0.0#
        ''基準点(右補強枠の中心点)
        'insPntE(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH / 2
        'insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'insPntE(2) = 0.0#
        ''寸法記入位置
        'InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + SyukairoData(4, j)
        'InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'InsPnt(2) = 0.0#

        'pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        'pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        'pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        ''寸法線(2つの補強枠の間隔の中心と箱センター線(X寸法))
        ''基準点(2つの補強枠の間隔の中心)
        'insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + SyukairoData(4, j)
        'insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'insPntS(2) = 0.0#
        ''基準点(箱センター線)
        'insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        'insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2
        'insPntE(2) = 0.0#
        ''寸法記入位置
        'InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + SyukairoData(4, j) / 2
        'InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) / 2 - 110
        'InsPnt(2) = 0.0#

        'If insPntS(0) <> insPntE(0) Then
        'pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        'pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        'pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        'End if

        '寸法線(補強枠)
        '基準点(箱センター線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntS(2) = 0.0#
        '基準点(補強枠の中心点)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (x + CUD_BaseH / 2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (x2 + CUD_BaseH / 2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) * 2 / 3)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    Public Sub Hokyo_(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(一字型)
        Dim y As Double             '奥行方向の補強枠の長さ(高さ)
        Dim TY As Double
        Dim UY As Double

        TY = P_sBanDat(j, pc_HokyoYRow2)
        UY = 0

        Call Ycompare(j, TY, UY)

        y = P_sBanDat(j, pc_HokyoYRow2)

        If tateumu = 0 Then
            Call hokyowaku1(CUD_MainX, j, y)
        ElseIf tateumu = 1 Or 2 Or 3 Then
            Call hokyowaku5(CUD_MainX, j, y, tateumu)
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(箱の正面側外形線と横向き補強枠の中心(Y寸法))
        '基準点(箱の正面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 200
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(横向き補強枠の中心点(奥行枠は考慮しない))
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 200
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2))
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 200
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(横向き補強枠の手前側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 200
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2))
        insPntS(2) = 0.0#
        '基準点(横向き補強枠の奥側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 200
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2)) + CUD_BaseH
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 200
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2) + CUD_BaseH / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    Public Sub Hokyoni(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(二字型)
        Dim y As Double             '奥行方向の補強枠の長さ(高さ)
        Dim y2 As Double            '奥行方向の補強枠の長さ(高さ)(2カ所目用)
        Dim TY As Double
        Dim UY As Double


        TY = P_sBanDat(j, pc_HokyoYRow2)
        UY = 0
        UY = TY - P_sBanDat(j, pc_HokyoBRow2) / 2
        TY = TY + P_sBanDat(j, pc_HokyoBRow2) / 2


        Call Ycompare(j, UY, TY)

        Call SetActiveLine("BYLAYER")

        y = P_sBanDat(j, pc_HokyoYRow2) - P_sBanDat(j, pc_HokyoBRow2) / 2 - CUD_BaseH
        y2 = P_sBanDat(j, pc_HokyoYRow2) + P_sBanDat(j, pc_HokyoBRow2) / 2 '- CUD_BaseH / 2

        If tateumu = 0 Then
            Call hokyowaku1(CUD_MainX, j, y)
        ElseIf tateumu = 1 Or tateumu = 2 Or tateumu = 3 Then
            Call hokyowaku5(CUD_MainX, j, y, tateumu)
        End If
        If tateumu2 = 0 Then
            Call hokyowaku1(CUD_MainX, j, y2)
        ElseIf tateumu2 = 1 Or tateumu2 = 2 Or tateumu2 = 3 Then
            Call hokyowaku5(CUD_MainX, j, y2, tateumu2)
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(B寸法の背面側と背面側外形線)
        '基準点(背面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 130
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j))
        insPntS(2) = 0.0#
        '基準点(B寸法の背面側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 130
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y2
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 130
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - (Val(H_D(j)) - y2) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(2本の補強枠の間隔(B寸法))
        '基準点(背面側補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 130
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y2
        insPntS(2) = 0.0#
        '基準点(正面側補強枠の中心点(奥行枠は考慮しない))
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 130
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y + CUD_BaseH)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 130
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(B寸法の正面側と正面側外形線)
        '基準点(B寸法の背面側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 130
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y + CUD_BaseH
        insPntS(2) = 0.0#
        '基準点(背面側外形線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) + 130
        insPntE(1) = SetScale(KM_ZahyoY, sScale)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 130
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + y / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)


        '寸法線(2本の補強枠の中心と箱の正面側外形線(Y寸法))
        '基準点(箱の正面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 300)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(2本の補強枠の中心点(奥行枠は考慮しない))
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 130)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 300)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2) / 2)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        acadDoc.SendCommand("_dimlinear" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & "V" & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(正面側横向き補強枠の奥側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) - 130
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y + CUD_BaseH)
        insPntS(2) = 0.0#
        '基準点(正面側横向き補強枠の手前側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) - 130
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) - 130
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y + CUD_BaseH / 2)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(横向き補強枠の手前側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) - 130
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y2
        insPntS(2) = 0.0#
        '基準点(横向き補強枠の奥側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) - 130
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 + CUD_BaseH)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2) - 130
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y2 + CUD_BaseH / 2)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    Public Sub HokyoT(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(Ｔ字型)
        Dim x As Double             '奥行方向の補強枠(図で見た場合の縦向きの枠)の左下基準点のx座標
        Dim y As Double             '奥行方向の補強枠の長さ(高さ)
        Dim TY As Double
        Dim UY As Double

        TY = P_sBanDat(j, pc_HokyoYRow2)
        UY = 0

        Call Ycompare(j, TY, UY)

        x = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) - CUD_BaseH / 2
        y = P_sBanDat(j, pc_HokyoYRow2)

        If tateumu = 0 Then
            Call hokyowaku1(CUD_MainX, j, y)
            Call hokyowaku2(CUD_MainX, j, x, y)
        ElseIf tateumu = 1 Or tateumu = 2 Or tateumu = 3 Then
            Call hokyowaku2(CUD_MainX, j, x, y)
            Call hokyowaku5(CUD_MainX, j, y, tateumu)
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(奥行方向の補強枠の中心と箱センター線との寸法(X寸法))
        '基準点(奥行方向の補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (x + CUD_BaseH / 2)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2) * 2 / 3)
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2) * 2 / 3)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) / 2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2) * 2 / 3)
        InsPnt(2) = 0.0#

        If insPntS(0) <> insPntE(0) Then
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        End If

        '寸法線(箱の正面側外形線と横向き補強枠の中心(Y寸法))
        '基準点(箱の正面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH + 60
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(横向き補強枠の中心点(奥行枠は考慮しない))
        insPntE(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH + 60
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (P_sBanDat(j, pc_HokyoYRow2))
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH + 60
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y - 150
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y - 150
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + y - 150
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)


    End Sub

    Public Sub HokyoT2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(逆Ｔ字型)
        Dim x As Double             '奥行方向の補強枠(図で見た場合の縦向きの枠)の左下基準点のx座標
        Dim y As Double             '奥行方向の補強枠の長さ(高さ)
        Dim TY As Double
        Dim UY As Double


        TY = P_sBanDat(j, pc_HokyoYRow2)
        UY = 0

        Call Ycompare(j, TY, UY)

        x = Val(H_W(j)) / 2 - P_sBanDat(j, pc_HokyoXRow2) - CUD_BaseH / 2
        y = Val(H_D(j)) - P_sBanDat(j, pc_HokyoYRow2) - CUD_BaseH

        If tateumu = 0 Then
            Call hokyowaku1(CUD_MainX, j, y)
            Call hokyowaku3(CUD_MainX, j, x, y)
        ElseIf tateumu = 1 Or tateumu = 2 Or tateumu = 3 Then
            Call hokyowaku3(CUD_MainX, j, x, y)
            Call hokyowaku5(CUD_MainX, j, y, tateumu)
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(奥行方向の補強枠の中心と箱センター線との寸法(X寸法))
        '基準点(奥行方向の補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + (CUD_BaseH / 2)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) - ((Val(H_D(j)) - P_sBanDat(j, pc_HokyoYRow2)) / 2))
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) - ((Val(H_D(j)) - P_sBanDat(j, pc_HokyoYRow2)) / 2))
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) - ((Val(H_D(j)) - P_sBanDat(j, pc_HokyoYRow2)) / 2))
        InsPnt(2) = 0.0#

        If insPntS(0) <> insPntE(0) Then
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)
        End If

        '寸法線(箱の正面側外形線と横向き補強枠の正面側枠(Y寸法))
        '基準点(箱の正面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 150)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(横向き補強枠の中心点(奥行枠は考慮しない))
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 150)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 150)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) * 4 / 5
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) * 4 / 5
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) * 4 / 5
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub

    Public Sub HokyoTT(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(Π字(くし)型)
        Dim x As Double             '奥行方向の補強枠(図で見た場合の縦向きの枠)の左下基準点のx座標
        Dim x2 As Double            '奥行方向の補強枠の左下基準点のx座標(2本目用)
        Dim y As Double             '奥行方向の補強枠の長さ(高さ)
        Dim TY As Double
        Dim UY As Double

        TY = P_sBanDat(j, pc_HokyoYRow2)
        UY = 0

        Call Ycompare(j, TY, UY)

        x = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) - P_sBanDat(j, pc_HokyoARow2) / 2 - CUD_BaseH
        x2 = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + P_sBanDat(j, pc_HokyoARow2) / 2
        y = P_sBanDat(j, pc_HokyoYRow2)

        If tateumu = 0 Then
            Call hokyowaku1(CUD_MainX, j, y)
            Call hokyowaku2(CUD_MainX, j, x, y)
            Call hokyowaku2(CUD_MainX, j, x2, y)
        ElseIf tateumu = 1 Or tateumu = 2 Or tateumu = 3 Then
            Call hokyowaku2(CUD_MainX, j, x, y)
            Call hokyowaku2(CUD_MainX, j, x2, y)
            Call hokyowaku5(CUD_MainX, j, y, tateumu)
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(2本の補強枠の間隔(A寸法))
        '基準点(左補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        insPntS(2) = 0.0#
        '基準点(右補強枠の中心点)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(2つの補強枠の間隔の中心と箱センター線(X寸法))
        '基準点(2つの補強枠の間隔の中心)
        insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y - 230
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + y - 230
        InsPnt(2) = 0.0#

        If insPntS(0) <> insPntE(0) Then
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimlinear" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & "H" & vbCrLf & pnt12 & vbCrLf)
        End If

        '寸法線(箱の正面側外形線と横向き補強枠の中心(Y寸法))
        '基準点(箱の正面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 150
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(横向き補強枠の中心点(奥行枠は考慮しない))
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 150
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 150
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + y - 120
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)


    End Sub

    Public Sub HokyoTT2(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強板(逆Π字(くし)型)
        Dim x As Double             '奥行方向の補強枠(図で見た場合の縦向きの枠)の左下基準点のx座標
        Dim x2 As Double            '奥行方向の補強枠の左下基準点のx座標(2本目用)
        Dim y As Double             '奥行方向の補強枠の長さ(高さ)
        Dim TY As Double
        Dim UY As Double

        TY = P_sBanDat(j, pc_HokyoYRow2)
        UY = 0

        Call Ycompare(j, TY, UY)

        x = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) - P_sBanDat(j, pc_HokyoARow2) / 2 - CUD_BaseH
        x2 = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + P_sBanDat(j, pc_HokyoARow2) / 2
        y = Val(H_D(j)) - P_sBanDat(j, pc_HokyoYRow2) - CUD_BaseH
        

        If tateumu = 0 Then
            Call hokyowaku1(CUD_MainX, j, y)
            Call hokyowaku3(CUD_MainX, j, x, y)
            Call hokyowaku3(CUD_MainX, j, x2, y)
        ElseIf tateumu = 1 Or tateumu = 2 Or tateumu = 3 Then
            Call hokyowaku3(CUD_MainX, j, x, y)
            Call hokyowaku3(CUD_MainX, j, x2, y)
            Call hokyowaku5(CUD_MainX, j, y, tateumu)
        End If

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(2本の補強枠の間隔(A寸法))
        '基準点(左補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        insPntS(2) = 0.0#
        '基準点(右補強枠の中心点)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(2つの補強枠の間隔の中心と箱センター線(X寸法))
        '基準点(2つの補強枠の間隔の中心)
        insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 360
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 360
        InsPnt(2) = 0.0#

        If insPntS(0) <> insPntE(0) Then
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimlinear" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & "H" & vbCrLf & pnt12 & vbCrLf)
        End If

        '寸法線(箱の正面側外形線と横向き補強枠の正面側枠(Y寸法))
        '基準点(箱の正面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 150)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(横向き補強枠の中心点(奥行枠は考慮しない))
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 150)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + 150)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        ''寸法線(箱の正面側外形線と横向き補強枠の中心(Y寸法))
        ''基準点(箱の正面側外形線)
        'insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        'insPntS(1) = SetScale(KM_ZahyoY, sScale)
        'insPntS(2) = 0.0#
        ''基準点(横向き補強枠の中心点(奥行枠は考慮しない))
        'insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2
        'insPntE(1) = SetScale(KM_ZahyoY, sScale) + SyukairoData(5, j)
        'insPntE(2) = 0.0#
        ''寸法記入位置
        'InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + 150
        'InsPnt(1) = SetScale(KM_ZahyoY, sScale) + SyukairoData(5, j) / 2
        'InsPnt(2) = 0.0#

        'pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        'pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        'pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH / 2
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) - 250
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)


    End Sub

    Public Sub Hokyoigata(ByVal CUD_MainX As Double, ByVal j As Integer)
        '補強枠(井型)作図
        Dim x As Double             '奥行方向の補強枠(図で見た場合の縦向きの枠)の左下基準点のx座標
        Dim x2 As Double            '奥行方向の補強枠の左下基準点のx座標(2本目用)

        Dim y As Double             '奥行方向の補強枠の長さ(高さ)
        Dim y2 As Double
        Dim y3 As Double
        Dim TY As Double
        Dim UY As Double

        TY = P_sBanDat(j, pc_HokyoYRow2)
        UY = 0
        UY = TY - P_sBanDat(j, pc_HokyoBRow2) / 2
        TY = TY + P_sBanDat(j, pc_HokyoBRow2) / 2

        Call Ycompare(j, UY, TY)

        x = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) - P_sBanDat(j, pc_HokyoARow2) / 2 - CUD_BaseH
        x2 = Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + P_sBanDat(j, pc_HokyoARow2) / 2
        y = Val(H_D(j)) - CUD_BaseH
        y2 = P_sBanDat(j, pc_HokyoYRow2) - P_sBanDat(j, pc_HokyoBRow2) / 2 - CUD_BaseH
        y3 = P_sBanDat(j, pc_HokyoYRow2) + P_sBanDat(j, pc_HokyoBRow2) / 2

        Call hokyowaku2(CUD_MainX, j, x, y)
        Call hokyowaku2(CUD_MainX, j, x2, y)
        Call hokyowaku4(CUD_MainX, j, x, x2, y2, tateumu)
        Call hokyowaku4(CUD_MainX, j, x, x2, y3, tateumu2)

        'アクティブレイヤーの変更
        Call SetActiveLayer("1.SUNPOU_MOJI_HATTINGU")
        Call SetActiveLine("BYLAYER")

        '寸法線(2本の補強枠の間隔(A寸法))
        '基準点(左補強枠の中心点)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x + CUD_BaseH
        'insPntS(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) * 4 / 5
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        insPntS(2) = 0.0#
        '基準点(右補強枠の中心点)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x2
        'insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j)) * 4 / 5
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2)
        'InsPnt(1) = SetScale(KM_ZahyoY, sScale) + +Val(H_D(j)) * 4 / 5
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(2本の補強枠の間隔(B寸法))
        '基準点(正面側補強枠の中心点)
        'insPntS(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH
        insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y2 + CUD_BaseH
        insPntS(2) = 0.0#
        '基準点(背面側補強枠の中心点)
        'insPntE(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y3
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + +P_sBanDat(j, pc_HokyoYRow2)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(2つの補強枠の間隔の中心と箱センター線(X寸法))
        '基準点(2つの補強枠の間隔の中心)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2))
        'insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y2 * 2 / 3)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        insPntS(2) = 0.0#
        '基準点(箱センター線)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2)
        'insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 * 2 / 3)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 230)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) / 2)
        'InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y2 * 2 / 3 - 110)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 230)
        InsPnt(2) = 0.0#

        If insPntS(0) <> insPntE(0) Then
            pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
            pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
            pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
            acadDoc.SendCommand("_dimlinear" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & "H" & vbCrLf & pnt12 & vbCrLf)
        End If

        '寸法線(B寸法の下側と箱の正面側外形線)
        '基準点(箱の正面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110)
        insPntS(1) = SetScale(KM_ZahyoY, sScale)
        insPntS(2) = 0.0#
        '基準点(B寸法の下側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 + CUD_BaseH)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, (pc_HokyoYRow2)) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(B寸法の背面側と箱の背面側外形線)
        '基準点(箱の背面側外形線)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y3
        insPntS(2) = 0.0#
        '基準点(B寸法の下側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + Val(H_D(j))
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (Val(H_W(j)) / 2 + P_sBanDat(j, pc_HokyoXRow2) + 110)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, (pc_HokyoYRow2)) / 2
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        ''寸法線(2本の補強枠の中心と箱の正面側外形線(Y寸法))
        ''基準点(箱の正面側外形線)
        'insPntS(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH + 130
        'insPntS(1) = SetScale(KM_ZahyoY, sScale)
        'insPntS(2) = 0.0#
        ''基準点(2本の補強枠の中心点(奥行枠は考慮しない))
        'insPntE(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH + 130
        'insPntE(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2)
        'insPntE(2) = 0.0#
        ''寸法記入位置
        'InsPnt(0) = SetScale(CUD_MainX, sScale) + x2 + CUD_BaseH + 260
        'InsPnt(1) = SetScale(KM_ZahyoY, sScale) + P_sBanDat(j, pc_HokyoYRow2) / 2
        'InsPnt(2) = 0.0#

        'pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        'pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        'pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        'acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠の太さ)
        '基準点(左補強枠の右側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + (x + CUD_BaseH)
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        insPntS(2) = 0.0#
        '基準点(左補強枠の左側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (x + CUD_BaseH / 2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠の太さ)
        '基準点(右補強枠の左側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x2
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        insPntS(2) = 0.0#
        '基準点(右補強枠の右側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + (x2 + CUD_BaseH)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + (x2 + CUD_BaseH / 2)
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y2 - 120)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(正面側横向き補強枠の手前側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x - 50
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + y2
        insPntS(2) = 0.0#
        '基準点(正面側横向き補強枠の奥側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x - 50
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (y2 + CUD_BaseH)
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x - 50
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y2 + CUD_BaseH / 2)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

        '寸法線(補強枠)
        '基準点(奥側横向き補強枠の奥側)
        insPntS(0) = SetScale(CUD_MainX, sScale) + x - 50
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y3 + CUD_BaseH)
        insPntS(2) = 0.0#
        '基準点(奥側横向き補強枠の手前側)
        insPntE(0) = SetScale(CUD_MainX, sScale) + x - 50
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y3
        insPntE(2) = 0.0#
        '寸法記入位置
        InsPnt(0) = SetScale(CUD_MainX, sScale) + x - 50
        InsPnt(1) = SetScale(KM_ZahyoY, sScale) + (y3 + CUD_BaseH / 2)
        InsPnt(2) = 0.0#

        pnt10 = CStr(insPntS(0)) & "," & CStr(insPntS(1)) & "," & CStr(insPntS(2))
        pnt11 = CStr(insPntE(0)) & "," & CStr(insPntE(1)) & "," & CStr(insPntE(2))
        pnt12 = CStr(InsPnt(0)) & "," & CStr(InsPnt(1)) & "," & CStr(InsPnt(2))
        acadDoc.SendCommand("_dimaligned" & vbCrLf & pnt10 & vbCrLf & pnt11 & vbCrLf & pnt12 & vbCrLf)

    End Sub


    '
    '補強枠作図プログラム(以下5つ)
    '
    Public Sub hokyowaku1(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal y As Double)
        '補強板(横向き長方形)
        Dim siten As String
        Dim taikaku As String
        Dim NinsPntS(0 To 2) As Double
        Dim NinsPntE(0 To 2) As Double
        Dim lin_Obj As Object

        SetActiveLine("BYLAYER")

        insPntS(0) = SetScale(CUD_MainX, sScale) + LX
        If P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
            insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y - CUD_BaseH
            insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y
        Else
            insPntS(1) = SetScale(KM_ZahyoY, sScale) + y
            insPntE(1) = SetScale(KM_ZahyoY, sScale) + y + CUD_BaseH
        End If
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) - RX
        insPntE(2) = 0.0#
        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString

        Call SetRectang(siten, taikaku)

        If nps = False Then
            '歯
            SetActiveLine("破線")
            NinsPntS(0) = SetScale(CUD_MainX + (LX / sScale), sScale)
            If P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
                NinsPntS(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) - y) / sScale), sScale) - 5
                NinsPntE(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) - y) / sScale), sScale) - 5
            Else
                NinsPntS(1) = SetScale(KM_ZahyoY + y / sScale, sScale) + CUD_BaseH - 5
                NinsPntE(1) = SetScale(KM_ZahyoY + y / sScale, sScale) + CUD_BaseH - 5
            End If
            NinsPntS(2) = 0.0#
            NinsPntE(0) = SetScale(CUD_MainX, sScale) + LX + 200
            NinsPntE(2) = 0.0#
            lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
            lin_Obj.Color = ACAD_COLOR.acRed

            NinsPntS(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) - RX
            If P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
                NinsPntS(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) - y) / sScale), sScale) - 5
                NinsPntE(1) = SetScale(KM_ZahyoY + ((Val(H_D(j)) - y) / sScale), sScale) - 5
            Else
                NinsPntS(1) = SetScale(KM_ZahyoY, sScale) + y + CUD_BaseH - 5
                NinsPntE(1) = SetScale(KM_ZahyoY + y / sScale, sScale) + CUD_BaseH - 5
            End If
            NinsPntS(2) = 0.0#
            NinsPntE(0) = SetScale(CUD_MainX + Val(H_W(j) / sScale), sScale) - RX - 200
            NinsPntE(2) = 0.0#
            lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
            lin_Obj.Color = ACAD_COLOR.acRed
            Call SetActiveLine("BYLAYER")
        End If
        

    End Sub

    Public Sub hokyowaku2(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal x As Double, ByVal y As Double)
        '補強板(縦向き長方形)
        Dim siten As String
        Dim taikaku As String
        Dim NinsPntS(0 To 2) As Double
        Dim NinsPntE(0 To 2) As Double
        Dim lin_Obj As Object

        SetActiveLine("BYLAYER")

        insPntS(0) = SetScale(CUD_MainX, sScale) + x
        insPntS(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX, sScale) + (x + CUD_BaseH)
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + y
        insPntE(2) = 0.0#
        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString

        Call SetRectang(siten, taikaku)

        If nps = False Then
            '歯
            If IO = "屋内" Then
                Call SetActiveLine("破線")
                NinsPntS(0) = SetScale(CUD_MainX, sScale) + CUD_BaseH - 5 + x
                NinsPntS(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH
                NinsPntS(2) = 0.0#
                NinsPntE(0) = SetScale(CUD_MainX, sScale) + CUD_BaseH - 5 + x
                NinsPntE(1) = SetScale(KM_ZahyoY, sScale) + CUD_BaseH + 200
                NinsPntE(2) = 0.0#
                lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
                lin_Obj.Color = ACAD_COLOR.acRed

                NinsPntS(0) = SetScale(CUD_MainX, sScale) + CUD_BaseH - 5 + x
                NinsPntS(1) = SetScale(KM_ZahyoY, sScale) + y
                NinsPntS(2) = 0.0#
                NinsPntE(0) = SetScale(CUD_MainX, sScale) + CUD_BaseH - 5 + x
                NinsPntE(1) = SetScale(KM_ZahyoY, sScale) - 200 + y
                NinsPntE(2) = 0.0#
                lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
                lin_Obj.Color = ACAD_COLOR.acRed
            End If
        End If
        

        Call SetActiveLine("BYLAYER")


    End Sub

    Public Sub hokyowaku3(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal x As Double, ByVal y As Double)
        '補強板(縦向き長方形、逆Ｔ、Π用)
        Dim siten As String
        Dim taikaku As String
        Dim NinsPntS(0 To 2) As Double
        Dim NinsPntE(0 To 2) As Double
        Dim lin_Obj As Object

        SetActiveLine("BYLAYER")

        insPntS(0) = SetScale(CUD_MainX, sScale) + x
        insPntS(1) = SetScale(KM_ZahyoY, sScale) - CUD_BaseH + Val(H_D(j))
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX, sScale) + CUD_BaseH + x
        insPntE(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) - y)
        insPntE(2) = 0.0#

        siten = insPntS(0).ToString & "," & insPntS(1).ToString & "," & insPntS(2).ToString
        taikaku = insPntE(0).ToString & "," & insPntE(1).ToString & "," & insPntE(2).ToString

        Call SetRectang(siten, taikaku)

        If nps = False Then
            '歯
            If IO = "屋内" Then
                Call SetActiveLine("破線")
                NinsPntS(0) = SetScale(CUD_MainX + x / sScale, sScale) + CUD_BaseH - 5
                NinsPntS(1) = SetScale(KM_ZahyoY + Val(H_D(j)) / sScale, sScale) - CUD_BaseH
                NinsPntS(2) = 0.0#
                NinsPntE(0) = SetScale(CUD_MainX + x / sScale, sScale) + CUD_BaseH - 5
                NinsPntE(1) = SetScale(KM_ZahyoY, sScale) - CUD_BaseH - 200 + Val(H_D(j))
                NinsPntE(2) = 0.0#
                lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
                lin_Obj.Color = ACAD_COLOR.acRed

                NinsPntS(0) = SetScale(CUD_MainX + x / sScale, sScale) + CUD_BaseH - 5
                NinsPntS(1) = SetScale(KM_ZahyoY, sScale) + (Val(H_D(j)) - y)
                NinsPntS(2) = 0.0#
                NinsPntE(0) = SetScale(CUD_MainX + x / sScale, sScale) + CUD_BaseH - 5
                NinsPntE(1) = SetScale(KM_ZahyoY, sScale) + 200 + (Val(H_D(j)) - y)
                NinsPntE(2) = 0.0#
                lin_Obj = moSpace.AddLine(NinsPntS, NinsPntE)
                lin_Obj.Color = ACAD_COLOR.acRed
            End If
        End If
        

        Call SetActiveLine("BYLAYER")
    End Sub

    Public Sub hokyowaku4(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal x As Double, ByVal x2 As Double, ByVal y As Double, ByVal tateumu As Integer)
        '補強枠(横向き長方形(井形用))
        Dim lin_obj As Object
        Dim i As Integer

        '横線
        For i = 0 To 1
            insPntS(0) = SetScale(CUD_MainX, sScale) + LX
            insPntS(1) = SetScale(KM_ZahyoY + (y / sScale), sScale)
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(CUD_MainX + (x / sScale), sScale)
            insPntE(1) = SetScale(KM_ZahyoY + (y / sScale), sScale)
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.Color = ACAD_COLOR.acGreen

            insPntS(0) = SetScale(CUD_MainX + x / sScale, sScale) + CUD_BaseH
            insPntS(1) = SetScale(KM_ZahyoY + (y / sScale), sScale)
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(CUD_MainX + (x2 / sScale), sScale)
            insPntE(1) = SetScale(KM_ZahyoY + (y / sScale), sScale)
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.Color = ACAD_COLOR.acGreen

            insPntS(0) = SetScale(CUD_MainX + x2 / sScale, sScale) + CUD_BaseH
            insPntS(1) = SetScale(KM_ZahyoY + (y / sScale), sScale)
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(CUD_MainX + (Val(H_W(j)) / sScale), sScale) - RX
            insPntE(1) = SetScale(KM_ZahyoY + (y / sScale), sScale)
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.Color = ACAD_COLOR.acGreen

            y = y + CUD_BaseH
        Next

        If tateumu = 0 Or tateumu = 2 Then
            '左側縦線
            insPntS(0) = SetScale(CUD_MainX, sScale) + LX
            insPntS(1) = SetScale(KM_ZahyoY, sScale) + (y - CUD_BaseH)
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(CUD_MainX, sScale) + LX
            insPntE(1) = SetScale(KM_ZahyoY, sScale) - 2 * CUD_BaseH + y
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.Color = ACAD_COLOR.acGreen

        End If
        If tateumu = 0 Or tateumu = 1 Then
            '右側縦線
            insPntS(0) = SetScale(CUD_MainX, sScale) - RX + Val(H_W(j))
            insPntS(1) = SetScale(KM_ZahyoY + y / sScale, sScale) - CUD_BaseH
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(CUD_MainX, sScale) - RX + Val(H_W(j))
            insPntE(1) = SetScale(KM_ZahyoY + y / sScale, sScale) - 2 * CUD_BaseH
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.Color = ACAD_COLOR.acGreen
        End If



    End Sub

    Public Sub hokyowaku5(ByVal CUD_MainX As Double, ByVal j As Integer, ByVal y As Double, ByVal tateumu As Integer)
        '横向き補強枠が線分で作図される(奥行枠が間に割り込まず、隣の枠と繋がるように見せる)場合の処理
        Dim lin_obj As Object

        insPntS(0) = SetScale(CUD_MainX, sScale) + LX
        If P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
            insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y - CUD_BaseH
            insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y - CUD_BaseH
        Else
            insPntS(1) = SetScale(KM_ZahyoY, sScale) + y
            insPntE(1) = SetScale(KM_ZahyoY, sScale) + y
        End If
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) - RX
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        lin_obj.Color = ACAD_COLOR.acGreen

        insPntS(0) = SetScale(CUD_MainX, sScale) + LX
        If P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
            insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y
            insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y
        Else
            insPntS(1) = SetScale(KM_ZahyoY, sScale) + y + CUD_BaseH
            insPntE(1) = SetScale(KM_ZahyoY, sScale) + y + CUD_BaseH
        End If
        insPntS(2) = 0.0#
        insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) - RX
        insPntE(2) = 0.0#
        lin_obj = moSpace.AddLine(insPntS, insPntE)
        '線種変更
        lin_obj.Color = ACAD_COLOR.acGreen

        If tateumu = 2 Then
            '左縦線
            insPntS(0) = SetScale(CUD_MainX, sScale) + LX
            If P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
                insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y
                insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y - CUD_BaseH
            Else
                insPntS(1) = SetScale(KM_ZahyoY, sScale) + y + CUD_BaseH
                insPntE(1) = SetScale(KM_ZahyoY, sScale) + y
            End If
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(CUD_MainX, sScale) + LX
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.Color = ACAD_COLOR.acGreen
        ElseIf tateumu = 1 Then
            '右縦線
            insPntS(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) - RX
            If P_sBanDat(j, pc_HokyoKataRow2) = "逆Ｔ字型" Or P_sBanDat(j, pc_HokyoKataRow2) = "逆Π型" Then
                insPntS(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y
                insPntE(1) = SetScale(KM_ZahyoY + (Val(H_D(j)) / sScale), sScale) - y - CUD_BaseH
            Else
                insPntS(1) = SetScale(KM_ZahyoY, sScale) + y + CUD_BaseH
                insPntE(1) = SetScale(KM_ZahyoY, sScale) + y
            End If
            insPntS(2) = 0.0#
            insPntE(0) = SetScale(CUD_MainX, sScale) + Val(H_W(j)) - RX
            insPntE(2) = 0.0#
            lin_obj = moSpace.AddLine(insPntS, insPntE)
            '線種変更
            lin_obj.Color = ACAD_COLOR.acGreen
        End If

    End Sub






    '-----------------------------------------------------------


    '
    '入力ﾃﾞｰﾀ取得
    '
    'Private Function fGetIptDat(ByRef sZbn As String, ByRef sScale As String) As Boolean

    '    fGetIptDat = False                                      '返値の初期化
    '------------------
    '図番
    '    sZbn = Trim(txtZbn.Text)                                '図番取得
    '    If sZbn = "" Then                                       '図番が入力されていない場合
    '        MsgBox("図番が入力されていません", vbOKOnly + vbExclamation, "図番未入力")   'ｴﾗｰﾒｯｾｰｼﾞ表示
    '        Exit Function                                       '処理中断
    '    End If
    '------------------
    '縮尺
    '    sScale = Trim(txtScale.Text)                            '縮尺取得
    '    If sScale = "" Then                                     '縮尺が入力されていない場合
    '        MsgBox("縮尺が入力されていません", vbOKOnly + vbExclamation, "縮尺未入力")   'ｴﾗｰﾒｯｾｰｼﾞ表示
    '        Exit Function                                       '処理中断
    '    End If
    '    fGetIptDat = True                                       'Trueを返す
    'End Function

    Private Sub btnkisoSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnkisoSave.Click

    End Sub
End Class