﻿Public Class frmHokyoIta

    Private Sub frmHokyoIta_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim num As Integer
        Dim i As Integer

        Call ReadBanData()

        num = P_sBanDat.GetLength(1) - 1
        ReDim Hako(num)

        For i = 0 To num
            cmbHakoNo.Items.Add("10" + P_sBanDat(25, i))           '箱番号
        Next

        Pic1.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板1.PNG"
        Pic2.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板1H.PNG"
        Pic3.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板3.PNG"
        Pic4.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板3H.PNG"
        Pic5.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板4.PNG"
        Pic6.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板4H.PNG"
        Pic7.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板5.PNG"
        Pic8.ImageLocation = "C:\Users\94503\Desktop\早期仕様確定\補強板画像\補強板5H.PNG"

    End Sub



    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Dim i As Integer
        Dim x As String

        If rbtnHokyo1.Checked = True Then
            HokyoPtn = 1
        ElseIf rbtnHokyo2.Checked = True Then
            HokyoPtn = 2
        ElseIf rbtnHokyo3.Checked = True Then
            HokyoPtn = 3
        ElseIf rbtnHokyo4.Checked = True Then
            HokyoPtn = 4
        ElseIf rbtnHokyo5.Checked = True Then
            HokyoPtn = 5
        ElseIf rbtnHokyo6.Checked = True Then
            HokyoPtn = 6
        ElseIf rbtnHokyo7.Checked = True Then
            HokyoPtn = 7
        ElseIf rbtnHokyo8.Checked = True Then
            HokyoPtn = 8
        End If

        On Error GoTo E
        x = cmbHakoNo.SelectedItem
        i = Val(x.Substring(2)) - 1
        Hako(i) = HokyoPtn       
        MsgBox("箱番号" & x & "の箱にパターン" & HokyoPtn & "を登録しました。")

        Exit Sub

E:
        Err.Clear()
        MsgBox("箱番号が選択されていません。")
        Exit Sub

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        FileClose(fileNumber)
        Me.Close()
    End Sub

    Private Sub frmHokyoIta_FormClosing(ByVal sender As System.Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        FileClose(fileNumber)
    End Sub

End Class
