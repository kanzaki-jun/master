﻿Public Class frmHairetu

    '図枠関係
    Private P_iTL_ZMaisu As Integer         '全ﾍﾟｰｼﾞ数

    '配列図関係
    Private PH_sPageBanNo(0, 0) As String  'ﾍﾟｰｼﾞ毎の盤No.
    Private P_dS_X As Double                '正面図のｽﾀｰﾄ座標(X座標)



    Private Const conH_Limit = 550          '最右表示位置(X座標)
    Private Const conDou10 = 72.0#          '配列図(正面図)と配列図(側面図)との間の距離


    '扉側面図
    Private Const conZhyX2 = 82.0#          '基準点X
    Private Const conZhyY2 = 159.0#         '基準点Y
    '正面図(2ﾍﾟｰｼﾞ目以降用)
    Private Const conZhyX3 = 90.0#          '基準点X






    '
    'ｷｬﾝｾﾙﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdCancel_Click(sender As System.Object, e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()    'ﾌｫｰﾑを閉じる
    End Sub
    '
    'ﾌｫｰﾑﾛｰﾄﾞ時
    '
    Private Sub frmHairetu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim sZbn As String                                      '図番
        Dim iDatNum As Integer                                  'ﾃﾞｰﾀ数
        Dim iShowNum As Integer                                 '表示箱数
        Dim iAllW As Integer                                    '全長
        Dim iDatCnt As Integer                                  'ﾃﾞｰﾀｶｳﾝﾀｰ

        frmkisoflg = True           'frm配列基礎仕様からではないことを示すフラグ
        BReadflg = True
        Wakuflg = False

        '※未決※：DBより過去に入力したﾃﾞｰﾀを取得する
        Call sRdGbnDat()
        If BReadflg = False Then
            Me.Close()
            Exit Sub
        End If

        '-----------------------------
        '工番情報表示
        lblKbn.Text = P_sKbnNam                                 '配列図作成ﾌｫｰﾑに工番表示
        lblGbn.Text = P_sGbn                                    '配列図作成ﾌｫｰﾑに群番表示
        lblSegment.Text = P_sSegment & "セグメント"             '配列図作成ﾌｫｰﾑにｾｸﾞﾒﾝﾄ表示
        iDatNum = UBound(P_sBanDat, 2)                          'ﾃﾞｰﾀ数取得
        '-----------------------------
        '図面に表記する箱数/全長表示
        iShowNum = 0 : iAllW = 0                                '表示箱数/全長初期化
        For iDatCnt = 0 To iDatNum                              '全箱分
            If InStr(P_sBanDat(pc_NoHairetuRow, iDatCnt), P_conNoShow) = 0 Then '納入外（非表示）でなければ
                iShowNum = iShowNum + 1                         '表示箱数を1増やす
                iAllW = iAllW + Val(P_sBanDat(pc_BanWRow, iDatCnt)) '全長計算
            End If
        Next iDatCnt
        lblAllHako.Text = "全" & CStr(iShowNum) & "箱　" & CStr(iAllW) & "mm"   '箱数･全長表示
        '-----------------------------
        'ﾃﾞﾌｫﾙﾄ値表示
        '※未決※：DBより取得したﾃﾞｰﾀがあればそれを表示する
        'txtSyubetu.Text = fGetMaxV() & "高圧スイッチギヤ"       '製品種別
        txtSyubetu.Text = Syubetu       '製品種別
        txtSetubi.Text = Meisho         '設備名称
        txtPage.Text = "1" : txtAllPage.Text = "1"              'ﾍﾟｰｼﾞ数表示
        sZbn = P_sKbn : Mid(sZbn, 4, 1) = "P"                   '工番に部門追加
        '配列図作成ﾌｫｰﾑに図番表示
        txtZbn.Text = Trim(Mid(sZbn, 1, 6) & "-" & Mid(sZbn, 7)) & "-BA" & Mid(P_sGbn, Len(P_sGbn), 1) & "01"
        txtY.Text = Now.ToString("yy")                          '現在の年表示
        txtM.Text = CStr(Now.Month)                             '現在の月表示
        txtD.Text = CStr(Now.Day)                               '現在の日表示
        cmbSiz.Text = "C"                                       '縮尺初期値表示
        cmbScale.Text = CStr(conScale_H)                        '縮尺初期値表示
    End Sub
    '
    '群番ﾃﾞｰﾀ読み込み(暫定版)
    '
    Private Sub sRdGbnDat()
        Dim iBanNum As Integer, iBanCnt As Integer      '盤数,盤ｶｳﾝﾀｰ
        Dim iFldNum As Integer, iFldCnt As Integer      'ﾌｨｰﾙﾄﾞ数, ﾌｨｰﾙﾄﾞｶｳﾝﾀｰ


        KoubanName = frm配列基礎メイン.txtKbnNam.Text
        GunbanName = frm配列基礎メイン.txtGbn.Text

        If DB_配列基礎共通("select") = True Then
            stat = DB_配列図箱別("select")
            stat = DB_基礎図箱別("select")
        Else
            MsgBox("盤データが設定されていません。" & vbCrLf & "処理を中止します。")
            BReadflg = False
            Me.Close()
            Exit Sub
        End If

        

        '-----------------------------------------------------------------------------------------------------------------
        ''txtファイルからの読み込み
        'Call MakeBanFile(frm配列基礎仕様.pc_HeaderTxt.Length - 4 + frm配列基礎仕様.pc_HeaderTxt2.Length - 4 + 4 * 4)
        'If BReadflg = False Then                        'ファイルの作成ができなかった場合
        '    Exit Sub
        'End If
        'Call ReadBanData()
        '------------------------------------------------------------------------------------------------------------------

        'iBanNum = UBound(P_sBanDat, 1)                  '盤数取得
        iBanNum = UBound(P_sBanDat, 1) + 1                  '盤数取得
        'iFldNum = UBound(P_sBanDat, 2)                  'ﾌｨｰﾙﾄﾞ数取得
        iFldNum = frm配列基礎仕様.pc_HeaderTxt.Length - 4 'ﾌｨｰﾙﾄﾞ数取得
        'Dim sTmpDat(iFldNum, iBanNum - 1)               '配列入替用変数定義
        Dim sTmpDat(iFldNum - 1, iBanNum)               '配列入替用変数定義
        'For iBanCnt = 0 To iBanNum - 1
        For iBanCnt = 1 To iBanNum
            For iFldCnt = 0 To iFldNum - 1
                'sTmpDat(iFldCnt, iBanCnt) = P_sBanDat(iBanCnt, iFldCnt)
                sTmpDat(iFldCnt, iBanCnt - 1) = P_sBanDat(iBanCnt - 1, iFldCnt)
            Next iFldCnt
        Next iBanCnt
        '--------------------------------
        '箱別事項
        ReDim H_CubNo(iBanNum + 1)                          '盤No.
        ReDim H_NP1(iBanNum)                            '名称(1)
        ReDim H_NP2(iBanNum)                            '名称(2)
        ReDim H_NP3(iBanNum)                            '名称(3)
        ReDim H_DRZuban(iBanNum)                        '側面図番
        ReDim H_DoorZuban(iBanNum)                      '盤面図番
        ReDim H_Kata(iBanNum)                           '形
        ReDim H_Hogo1(iBanNum)                          '保護等級（閉鎖箱）
        ReDim H_Hogo2(iBanNum)                          '保護等級(仕切板）
        ReDim H_DenAtu(iBanNum)                         '定格電圧
        ReDim H_Hz(iBanNum)                             '周波数
        ReDim H_PowerFreq(iBanNum)                      '商用周波
        ReDim H_Impulse(iBanNum)                        '雷インパルス
        ReDim H_Zetuen(iBanNum)                         '絶縁階級
        ReDim H_TNP(iBanNum)                            '製造者銘板番号
        ReDim H_Jyotai(iBanNum)                         '環境条件
        ReDim H_DoorOpen(iBanNum)                       '扉開放角度
        ReDim H_Jyuryo(iBanNum)                         '盤概略質量
        ReDim H_D(iBanNum)                              '奥行配列再定義
        ReDim H_H(iBanNum)                              '高さ配列再定義
        ReDim H_W(iBanNum)                              '幅配列再定義
        ReDim H_WakuType(iBanNum)                       '正面扉形状
        ReDim H_Totte(iBanNum)                          '把手の形配列再定義
        ReDim ExtCubNo(iBanNum)                         '納入外配列箱No再定義
        ReDim SKFullPath(iBanCnt - 1)

        For iBanCnt = 1 To iBanNum                      '全ての盤ﾃﾞｰﾀを取得
            H_CubNo(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_BanNoRow)          '盤No.
            H_NP1(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_NP1Row)              '名称(1)
            H_NP2(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_NP2Row)              '名称(2)
            H_NP3(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_NP3Row)              '名称(3)
            H_DRZuban(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_DRZbnRow)        '側面図番
            H_DoorZuban(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_DoorZbnRow)    '盤面図番
            '形と規格番号が入力されている場合
            If Trim(P_sBanDat(iBanCnt - 1, pc_BoxTypRow)) <> "" And Trim(P_sBanDat(iBanCnt - 1, pc_KikakuNoRow)) <> "" Then
                H_Kata(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_BoxTypRow) & "(" & P_sBanDat(iBanCnt - 1, pc_KikakuNoRow) & ")" '形
            Else
                H_Kata(iBanCnt) = ""
            End If
            H_Hogo1(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_HogoBoxRow)        '保護等級(閉鎖箱)
            H_Hogo2(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_HogoItaRow)        '保護等級(仕切板)
            H_DenAtu(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_TeikakuVRow)      '定格電圧
            H_Hz(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_FreqRow)              '周波数
            H_PowerFreq(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_ComFreqRow)    '商用周波
            H_Impulse(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_ImplsRow)        '雷ｲﾝﾊﾟﾙｽ
            H_Zetuen(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_ClsRow)           '絶縁階級
            H_TNP(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_NPRow)               '製造者銘板番号
            H_Jyotai(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_KankyouRow)       '環境条件
            H_DoorOpen(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_DoorOpnRow)     '扉開放角度
            H_Jyuryo(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_JyuryoRow)        '扉開放角度
            H_D(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_BanDRow)               '盤奥行
            H_H(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_BanHRow)               '盤高さ
            H_W(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_BanWRow)               '盤幅
            H_WakuType(iBanCnt) = fCreDoorTyp(P_sBanDat(iBanCnt - 1, pc_FDoorRow), P_sBanDat(iBanCnt - 1, pc_RDoorRow))
            H_Totte(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_FTotteRow)         '正面把手
            ExtCubNo(iBanCnt) = P_sBanDat(iBanCnt - 1, pc_NoHairetuRow)     '納入外配列箱No

            If P_sBanDat(iBanCnt - 1, pc_BlkSKRow) <> "" Then
                Dim files As String() = System.IO.Directory.GetFiles(SKPath, _
             P_sBanDat(iBanCnt - 1, pc_BlkSKRow) & ".dwg", System.IO.SearchOption.AllDirectories)
                If files.Length <> 0 Then
                    SKFullPath(iBanCnt - 1) = files(0)
                End If
            End If
            

        Next iBanCnt
        'ReDim P_sBanDat(iFldNum, iBanNum - 1)
        ReDim P_sBanDat(iFldNum - 1, iBanNum - 1)
        For iBanCnt = 0 To iBanNum - 1
            'For iFldCnt = 0 To iFldNum
            For iFldCnt = 0 To iFldNum - 1
                P_sBanDat(iFldCnt, iBanCnt) = sTmpDat(iFldCnt, iBanCnt)
            Next iFldCnt
        Next iBanCnt

    End Sub

    '
    '群番内の最大定格電圧を返す
    '
    Private Function fGetMaxV() As String
        Dim iDatNum As Integer                                  'ﾃﾞｰﾀ数
        Dim dMaxV As Double, iMaxVNo As Integer                 '最大定格電圧,最大定格電圧のﾃﾞｰﾀNo.
        Dim sTmpV As String, dTmpV As Double                    '定格電圧

        iDatNum = UBound(P_sBanDat, 2)                          'ﾃﾞｰﾀ数取得
        dMaxV = 0
        For iDatCnt = 0 To iDatNum                              '全箱分
            sTmpV = UCase(P_sBanDat(pc_TeikakuVRow, iDatCnt))   '定格電圧取得
            If sTmpV = "" Then                                  '定格電圧が入力されていない場合
                dTmpV = 0                                       '数値を取得しない
            ElseIf Mid(sTmpV, Len(sTmpV) - 1, 2) = "KV" Then    '単位がkVの場合
                sTmpV = Mid(sTmpV, 1, Len(sTmpV) - 2)           '単位より前を取得
                If IsNumeric(sTmpV) = True Then                 '単位より前が数値の場合
                    dTmpV = Val(sTmpV) * 1000                   '数値を1000倍する
                End If
            ElseIf Mid(sTmpV, Len(sTmpV), 1) = "V" Then         '単位がVの場合
                sTmpV = Mid(sTmpV, 1, Len(sTmpV) - 1)           '単位より前を取得
                If IsNumeric(sTmpV) = True Then                 '単位より前が数値の場合
                    dTmpV = Val(sTmpV)                          '数値を取得
                End If
            Else                                                '単位がkV,V以外
                dTmpV = 0                                       '数値を取得しない
            End If
            If dMaxV < dTmpV Then                               'これまでの最大定格電圧の場合
                dMaxV = dTmpV                                   '定格電圧を覚えておく
                iMaxVNo = iDatCnt                               'ﾃﾞｰﾀNo.を覚えておく
            End If
        Next iDatCnt
        If dMaxV = 0 Then                                       '定格電圧が取得できなかった場合
            fGetMaxV = ""                                       '""を返す
        Else                                                    '定格電圧が取得できた場合
            fGetMaxV = P_sBanDat(pc_TeikakuVRow, iMaxVNo)       '最大定格電圧を返す
        End If
    End Function
    '
    '作成開始ﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdOK_Click(sender As System.Object, e As System.EventArgs) Handles cmdOK.Click
        Dim sSetubi As String                                   '設備名称
        Dim sSyubetu As String                                  '製品種別
        Dim sPage As String                                     'ﾍﾟｰｼﾞ
        Dim sZbn As String                                      '図番
        Dim sDate As String                                     '日付
        Dim sSiz As String                                      '図面ｻｲｽﾞ
        Dim sPath As String                                     '配列図保存場所
        Dim sFilNam As String                                   '配列図ﾌｧｲﾙ名
        Dim sDwtFilNam As String                                'ﾃﾝﾌﾟﾚｰﾄﾌｧｲﾙ名
        Dim Ans As String
        Dim i As Integer, p As Integer
        iPage = 1

        '------------------------
        '入力ﾃﾞｰﾀの取得ができなかった場合は処理中断
        If fGetIptDat(sSetubi, sSyubetu, sPage, sZbn, sDate, sSiz) = False Then Exit Sub

        Sea_Dir_Hairetu = "\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\" & P_sSegment & "\"

        '※未決※：入力ﾃﾞｰﾀをDBに保存


        Stopflg = False
        Sakuzuflg = True           'エラーチェック用フラグ:作図処理中
        Diversionflg = False

        'Call BanNoErrChk()          '箱番の重複
        'Call IsNumericErrChk()      '数値のみ入力するセルに数値以外の入力があるか
        'Call Mesure0Chk()           '寸法値が0になっていないか
        'Call DoorSelectChk()
        'Call DataErrChk()
        'If lblCnt <> 0 Then
        '    frmErrorList.Show()
        '    MsgBox("正しく作図できないので、各データを修正してから再作図してください。", , "作図中断")
        '    Me.Close()
        '    Exit Sub
        'End If
        SKCnt = 0
        Syubetu = txtSyubetu.Text
        stat = DB_配列基礎共通("update2")     'frmHairetuで入力された内容をDBへ(現在は製品種別のみ)

        If CmbNps.SelectedItem = "NPS承認図" Then                  'NPS承認図用(簡略図)として作図するなら(01/18追加)
            nps = True
        Else
            nps = False
        End If

        '------------------------
        sDwtFilNam = P_sWakPath & "M_" & p_Scale & ".dwt"        'ﾃﾝﾌﾟﾚｰﾄﾌｧｲﾙ名作成
        Tmpnam = P_sWakPath & "M_" & p_Scale & ".dwt"        'ﾃﾝﾌﾟﾚｰﾄﾌｧｲﾙ名作成
        If FileIO.FileSystem.FileExists(sDwtFilNam) = False Then    '指定された縮尺用のﾃﾝﾌﾟﾚｰﾄが存在しない場合
            MsgBox("指定された縮尺の図面は作成できません", vbOKOnly + vbExclamation, "縮尺非対応") 'ｴﾗｰﾒｯｾｰｼﾞ表示
            Exit Sub                                            '処理中断
        End If
        '------------------------
        sPath = fCreSavPath("配列")                             '配列図保存場所取得
        '保存場所が無い場合はﾌｫﾙﾀﾞを作成する
        If FileIO.FileSystem.DirectoryExists(sPath) = False Then FileIO.FileSystem.CreateDirectory(sPath)
        sFilNam = sPath & sZbn & ".dwg"                         '配列図ﾌｧｲﾙ名作成
        If FileIO.FileSystem.FileExists(sFilNam) = True Then    '既に配列図ﾌｧｲﾙが存在する場合
            '上書き確認の結果NGの場合
            If MsgBox("既にファイルが存在しています。" & vbCrLf & "上書きしてもよろしいですか？", _
                   vbYesNo + vbQuestion, "ファイル上書き確認") = MsgBoxResult.No Then
                MsgBox("処理を中断しました", vbOKOnly + vbInformation, "処理中断")   '処理中断ﾒｯｾｰｼﾞ表示
                Exit Sub                                        '処理中断
            Else                                                '上書き確認の結果OKの場合
                'ﾌｧｲﾙを開く処理とかUSERﾚｲﾔｰ以外の消去とかする
                MsgBox("まだ上書き処理できてないの　((((；ﾟДﾟ)))", vbOKOnly + vbInformation, "処理中断")   '処理中断ﾒｯｾｰｼﾞ表示
                Exit Sub                                        '処理中断
            End If
        Else                                                    '新規にﾌｧｲﾙを作成する場合
            Call sOpnBcad(sDwtFilNam)                           'BricsCAD起動


            '必要図面枚数の計算
            Call CalNeedPageH()
            

            ' ファイルを開く
            i = 1
            'Ans = OpenAcadFile("配列", i)
            '図枠挿入(ひとまず和文一択)


            For p = 1 To TL_ZMaisu
                iPage = p
                Ans = OpenAcadFile("配列", p)
                Call sCreZwkH("配列図", sSetubi, sSyubetu, sPage, sZbn, sDate, sSiz, "JPN")
                Call sCreHairetu()
                'Hairetuzu = MkKiPath(Sea_Dir_Hairetu, P_sKbnNam) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & "\" & TGbn & "\H_" & P_sKbnNam & GunbanName & "P" & p & "K0.dwg"
                Hairetuzu = MkKiPath(Sea_Dir_Hairetu, P_sKbnNam) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & Strings.Mid(sZbn, 1, sZbn.Length - 1) & iPage & "_R0.dwg"
                On Error Resume Next
                acadDoc.SaveAs(Hairetuzu)
            Next



        End If

        acadDoc.SendCommand("LTSCALE" & vbCrLf & sScale & vbCrLf)    '線種尺度の調整(一点鎖線や破線がただの直線に見えるため追加)

        ' OSNAPのオン
        acadDoc.ObjectSnapMode = True

        acadApp.Visible = True                                          'BricsCAD可視化
        MsgBox("作成完了", vbOKOnly + vbSystemModal, "完了")
        'ファイル名の決定
        'Hairetuzu = MkKiPath(Sea_Dir_Kiso, KoubanName) & "\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & "\" & TGbn & "\H_" & KoubanName & GunbanName & "P" & i & "K0.dwg"
        ' 基礎図を工番名にて保存
        'On Error Resume Next
        'acadDoc.SaveAs(Hairetuzu)
        Me.Close()
        MsgBox("終わります")
    End Sub
    '
    '入力ﾃﾞｰﾀ取得
    '
    Public Function fGetIptDat(ByRef sSetubi As String, ByRef sSyubetu As String, ByRef sPage As String, _
                                ByRef sZbn As String, ByRef sDate As String, ByRef sSiz As String) _
                            As Boolean


        fGetIptDat = False                                      '返値の初期化
        '------------------
        '図番
        sZbn = Trim(txtZbn.Text)                                '図番取得
        If sZbn = "" Then                                       '図番が入力されていない場合
            MsgBox("図番が入力されていません", vbOKOnly + vbExclamation, "図番未入力")   'ｴﾗｰﾒｯｾｰｼﾞ表示
            Exit Function                                       '処理中断
        End If


        '------------------
        sSetubi = Meisho                                '設備名称取得(DBより)
        sSyubetu = Syubetu                              '製品種別取得(DBより)
        sPage = "(" & txtPage.Text & "/" & txtAllPage.Text & ")"    'ﾍﾟｰｼﾞ取得
        sDate = String.Format("{0,2} 年{1,2} 月{2,2} 日", txtY.Text, txtM.Text, txtD.Text) '日付取得
        sSiz = Trim(cmbSiz.Text)                                '図面ｻｲｽﾞ取得
        p_Scale = Val(Trim(cmbScale.Text))                      '縮尺取得
        fGetIptDat = True                                       'Trueを返す
    End Function


End Class