﻿Imports System
Imports System.IO
Imports System.Collections.Generic


Public Class frmBlkSK
    'ブロックスケルトン選択ツリーのフォーム
    'ツリー自体は配列基礎メインのフォームのロード時に作成

    Private Sub frmBlkSK_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ReDim Preserve SKFullPath(frm配列基礎仕様.gridHairetuKiso.ColumnCount - 1)
    End Sub

    Private Sub tvBlkSK_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvBlkSK.AfterSelect
        Dim i As Integer, j As Integer, k As Integer
        Dim pic As String
        Dim ClkPath As String = SKPath & e.Node.FullPath.Substring(rootNode.Text.Length) & "\"
        'For i = 0 To Folders.Length - 1
        'If Folders(i) = SKPath & e.Node.FullPath.Substring(2) Then
        'If System.IO.File.Exists("\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\skeleton\SKTree\7.2kV\TR2次\配列\ダクト引込\EVT\VCB\GC無し\") Then

        '.dwgか.pngのつくファイル名を配列で取得
        'ClkPathは上で宣言されている変数。
        'そこに代入されているSKPathはParameterで宣言されており、
        '"\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\skeleton\SKTree"が入っている
        'それ以降にはクリックしたところまでのPathが入力されている　

        Dim files As String() = System.IO.Directory.GetFiles(ClkPath, _
             "*.dwg", System.IO.SearchOption.TopDirectoryOnly)

        'picfilesはパブリック変数でParameterで宣言されている。

        picfiles = System.IO.Directory.GetFiles(ClkPath, _
                 "*.png", System.IO.SearchOption.TopDirectoryOnly)

        j = 0 : k = 0 : pic = ""

        For j = 0 To picfiles.Length - 1        '拡張子「PNG」を小文字にする処理
            pic = picfiles(j).Substring(picfiles(j).Length - 3)     '拡張子を抜き出す
            pic = LCase(pic)                                        '小文字に変換
            picfiles(j) = picfiles(j).Substring(0, picfiles(j).Length - 3) & pic    '小文字にした拡張子を適用
        Next

        lstSK.Items.Clear()         '選択フォルダがかわっているため、リストボックスを空に
        btnTuika.Enabled = False
        'ListBox1に結果を表示する
        For i = 0 To files.Length - 1       '見つかったdwgファイルの数だけループ
            '取得したファイル名がパス付きなので、パス部分を消してリストボックスに追加
            lstSK.Items.Add(files(i).ToString.Substring(ClkPath.Length))
        Next


        If picSK.ImageLocation <> Nothing Then      '既にプレビュー表示がされている場合
            picSK.ImageLocation = Nothing           'プレビューを無くす
        End If
        btnTuika.Enabled = False

    End Sub

    Private Sub btnTuika_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTuika.Click
        frm配列基礎仕様.gridHairetuKiso.Rows(pc_BlkSKRow).Cells(SKX).Value = lstSK.Text.Substring(0, lstSK.Text.Length - 4)
        SKFullPath(SKX) = fullpath & "\" & lstSK.Text
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub


    'リストから種類をクリックし、下のテキストボックスにファイル名が表示される
    'そのファイル名を選択すると、プレビューを表示する作業をここでおこなう

    Private Sub lstSK_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstSK.SelectedIndexChanged
        Dim i As Integer, j As Integer
        i = 0 : j = 0
        Dim ItemIndex As Integer

        ItemIndex = lstSK.SelectedIndex

        If ItemIndex <> -1 Then     'リストボックスの項目が選択されていれば

            'SKPathは"\\Nas-Server.swg.nissin.co.jp\設計データ\20 設計ツール\shounin\block\skeleton\SKTree"の文字列が入っており、
            '

            fullpath = SKPath & tvBlkSK.SelectedNode.FullPath.Substring(rootNode.Text.Length)
            picname = lstSK.Text.Substring(0, lstSK.Text.Length - 4) & ".png"

            If picSK.ImageLocation <> Nothing Then      '既にプレビュー表示がされている場合
                picSK.ImageLocation = Nothing           'プレビューを無くす
            End If

            'picfiles内の繰り返し
            For i = 0 To picfiles.Length - 1
                'picfilesに入っているパスとpath\picnameが同じとき画像を表示
                If picfiles(i) = fullpath & "\" & picname Then
                    If System.IO.File.Exists(picfiles(i)) Then
                        picSK.ImageLocation = picfiles(i)   'pictuireboxに表示する画像ファイルのパスを取得
                        MsgBox(picfiles(i))
                    End If
                    Exit For
                End If
            Next

            'lblPrev.Text = lstSK.Text.Substring(0, lstSK.Text.Length - 4)
            '「表に追加」ボタンを押せるようにする
            btnTuika.Enabled = True
        Else
            'ボタンを押せないように
            btnTuika.Enabled = False
        End If
    End Sub



End Class