﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm配列基礎メイン
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtKbnNam = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtGbn = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnHairetuKiso = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnRyuyo = New System.Windows.Forms.Button()
        Me.cmdCreHairetu = New System.Windows.Forms.Button()
        Me.btnOpen = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.cmdCreKiso = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.cmbSegment = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "工番"
        '
        'txtKbnNam
        '
        Me.txtKbnNam.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtKbnNam.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtKbnNam.Location = New System.Drawing.Point(41, 10)
        Me.txtKbnNam.Name = "txtKbnNam"
        Me.txtKbnNam.Size = New System.Drawing.Size(87, 19)
        Me.txtKbnNam.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(144, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "群番"
        '
        'txtGbn
        '
        Me.txtGbn.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtGbn.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtGbn.Location = New System.Drawing.Point(179, 10)
        Me.txtGbn.Name = "txtGbn"
        Me.txtGbn.Size = New System.Drawing.Size(39, 19)
        Me.txtGbn.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(46, 80)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(63, 22)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "工番変更"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnHairetuKiso
        '
        Me.btnHairetuKiso.Location = New System.Drawing.Point(237, 36)
        Me.btnHairetuKiso.Name = "btnHairetuKiso"
        Me.btnHairetuKiso.Size = New System.Drawing.Size(100, 22)
        Me.btnHairetuKiso.TabIndex = 5
        Me.btnHairetuKiso.Text = "配列・基礎仕様"
        Me.btnHairetuKiso.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(343, 36)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(72, 22)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "盤仕様"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnRyuyo
        '
        Me.btnRyuyo.Location = New System.Drawing.Point(127, 80)
        Me.btnRyuyo.Name = "btnRyuyo"
        Me.btnRyuyo.Size = New System.Drawing.Size(63, 22)
        Me.btnRyuyo.TabIndex = 7
        Me.btnRyuyo.Text = "仕様流用"
        Me.btnRyuyo.UseVisualStyleBackColor = True
        '
        'cmdCreHairetu
        '
        Me.cmdCreHairetu.Location = New System.Drawing.Point(446, 8)
        Me.cmdCreHairetu.Name = "cmdCreHairetu"
        Me.cmdCreHairetu.Size = New System.Drawing.Size(103, 22)
        Me.cmdCreHairetu.TabIndex = 8
        Me.cmdCreHairetu.Text = "配列図自動作図"
        Me.cmdCreHairetu.UseVisualStyleBackColor = True
        '
        'btnOpen
        '
        Me.btnOpen.Location = New System.Drawing.Point(585, 8)
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.Size = New System.Drawing.Size(75, 22)
        Me.btnOpen.TabIndex = 9
        Me.btnOpen.Text = "図面を開く"
        Me.btnOpen.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(585, 36)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 22)
        Me.Button7.TabIndex = 10
        Me.Button7.Text = "終了"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'cmdCreKiso
        '
        Me.cmdCreKiso.Location = New System.Drawing.Point(446, 36)
        Me.cmdCreKiso.Name = "cmdCreKiso"
        Me.cmdCreKiso.Size = New System.Drawing.Size(103, 22)
        Me.cmdCreKiso.TabIndex = 11
        Me.cmdCreKiso.Text = "基礎図自動作図"
        Me.cmdCreKiso.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(237, 8)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(100, 22)
        Me.Button9.TabIndex = 12
        Me.Button9.Text = "共通仕様"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'cmbSegment
        '
        Me.cmbSegment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSegment.FormattingEnabled = True
        Me.cmbSegment.Items.AddRange(New Object() {"産業", "水", "電鉄", "電力", "道路"})
        Me.cmbSegment.Location = New System.Drawing.Point(62, 38)
        Me.cmbSegment.Name = "cmbSegment"
        Me.cmbSegment.Size = New System.Drawing.Size(66, 20)
        Me.cmbSegment.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 41)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 12)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "セグメント"
        '
        'frm配列基礎メイン
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(679, 114)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmbSegment)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.cmdCreKiso)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.btnOpen)
        Me.Controls.Add(Me.cmdCreHairetu)
        Me.Controls.Add(Me.btnRyuyo)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnHairetuKiso)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtGbn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtKbnNam)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frm配列基礎メイン"
        Me.Text = "配列図・基礎図メイン"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtKbnNam As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtGbn As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnHairetuKiso As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btnRyuyo As System.Windows.Forms.Button
    Friend WithEvents cmdCreHairetu As System.Windows.Forms.Button
    Friend WithEvents btnOpen As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents cmdCreKiso As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents cmbSegment As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label

End Class
