﻿Module BricsCAD
    '
    'BricsCAD起動
    'sTmpFil:ﾃﾝﾌﾟﾚｰﾄﾌｧｲﾙ名
    '
    Public Sub sOpnBcad(ByVal sTmpFil As String)
        On Error Resume Next                                            'ｴﾗｰがあっても次へ
        acadApp = GetObject(, "BricscadApp.AcadApplication")            'BricsCADｱﾌﾟﾘｹｰｼｮﾝ取得
        If Err.Number <> 0 Then                                         '取得できなければ
            Err.Clear()                                                 'ｴﾗｰｸﾘｱ
            acadApp = CreateObject("BricscadApp.AcadApplication")       'BricsCADｱﾌﾟﾘｹｰｼｮﾝ作成
        Else                                                            '既にBricsCADが起動している場合
            'For iDocCnt = 0 To acadApp.Documents.Count - 1              '全ての開いているﾄﾞｷｭﾒﾝﾄ
            '    '作成しようとしているﾌｧｲﾙが開いていた場合
            '    For i = 1 To 5
            '        sWakDWGNam = "K_" & P_sKbnNam & P_sGbn & "P*.dwg"
            '        sCreFilNam = UCase(Mid(sWakDWGNam, InStrRev(sWakDWGNam, "\") + 1))  '作成するﾌｧｲﾙ名(ﾊﾟｽ無し)取得
            '        If UCase(acadApp.Documents.Item(iDocCnt).Name) = sCreFilNam Then
            '            'ｴﾗｰﾒｯｾｰｼﾞ表示
            '            MsgBox("BricsCAD上で作成しようとしているファイルが既に開いています。" & vbCrLf & _
            '            "ファイルを閉じてから再度データを作成して下さい" & vbCrLf & _
            '            "ファイル名：" & sWakDWGNam, vbOKOnly + vbExclamation, "処理中断")
            '            sWakDWGNam = ""                                     'ﾌｧｲﾙ名をｸﾘｱする
            '            MsgBox("処理を終了します。")
            '            Ovrlapflg = True
            '            Exit Sub
            '        End If
            '    Next

            'Next iDocCnt                                                '
        End If
        acadDoc = acadApp.Documents.Add(sTmpFil)                        '新規ﾄﾞｷｭﾒﾝﾄをﾃﾝﾌﾟﾚｰﾄを使用して追加
        acadDoc = acadApp.ActiveDocument                                'ｶﾚﾝﾄ図面取得
        acadDoc.ObjectSnapMode = False                                  'ｵﾌﾞｼﾞｪｸﾄｽﾅｯﾌﾟを解除しておく
        acadUtl = acadDoc.Utility                                       'ﾕｰﾃｨﾘﾃｨｰ取得
        moSpace = acadDoc.ModelSpace                                    'ﾓﾃﾞﾙ空間取得
        'acadApp.Visible = False                                          'BricsCAD非可視化

    End Sub
    '
    '図枠読込
    '
    Public Sub sCreZwk()
        Dim dInsPnt(0 To 2) As Double
        Dim sWakFil As String
        Dim blkObj As Object
        Dim Attribs As Object                                           '属性
        Dim iCnt As Integer                                             'ｶｳﾝﾀｰ

        If Wakuflg = False Then
            sWakFil = BlockPath3 & "M_2C(JPN_Outline_A2).dwg"

            Call SetActiveLayer("枠")

            dInsPnt(0) = 0 : dInsPnt(1) = 0 : dInsPnt(2) = 0
            blkObj = moSpace.InsertBlock(dInsPnt, sWakFil, sScale, sScale, 1, 0)
            Attribs = blkObj.GetAttributes                                  '図枠中の属性を全て取得
            For iCnt = LBound(Attribs) To UBound(Attribs)                   '全属性
                Select Case Attribs(iCnt).TagString                         '属性名
                    Case "NAME_UPPER"                                       '図題1
                        Attribs(iCnt).TextString = "基礎図"                    '図題1入力
                    Case "NAME_MIDDLE"                                      '図題2
                        Attribs(iCnt).TextString = frm配列基礎仕様.txtMeisyo.Text                    '図題2入力
                    Case "NAME_LOWER"                                       '図題3
                        Attribs(iCnt).TextString = frm配列基礎仕様.txtSyubetu.Text                    '図題3入力
                    Case "PAGE"                                             'ﾍﾟｰｼﾞ
                        'Attribs(iCnt).TextString = sPage                    'ﾍﾟｰｼﾞ入力
                    Case "SCALE"                                            '縮尺              
                        Attribs(iCnt).TextString = "1:" & sScale '縮尺入力
                    Case "GUNBAN"                                           '群番
                        Attribs(iCnt).TextString = P_sGbn                   '群番入力
                    Case "DWG.NO"                                           '図番
                        TL_Zuban = Strings.Mid(frmkiso.txtZbn.Text, 1, frmkiso.txtZbn.Text.Length - 1) & PCnt   '図番の最後の1桁をページ番号にする
                        Attribs(iCnt).TextString = TL_Zuban                     '図番入力
                    Case "DATE"                                             '日付
                        Attribs(iCnt).TextString = TL_Date                    '日付入力
                    Case "'00年00月00日"                                       '日付
                        Attribs(iCnt).TextString = TL_Date                    '日付入力

                End Select
            Next iCnt

            Call SetActiveLayer("自動作成")

            Wakuflg = True
        End If

    End Sub
    '
    '図枠読込(配列図処理用)
    'sSiz:図面ｻｲｽﾞ iScale:縮尺　sJpnEng:"JPN"or"ENG"　sZbn:図番
    '
    Public Sub sCreZwkH(ByVal sZdi1 As String, ByVal sZdi2 As String, ByVal sZdi3 As String, ByVal sPage As String, _
                        ByVal sZbn As String, ByVal sDate As String, ByVal sSiz As String, _
                        ByVal sJpnEng As String)
        Dim dInsPnt(0 To 2) As Double                                   '図枠挿入位置
        Dim sWakFil As String                                           '図枠ﾌｧｲﾙ名
        Dim blkObj As AcadBlockReference                                'ﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
        Dim Attribs As Object                                           '属性
        Dim iCnt As Integer                                             'ｶｳﾝﾀｰ

        'If Wakuflg = False Then                                         'まだ図枠が作図されていないなら
        If sJpnEng = "JPN" Then                                         '和文の場合
            '図枠ﾌｧｲﾙ名作成
            sWakFil = P_sWakPath & "M_2" & sSiz & "(JPN_Outline_A" & CStr(InStr("BCD", sSiz)) & ")" & EndString
        Else                                                            '和文以外の場合
            '図枠ﾌｧｲﾙ名作成
            sWakFil = P_sWakPath & "M_4" & sSiz & "(ENG_Outline_A" & CStr(InStr("BCD", sSiz)) & ")" & EndString
        End If
        dInsPnt(0) = 0 : dInsPnt(1) = 0 : dInsPnt(2) = 0                '図枠は0,0に挿入
        blkObj = moSpace.InsertBlock(dInsPnt, sWakFil, p_Scale, p_Scale, 1, 0)    '図枠挿入
        Attribs = blkObj.GetAttributes                                  '図枠中の属性を全て取得
        For iCnt = LBound(Attribs) To UBound(Attribs)                   '全属性
            Select Case Attribs(iCnt).TagString                         '属性名
                Case "NAME_UPPER"                                       '図題1
                    Attribs(iCnt).TextString = sZdi1                    '図題1入力
                Case "NAME_MIDDLE"                                      '図題2
                    Attribs(iCnt).TextString = sZdi2                    '図題2入力
                Case "NAME_LOWER"                                       '図題3
                    Attribs(iCnt).TextString = sZdi3                    '図題3入力
                Case "PAGE"                                             'ﾍﾟｰｼﾞ
                    Attribs(iCnt).TextString = sPage                    'ﾍﾟｰｼﾞ入力
                Case "SCALE"                                            '縮尺
                    If nps = True Then
                        Attribs(iCnt).TextString = ""                   '縮尺入力(省略)
                    Else
                        Attribs(iCnt).TextString = "1:" & CStr(p_Scale) '縮尺入力
                    End If
                Case "GUNBAN"                                           '群番
                    Attribs(iCnt).TextString = P_sGbn                   '群番入力
                Case "DWG.NO"                                           '図番
                    sZbn = Strings.Mid(sZbn, 1, sZbn.Length - 1) & iPage    '図番の最後の1桁をページ番号にする
                    TL_Zuban = sZbn
                    Attribs(iCnt).TextString = sZbn                     '図番入力
                Case "DATE"                                             '日付
                    Attribs(iCnt).TextString = sDate                    '日付入力
            End Select
        Next iCnt

        'Wakuflg = True
        'End If

    End Sub
    '
    'ﾌﾞﾛｯｸ挿入
    '
    Public Function fInsBlk(ByVal dInsPnt() As Double, ByVal sBlkFil As String, ByVal dScale As Double, _
                            ByVal sAttStr As String) As AcadBlockReference
        Dim blkObj As AcadBlockReference                                        'ﾌﾞﾛｯｸｵﾌﾞｼﾞｪｸﾄ
        Dim Attribs As Object                                                   '属性
        blkObj = moSpace.InsertBlock(dInsPnt, sBlkFil & EndString, dScale, dScale, 1, 0) 'ﾌﾞﾛｯｸ挿入
        If sAttStr <> "" Then                                                   '属性値の指定がある場合
            Attribs = blkObj.GetAttributes                                      'ﾌﾞﾛｯｸ中の属性を全て取得
            Attribs(0).TextString = sAttStr                                     '属性値設定
        End If
        fInsBlk = blkObj
    End Function

    Public Sub SetHakoData()
        '-----------------------------------------------
        '  個々の箱データをセットするプログラム
        '-----------------------------------------------
        'Dim comFile As String
        'Dim Dummy As String, Dummy3 As String
        'Dim i As Integer, J As Integer

        'i = 0
        'J = 1
        CubCnt = 0

        Do Until CubNo(CubCnt) = ""


            'stat = DB_箱別基本仕様2("select")

            H_CubNo(CubCnt) = CubNo(CubCnt)
            'H_Hz(CubCnt + 1) = H_Hz(0)
            H_Jyotai(CubCnt + 1) = H_Jyotai(0)
            H_DRZuban(CubCnt + 1) = H_DRZuban(0)
            H_DoorZuban(CubCnt + 1) = H_DoorZuban(0)
            Select Case Left(H_WakuType(0), 1)
                Case "A", "C"
                    H_D(CubCnt + 1) = Format(Val(H_D(0)) - 100)
                Case "B", "D"
                    H_D(CubCnt + 1) = Format(Val(H_D(0)) - 50)
            End Select
            'H_D(CubCnt + 1) = H_D(0)
            'H_H(CubCnt + 1) = H_H(0)
            'H_W(CubCnt + 1) = H_W(0)
            If H_W(CubCnt + 1) = "" Then
                H_W(CubCnt + 1) = 0
            End If
            'H_Zetuen(CubCnt + 1) = H_Zetuen(0)
            'H_Kata1(CubCnt + 1) = H_Kata1(0)
            'H_Kata2(CubCnt + 1) = H_Kata2(0)
            'H_DenAtu(CubCnt + 1) = H_DenAtu(0)
            'H_Hogo1(CubCnt + 1) = H_Hogo1(0)
            'H_Hogo2(CubCnt + 1) = H_Hogo2(0)
            H_TNP(CubCnt + 1) = H_TNP(0)
            H_NP1(CubCnt + 1) = H_NP1(0)
            H_NP2(CubCnt + 1) = H_NP2(0)
            H_NP3(CubCnt + 1) = H_NP3(0)
            H_NP4(CubCnt + 1) = H_NP4(0)
            H_WakuType(CubCnt + 1) = H_WakuType(0)
            H_Totte(CubCnt + 1) = H_Totte(0)
            H_DoorOpen(CubCnt + 1) = H_DoorOpen(0)
            H_Jyuryo(CubCnt + 1) = H_Jyuryo(0)
            H_PowerFreq(CubCnt + 1) = H_PowerFreq(0)
            H_Impulse(CubCnt + 1) = H_Impulse(0)
            CubCnt = CubCnt + 1
        Loop

        '  Do Until (CubNo(I) = "")
        '    comFile = Sea_Dir & "\" & KoubanName & GunbanName & "." & Trim(CubNo(I))
        '    Open comFile For Input As #1
        '    Line Input #1, Dummy
        '    Close #1
        '
        'データをシンボルにセット
        '    H_CubNo(J) = Trim(CubNo(I))
        '    Dummy = StringGet(Dummy, H_Hz(J), ";")
        '    Dummy = StringGet(Dummy, H_Zetuen(J), ";")
        '    Dummy = StringGet(Dummy, H_Kata1(J), ";")
        '    Dummy = StringGet(Dummy, H_Kata2(J), ";")
        '    Dummy = StringGet(Dummy, H_DenAtu(J), ";")
        '    Dummy = StringGet(Dummy, H_Hogo1(J), ";")
        '    Dummy = StringGet(Dummy, H_Hogo2(J), ";")
        '    Dummy = StringGet(Dummy, Dummy3, ";")
        '    H_TNP(J) = FunCvtTNP(Dummy3, 1) 'conv
        '    Dummy = StringGet(Dummy, H_DRZuban(J), ";")
        '    Dummy = StringGet(Dummy, H_DoorZuban(J), ";")
        '    Dummy = StringGet(Dummy, H_NP1(J), ";")
        '    Dummy = StringGet(Dummy, H_NP2(J), ";")
        '    Dummy = StringGet(Dummy, H_NP3(J), ";")
        '    Dummy = StringGet(Dummy, H_NP4(J), ";")
        '    Dummy = StringGet(Dummy, Dummy3, ";")
        '    H_Jyotai(J) = FunCvtJyotai(Dummy3, 1) 'conv
        '    Dummy = StringGet(Dummy, Dummy3, ";")
        '    H_WakuType(J) = FunCvtWakuType(Dummy3, 1) 'conv
        'Dummy = StringGet(Dummy, H_D(J), ";")
        '    Dummy = StringGet(Dummy, Dummy3, ";")
        '    Select Case Left(H_WakuType(J), 1)
        '        Case "A", "C"
        '            H_D(J) = Format(Val(Dummy3) - 100)
        '        Case "B", "D"
        '            H_D(J) = Format(Val(Dummy3) - 50)
        '    End Select
        '    Dummy = StringGet(Dummy, H_H(J), ";")
        '    Dummy = StringGet(Dummy, H_W(J), ";")
        '    Dummy = StringGet(Dummy, Dummy3, ";")
        '    H_Totte(J) = FunCvtTotte(Dummy3, 1) 'conv
        '    Dummy = StringGet(Dummy, Dummy3, ";")
        '    H_DoorOpen(J) = FunCvtDoorOpen(Dummy3, 1) 'conv
        '    Dummy = StringGet(Dummy, H_Jyuryo(J), ";")
        '    I = I + 1
        '    J = J + 1
        '  Loop
    End Sub
    '-----------------------------------------------
    '  個々の箱データをセットするプログラム（配列図用）
    '-----------------------------------------------
    Public Sub SetHakoDataH()
        CubCnt = 0
        Do Until CubNo(CubCnt) = ""
            'stat = DB_箱別基本仕様2("select")
            H_CubNo(CubCnt + 1) = CubNo(CubCnt)
            H_Hz(CubCnt + 1) = H_Hz(0)
            H_Jyotai(CubCnt + 1) = H_Jyotai(0)
            H_DRZuban(CubCnt + 1) = H_DRZuban(0)
            H_DoorZuban(CubCnt + 1) = H_DoorZuban(0)
            Select Case Left(H_WakuType(0), 1)
                Case "A", "C"
                    H_D(CubCnt + 1) = Format(Val(H_D(0)) - 100)
                Case "B", "D"
                    H_D(CubCnt + 1) = Format(Val(H_D(0)) - 50)
            End Select
            H_H(CubCnt + 1) = H_H(0)
            H_W(CubCnt + 1) = H_W(0)
            H_Zetuen(CubCnt + 1) = H_Zetuen(0)
            H_Kata1(CubCnt + 1) = H_Kata1(0)
            H_Kata2(CubCnt + 1) = H_Kata2(0)
            H_DenAtu(CubCnt + 1) = H_DenAtu(0)
            H_Hogo1(CubCnt + 1) = H_Hogo1(0)
            H_Hogo2(CubCnt + 1) = H_Hogo2(0)

            H_TNP(CubCnt + 1) = H_TNP(0)
            H_NP1(CubCnt + 1) = H_NP1(0)
            H_NP2(CubCnt + 1) = H_NP2(0)
            H_NP3(CubCnt + 1) = H_NP3(0)

            H_WakuType(CubCnt + 1) = H_WakuType(0)
            H_Totte(CubCnt + 1) = H_Totte(0)
            H_DoorOpen(CubCnt + 1) = H_DoorOpen(0)
            H_Jyuryo(CubCnt + 1) = H_Jyuryo(0)
            H_PowerFreq(CubCnt + 1) = H_PowerFreq(0)
            H_Impulse(CubCnt + 1) = H_Impulse(0)
            CubCnt = CubCnt + 1
        Loop
    End Sub

    Public Sub AcadMain_Kiso()
        '-----------------------------------------------
        '  基礎用AutoCADメインプログラム
        '-----------------------------------------------
        'Dim comFile As String 'ストリングテンポラリー
        'Dim Chk As String
        'Dim sysVarName As String
        'Dim sysVarData As Object
        'Dim sysStrData As String
        'Dim TmpCubNo(conNum) As String
        'Dim Cnt As Integer


        'データ格納配列の初期化
        'Call ClearCom()
        '
        ' VB側で設定したデータのGET
        '
        'comFile = Dir(Sea_Dir & "\" & KoubanName & GunbanName & ".kyo")
        'comFile = Sea_Dir & "\" & comFile
        '共通項目を配列にセット
        'Call SetKyotuData(comFile)


        '納入外CUB.で配列図に図示しないものがあればCubNo配列から取り除く
        'TmpCubNo(0) = ""
        'If (ChkExt = "1") And (ExtCubNo(0) <> "") Then Call DelCubNo(ExtCubNo, TmpCubNo)
        If (ChkExt = "1") And (ExtCubNo(0) <> "") Then Call DelCubNo(ExtCubNo)

        '箱別項目を配列にセット
        Call SetHakoData()      '(メモ　DB_箱別基本仕様2)

        'アイコン変更(砂時計）
        'Screen.MousePointer = vbHourglass
        'System.Windows.Forms.Cursor.Current = Cursors.WaitCursor

        'AutoCADを起動する
        '  Call AcadStart

        '列番全長寸法の計算
        Zencho = CalZenCho()

        '図形スナップ設定
        acadDoc.SendCommand("aperture" & vbCrLf & "1" & vbCrLf)
        acadDoc.SendCommand("-OSNAP" & vbCrLf & "OFF" & vbCrLf) '作図が思うようにいかないことがあるため、作図中はオフ

        Call frmkiso.KisoMain()
        Call fin_man()
        'fin_man:
        '線色を緑に変更
        'sysVarName = "CECOLOR"
        'sysStrData = "GREEN"
        'sysVarData = sysStrData
        'acadDoc.SetVariable(sysVarName, sysVarData)

        '自動作成中を示すメッセージフォームを閉じる
        'Unload(frmContiMassage)
        'frmContiMassage.close()    ←フォームを作り次第フォーム名変更

        'アイコン変更（矢印）
        'Screen.MousePointer = vbArrow
        'System.Windows.Forms.Cursor.Current = Cursors.Arrow

        '終了メッセージの表示
        'frm配列基礎メイン.Show()  'ﾒｯｾｰｼﾞﾎﾞｯｸｽがAutoCADより手前に表示されるようにする '04.3.18 松本
        'MsgBox("自動作成完了", vbOKOnly, "自動作図処理")

        'AutoCADを可視化する
        'acadApp.Visible = acOn
        'acadApp.Visible = True
    End Sub

    Public Sub fin_man()
        Dim sysVarName As String
        Dim sysVarData As Object
        Dim sysStrData As String

        '線色を緑に変更
        sysVarName = "CECOLOR"
        sysStrData = "GREEN"
        sysVarData = sysStrData
        acadDoc.SetVariable(sysVarName, sysVarData)

        '自動作成中を示すメッセージフォームを閉じる
        'Unload(frmContiMassage)
        'frmContiMassage.close()    ←フォームを作り次第フォーム名変更

        'アイコン変更（矢印）
        'Screen.MousePointer = vbArrow
        System.Windows.Forms.Cursor.Current = Cursors.Arrow

        '終了メッセージの表示
        ' .Show()  'ﾒｯｾｰｼﾞﾎﾞｯｸｽがAutoCADより手前に表示されるようにする '04.3.18 松本
        MsgBox("自動作成完了", vbSystemModal, "自動作図処理")

        'AutoCADを可視化する
        'acadApp.Visible = acOn
        acadApp.Visible = True
    End Sub

    Public Function ChkReadYN(ByVal ChkNO As String, ByVal ChkCubNo As String) As String
        '-----------------------------------------------
        'メモリーに読み込むデータか判断
        '-----------------------------------------------
        ' ChkNo     : 対象となる箱No(ex 101)
        ' ChkCubNo  : 非対象となる文字列(ex 101,102,103)
        ' 戻り値    : 「Yes」or「No」
        '-----------------------------------------------

        Dim Dummy As String
        Dim T_Cubno As String

        T_Cubno = ""
        Dummy = ChkCubNo
        Do Until Dummy = ""
            Dummy = StringGet(Dummy, T_Cubno, ",")
            If T_Cubno = ChkNO Then
                ChkReadYN = "YES"
                Exit Function
            End If
        Loop
        ChkReadYN = "NO"
    End Function


End Module
