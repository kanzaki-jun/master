﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHairetu
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblKbn = New System.Windows.Forms.Label()
        Me.lblGbn = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtSyubetu = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPage = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAllPage = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtZbn = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtY = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtM = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtD = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.lblSegment = New System.Windows.Forms.Label()
        Me.lblAllHako = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSetubi = New System.Windows.Forms.TextBox()
        Me.cmbScale = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbSiz = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.CmbNps = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'lblKbn
        '
        Me.lblKbn.AutoSize = True
        Me.lblKbn.Location = New System.Drawing.Point(10, 9)
        Me.lblKbn.Name = "lblKbn"
        Me.lblKbn.Size = New System.Drawing.Size(66, 12)
        Me.lblKbn.TabIndex = 1
        Me.lblKbn.Text = "99X99-9999"
        '
        'lblGbn
        '
        Me.lblGbn.AutoSize = True
        Me.lblGbn.Location = New System.Drawing.Point(89, 9)
        Me.lblGbn.Name = "lblGbn"
        Me.lblGbn.Size = New System.Drawing.Size(19, 12)
        Me.lblGbn.TabIndex = 3
        Me.lblGbn.Text = "B9"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(12, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(64, 18)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "製品種別："
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtSyubetu
        '
        Me.txtSyubetu.Enabled = False
        Me.txtSyubetu.Location = New System.Drawing.Point(80, 57)
        Me.txtSyubetu.Name = "txtSyubetu"
        Me.txtSyubetu.Size = New System.Drawing.Size(171, 19)
        Me.txtSyubetu.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(255, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(11, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "（"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPage
        '
        Me.txtPage.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtPage.Location = New System.Drawing.Point(272, 56)
        Me.txtPage.Name = "txtPage"
        Me.txtPage.Size = New System.Drawing.Size(20, 19)
        Me.txtPage.TabIndex = 1
        Me.txtPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(298, 59)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(11, 12)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "/"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtAllPage
        '
        Me.txtAllPage.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtAllPage.Location = New System.Drawing.Point(313, 56)
        Me.txtAllPage.Name = "txtAllPage"
        Me.txtAllPage.Size = New System.Drawing.Size(20, 19)
        Me.txtAllPage.TabIndex = 2
        Me.txtAllPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(339, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(11, 12)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "）"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(27, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(47, 16)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "図番："
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtZbn
        '
        Me.txtZbn.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtZbn.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtZbn.Location = New System.Drawing.Point(80, 82)
        Me.txtZbn.Name = "txtZbn"
        Me.txtZbn.Size = New System.Drawing.Size(171, 19)
        Me.txtZbn.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(27, 109)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(47, 16)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "日付："
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtY
        '
        Me.txtY.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtY.Location = New System.Drawing.Point(80, 106)
        Me.txtY.Name = "txtY"
        Me.txtY.Size = New System.Drawing.Size(20, 19)
        Me.txtY.TabIndex = 4
        Me.txtY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(106, 111)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(17, 12)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "年"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtM
        '
        Me.txtM.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtM.Location = New System.Drawing.Point(122, 106)
        Me.txtM.Name = "txtM"
        Me.txtM.Size = New System.Drawing.Size(20, 19)
        Me.txtM.TabIndex = 5
        Me.txtM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(148, 111)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(17, 12)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "月"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtD
        '
        Me.txtD.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtD.Location = New System.Drawing.Point(171, 106)
        Me.txtD.Name = "txtD"
        Me.txtD.Size = New System.Drawing.Size(20, 19)
        Me.txtD.TabIndex = 6
        Me.txtD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(197, 111)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(17, 12)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "日"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(27, 162)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(47, 16)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "縮尺："
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(80, 164)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(17, 12)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "1/"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(304, 111)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(73, 29)
        Me.cmdOK.TabIndex = 8
        Me.cmdOK.Text = "作成開始"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(304, 147)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(73, 29)
        Me.cmdCancel.TabIndex = 9
        Me.cmdCancel.Text = "キャンセル"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'lblSegment
        '
        Me.lblSegment.AutoSize = True
        Me.lblSegment.Location = New System.Drawing.Point(120, 9)
        Me.lblSegment.Name = "lblSegment"
        Me.lblSegment.Size = New System.Drawing.Size(61, 12)
        Me.lblSegment.TabIndex = 22
        Me.lblSegment.Text = "**セグメント"
        '
        'lblAllHako
        '
        Me.lblAllHako.AutoSize = True
        Me.lblAllHako.Location = New System.Drawing.Point(203, 9)
        Me.lblAllHako.Name = "lblAllHako"
        Me.lblAllHako.Size = New System.Drawing.Size(91, 12)
        Me.lblAllHako.TabIndex = 23
        Me.lblAllHako.Text = "全**箱　****mm"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(12, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(64, 18)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "設備名称："
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtSetubi
        '
        Me.txtSetubi.Enabled = False
        Me.txtSetubi.Location = New System.Drawing.Point(80, 32)
        Me.txtSetubi.Name = "txtSetubi"
        Me.txtSetubi.Size = New System.Drawing.Size(171, 19)
        Me.txtSetubi.TabIndex = 0
        '
        'cmbScale
        '
        Me.cmbScale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbScale.FormattingEnabled = True
        Me.cmbScale.Items.AddRange(New Object() {"10", "15", "20", "25", "30"})
        Me.cmbScale.Location = New System.Drawing.Point(103, 158)
        Me.cmbScale.Name = "cmbScale"
        Me.cmbScale.Size = New System.Drawing.Size(50, 20)
        Me.cmbScale.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(3, 135)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(71, 17)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "図面サイズ："
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmbSiz
        '
        Me.cmbSiz.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSiz.FormattingEnabled = True
        Me.cmbSiz.Items.AddRange(New Object() {"B", "C"})
        Me.cmbSiz.Location = New System.Drawing.Point(80, 132)
        Me.cmbSiz.Name = "cmbSiz"
        Me.cmbSiz.Size = New System.Drawing.Size(34, 20)
        Me.cmbSiz.TabIndex = 27
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(120, 137)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(17, 12)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "版"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(162, 137)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 12)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "図面："
        '
        'CmbNps
        '
        Me.CmbNps.FormattingEnabled = True
        Me.CmbNps.Items.AddRange(New Object() {"通常", "NPS承認図"})
        Me.CmbNps.Location = New System.Drawing.Point(199, 134)
        Me.CmbNps.Name = "CmbNps"
        Me.CmbNps.Size = New System.Drawing.Size(80, 20)
        Me.CmbNps.TabIndex = 30
        Me.CmbNps.Text = "通常"
        '
        'frmHairetu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(389, 189)
        Me.Controls.Add(Me.CmbNps)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.cmbSiz)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbScale)
        Me.Controls.Add(Me.txtSetubi)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblAllHako)
        Me.Controls.Add(Me.lblSegment)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtD)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtM)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtY)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtZbn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtAllPage)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtPage)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtSyubetu)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblGbn)
        Me.Controls.Add(Me.lblKbn)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmHairetu"
        Me.Text = "配列図作成"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblKbn As System.Windows.Forms.Label
    Friend WithEvents lblGbn As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSyubetu As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPage As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtAllPage As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtZbn As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtY As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtM As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtD As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents lblSegment As System.Windows.Forms.Label
    Friend WithEvents lblAllHako As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtSetubi As System.Windows.Forms.TextBox
    Friend WithEvents cmbScale As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbSiz As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents CmbNps As System.Windows.Forms.ComboBox
End Class
