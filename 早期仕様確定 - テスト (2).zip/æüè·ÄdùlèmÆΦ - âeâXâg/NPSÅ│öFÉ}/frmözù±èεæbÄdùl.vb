﻿Public Class frm配列基礎仕様

    Public pc_HeaderTxt() As String = {"盤No.", "名称(1)", "名称(2)", "名称(3)", "側面図(内部構造図)", _
                                        "正面扉図", "ブロックSKコード", "規格番号", "形", "保護等級[閉鎖箱]", "保護等級[仕切板]", _
                                        "定格電圧(定格使用電圧)", "定格周波数", "定格耐電圧[商用周波]", _
                                        "定格耐電圧[雷ｲﾝﾊﾟﾙｽ]", "絶縁階級(定格絶縁電圧)", "製造者銘板番号", _
                                        "環境条件", "扉開放角度{度}", "盤概略質量{kg}", "納入外配列", "納入外基礎", _
                                        "盤寸法(幅)", "盤寸法(高さ)", "盤寸法(奥行)", "換気箱", _
                                        "扉形状（正面）", "扉形状（背面）", "把手（正面）", _
                                        "盤データのコピー", "盤データのペースト", "盤データ削除", ""}

    'ｺﾝﾎﾞﾎﾞｯｸｽの選択肢
    Public p_SelKikakuNo() As String = {"", "JEM1425", "JEM1265", "JEM1225"}           '規格番号
    Public p_SelBoxTyp(,) As String = {{"", "", "", "", "", "", "", "", "", ""}, _
                                        {"", "CX", "CY", "MW", "MWG", "PW", "PWG", "CW", "", ""}, _
                                        {"", "AX", "AY", "AS", "CX", "CY", "CS", "CW", "FW", "FWG"}, _
                                        {"", "?", "?", "?", "?", "?", "?", "?", "?", "?"}}      'ｽｲｯﾁｷﾞﾔの形
    Public p_SelHogoBox() As String = {"", "IP2X", "IP3X", "IP4X", "IP2XW", "IP3XW", "IP4XW", "IP23W"}  '保護等級(閉鎖箱)
    Public p_SelHogoIta() As String = {"", "IP1X", "IP2X", "IP3X", "IP4X"}             '保護等級(仕切板)
    Public p_SelTeikakuV() As String = {"", "220V", "460V", "550V", "3.6kV", "7.2kV", "12kV", "24kV", _
                                         "36kV", "15kV", "15.5kV"}                      '定格電圧
    Public p_SelFreq() As String = {"", "50Hz", "60Hz", "50/60Hz"}                     '周波数
    Public p_SelComFreq() As String = {"", "10kV", "16kV", "22kV", "28kV", "38kV", "50kV", "70kV", "95kV"} '商用周波
    Public p_SelImpls() As String = {"", "30kV", "45kV", "60kV", "75kV", "95kV", "125kV", "145kV", "170kV", "250kV"} '雷ｲﾝﾊﾟﾙｽ
    Public p_SelCls() As String = {"", "3B", "3A", "6B", "6A", "10B", "20B", "30B", "250V", "500V", "600V"} '絶縁階級
    Public p_SelNP() As String = {"", "NP-6449", "NPS-99538", "NPS-9878", "NPS-9881", "NP-6330E", _
                                   "NP-6449E", "NPS-9879"}                             '製造者銘板番号
    'Public p_SelKankyou() As String = {"", "一般", "防塵", "耐塵", "防滴", "防雪", "耐熱温帯", "簡易防塵", "屋外形防塵"} '環境条件
    Public p_SelKankyou() As String = {"", "一般", "防塵", "耐塵", "防滴", "防雪", "耐熱温帯", "簡易防塵"} '環境条件(配列図で屋内か屋外かを表示するようにしたため、「屋外形防塵」を削除)
    Public p_SelNoHairetu() As String = {"", "納入外（表示）", "納入外（非表示）"}    '配列図納入外
    Public p_SelNoKiso() As String = {"", "納入外（表示）", "納入外（非表示）"}       '基礎図納入外
    'Public p_SelFDoor() As String = {conD1, conD2, conD3, conD4, conBU, conBM}         '扉形状(正面)
    Public p_SelFDoor() As String = {conD1, conD2, conD3, conD4}         '扉形状(正面)
    'Public p_SelRDoor() As String = {conDR, conPR, conDMcb1, conDMcb2, conPMcb1, conPMcb2, conBU, conBM}     '扉形状(背面)
    Public p_SelRDoor() As String = {conN, conDR, conHDR}     '扉形状(背面)
    'Public p_SelTotte() As String = {"LT", "RT", "WO", "OT", "RLT", "RRT", "RWO", "WO2", "RWO2"}       '把手
    Public p_SelTotte() As String = {"LT", "RT", "WO", "RLT", "RRT", "RWO", "WO2", "RWO2"}       '把手
    Public p_SelKanki() As String = {"", "天井", "背面扉"}                            '換気箱

    Public p_SelSeigyo() As String = {"COMPA(左優先)", "COMPA(右優先)", "F-PAC(左優先)", "F-PAC(右優先)", _
                                       "S-PAC7(左優先)", "S-PAC7(右優先)"}
    'Private p_SelHikikomi() As String = {"無", "1型500*250", "1型500*300", "1型600*250", "1型任意", "4型LS01", "4型任意", "2-α型", "2-β型"}
    Public p_SelHikikomi() As String
    'Private p_SelHokyoKata() As String = {"無", "Ⅰ字型", "Ⅱ字型", "一字型", "二字型", "Ｔ字型", "逆Ｔ字型", "Π型", "逆Π型", "井型"}
    Public p_SelHokyoKata() As String
    'Private pc_HeaderTxt3() As String = {"①盤No", "②引込穴の型", "③引込穴の幅", "④引込穴の奥行長さ", "⑤奥行寸法Ａ", "⑥幅寸法Ａ", _
    '                                    "⑦奥行枠の有無(左側)", "⑧奥行枠の有無(右側)", "⑨補強枠の型", "⑩奥行寸法Ｂ(※1)", "⑪奥行寸法Ｃ(※2)"}
    Public pc_HeaderTxt2() As String = {"盤No", "補強枠の型", "Ａ寸法", "Ｂ寸法", "Ｘ寸法", "Ｙ寸法", _
                                        "奥行枠の有無(左側)", "奥行枠の有無(右側)", "分割点(箱の右側)", _
                                        "引込穴1の情報", "引込穴2の情報", "引込穴3の情報", "引込穴4の情報", _
                                        "盤データのコピー", "盤データの貼り付け"}
    Public p_SelZengo() As String = {"正面", "背面"}
    Public p_SelUmu() As String = {"無", "有"}


    Private NewData As String
    Private ChgCell As DataGridViewComboBoxCell
    Private DataCnt As Integer
    Private Kikaku As String
    Private befCell As DataGridViewComboBoxCell
    Private befCell2 As DataGridViewTextBoxCell
    Private befCellX As Integer
    Private befCellY As Integer
    Private Copyflg As Boolean                         'HokyoData読込フラグ(txtファイルなくても動くようにするため)
    Private Delflg As Boolean                           '盤1列削除処理中か判断するフラグ(true → 処理中)
    '
    '
    '
    Private Sub 配列基礎仕様_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim iRowNum As Integer, iRowNum2 As Integer ', iRowCnt As Integer      '行数/行ｶｳﾝﾀｰ
        Dim a As Integer
        Dim iColNum As Integer ', iColCnt As Integer      '列数/列ｶｳﾝﾀｰ
        Dim k As Integer, l As Integer
        Dim HakoNo2 As String
        Delflg = False


        '----------------------------------------------------------------
        'データベース移行後に使用
        KoubanName = sTmpKbn
        GunbanName = TGbn
        LoadCnt = 0

        For l = 0 To p_SelSeigyo.Length - 1     '制御ケーブル穴コンボボックスの選択肢設定
            cmbSeigyo.Items.Add(p_SelSeigyo(l))
        Next

        'データベースから情報をとってくる
        'stat = DB_配列基礎共通("select")

        If DB_配列基礎共通("select") = True Then
            stat = DB_配列図箱別("select")
            stat = DB_基礎図箱別("select")
        Else
            '1盤分の空の表を表示(配列を用意)
            ReDim P_sBanDat(0, pc_HeaderTxt.Length - 4 + pc_HeaderTxt2.Length - 4 + 4 * 4)
            '配列基礎仕様の上部の初期値
            cmbInOut.SelectedItem = "屋外"           'とりあえず屋外
            cmbDoorTyp.SelectedItem = "無"
            cmbKeshoTyp.SelectedItem = "無"
            cmbSeikanTyp.SelectedItem = "無"
            cmbSeigyo.SelectedItem = "無"
            txtBaseH.Text = "100"                      '屋外を選択したので100に
            txtFntSunpo.Text = "0"
            txtBckSunpo.Text = "0"
            'P_sBanDat(0, 0) = "101"
            '盤データを読み込む配列に1盤分のデータを代入する
            For a = 0 To UBound(P_sBanDat, 2)
                Select Case a                                          '選択行番号
                    Case pc_BanNoRow
                        P_sBanDat(0, a) = ""
                    Case pc_HokyoKataRow2, pc_LOkuyukiRow2, pc_ROkuyukiRow2, pc_Hiki1Row2, pc_Hiki2Row2, pc_Hiki3Row2, pc_Hiki4Row2        '基礎図表コンボボックス行
                        P_sBanDat(0, a) = "無"
                    Case pc_BanWRow To pc_BanDRow, pc_HokyoARow2 To pc_HokyoYRow2, _
                        pc_Hiki1Row2 + 1 To pc_Hiki1Row2 + 4, pc_Hiki2Row2 + 1 To pc_Hiki2Row2 + 4, _
                        pc_Hiki3Row2 + 1 To pc_Hiki3Row2 + 4, pc_Hiki4Row2 + 1 To pc_Hiki4Row2 + 4
                        '盤のW、H、D寸法と補強枠、引込穴それぞれの4つの寸法
                        P_sBanDat(0, a) = "0"
                    Case Else
                        P_sBanDat(0, a) = ""
                End Select
            Next

        End If

        If cmbKumitate.SelectedItem = "" Then
            cmbKumitate.SelectedItem = "組立式"
        End If

        '--------------------------------------------------------------------


        'Dim Haba As Integer
        HakoNo2 = ""
        Copyflg = False
        Loadflg = True
        BReadflg = True
        frmkisoflg = False
        Lflg = False
        Dim ColW As Integer
        'sScale2 = ""

        Call KPicLoad()                             '引込穴のサムネイル用の画像の読み込み
        Call HPicLoad()                             '補強枠のサムネイル用の画像の読み込み
        Call cmbDefinition()                        '上2つの情報からコンボボックスの選択肢を定義


        '最初にこの命令を実行すると行ヘッダーの三角を消せる(三角マークがあっても行き来することがなくなったのでコメントアウト)
        'gridHairetuKiso.RowTemplate.HeaderCell = New myDataGridViewRowHeaderCell

        iRowNum = UBound(pc_HeaderTxt)              '行数取得(配列基礎仕様)
        gridHairetuKiso.RowCount = iRowNum + 1 'ｸﾞﾘｯﾄﾞの行数定義

        '----------------------------------------------------------------------------------------
        'txtファイルから読み込む
        'Call MakeBanFile(pc_HeaderTxt.Length - 4 + pc_HeaderTxt2.Length - 4 + 4 * 4)
        'If BReadflg = False Then
        '    Me.Close()
        '    Exit Sub
        'End If
        'Call ReadBanData()                          '盤データをtxtファイルから読み込む
        'FileClose(fileNumber)                       'txtファイルを閉じる
        'Call DataLoad()             '表の上の部分(屋内外など)の読込
        '----------------------------------------------------------------------------------------

        iColNum = UBound(P_sBanDat, 1)

        'Call ReadHokyoData()
        'FileClose(fileNumber)
        'If Loadflg = True Then
        '    For k = 0 To UBound(P_sHokyoDat, 2) - 1
        '        lstHokyo.Items.Add(P_sHokyoDat(0, k))
        '    Next
        'End If

        For k = 0 To p_SelHikikomi.Length - 1
            cmbK1.Items.Add(p_SelHikikomi(k))
        Next
        cmbK1.SelectedItem = "無"
        txtBanNo.ReadOnly = True
        txtKeisikiNo.ReadOnly = True

        'セルの選択状態を表示しないための透明化(透明化しないことにしたのでコメントアウト)
        'gridHairetuKiso.DefaultCellStyle.SelectionBackColor = Color.Transparent
        'gridHairetuKiso.DefaultCellStyle.SelectionForeColor = Color.Transparent

        '---------------------------


        Call HeaderTitle()          '表題表記


        Call sSetGrdDat()           'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(配列基礎仕様表)
        '---------------------------
        '列幅調整
        gridHairetuKiso.AutoResizeRowHeadersWidth( _
            DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders)   'ﾍｯﾀﾞｰ
        gridHairetuKiso.AutoResizeColumns()                            '内容

        If iColNum = 0 Then                             '表が1列しかない場合
            gridHairetuKiso.Columns(0).Width = 100      '1列目の幅設定(表に値がない場合、ボタンにサイズを合わせてしまい、列幅が狭いため)
        Else                                            '2列目以降、値の長さによってセルの幅が100を超えればその列幅を記憶
            For k = 1 To iColNum
                If gridHairetuKiso.Columns(k - 1).Width <= gridHairetuKiso.Columns(k).Width Then
                    ColW = gridHairetuKiso.Columns(k).Width
                End If
            Next
            For l = 0 To iColNum
                gridHairetuKiso.Columns(l).Width = ColW             '各列の幅を上で記憶した値に設定
            Next
        End If


        '---------------------------
        '列内でｿｰﾄできないようにする
        For Each c As DataGridViewColumn In gridHairetuKiso.Columns
            c.SortMode = DataGridViewColumnSortMode.NotSortable
        Next c
        gridHairetuKiso.AllowUserToAddRows = False                      '行が追加されないようにする


        'ReDim HakoNoData(iColNum)                               '要素数再定義


        'For i = 0 To iColNum
        '    If i + 1 < 10 Then
        '        HakoNo2 = "10" & (i + 1).ToString
        '    ElseIf i + 1 >= 10 Then
        '        HakoNo2 = "1" & (i + 1).ToString
        '    End If
        '    HakoNoData(i) = HakoNo2
        '    'cmbHakoNo.Items.Add(HakoNo2)
        'Next

        For a = 1 To iColNum + 1
            CubNo(a - 1) = a.ToString
        Next

        iColNum = UBound(P_sBanDat, 1)
        gridSyukairo.ColumnCount = iColNum + 1          'ｸﾞﾘｯﾄﾞの列数定義
        iRowNum2 = UBound(pc_HeaderTxt2)
        gridSyukairo.RowCount = iRowNum2               'ｸﾞﾘｯﾄﾞの行数定義


        Call sSetGrdDat2()                              'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(基礎図表)
        '基礎図表のデータ保存用配列(4*4 → 引込穴の形式が、表では1つの形式につき1行しかないので足りない分を追加(4形式*4項目))
        'ReDim SyukairoData(pc_HeaderTxt2.Length - 1 + 4 * 4, gridSyukairo.ColumnCount - 1)

        '列内でｿｰﾄできないようにする
        For Each c2 As DataGridViewColumn In gridSyukairo.Columns
            c2.SortMode = DataGridViewColumnSortMode.NotSortable
        Next c2
        gridSyukairo.AllowUserToAddRows = False                      '行が追加されないようにする
        '列幅調整
        gridSyukairo.AutoResizeRowHeadersWidth( _
            DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders)   'ﾍｯﾀﾞｰ
        'gridSyukairo.AutoResizeColumns()                             '内容


        gridHairetuKiso.AllowUserToAddRows = False                      '行が追加されないようにする
        'gridHairetuKisoの列の幅をユーザーが変更できないようにする
        gridHairetuKiso.AllowUserToResizeColumns = False
        'gridHairetuKisoの行の高さをユーザーが変更できないようにする
        gridHairetuKiso.AllowUserToResizeRows = False
        'gridSyukairoの列の幅をユーザーが変更できないようにする
        gridSyukairo.AllowUserToResizeColumns = False
        'gridSyukairoの行の高さをユーザーが変更できないようにする
        gridSyukairo.AllowUserToResizeRows = False


        gridHairetuKiso.AutoGenerateColumns = False

        Lflg = True

    End Sub

    '読み込んだファイル名から引込穴と補強枠のコンボボックスの選択肢を定義
    Public Sub cmbDefinition()
        Dim HikiAna As String

        ReDim p_SelHikikomi(Kpicname.Length)    '引込穴の型選択のコンボボックスの中身の配列を再定義(配列にない選択肢"無"があるためlengthに-1しない)
        p_SelHikikomi(0) = "無"
        For j = 0 To Kpicname.Length - 1
            HikiAna = Kpicname(j)                   '配列の値を変えないために別変数で処理をする
            If 0 < HikiAna.IndexOf(",") Then        ' "*"が名前に含まれているなら
                HikiAna = HikiAna.Replace(",", "*") ' ","を"*"に変更(1型の既定の型のコンボボックスの選択肢が「1型○○○*○○○」なので)
            End If
            p_SelHikikomi(j + 1) = HikiAna              'コンボボックスの選択肢に型名を追加
        Next
        ReDim p_SelHokyoKata(Hpicname.Length)   '補強枠の型選択のコンボボックスの中身の配列を再定義
        p_SelHokyoKata(0) = "無"
        For j = 0 To Hpicname.Length - 1
            p_SelHokyoKata(j + 1) = Hpicname(j)         'コンボボックスに型名を追加
        Next
    End Sub

    '表題表記(配列基礎仕様)
    Private Sub HeaderTitle()
        Dim iRowNum As Integer, iRowCnt As Integer      '行数/行ｶｳﾝﾀｰ
        iRowNum = UBound(pc_HeaderTxt)              '行数取得

        For iRowCnt = 0 To iRowNum - 1
            gridHairetuKiso.Rows(iRowCnt).HeaderCell.Value = pc_HeaderTxt(iRowCnt)

            Select Case iRowCnt
                Case pc_BanNoRow To pc_DoorZbnRow, pc_JyuryoRow
                    gridHairetuKiso.Rows(iRowCnt).HeaderCell.Style.BackColor = Color.LightGreen      'セルカラー変更(NPS承認図で表として表示される項目)
                Case pc_NoHairetuRow, pc_NoKisoRow                                                  '納入外指定
                    'gridHairetuKiso.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
                    gridHairetuKiso.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
                    'ﾁｪｯｸﾎﾞｯｸｽは中央寄せ
                    'gridHairetuKiso.Rows(iRowCnt).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                Case pc_BanWRow To pc_BanDRow                                                       '盤寸法行
                    gridHairetuKiso.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LemonChiffon 'ｾﾙ色変更
                    gridHairetuKiso.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.OrangeRed      'ﾍｯﾀﾞ文字色変更
                    gridHairetuKiso.Rows(iRowCnt).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    'Case Is >= pc_KankiRow                                                              '換気箱行以降
                    '    gridHairetuKiso.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.OrangeRed      'ﾍｯﾀﾞ文字色変更
            End Select

        Next iRowCnt
    End Sub

    Private Sub DataLoad()
        cmbInOut.SelectedItem = InOut
        cmbDoorTyp.SelectedItem = Door
        cmbKeshoTyp.SelectedItem = Kesho
        cmbSeikanTyp.SelectedItem = Seikan
        cmbSeigyo.SelectedItem = SeigyoK
        txtBaseH.Text = BaseH
        txtFntSunpo.Text = TFntSunpo
        txtBckSunpo.Text = TBckSunpo
        txtMeisyo.Text = Meisho
        txtSyubetu.Text = Syubetu
    End Sub


    'Private Sub frm配列基礎仕様_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
    '    gridHairetuKiso.CurrentCell = Nothing       'カレントセルを無くす(デフォルトは左上が選択状態)
    'End Sub

    '
    'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(配列基礎仕様表)
    '
    Private Sub sSetGrdDat()
        Dim iRowNum As Integer, iColNum As Integer  '行/列数
        Dim iRowCnt As Integer, iColCnt As Integer  '行/列ｶｳﾝﾀｰ
        'Dim i As Integer

        '--------------
        '盤情報取得

        '--------------
        'iRowNum = UBound(P_sBanDat, 2) - 24                   '盤の並びは列ﾍｯﾀﾞｰに記述
        iRowNum = pc_HeaderTxt.Length - 2
        iColNum = UBound(P_sBanDat, 1)
        gridHairetuKiso.ColumnCount = iColNum + 1                   '列数定義
        '--------------
        ReDim BanDataArray(iRowNum)
        ReDim BanDataArray2(pc_HeaderTxt2.Length - 3)


        'ﾃﾞｰﾀ表示
        For iRowCnt = 0 To iRowNum
            For iColCnt = 0 To iColNum
                If iRowCnt = 0 Then                                 '1行目の処理時
                    gridHairetuKiso.Columns(iColCnt).HeaderText = iColCnt + 1
                    '列ﾍｯﾀﾞｰは中央寄せ
                    gridHairetuKiso.Columns(iColCnt).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                End If
                Select Case iRowCnt                                          '選択行番号
                    Case pc_BlkSKRow
                        gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).ReadOnly = True
                    Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_BanDataDelete        'ｺﾝﾎﾞﾎﾞｯｸｽ行
                        If TypeOf gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) Is DataGridViewTextBoxCell Then   'ﾃｷｽﾄﾎﾞｯｸｽｾﾙの場合
                            Select Case iRowCnt
                                Case pc_KikakuNoRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelKikakuNo)  'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_BoxTypRow
                                    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                    Call sCrecmbBoxTyp(gridHairetuKiso.Rows(pc_KikakuNoRow).Cells(iColCnt).Value, iRowCnt, iColCnt)
                                Case pc_HogoBoxRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelHogoBox)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_HogoItaRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelHogoIta)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_TeikakuVRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelTeikakuV)  'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_FreqRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelFreq)      'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_ComFreqRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelComFreq)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_ImplsRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelImpls)     'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_ClsRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelCls)       'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_NPRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelNP)        'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_KankyouRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelKankyou)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_NoHairetuRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelNoHairetu) 'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_NoKisoRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelNoKiso)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_KankiRow
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelKanki)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_FDoorRow    '16.12.1 松本追加
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelFDoor)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_RDoorRow    '16.12.1 松本追加
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelRDoor)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_FTotteRow   '16.12.1 松本追加
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelTotte)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Case pc_BanDataCopy
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                                Case pc_BanDataPaste
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                                Case pc_BanDataDelete
                                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                            End Select
                        End If
                End Select

                'Select Case iRowCnt
                'Case pc_NoHairetuRow, pc_NoKisoRow              '納入外行
                'gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt) = fCrechkCel() 'ﾁｪｯｸﾎﾞｯｸｽｾﾙに変更
                '値が"1"の時はﾁｪｯｸを入れる
                'If P_sBanDat(iRowCnt, iColCnt) = "1" Then gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).Value = True
                'Case Else                                       'それ以外
                'End Select
                If iRowCnt < iRowNum - 2 Then       '下3行はtxtファイルにないデータ(ボタン)なので省く
                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, iRowCnt)
                ElseIf iRowCnt = iRowNum - 2 Then
                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).Value = "保存"
                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).ReadOnly = False
                ElseIf iRowCnt = iRowNum - 1 Then
                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).Value = "貼り付け"
                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).ReadOnly = False
                Else
                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).Value = "削除"
                    gridHairetuKiso.Rows(iRowCnt).Cells(iColCnt).ReadOnly = False
                End If
            Next iColCnt
        Next iRowCnt
    End Sub

    '
    'ｸﾞﾘｯﾄﾞ内にﾃﾞｰﾀを表示する(基礎図表)
    '
    Private Sub sSetGrdDat2()
        Dim iRowNum As Integer, iColNum As Integer  '行/列数
        Dim iRowCnt As Integer, iColCnt As Integer  '行/列ｶｳﾝﾀｰ
        Dim i As Integer


        iColNum = UBound(P_sBanDat, 1)
        gridSyukairo.ColumnCount = iColNum + 1          'ｸﾞﾘｯﾄﾞの列数定義
        iRowNum = UBound(pc_HeaderTxt2)
        gridSyukairo.RowCount = iRowNum + 1             'ｸﾞﾘｯﾄﾞの行数定義

        ReDim P_sBanDatK(gridSyukairo.ColumnCount - 1, gridSyukairo.RowCount - 3)

        'For j = 0 To gridHairetuKiso.ColumnCount - 1
        '    gridHairetuKiso.Columns(j).Name = j
        'Next

        'データグリッドビュー設定
        For iRowCnt = 0 To iRowNum
            For iColCnt = 0 To iColNum
                If iRowCnt = 0 Then
                    gridSyukairo.Columns(iColCnt).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter    '列ﾍｯﾀﾞｰは中央寄せ
                    gridSyukairo.Columns(iColCnt).HeaderText = iColCnt + 1
                    gridSyukairo.Columns(iColCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
                    gridSyukairo.Columns(iColCnt).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, 0)         '盤No.
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).ReadOnly = True
                    P_sBanDatK(iColCnt, iRowCnt) = P_sBanDat(iColCnt, 0)
                End If
                If iRowCnt = pc_HokyoKataRow Then
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelHokyoKata)         '2行目のセルをコンボボックスに
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, pc_HokyoKataRow2)   '初期値設定
                    P_sBanDatK(iColCnt, iRowCnt) = P_sBanDat(iColCnt, pc_HokyoKataRow2)
                    gridSyukairo.CurrentCell = gridSyukairo.Rows(iRowCnt).Cells(iColCnt)        'コンボボックスを選択
                    Lflg = True                                                                 '一時的にフラグをロード終了に(CellEndEditでこのフラグがTrueである必要があるため)
                    gridSyukairo.BeginEdit(False)                                               'コンボボックスを編集状態に
                    gridSyukairo.EndEdit()                                                      '編集終了(CellEndEditを誘発して型によって寸法がいらないセルをReadOnlyに)
                    Lflg = False                                                                'フラグを戻す
                    For i = iRowCnt + 1 To iRowCnt + 4
                        If gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = "無" Then
                            gridSyukairo.Rows(i).Cells(iColCnt).Value = P_sBanDat(iColCnt, pc_HokyoKataRow2 + (i - iRowCnt))
                            gridSyukairo.Rows(i).Cells(iColCnt).ReadOnly = True                     '最初の選択肢が"無"なので、
                            gridSyukairo.Rows(i).Cells(iColCnt).Style.BackColor = Color.Gray        '4つの寸法を記入できないようにする
                        Else
                            gridSyukairo.Rows(i).Cells(iColCnt).Value = P_sBanDat(iColCnt, pc_HokyoKataRow2 + (i - iRowCnt))
                        End If
                        P_sBanDatK(iColCnt, i) = P_sBanDat(iColCnt, pc_HokyoKataRow2 + (i - iRowCnt))
                    Next
                ElseIf iRowCnt = pc_LOkuyukiRow Or iRowCnt = pc_ROkuyukiRow Or iRowCnt = pc_BunkatuRow Then   '奥行枠、分割点行なら
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt) = fCreCmb(p_SelUmu)               '5,6行目のセルをコンボボックスに
                    'gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, iRowCnt + UBound(P_sBanDat, 2) - 27)   '初期値設定
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = P_sBanDat(iColCnt, iRowCnt - pc_LOkuyukiRow + pc_LOkuyukiRow2)   '初期値設定
                    P_sBanDatK(iColCnt, iRowCnt) = P_sBanDat(iColCnt, iRowCnt - pc_LOkuyukiRow + pc_LOkuyukiRow2)
                ElseIf iRowCnt = pc_Hiki1Row Or iRowCnt = pc_Hiki2Row Or iRowCnt = pc_Hiki3Row Or iRowCnt = pc_Hiki4Row Then          '引込穴の行なら
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 1) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 2) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 3) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 4)
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).ReadOnly = True
                    P_sBanDatK(iColCnt, iRowCnt) = _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 1) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 2) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 3) & "," & _
                        P_sBanDat(iColCnt, 5 * (iRowCnt - 9) + pc_Hiki1Row2 + 4)
                    'gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 1) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 2) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 3) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 4)
                    'gridSyukairo.Rows(iRowCnt).Cells(iColCnt).ReadOnly = True
                    'P_sBanDatK(iColCnt, iRowCnt) = _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 1) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 2) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 3) & "," & _
                    '    P_sBanDat(iColCnt, 8 + 5 * (iRowCnt - 8) + UBound(P_sBanDat, 2) - 27 + 4)
                ElseIf iRowCnt = iRowNum - 1 Then
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt) = fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = "保存"
                ElseIf iRowCnt = iRowNum Then
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt) = fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                    gridSyukairo.Rows(iRowCnt).Cells(iColCnt).Value = "貼り付け"
                End If

            Next iColCnt
            gridSyukairo.Rows(iRowCnt).HeaderCell.Value = pc_HeaderTxt2(iRowCnt)        'ヘッダーセル設定
            gridSyukairo.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
            gridSyukairo.Rows(iRowCnt).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
        Next
        For l = 0 To iColNum
            gridSyukairo.Columns(l).Width = 100                          '各列の幅設定
        Next
        gridSyukairo.CurrentCell = Nothing
    End Sub

    '
    '指定された選択肢でｺﾝﾎﾞﾎﾞｯｸｽ定義
    'sSelDat():選択肢
    '
    Function fCreCmb(ByVal sSelDat() As String) As DataGridViewComboBoxCell
        Dim iDatCnt As Integer                              'ﾃﾞｰﾀｶｳﾝﾀｰ    
        Dim cmb As New DataGridViewComboBoxCell()           '規格番号ｺﾝﾎﾞﾎﾞｯｸｽ

        For iDatCnt = 0 To UBound(sSelDat)                  '全選択肢
            cmb.Items.Add(sSelDat(iDatCnt))                 '選択肢追加
        Next iDatCnt

        Return cmb                                          'ｺﾝﾎﾞﾎﾞｯｸｽを返す
    End Function
    '
    'ﾃｷｽﾄﾎﾞｯｸｽｾﾙ定義
    '
    Function fCretxtCel() As DataGridViewTextBoxCell
        Dim txtCel As New DataGridViewTextBoxCell()     'ﾃｷｽﾄﾎﾞｯｸｽｾﾙ定義

        Return txtCel                                   'ﾃｷｽﾄﾎﾞｯｸｽｾﾙを返す
    End Function
    '
    'ﾁｪｯｸﾎﾞｯｸｽｾﾙ定義
    '
    Function fCrechkCel() As DataGridViewCheckBoxCell
        Dim chkCel As New DataGridViewCheckBoxCell()    'ﾁｪｯｸﾎﾞｯｸｽｾﾙ定義

        Return chkCel                                   'ﾃｷｽﾄﾎﾞｯｸｽｾﾙを返す
    End Function
    '
    'ﾎﾞﾀﾝｾﾙ定義
    '
    Function fCrebtnCel() As DataGridViewButtonCell
        Dim btnCel As New DataGridViewButtonCell        'ﾎﾞﾀﾝｾﾙ定義
        btnCel.Style.Alignment = DataGridViewContentAlignment.BottomCenter      '文字をボタンの中央に
        Return btnCel                                   'ﾎﾞﾀﾝｾﾙを返す
    End Function

    '
    'ｽｲｯﾁｷﾞﾔの形ｺﾝﾎﾞﾎﾞｯｸｽ定義
    '
    Public Sub sCrecmbBoxTyp(ByVal sKikakuNo As String, ByVal iRowNo As Integer, ByVal iColNo As Integer)
        Dim iKikakuNum As Integer                                           '規格数
        Dim iKikakuCnt As Integer, iSelCnt As Integer                       '規格ｶｳﾝﾀｰ/選択肢ｶｳﾝﾀｰ
        Dim sSelDat() As String                                             '選択肢ﾃﾞｰﾀ

        iKikakuNum = UBound(p_SelKikakuNo)                                  '規格数取得
        For iKikakuCnt = 1 To iKikakuNum                                    '全規格番号
            If sKikakuNo = p_SelKikakuNo(iKikakuCnt) Then  '選択済の規格番号が規定のものであれば
                Exit For                                                    '検索終了
            End If
        Next iKikakuCnt

        If iKikakuCnt <= iKikakuNum Then                    '選択済の規格番号が規定のものであれば
            ReDim sSelDat(0) : sSelDat(0) = ""                              '配列再定義
            iSelCnt = 1                                                     '選択肢ｶｳﾝﾀｰ初期化
            Do Until p_SelBoxTyp(iKikakuCnt, iSelCnt) = ""                  '選択肢が""になるまで
                ReDim Preserve sSelDat(0 To iSelCnt)                        '配列再定義
                sSelDat(iSelCnt) = p_SelBoxTyp(iKikakuCnt, iSelCnt)         '選択肢取得
                iSelCnt = iSelCnt + 1                                       '選択肢ｶｳﾝﾀｰを1増やす
                If iSelCnt > UBound(p_SelBoxTyp, 2) Then Exit Do '最後の選択肢の場合はこれで終わり
            Loop
            gridHairetuKiso.Rows(iRowNo).Cells(iColNo) = fCreCmb(sSelDat)   'ｺﾝﾎﾞﾎﾞｯｸｽ表示
        Else
            ReDim sSelDat(0) : sSelDat(0) = ""                              '配列再定義
            iSelCnt = 1                                                     '選択肢ｶｳﾝﾀｰ初期化
            Do Until p_SelBoxTyp(0, iSelCnt) = ""                  '選択肢が""になるまで
                ReDim Preserve sSelDat(0 To iSelCnt)                        '配列再定義
                sSelDat(iSelCnt) = p_SelBoxTyp(iKikakuCnt, iSelCnt)         '選択肢取得
                iSelCnt = iSelCnt + 1                                       '選択肢ｶｳﾝﾀｰを1増やす
                If iSelCnt > UBound(p_SelBoxTyp, 2) Then Exit Do '最後の選択肢の場合はこれで終わり
            Loop
            gridHairetuKiso.Rows(iRowNo).Cells(iColNo) = fCreCmb(sSelDat)   'ｺﾝﾎﾞﾎﾞｯｸｽ表示
        End If
    End Sub


    '
    '「配列逆転」ボタンクリック時
    '
    Private Sub btnGyakuten_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGyakuten.Click
        Dim i As Integer, j As Integer, a As Integer, b As Integer, k As Integer, l As Integer  'ループ変数
        Dim Hyou(gridHairetuKiso.RowCount - 4) As String
        Dim Hyou2(gridHairetuKiso.RowCount - 4) As String
        Dim SHyou(gridSyukairo.RowCount - 3) As String
        Dim SHyou2(gridSyukairo.RowCount - 3) As String
        Dim CCnt As Integer = gridHairetuKiso.ColumnCount
        Dim ColSoat(gridHairetuKiso.ColumnCount - 1) As Integer   '元々の列の位置を見た目の列の位置にするための配列
        'Dim ColSoat2(gridHairetuKiso.ColumnCount - 1) As Integer   '元々の列の位置を見た目の列の位置にするための配列
        Dim NHyou(gridHairetuKiso.ColumnCount - 1, gridHairetuKiso.RowCount - 4) As String
        Dim SNHyou(gridHairetuKiso.ColumnCount - 1, gridSyukairo.RowCount - 3) As String
        'Dim colarr(gridHairetuKiso.ColumnCount - 1) As Integer

        gridHairetuKiso.EndEdit()       '編集モード終了
        gridSyukairo.EndEdit()          '編集モード終了
        For k = 0 To gridSyukairo.ColumnCount - 1
            For l = 0 To gridSyukairo.RowCount - 3
                gridSyukairo.Rows(l).Cells(k).ReadOnly = False
                gridSyukairo.Rows(l).Cells(k).Style.BackColor = Color.Empty
            Next
        Next
        Call CopyModeClear()            'セルコピーモード解除処理

        'MsgBox(gridHairetuKiso.Rows(0).Cells(1).Value & gridHairetuKiso.Columns(1).Index & gridHairetuKiso.Columns(1).DisplayIndex)

        For a = 0 To gridHairetuKiso.ColumnCount - 1                    '1列(盤)目から順に処理
            For b = 0 To gridHairetuKiso.ColumnCount - 1                '
                If gridHairetuKiso.Columns(a).DisplayIndex = b Then     '見た目の列の位置と一致したら
                    ColSoat(b) = gridHairetuKiso.Columns(a).Index             '見た目の行の位置と保存したい行の位置を一致させる
                    Exit For                                            '次の列へ
                End If
            Next
            'header(a) = a + 1                                           '列ヘッダーの値を配列に
        Next

        'For m = 0 To gridHairetuKiso.ColumnCount - 1
        '    For n = 0 To gridHairetuKiso.ColumnCount - 1
        '        'If m = gridHairetuKiso.Columns(n).Name Then
        '        '    colarr(m) = gridHairetuKiso.Columns(n).DisplayIndex
        '        'End If
        '    Next
        'Next

        '2盤ずつ入れ替え作業を行う
        If CCnt Mod 2 = 0 Then
            b = gridHairetuKiso.ColumnCount / 2
            '2盤ずつ処理を行うため盤の数によって分岐(両端の箱から始め、1つずつ内側へ)
            '盤数が偶数の場合
            For i = 0 To b
                For j = 0 To gridHairetuKiso.RowCount - 4   '「保存」、「貼り付け」行以外の行

                    '盤データの一時的な保存
                    Hyou(j) = gridHairetuKiso.Rows(j).Cells(ColSoat(i)).Value                                    '左端から処理
                    Hyou2(j) = gridHairetuKiso.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value '右端から処理
                    'Hyou(j) = gridHairetuKiso.Columns(colarr(i)).DataGridView.Rows(j).Cells(i).Value        '左端から処理
                    'Hyou2(j) = gridHairetuKiso.Columns(colarr(colarr.Length - 1 - i)).DataGridView.Rows(j).Cells(colarr(gridHairetuKiso.ColumnCount - 1 - i)).Value '右端から処理
                    'Hyou(j) = gridHairetuKiso.Rows(j).Cells(colarr(i)).Value                                    '左端から処理
                    'Hyou2(j) = gridHairetuKiso.Rows(j).Cells(colarr(gridHairetuKiso.ColumnCount - 1 - i)).Value '右端から処理
                    If j <= gridSyukairo.RowCount - 3 Then
                        SHyou(j) = gridSyukairo.Rows(j).Cells(ColSoat(i)).Value                                    '左端から処理
                        SHyou2(j) = gridSyukairo.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value '右端から処理
                        'SHyou(j) = gridSyukairo.Rows(j).Cells(ColSoat(i)).Value                                    '左端から処理
                        'SHyou2(j) = gridSyukairo.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value '右端から処理
                        SNHyou(gridSyukairo.ColumnCount - 1 - i, j) = SHyou(j)
                        SNHyou(i, j) = SHyou2(j)
                    End If
                    NHyou(gridHairetuKiso.ColumnCount - 1 - i, j) = Hyou(j)
                    NHyou(i, j) = Hyou2(j)
                Next


            Next
            Call HairetuGyakuten(NHyou, ColSoat, b)    '配列基礎仕様の表の逆転処理へ
            Call HairetuGyakuten2(SNHyou, ColSoat) '基礎図設定表の逆転処理へ
        Else
            b = (gridHairetuKiso.ColumnCount - 1) / 2
            '盤数が奇数の場合
            For i = 0 To b
                For j = 0 To gridHairetuKiso.RowCount - 4   '「保存」、「貼り付け」行以外の行
                    Hyou(j) = gridHairetuKiso.Rows(j).Cells(ColSoat(i)).Value                                        '左端から処理
                    Hyou2(j) = gridHairetuKiso.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value     '右端から処理
                    'Hyou(j) = gridHairetuKiso.Rows(j).Cells(colarr(i)).Value                                        '左端から処理
                    'Hyou2(j) = gridHairetuKiso.Rows(j).Cells(colarr(gridHairetuKiso.ColumnCount - 1 - i)).Value     '右端から処理
                    If j <= gridSyukairo.RowCount - 3 Then
                        SHyou(j) = gridSyukairo.Rows(j).Cells(ColSoat(i)).Value                                      '左端から処理
                        SHyou2(j) = gridSyukairo.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value   '右端から処理
                        'SHyou(j) = gridSyukairo.Rows(j).Cells(colarr(i)).Value                                      '左端から処理
                        'SHyou2(j) = gridSyukairo.Rows(j).Cells(colarr(gridHairetuKiso.ColumnCount - 1 - i)).Value   '右端から処理
                        SNHyou(gridSyukairo.ColumnCount - 1 - i, j) = SHyou(j)
                        SNHyou(i, j) = SHyou2(j)
                    End If
                    NHyou(gridHairetuKiso.ColumnCount - 1 - i, j) = Hyou(j)
                    NHyou(i, j) = Hyou2(j)

                Next

            Next
            Call HairetuGyakuten(NHyou, ColSoat, b)    '配列基礎仕様の表の逆転処理へ
            Call HairetuGyakuten2(SNHyou, ColSoat) '基礎図設定表の逆転処理へ
        End If

    End Sub

    Private Sub HairetuGyakuten(ByVal NData As String(,), ByVal ColSoat As Integer(), ByVal b As Integer)
        '逆転した盤データ貼り付け処置
        Dim i As Integer, j As Integer

        'MsgBox(gridHairetuKiso.Columns(0).Index & gridHairetuKiso.Columns(0).DisplayIndex & gridHairetuKiso.Columns(1).Index & gridHairetuKiso.Columns(1).DisplayIndex & gridHairetuKiso.Columns(2).Index & gridHairetuKiso.Columns(2).DisplayIndex)

        For i = 0 To b
            'For j = pc_BanNoRow To pc_KankiRow      '「盤No」行から「換気箱」行まで  '16.12.1 ﾃﾞｰﾀ行追加に伴い修正 松本
            For j = pc_BanNoRow To pc_FTotteRow      '「盤No」行から「把手（正面）」行まで
                'コンボボックスのリストにない項目を貼り付ける際の処理
                '処理対象のセルがコンボボックスセルかつ値がNothingではない場合
                If TypeOf gridHairetuKiso.Rows(j).Cells(ColSoat(i)) Is DataGridViewComboBoxCell _
                    And gridHairetuKiso.Rows(j).Cells(ColSoat(i)).Value <> Nothing Then
                    Dim cbc As DataGridViewComboBoxCell = _
                    CType(gridHairetuKiso.Rows(j).Cells(ColSoat(i)), DataGridViewComboBoxCell)
                    'セルの値がコンボボックスのリストになければ追加する(リストにない値は消えてしまうため)
                    If NData(i, j) <> Nothing Then
                        If Not cbc.Items.Contains(NData(i, j)) Then
                            cbc.Items.Add(NData(i, j))
                        End If
                    End If
                End If
                gridHairetuKiso.Rows(j).Cells(ColSoat(i)).Value = NData(i, j)     '配列のデータを貼り付ける
                Console.Write(j & "," & i & "," & gridHairetuKiso.Rows(j).Cells(ColSoat(i)).Value & vbCrLf)
                If b = (gridHairetuKiso.ColumnCount - 1) / 2 And i = b Then

                Else
                    '処理対象のセルがコンボボックスセルかつ値がNothingではない場合
                    If TypeOf gridHairetuKiso.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)) Is DataGridViewComboBoxCell _
                        And gridHairetuKiso.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value <> Nothing Then
                        Dim cbc2 As DataGridViewComboBoxCell = _
                        CType(gridHairetuKiso.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)), DataGridViewComboBoxCell)
                        'セルの値がコンボボックスのリストになければ追加する(リストにない値は消えてしまうため)
                        If NData(gridHairetuKiso.ColumnCount - 1 - i, j) <> Nothing Then
                            If Not cbc2.Items.Contains(NData(gridHairetuKiso.ColumnCount - 1 - i, j)) Then
                                cbc2.Items.Add(NData(gridHairetuKiso.ColumnCount - 1 - i, j))
                            End If
                        End If
                    End If
                    gridHairetuKiso.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value = NData(gridHairetuKiso.ColumnCount - 1 - i, j)     '配列のデータを貼り付ける
                    Console.Write(j & "," & ColSoat(gridHairetuKiso.ColumnCount - 1 - i) & "," & gridHairetuKiso.Rows(j).Cells(ColSoat(gridHairetuKiso.ColumnCount - 1 - i)).Value & vbCrLf)
                    '「形」行のコンボボックス処理
                    If j = pc_KikakuNoRow Then
                        Call sCrecmbBoxTyp(NData(gridHairetuKiso.ColumnCount - 1 - i, j), j + 1, gridHairetuKiso.ColumnCount - 1 - i)    'スイッチギアコンボボックス定義へ
                        Call sCrecmbBoxTyp(NData(i, j), j + 1, i)    'スイッチギアコンボボックス定義へ
                    End If
                End If

            Next
        Next


    End Sub

    Private Sub HairetuGyakuten2(ByVal SNData As String(,), ByVal ColSoat() As Integer)
        Dim i As Integer, j As Integer, k As Integer, l As Integer

        '基礎図用表の並び替え処理(貼り付け)
        For i = 0 To gridSyukairo.ColumnCount - 1           '左から1列ずつ
            For l = 0 To gridSyukairo.ColumnCount - 1       '
                If gridHairetuKiso.Rows(0).Cells(ColSoat(i)).Value = SNData(l, 0) Then
                    For j = 0 To gridSyukairo.RowCount - 3
                        gridSyukairo.Rows(j).Cells(i).Value = SNData(l, j)     '配列のデータを貼り付ける
                        'gridSyukairo.Rows(j).Cells(gridHairetuKiso.ColumnCount - 1 - i).Value = SNData(gridHairetuKiso.ColumnCount - 1 - i, j)     '配列のデータを貼り付ける
                    Next
                    Exit For
                End If
            Next
        Next

        For k = 0 To gridSyukairo.ColumnCount - 1
            gridSyukairo.CurrentCell = gridSyukairo.Rows(1).Cells(k)
            gridSyukairo.BeginEdit(True)
            Dim cb As DataGridViewComboBoxEditingControl = CType(gridSyukairo.EditingControl, DataGridViewComboBoxEditingControl)
            cb.EditingControlDataGridView.NotifyCurrentCellDirty(True)  '1回目の選択の時に値が変わったという情報が伝わらないので伝える
            cb.EditingControlDataGridView.EndEdit() 'コンボボックスの値を選択してすぐにサムネイルを表示するために編集モードを終了する
        Next

        'For i = 0 To gridSyukairo.ColumnCount - 1
        '    For j = 0 To gridSyukairo.RowCount - 3
        '        gridSyukairo.Rows(j).Cells(i).Value = SNData(i, j)     '配列のデータを貼り付ける
        '        gridSyukairo.Rows(j).Cells(gridHairetuKiso.ColumnCount - 1 - i).Value = SNData(gridHairetuKiso.ColumnCount - 1 - i, j)     '配列のデータを貼り付ける
        '    Next
        'Next

        'For k = 0 To gridSyukairo.ColumnCount - 1
        '    gridSyukairo.CurrentCell = gridSyukairo.Rows(1).Cells(k)
        '    gridSyukairo.BeginEdit(True)
        '    Dim cb As DataGridViewComboBoxEditingControl = CType(gridSyukairo.EditingControl, DataGridViewComboBoxEditingControl)
        '    cb.EditingControlDataGridView.NotifyCurrentCellDirty(True)  '1回目の選択の時に値が変わったという情報が伝わらないので伝える
        '    cb.EditingControlDataGridView.EndEdit() 'コンボボックスの値を選択してすぐにサムネイルを表示するために編集モードを終了する
        'Next
    End Sub

    '
    '「盤追加」ボタンクリック時
    '
    Private Sub btnTuika_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTuika.Click
        Dim Col As Integer, Col2 As Integer
        Dim iRowNum As Integer  '行数
        Dim iRowCnt As Integer  '行ｶｳﾝﾀｰ
        Dim name As String = Str(gridHairetuKiso.ColumnCount)
        Dim i As Integer, j As Integer

        gridHairetuKiso.Columns.Add(name, gridHairetuKiso.ColumnCount + 1)  '1列追加
        Col = gridHairetuKiso.ColumnCount - 1
        gridHairetuKiso.Columns(Col).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter '列ヘッダー中央揃え
        For iRowCnt = 0 To gridHairetuKiso.RowCount - 1
            Select Case iRowCnt                                          '選択行番号
                Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_BanDataDelete        'ｺﾝﾎﾞﾎﾞｯｸｽ行とボタンセルの行
                    If TypeOf gridHairetuKiso.Rows(iRowCnt).Cells(Col) Is DataGridViewTextBoxCell Then   'ﾃｷｽﾄﾎﾞｯｸｽｾﾙの場合
                        Select Case iRowCnt
                            Case pc_KikakuNoRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelKikakuNo)  'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_BoxTypRow
                                'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                                Call sCrecmbBoxTyp(gridHairetuKiso.Rows(pc_KikakuNoRow).Cells(Col).Value, iRowCnt, Col)
                            Case pc_HogoBoxRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelHogoBox)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_HogoItaRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelHogoIta)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_TeikakuVRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelTeikakuV)  'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_FreqRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelFreq)      'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_ComFreqRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelComFreq)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_ImplsRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelImpls)     'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_ClsRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelCls)       'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_NPRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelNP)        'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_KankyouRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelKankyou)   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_NoHairetuRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelNoHairetu) 'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_NoKisoRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelNoKiso)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_KankiRow
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelKanki)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_FDoorRow    '16.12.1 松本追加
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelFDoor)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_RDoorRow    '16.12.1 松本追加
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelRDoor)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_FTotteRow   '16.12.1 松本追加
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCreCmb(p_SelTotte)    'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙに変更
                            Case pc_BanDataCopy
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCrebtnCel()         'ﾎﾞﾀﾝｾﾙに変更
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col).Value = "保存"           'ボタン名
                            Case pc_BanDataPaste
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCrebtnCel()         'ﾎﾞﾀﾝｾﾙに変更
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col).Value = "貼り付け"
                            Case pc_BanDataDelete
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col) = fCrebtnCel()         'ﾎﾞﾀﾝｾﾙに変更
                                gridHairetuKiso.Rows(iRowCnt).Cells(Col).Value = "削除"
                        End Select

                    End If
            End Select
        Next iRowCnt
        gridHairetuKiso.Columns(Col).SortMode = DataGridViewColumnSortMode.NotSortable
        gridHairetuKiso.Columns(Col).Width = gridHairetuKiso.Columns(Col - 1).Width

        '主回路ケーブル穴の表にも1列追加
        gridSyukairo.Columns.Add("newcol", gridSyukairo.ColumnCount + 1)
        iRowNum = UBound(pc_HeaderTxt2)
        gridSyukairo.RowCount = iRowNum + 1              'ｸﾞﾘｯﾄﾞの行数定義
        Col2 = gridHairetuKiso.ColumnCount - 1
        Dim P_sBanDatK_cp(Col2, gridSyukairo.RowCount - 3) As String
        For i = 0 To Col2 - 1   '1列増える前の数まで
            For j = 0 To gridSyukairo.RowCount - 3
                P_sBanDatK_cp(i, j) = P_sBanDatK(i, j)
            Next
        Next
        ReDim P_sBanDatK(Col2, gridSyukairo.RowCount - 3)
        For i = 0 To Col2     '1列増える前の数まで
            For j = 0 To gridSyukairo.RowCount - 3
                P_sBanDatK(i, j) = P_sBanDatK_cp(i, j)
            Next
        Next

        gridHairetuKiso.Columns(Col2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter '列ヘッダー中央揃え

        For iRowCnt = 0 To iRowNum
            If iRowCnt = pc_BanNoRow Then
                gridSyukairo.Columns(Col2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter    '列ﾍｯﾀﾞｰは中央寄せ
                gridSyukairo.Columns(Col2).HeaderText = Col2 + 1
                gridSyukairo.Columns(Col2).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
                gridSyukairo.Columns(Col2).HeaderCell.Style.ForeColor = Color.DarkBlue       'ﾍｯﾀﾞ文字色変更
            End If
            If iRowCnt = pc_HokyoKataRow Then
                gridSyukairo.Rows(iRowCnt).Cells(Col2) = fCreCmb(p_SelHokyoKata)          '2行目のセルをコンボボックスに
                gridSyukairo.Rows(iRowCnt).Cells(Col2).Value = p_SelHokyoKata(0)           '初期値設定
            ElseIf iRowCnt = pc_HokyoARow Or iRowCnt = pc_HokyoBRow Or iRowCnt = pc_HokyoXRow Or iRowCnt = pc_HokyoYRow Then        '補強枠の寸法4カ所
                gridSyukairo.Rows(iRowCnt).Cells(Col2).ReadOnly = True
                gridSyukairo.Rows(iRowCnt).Cells(Col2).Style.BackColor = Color.Gray
                gridSyukairo.Rows(iRowCnt).Cells(Col2).Value = "0"                      '初期値設定
            ElseIf iRowCnt = pc_LOkuyukiRow Or iRowCnt = pc_LOkuyukiRow Or iRowCnt = pc_BunkatuRow Then
                gridSyukairo.Rows(iRowCnt).Cells(Col2) = fCreCmb(p_SelUmu)            '6,7,8行目のセルをコンボボックスに
                gridSyukairo.Rows(iRowCnt).Cells(Col2).Value = p_SelUmu(0)             '初期値設定
            ElseIf iRowCnt = pc_Hiki1Row Or iRowCnt = pc_Hiki2Row Or iRowCnt = pc_Hiki3Row Or iRowCnt = pc_Hiki4Row Then
                gridSyukairo.Rows(iRowCnt).Cells(Col2).Value = "無,0,0,0,0"             '初期値設定
                gridSyukairo.Rows(iRowCnt).Cells(Col2).ReadOnly = True
            ElseIf iRowCnt = pc_BanCopyRow Then
                gridSyukairo.Rows(iRowCnt).Cells(Col2) = fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                gridSyukairo.Rows(iRowCnt).Cells(Col2).Value = "保存"
            ElseIf iRowCnt = pc_BanPasteRow Then
                gridSyukairo.Rows(iRowCnt).Cells(Col2) = fCrebtnCel()    'ﾎﾞﾀﾝｾﾙに変更
                gridSyukairo.Rows(iRowCnt).Cells(Col2).Value = "貼り付け"
            End If
            gridSyukairo.Rows(iRowCnt).DefaultCellStyle.BackColor() = Color.LightBlue    'ｾﾙ色変更
        Next
        gridSyukairo.Columns(Col2).Width = 100                                          '列幅を100に固定
        gridSyukairo.Columns(Col2).SortMode = DataGridViewColumnSortMode.NotSortable    'ソートできないようにする
    End Sub

    '
    '「編集リセット」ボタンクリック時　(現在非表示中)
    'frm配列基礎仕様を読み込んだ時点の状態に戻す(保存ボタン押した場合でも元に戻る)
    '(但し、フォームを読み込んだ時点に戻すので、保存後にフォームを閉じ、再度開いた後はフォームを閉じる前に保存した表の状態になる)
    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '配列再定義
        ReDim P_sBanDat(UBound(P_sBanDat_cp, 1), UBound(P_sBanDat_cp, 2))
        'フォームを読み込むときにコピーしておいた配列で、読込に使われる配列を上書き
        P_sBanDat = P_sBanDat_cp
        '表の再描画
        Call sSetGrdDat()
        Call sSetGrdDat2()
    End Sub

    '
    'ｾﾙ上でｸﾘｯｸされた時(配列基礎仕様)
    '
    Private Sub gridHairetuKiso_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridHairetuKiso.CellClick
        Dim i As Integer, j As Integer
        Dim cmbflg As Boolean                                       'コンボボックスセルかテキストボックスセルかを判断する
        Dim iRowNo As Integer, iColNo As Integer                    '選択行/列番号
        iRowNo = gridHairetuKiso.CurrentCell.RowIndex               '選択行番号取得
        iColNo = gridHairetuKiso.CurrentCell.ColumnIndex            '選択列番号取得
        'Dim sDat As String                                          '入力済ﾃﾞｰﾀ

        If Copyflg = True Then                                      'コピー先選択状態の場合
            If e.ColumnIndex = -1 Or e.RowIndex = -1 Then           'クリックされた場所が行ヘッダー、列ヘッダーなら
                gridHairetuKiso.CurrentCell = Nothing               'カレントセルなし
                MsgBox("行ヘッダー・列ヘッダーにはコピーできません。" & vbCrLf & "(コピー先選択状態は継続しています)")
                Exit Sub
            End If
            If gridHairetuKiso.CurrentCellAddress.Y = befCellY And gridHairetuKiso.CurrentCellAddress.X <> befCellX Then 'コピー元セルと同じ行のセルが選択されたなら
                Select Case gridHairetuKiso.CurrentCellAddress.Y    'コンボボックスセルの行とそれ以外で条件分岐
                    'Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow   'ﾃﾞｰﾀ行追加に伴い修正 '16.12.1 松本
                    Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_FTotteRow '←
                        Dim cmbCell As DataGridViewComboBoxCell = _
                            CType(gridHairetuKiso.CurrentCell, DataGridViewComboBoxCell)
                        cmbCell.Items.Clear()
                        For i = 0 To befCell.Items.Count - 1
                            If i = 0 Then                           'コンボボックスの1行目は空文字列
                                cmbCell.Items.Add("")
                            Else
                                cmbCell.Items.Add(befCell.Items.Item(i))
                            End If
                        Next
                        gridHairetuKiso.CurrentCell.Value = befCell.Value   '表示される値をコピーしたものに変更
                        'If befCellY = pc_KikakuNoRow Then
                        '    Call sCrecmbBoxTyp(gridHairetuKiso.Rows(pc_KikakuNoRow).Cells(iColNo).FormattedValue, iRowNo + 1, iColNo)
                        'ElseIf befCellY = pc_BoxTypRow Then

                        'End If
                    Case Else
                        gridHairetuKiso.CurrentCell.Value = befCell2.Value  'テキストボックスセルにはそのまま貼り付け
                End Select
            Else        'コピー元のセルの行とクリックされたセルの行が異なるなら
                '行ヘッダー、ボタンセル行以外なら
                If 0 <= gridHairetuKiso.CurrentCellAddress.Y And gridHairetuKiso.CurrentCellAddress.Y < gridHairetuKiso.RowCount - 3 Then
                    Select Case gridHairetuKiso.CurrentCellAddress.Y
                        'Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow    'コンボボックスセルの場合
                        '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
                        Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_FTotteRow
                            cmbflg = True
                            Call BefCellDiscrime(cmbflg)
                        Case Else                               'テキストボックスセルなら
                            cmbflg = False
                            Call BefCellDiscrime(cmbflg)
                    End Select
                    gridHairetuKiso.CurrentCell = Nothing       'コピー元のセルの値の色の変化がわかるようにカレントセルをなくす
                Else        '行ヘッダーまたはボタンセルがクリックされたなら
                    Call CopyModeClear()                        'セルコピーモード解除処理
                End If
            End If
        Else                                                    'コピー先選択状態ではない場合
            If e.ColumnIndex = -1 Then       '行ヘッダーをクリックするとコンボボックスが開くのを防ぐ
                'If e.RowIndex = -1 Then
                '    Console.WriteLine(gridHairetuKiso.Columns(e.ColumnIndex).Name) '列名確認用
                'End If
                gridHairetuKiso.CurrentCell = Nothing
                Exit Sub
            ElseIf e.RowIndex = -1 Then
                'For l = 0 To gridSyukairo.ColumnCount - 1
                '    For m = 0 To gridSyukairo.RowCount - 3
                '        P_sBanDatK(l, m) = gridSyukairo.Rows(m).Cells(l).Value
                '    Next
                'Next
                gridHairetuKiso.CurrentCell = Nothing
                Exit Sub
            End If

            Select Case iRowNo                                          '選択行番号
                'Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow         'ｺﾝﾎﾞﾎﾞｯｸｽ行
                '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
                Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_FTotteRow    'ｺﾝﾎﾞﾎﾞｯｸｽ行

                    'SendKeys.SendWait("{F4}")                       '1ｸﾘｯｸで選択できるようにする
                    gridHairetuKiso.BeginEdit(True)
                    Dim cb As DataGridViewComboBoxEditingControl = CType(gridHairetuKiso.EditingControl, DataGridViewComboBoxEditingControl)
                    cb.DroppedDown = True

                    If gridHairetuKiso.CurrentCellAddress.Y = pc_KikakuNoRow Then       '「規格番号」行なら
                        'コンボボックスの中身を変える処理があるため、値の変化がわかるように変数に現在のセルの値を記憶しておく
                        Kikaku = gridHairetuKiso.CurrentCell.Value
                    End If
                    'Case pc_BlkSKRow            'ブロックスケルトンコード行


                Case pc_BanDataCopy         '(「盤データの保存」行)
                    For j = 0 To gridHairetuKiso.ColumnCount - 1
                        If gridHairetuKiso.Rows(iRowNo).Cells(j).Style.ForeColor = Color.Red Then
                            gridHairetuKiso.Rows(iRowNo).Cells(j).Style.ForeColor = Color.Black
                        End If
                    Next
                    gridHairetuKiso.CurrentCell.Style.SelectionForeColor = Color.Red
                    Call DataCopy()
                Case pc_BanDataPaste        '(「盤データの貼り付け」行)
                    Call DataPaste()
                Case pc_BanDataDelete       '(「盤データの削除」行)
                    Call DataDelete()
            End Select
        End If
    End Sub

    '
    'ｾﾙ上でｸﾘｯｸされた時(基礎図表)
    '
    Private Sub gridSyukairo_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridSyukairo.CellClick
        Dim iRowNo As Integer, iColNo As Integer                    '選択行/列番号
        'Dim sDat As String                                          '入力済ﾃﾞｰﾀ
        iRowNo = gridSyukairo.CurrentCell.RowIndex               '選択行番号取得
        iColNo = gridSyukairo.CurrentCell.ColumnIndex            '選択列番号取得

        If e.ColumnIndex = -1 Or e.RowIndex = -1 Then                                  '行ヘッダーをクリックするとコンボボックスが開くのを防ぐ
            gridSyukairo.CurrentCell = Nothing
            Exit Sub
        End If
        Select Case iRowNo                                          '選択行番号
            Case pc_HokyoKataRow, pc_LOkuyukiRow, pc_ROkuyukiRow, pc_BunkatuRow         'ｺﾝﾎﾞﾎﾞｯｸｽ行

                gridSyukairo.BeginEdit(True)
                Dim cb As DataGridViewComboBoxEditingControl = CType(gridSyukairo.EditingControl, DataGridViewComboBoxEditingControl)
                cb.DroppedDown = True

            Case pc_Hiki1Row, pc_Hiki2Row, pc_Hiki3Row, pc_Hiki4Row
                txtBanNo.Text = gridSyukairo.Rows(0).Cells(iColNo).Value    'どの盤の引込穴の設定をしているかを表示
                txtKeisikiNo.Text = iRowNo - (pc_Hiki1Row - 1)                    '何番目の引込穴の形式かを表示

            Case pc_BanCopyRow
                Call DataCopy2()
            Case pc_BanPasteRow
                Call DataPaste2()
        End Select
    End Sub

    '
    'セルコピーモード解除処理
    '
    Private Sub CopyModeClear()
        Copyflg = False                             'セルコピーフラグ変更
        If IsNothing(befCell) = False Then          'テキストボックスセルのセルコピー状態なら
            befCell.FlatStyle = FlatStyle.Standard  'コンボボックススタイルを元に戻す
            befCell = Nothing                       '初期化
        End If
        If IsNothing(befCell2) = False Then         'コンボボックスセルのセルコピー状態なら
            befCell2.Style.ForeColor = Color.Black  'コピー元の色を戻す
            befCell2 = Nothing                      '初期化
        End If
        befCellY = Nothing                          '初期化
        btnCopy.ForeColor = Color.Black             '「セルコピー」ボタンの色を元に戻す
    End Sub

    '
    'コピー元セルと新しいコピー元セルそれぞれの種類の判別とコピーモード
    'CmbCell → CmbCellflg : コンボボックスセルかどうか(True:コンボボックスセル)
    '
    Public Sub BefCellDiscrime(ByVal CmbCellflg As Boolean)
        If IsNothing(befCell) = False Then                          'コピー元のセルがコンボボックスなら
            befCell.FlatStyle = FlatStyle.Standard                  'コピー元のコンボボックススタイルを元に戻す
            'befCell.ReadOnly = False
            befCell = Nothing                                       '初期化
        ElseIf IsNothing(befCell2) = False Then                     'コピー元のセルがテキストボックスセルなら
            befCell2.Style.ForeColor = Color.Black                  'コピー元と分かるように文字の色を変更
            'befCell.ReadOnly = False
            befCell2 = Nothing                                      '初期化
        End If
        If CmbCellflg = True Then                                   '新しいコピー先セルがコンボボックスセルなら
            befCell = gridHairetuKiso.CurrentCell                   '現在のセルを記憶
            befCell.FlatStyle = FlatStyle.Flat                      'コピー元と分かるようにコンボボックススタイルを変更
            befCellX = gridHairetuKiso.CurrentCellAddress.X
            befCellY = gridHairetuKiso.CurrentCellAddress.Y         '現在のセルのY座標を記憶
            btnCopy.ForeColor = Color.Cyan                          'セルコピー状態だと分かるように「セルコピー」ボタンの色を変更
            Copyflg = True                                          'セルコピー状態
        Else                                                        '新しいコピー先セルがテキストボックスセルなら
            befCell2 = gridHairetuKiso.CurrentCell                  '現在のセルを記憶
            befCell2.Style.ForeColor = Color.Cyan                   'コピー元と分かるように文字の色を変更
            befCellX = gridHairetuKiso.CurrentCellAddress.X
            befCellY = gridHairetuKiso.CurrentCellAddress.Y         '現在のセルのY座標を記憶
            btnCopy.ForeColor = Color.Cyan                          'セルコピー状態だと分かるように「セルコピー」ボタンの色を変更
            Copyflg = True                                          'セルコピー状態
        End If

    End Sub

    '盤データの一時的な保存(1盤分のみ、上書き式、配列基礎仕様)
    Private Sub DataCopy()
        Dim i As Integer

        'For i = pc_BanNoRow + 1 To pc_KankiRow      '「盤No」行から「換気箱」行まで
        '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
        For i = pc_BanNoRow + 1 To pc_FTotteRow      '「盤No」行から「把手(正面)」行まで
            BanDataArray(i) = gridHairetuKiso.Rows(i).Cells(gridHairetuKiso.CurrentCellAddress.X).Value '配列に保存したい盤のデータを保存
        Next
    End Sub

    '盤データの一時的な保存(1盤分のみ、上書き式、基礎図表)
    Private Sub DataCopy2()
        Dim i As Integer

        For i = 0 To pc_HeaderTxt2.Length - 3      '「盤No」行から「分割点」行まで
            BanDataArray2(i) = gridSyukairo.Rows(i).Cells(gridSyukairo.CurrentCellAddress.X).Value '配列に保存したい盤のデータを保存
        Next
    End Sub

    '盤データの貼り付け(直前に保存した盤データを指定の列に貼り付け、配列基礎仕様)
    Private Sub DataPaste()
        Dim i As Integer, j As Integer
        Dim NKikaku As String
        Dim A As Integer

        NKikaku = Kikaku
        gridHairetuKiso.EndEdit()       '編集モード終了

        For j = 0 To gridHairetuKiso.ColumnCount - 1
            '「規格番号」行のセルの値を変えたあと、そのセルのしたの「形」を変更しないままだと値がNothingになり、
            '処理中にエラーになるため
            If gridHairetuKiso.Rows(pc_BoxTypRow).Cells(j).Value = Nothing Then
                gridHairetuKiso.Rows(pc_BoxTypRow).Cells(j).Value = ""
            End If
        Next

        '盤データが保存されているか(配列の値がすべて空文字列になっているか)確認
        'For i = pc_BanNoRow To pc_KankiRow      '「盤No」行から「換気箱」行まで
        '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
        For i = pc_BanNoRow To pc_FTotteRow      '「盤No」行から「把手(正面)」行まで
            If BanDataArray(i) <> "" Then       '盤にデータがあれば
                Exit For                        '次の処理へ
            End If
            'If i = pc_KankiRow Then             'すべての行にデータが保存されていなければ
            '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
            If i = pc_FTotteRow Then             'すべての行にデータが保存されていなければ
                A = MsgBox("盤データがコピーされていません。" & vbCrLf & "空データで上書きしても良いですか？", MsgBoxStyle.OkCancel)
                If A <> 1 Then                  'いいえ
                    Exit Sub
                End If
            End If
        Next
        i = 0
        'For i = pc_BanNoRow + 1 To pc_KankiRow      '「盤No」行から「換気箱」行まで
        '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
        For i = pc_BanNoRow + 1 To pc_FTotteRow      '「盤No」行から「把手(正面)」行まで
            'コンボボックスのリストにない項目を貼り付ける際の処理
            '選択したセルがコンボボックスセルだった場合
            If TypeOf gridHairetuKiso.Rows(i).Cells(gridHairetuKiso.CurrentCellAddress.X) Is DataGridViewComboBoxCell _
                And gridHairetuKiso.Rows(i).Cells(gridHairetuKiso.CurrentCellAddress.X).Value <> Nothing Then
                Dim cbc As DataGridViewComboBoxCell = _
                CType(gridHairetuKiso.Rows(i).Cells(gridHairetuKiso.CurrentCellAddress.X), DataGridViewComboBoxCell)
                'CmbV = cbc.Value

                'コンボボックスのリストに追加する(リストにない値は消えてしまうため)
                On Error Resume Next        'データなしだと追加できないため(各コンボボックスの最初の項目が空データのため)
                If Not cbc.Items.Contains(BanDataArray(i)) Then
                    cbc.Items.Add(BanDataArray(i))
                End If
            End If
            gridHairetuKiso.Rows(i).Cells(gridHairetuKiso.CurrentCellAddress.X).Value = BanDataArray(i)     '配列のデータを貼り付ける
            '規格番号、形のコンボボックス処理
            If i = pc_KikakuNoRow Then
                Call sCrecmbBoxTyp(BanDataArray(i), i + 1, gridHairetuKiso.CurrentCellAddress.X)    'スイッチギアコンボボックス定義へ
            End If
        Next
    End Sub

    '盤データの貼り付け(直前に保存した盤データを指定の列に貼り付け、基礎図表)
    Private Sub DataPaste2()
        Dim i As Integer
        Dim A As Integer

        gridSyukairo.EndEdit()       '編集モード終了

        For i = 0 To pc_HeaderTxt2.Length - 3     '「盤No」行から「分割点」行まで
            If BanDataArray2(i) <> "" Then       '盤にデータがあれば
                Exit For                        '次の処理へ
            End If
            If i = pc_HeaderTxt2.Length - 3 Then             'すべての行にデータが保存されていなければ
                A = MsgBox("盤データがコピーされていません。" & vbCrLf & "空データで上書きしても良いですか？", MsgBoxStyle.OkCancel)
                If A <> 1 Then                  'いいえ
                    Exit Sub
                End If
            End If
        Next
        i = 0
        For i = 1 To gridSyukairo.RowCount - 3      '盤Noとボタンセル行以外
            gridSyukairo.Rows(i).Cells(gridSyukairo.CurrentCellAddress.X).Value = BanDataArray2(i)     '配列のデータを貼り付ける
        Next
    End Sub

    '盤データの削除(クリックされた削除ボタンがある列のみ)
    Private Sub DataDelete()
        Dim DelCol As Integer
        Dim i As Integer, j As Integer
        Delflg = True

        DelCol = gridHairetuKiso.CurrentCellAddress.X

        If gridHairetuKiso.ColumnCount = 1 Then         '1列しかない場合は列削除ではなく、セルの値のみを消す
            'For i = 0 To pc_KankiRow
            '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
            For i = 0 To pc_FTotteRow                   'ボタンセル行以外
                gridHairetuKiso.Rows(i).Cells(DelCol).Value = ""    '値を空文字列に
            Next
        Else
            gridHairetuKiso.Columns.Remove(gridHairetuKiso.Columns(DelCol)) '選択された削除ボタンがある列を削除
            gridSyukairo.Columns.Remove(gridSyukairo.Columns(DelCol))       '基礎図表のほうも削除

            For j = 0 To gridHairetuKiso.ColumnCount - 1
                gridHairetuKiso.Columns(j).HeaderText = j + 1
                gridSyukairo.Columns(j).HeaderText = j + 1
            Next
        End If
        Delflg = False
    End Sub

    '
    '現在のセルの編集モードが終わったとき(配列基礎仕様表)
    '
    Private Sub gridHairetuKiso_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridHairetuKiso.CellEndEdit
        Dim iRowNo As Integer, iColNo As Integer                    '選択行/列番号
        Dim a As Integer, b As Integer
        Dim ColSoat(gridHairetuKiso.ColumnCount - 1) As Integer

        iRowNo = gridHairetuKiso.CurrentCell.RowIndex               '選択行番号取得
        iColNo = gridHairetuKiso.Columns(gridHairetuKiso.CurrentCellAddress.X).DisplayIndex '選択列番号取得(DisplayIndexなのは列入替対策)

        For a = 0 To gridHairetuKiso.ColumnCount - 1                    '1列(盤)目から順に処理
            For b = 0 To gridHairetuKiso.ColumnCount - 1                '
                If gridHairetuKiso.Columns(a).DisplayIndex = b Then     '見た目の列の位置と一致したら
                    ColSoat(b) = gridHairetuKiso.Columns(a).Index       '見た目の行の位置と保存したい行の位置を一致させる
                    Exit For                                            '次の列へ
                End If
            Next
        Next

        Select Case iRowNo                                          '選択行
            Case pc_BanNoRow            '箱Noを変えたら、基礎図表のほうも同時に変更
                gridSyukairo.Rows(iRowNo).Cells(iColNo).Value = gridHairetuKiso.CurrentCell.Value
                'cmbCubNo.Items.Add(gridHairetuKiso.CurrentCell.Value)
                'Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow 'ｺﾝﾎﾞﾎﾞｯｸｽ行   'ﾃﾞｰﾀ行追加 '16.12.1 松本
            Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_FTotteRow     '←
                If TypeOf gridHairetuKiso.CurrentCell Is DataGridViewComboBoxCell Then   'ｺﾝﾎﾞﾎﾞｯｸｽｾﾙの場合
                    '規格が空欄になったら、「形」の項目も空欄にする
                    If iRowNo = pc_KikakuNoRow Then
                        If gridHairetuKiso.Rows(iRowNo).Cells(ColSoat(iColNo)).Value = "" Then
                            gridHairetuKiso.Rows(iRowNo + 1).Cells(ColSoat(iColNo)).Value = ""
                        End If
                    End If
                End If
            Case pc_BanWRow To pc_BanDRow
                If gridHairetuKiso.CurrentCell.Value = "" Then
                    gridHairetuKiso.CurrentCell.Value = "0"
                    'ElseIf IsNumeric(gridHairetuKiso.CurrentCell.Value) = False Then
                    '    gridHairetuKiso.CurrentCell.Value = "0"
                End If
            Case pc_DoorOpnRow, pc_JyuryoRow
                If gridHairetuKiso.CurrentCell.Value = "" Then
                    gridHairetuKiso.CurrentCell.Value = "0"
                    'ElseIf IsNumeric(gridHairetuKiso.CurrentCell.Value) = False Then
                    '    gridHairetuKiso.CurrentCell.Value = "0"
                End If
        End Select

    End Sub


    '
    'ﾃﾞｰﾀｴﾗｰ発生時(とりあえず何もしない)
    '
    Private Sub gridHairetuKiso_DataError(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles gridHairetuKiso.DataError
    End Sub

    '
    'ﾃﾞｰﾀｴﾗｰ発生時(とりあえず何もしない これがないとエラーが出ます)
    '
    Private Sub gridSyukairo_DataError(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles gridSyukairo.DataError
    End Sub
    '
    'ｷｰﾎﾞｰﾄﾞ入力があった時
    '
    Private Sub gridHairetuKiso_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles gridHairetuKiso.KeyDown

        Select Case e.KeyCode                           '入力されたｷｰ
            Case Keys.Delete, Keys.Back                 'Del,Backの場合
                gridHairetuKiso.CurrentCell.Value = ""  'ﾃﾞｰﾀ削除
                If gridHairetuKiso.CurrentCellAddress.Y = pc_BanWRow Or gridHairetuKiso.CurrentCellAddress.Y = pc_BanHRow Or gridHairetuKiso.CurrentCellAddress.Y = pc_BanDRow Then
                    '数値が必要な箇所なので、0をいれておく
                    gridHairetuKiso.CurrentCell.Value = "0"
                End If
            Case Keys.Enter
                Select Case gridHairetuKiso.CurrentCellAddress.Y
                    'クリックだけではなく、キーボード操作でもコンボボックスの編集ができるようにする処理
                    Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_FTotteRow    'コンボボックス行
                        'コンボボックスのリストのイベントを取得するために編集モードにする(編集モードにするだけなのでTrueとFalseはどちらでもよい)
                        gridHairetuKiso.BeginEdit(False)
                        Dim cb As DataGridViewComboBoxEditingControl = CType(gridHairetuKiso.EditingControl, DataGridViewComboBoxEditingControl)
                        cb.DroppedDown = True           'コンボボックスのリストを表示
                        'コンボボックスを表示する際に、Enterキーの元々の処理である下のセルへの移動を防ぐため、
                        'イベントを処理し終えた扱いにする
                        e.Handled = True

                        '以下3つはクリックだけだなく、ENTERキーでも1列の保存と貼り付け、削除ができるようにする処理
                    Case pc_BanDataCopy
                        Call DataCopy()
                    Case pc_BanDataPaste
                        Call DataPaste()
                    Case pc_BanDataDelete
                        Call DataDelete()
                End Select
        End Select
    End Sub

    '
    'ｷｬﾝｾﾙﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        FileClose(fileNumber)
        Me.Close()  'このﾌｫｰﾑを閉じる
    End Sub
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    'フォームが閉じられるとき
    Private Sub f_FormClosing(ByVal sender As System.Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        FileClose(fileNumber)
    End Sub

    '
    '保存ﾎﾞﾀﾝｸﾘｯｸ時
    '
    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        'frmkisoのロード時に表のデータを読み込む処理があるため、frmkiso(基礎図作成ウィンドウ)が開いたままなら警告文を表示する
        For Each f As Form In My.Application.OpenForms
            If f.Name = "frmkiso" Then
                MsgBox("基礎図作成フォームが開かれたままです。" & Chr(13) & "保存内容が作図に反映されないので、" & Chr(13) & "自動作図する際は基礎図作成フォームを開きなおしてください。", MsgBoxStyle.Exclamation)
                Exit For
            End If
        Next
        'セルコピー状態解除
        If Copyflg = True Then
            Call CopyModeClear()
        End If
        '盤データ保存処理
        Call DataSave()
    End Sub


    '
    '盤データ保存処理
    '
    Private Sub DataSave()
        Dim a As Integer, b As Integer, c As Integer, d As Integer
        Dim i As Integer, j As Integer, n As Integer, m As Integer
        Dim o As Integer, p As Integer
        Dim k As Integer                      '選択行/列番号

        Dim ColSoat(gridHairetuKiso.ColumnCount - 1) As Integer   '元々の列の位置を見た目の列の位置にするための配列
        Dim iColNo As Integer                                   '基礎図表データ保存用
        Dim Ans As Integer
        Dim HozonFlg As Boolean = True
        'Dim header(gridHairetuKiso.ColumnCount - 1) As String   '読み込み時のヘッダー用配列(26行目)
        Dim HikiArray((4 * 5 * gridHairetuKiso.ColumnCount) - 1) As String
        Dim DelCnt As Integer           'DBから読み込んだ盤数からいくつ減ったか
        Dim NoCubNo(gridHairetuKiso.ColumnCount - 1) As Integer '納入外(表示)の箱番
        DelCnt = 0
        P_sBanDat2 = ""
        b = 0



        Sakuzuflg = False           'エラーチェック用フラグ:保存処理中
        Stopflg = False
        lblCnt = 0
        ACnt = 0
        BCnt = 0
        YCnt = 0
        ReDim ErrCell(100)
        For c = 0 To 100
            ErrCell(c) = ""
        Next

        'iColNo = gridHairetuKiso.Columns(gridHairetuKiso.CurrentCellAddress.X).DisplayIndex

        '「盤No」行エラーチェック(同じ値がないか確認)

        'For a = 0 To gridHairetuKiso.ColumnCount - 2            '最終行以外の盤を調べる
        '    For b = a + 1 To gridHairetuKiso.ColumnCount - 1
        '        If gridHairetuKiso.Rows(pc_BanNoRow).Cells(a).Value = gridHairetuKiso.Rows(pc_BanNoRow).Cells(b).Value Then
        '            MsgBox("「盤No.」が重複しています。")
        '            MsgBox("保存に失敗しました。", MsgBoxStyle.Critical)
        '            Exit Sub
        '        End If
        '        If a = gridHairetuKiso.ColumnCount - 1 And b + 1 = gridHairetuKiso.ColumnCount - 1 Then
        '            Exit For
        '        End If
        '    Next
        'Next
        

        a = 0
        '数値のみ入力が通る行のエラーチェック(数値になっているか)

        'For a = 0 To gridHairetuKiso.ColumnCount - 1
        '    If IsNumeric(gridHairetuKiso.Rows(pc_BanNoRow).Cells(a).Value) = False Then
        '        MsgBox(a + 1 & "列目の「盤No.」に数値以外の文字が含まれています。")
        '        MsgBox("保存に失敗しました。", MsgBoxStyle.Critical)
        '        Exit Sub
        '    End If
        '    If IsNumeric(gridHairetuKiso.Rows(pc_DoorOpnRow).Cells(a).Value) = False Then
        '        MsgBox(a + 1 & "列目の「扉解放角度」に数値以外の文字が含まれています。")
        '        MsgBox("保存に失敗しました。", MsgBoxStyle.Critical)
        '        Exit Sub
        '    End If
        '    If IsNumeric(gridHairetuKiso.Rows(pc_JyuryoRow).Cells(a).Value) = False Then
        '        MsgBox(a + 1 & "列目の「盤概略質量」に数値以外の文字が含まれています。")
        '        MsgBox("保存に失敗しました。", MsgBoxStyle.Critical)
        '        Exit Sub
        '    End If
        'Next
        'If txtBunkatu.Text = "" Or IsNumeric(txtBunkatu.Text) = False Then          '分割位置の入力がなかったり数字ではない場合
        '    MsgBox("分割位置を正しく入力してください。", MsgBoxStyle.Exclamation)
        '    MsgBox("保存できませんでした。", MsgBoxStyle.Critical)
        '    Exit Sub
        'End If


        '    '16.12.1 松本追加   '↓ここから
        '    If fCreDoorTyp(gridHairetuKiso.Rows(pc_FDoorRow).Cells(c).Value, _
        '                                      gridHairetuKiso.Rows(pc_RDoorRow).Cells(c).Value) = "" Then
        '        MsgBox(gridHairetuKiso.Rows(pc_BanNoRow).Cells(c).Value & _
        '               "箱の扉形状の選択肢の組み合わせが正しくありません" & vbCrLf & "データは保存できません", _
        '                   vbOKOnly + vbExclamation, "扉形状選択エラー")    'ｴﾗｰﾒｯｾｰｼﾞ表示
        '        Exit Sub                                '保存処理中断
        '    End If              '←ここまで

        'Next

        'If HozonFlg = False Then        '特殊な形式もあると思われるので、違う組み合わせでも確認をしたうえで保存できるようにする処理
        '    MsgBox("規格と形が規定の組み合わせと一致していない箇所があります。")
        '    Ans = MsgBox("このまま保存しますか？", MsgBoxStyle.OkCancel)
        '    If Ans <> 1 Then            '「はい」でなければ
        '        MsgBox("保存に失敗しました。", MsgBoxStyle.Critical)
        '        Exit Sub                '保存せずに入力待機状態へ
        '    End If
        'End If

        'txtファイルに仕様を書き込む

        '手動で列の並び替えをされている可能性があるので、表示されている順に保存できるようにする
        '(列ヘッダーを移動して並び替えをすると、見た目の位置(DisplayIndex)は目的の位置になっているがその列の元々の位置情報(index)は変わっていない)
        '(例：元々が2列目なら、移動した結果見た目が5列目になっても2列目に存在している扱い)
        For a = 0 To gridHairetuKiso.ColumnCount - 1                    '1列(盤)目から順に処理
            For b = 0 To gridHairetuKiso.ColumnCount - 1                '
                If gridHairetuKiso.Columns(a).DisplayIndex = b Then     '見た目の列の位置と一致したら
                    ColSoat(b) = gridHairetuKiso.Columns(a).Index             '見た目の行の位置と保存したい行の位置を一致させる
                    Exit For                                            '次の列へ
                End If
            Next
            'header(a) = a + 1                                           '列ヘッダーの値を配列に
        Next

        ReDim P_sBanDat(gridHairetuKiso.ColumnCount - 1, gridHairetuKiso.RowCount - 4 + gridSyukairo.RowCount - 3 + 4 * 4)

        'txtファイルにデータを保存するために、表のデータを配列にする
        '下準備(基礎図表の引込穴のセルに5つの情報があるのでそれを配列に)
        Dim stArrayData As String()

        For i = 0 To gridHairetuKiso.ColumnCount - 1
            For j = 0 To 3
                stArrayData = gridSyukairo.Rows(j + 9).Cells(gridSyukairo.Columns(i).DisplayIndex).Value.Split(","c)
                For n = 0 To 4
                    HikiArray(5 * j + n + 20 * i) = stArrayData(n)
                Next

            Next
        Next
        For i = 0 To gridHairetuKiso.ColumnCount - 1                                     '現在の表のデータを2次元配列の変数に代入
            For j = 0 To gridHairetuKiso.RowCount - 4           '配列基礎仕様の24行
                P_sBanDat(i, j) = gridHairetuKiso.Rows(j).Cells(ColSoat(i)).Value    '表の値を書き込む
            Next
            For j = gridHairetuKiso.RowCount - 3 To gridHairetuKiso.RowCount - 4 + 8    '基礎図表の補強枠と奥行枠の行
                P_sBanDat(i, j) = gridSyukairo.Rows(j - (gridHairetuKiso.RowCount - 4)).Cells(gridSyukairo.Columns(i).DisplayIndex).Value    '表の値を書き込む
            Next
            For j = gridHairetuKiso.RowCount - 4 + 9 To gridHairetuKiso.RowCount - 4 + gridSyukairo.RowCount - 3 + 4 * 4    '引込穴の行
                P_sBanDat(i, j) = HikiArray(j - (gridHairetuKiso.RowCount - 4 + 9) + 20 * i)    '表の値を書き込む
            Next
            'j = gridHairetuKiso.RowCount - 4 + gridSyukairo.RowCount - 3 + 4 * 4 + 1    '分割点
            'P_sBanDat(i, j) = gridSyukairo.Rows(j - (gridHairetuKiso.RowCount - 4)).Cells(gridSyukairo.Columns(i).DisplayIndex).Value    '表の値を書き込む
        Next
        ''2次元配列を文字列に変換
        'For k = 0 To gridHairetuKiso.ColumnCount        '2次元配列を文字列に変換
        '    For l = 0 To gridHairetuKiso.RowCount - 4 + gridSyukairo.RowCount - 3 + 4 * 4
        '        If k = 0 Then           '1行目はデータを読み込むとき用に盤数と全体の情報を書き込み、2行目から盤データを書き込む
        '            P_sBanDat2 = Str(gridHairetuKiso.ColumnCount) & "," & cmbInOut.SelectedItem & ","
        '            P_sBanDat2 += cmbDoorTyp.SelectedItem & "," & cmbKeshoTyp.SelectedItem & ","
        '            P_sBanDat2 += cmbSeikanTyp.SelectedItem & "," & cmbSeigyo.SelectedItem & ","
        '            P_sBanDat2 += txtBaseH.Text & "," & txtFntSunpo.Text & "," & txtBckSunpo.Text

        '            For m = 9 To gridHairetuKiso.RowCount - 4 + gridSyukairo.RowCount - 3 + 4 * 4
        '                P_sBanDat2 += "," + ""
        '            Next
        '        ElseIf l = 0 Then
        '            P_sBanDat2 += P_sBanDat(k - 1, l)
        '        ElseIf l <= gridHairetuKiso.RowCount - 4 Then
        '            P_sBanDat2 += "," + P_sBanDat(k - 1, l)     '区切り文字
        '        ElseIf gridHairetuKiso.RowCount - 4 < l And l <= gridHairetuKiso.RowCount - 4 + 7 Then
        '            'P_sBanDat2 += "," + SyukairoData(gridHairetuKiso.RowCount - 4 + k - 1, l)
        '            P_sBanDat2 += "," + P_sBanDat(k - 1, l)
        '        Else
        '            'P_sBanDat2 += "," + SyukairoData(gridHairetuKiso.RowCount - 4 + 5 * k - 32, l)
        '            P_sBanDat2 += "," + P_sBanDat(k - 1, l)
        '        End If
        '    Next l
        '    If k <> gridHairetuKiso.ColumnCount Then
        '        P_sBanDat2 += vbCrLf        'txtファイル内で改行して配列の次の行を文字列に
        '    End If

        'Next k

        ''Dim sw As New System.IO.StreamWriter(BlockPath2 + txtPath, _
        ''False, _
        ''System.Text.Encoding.GetEncoding("shift_jis"))
        'Dim sw As New System.IO.StreamWriter("\\Nas-Server.swg.nissin.co.jp\設計データ\00 工番データ\産業\" & TKi & "期\" & P_sKbnNam & "\20 構造設計\20 図面\20 構造図\" & TGbn & "\" & txtNam, _
        'False, _
        'System.Text.Encoding.GetEncoding("shift_jis"))

        'sw.Write(P_sBanDat2)        'txtファイルに書き込み(上書き)
        ''閉じる
        'sw.Close()


        '--------------------------------
        '共通事項
        p_DoorTyp = cmbDoorTyp.SelectedItem             '扉形番取得          '16.12.1 松本追加
        KeshoType = cmbKeshoTyp.SelectedItem            '側面化粧板取得      '←
        P_SeikanTyp = cmbSeikanTyp.SelectedItem         '製缶方式            '←
        FntSunpo = txtFntSunpo.Text                     '機器引出寸法(前)    '←
        BckSunpo = txtBckSunpo.Text                     '機器引出寸法(前)    '←
        BaseH = txtBaseH.Text
        SeigyoAna = cmbSeigyo.SelectedItem
        Bunkatu = txtBunkatu.Text
        If cmbInOut.SelectedItem = "屋内" Then  '屋内選択時
            'chkCaulk.Checked = False            'ｺｰｷﾝｸﾞ注意書きは記入しない
            'chkCaulk.Enabled = False            'ｺｰｷﾝｸﾞ注意書きを選択できないようにする
            Okugai = False
            InOut = "屋内"
            IO = "屋内"
        Else                                    '屋内以外
            'chkCaulk.Enabled = True             'ｺｰｷﾝｸﾞ注意書きを選択できるようにする
            Okugai = True
            InOut = "屋外"
            IO = "屋外"
        End If




        'エラーチェック
        Call BanNoErrChk()          '箱番の重複
        If Stopflg = True Then
            Exit Sub
        End If
        Call IsNumericErrChk()      '数値のみ入力するセルに数値以外の入力があるか
        If Stopflg = True Then
            Exit Sub
        End If
        Call Mesure0Chk()           '寸法値が0になっていないか
        If Stopflg = True Then
            Exit Sub
        End If
        Call HokyoSizeChk()
        If Stopflg = True Then
            Exit Sub
        End If
        Call HikiSizeChk()
        If Stopflg = True Then
            Exit Sub
        End If

        Call DoorSelectChk()
        If Stopflg = True Then
            Exit Sub
        End If

        Call DataErrChk()
        If Stopflg = True Then
            Exit Sub
        End If

        Call KisoErrorChk()
        If Stopflg = True Then
            Exit Sub
        End If

        If lblCnt <> 0 Then
            frmErrorList.Show()
        End If


        For o = 0 To gridHairetuKiso.ColumnCount - 1
            If gridHairetuKiso.Rows(pc_NoKisoRow).Cells(o).Value = "納入外（表示）" Then
                NoCubNo(o) = gridHairetuKiso.Rows(pc_BanNoRow).Cells(o).Value
            End If
        Next


        ReDim BaseBunkatu(30)
        ReDim Bunkatuiti(gridHairetuKiso.ColumnCount - 1)
        m = 0
        For k = 0 To gridHairetuKiso.ColumnCount - 1
            ExtCubNo(k) = gridHairetuKiso.Rows(pc_NoKisoRow).Cells(ColSoat(k)).Value
            If gridSyukairo.Rows(pc_BunkatuRow).Cells(ColSoat(k)).Value = "有" Then           '分割点を設ける場合
                Bunkatuiti(m) = gridHairetuKiso.Rows(0).Cells(ColSoat(k)).Value
                KM_BaseBunkatu(m) = gridHairetuKiso.Rows(0).Cells(ColSoat(k)).Value          '箱番を配列にセット
                BaseBunkatu(m) = gridHairetuKiso.Rows(0).Cells(ColSoat(k)).Value          '箱番を配列にセット
                m = m + 1
            End If
            If k = gridHairetuKiso.ColumnCount - 1 Then                                     '最後の盤の処理
                If gridSyukairo.Rows(pc_BunkatuRow).Cells(k).Value <> "有" And m <> 0 Then   '最後の盤が分割指定されていない且つ1つでも分割指示がある場合
                    'KM_BaseBunkatu(m) = gridHairetuKiso.Rows(0).Cells(ColSoat(k)).Value          '箱番を配列にセット
                    BaseBunkatu(m) = gridHairetuKiso.Rows(0).Cells(ColSoat(k)).Value          '箱番を配列にセット

                ElseIf m = 0 Then
                    p = k
                    Do Until (gridHairetuKiso.Rows(pc_NoKisoRow).Cells(p).Value = "")
                        If p = 0 Then
                            Exit Do
                        End If
                        p = p - 1
                    Loop

                    If NoCubNo(0) <> 0 Or p <> gridHairetuKiso.ColumnCount - 1 Then
                        '最後の箱番を分割指定する(分割指示有りの状態にしておくことで、納入外(表示)の箱に分割が入るようになる)
                        KM_BaseBunkatu(m) = gridHairetuKiso.Rows(0).Cells(ColSoat(p)).Value          '箱番を配列にセット
                        BaseBunkatu(m) = gridHairetuKiso.Rows(0).Cells(ColSoat(p)).Value          '箱番を配列にセット
                    End If
                End If
            End If
        Next



        
        FileClose(fileNumber)
        MsgBox("保存しました。")
        'MsgBox("データ保存機能 未作成" & vbCrLf & "m(_ _)m", vbOKOnly + vbInformation, "まだ保存できません")



        '-----------------------------------------------------------------------
        'データベースへ保存する処理 

        i = 0

        'DBへの保存の方法を変更
        '不足分をinsert、既にあるものはupdate → 保存したい群番のデータを削除し、すべてinsert


        stat = DB_配列基礎共通("check")
        If Not rs.EOF Then
            stat = DB_配列基礎共通("delete")
            'stat = DB_配列基礎共通("check")
        End If
        stat = DB_配列基礎共通("insert")
        'stat = DB_配列基礎共通("update")

        'stat = DB_配列図箱別("check")
        'If Not rs.EOF Then
        '    stat = DB_配列図箱別("delete")
        'End If

        'stat = DB_基礎図箱別("check")
        'If Not rs.EOF Then
        '    stat = DB_基礎図箱別("delete")
        'End If
        stat = DB_配列図箱別("check")
        If Not rs.EOF Then
            stat = DB_配列図箱別("delete")
            'stat = DB_配列図箱別("select")
        End If
        For i = 0 To UBound(P_sBanDat, 1)   '箱の数だけループ(現在保存時にtxtファイル用に配列が1列多くなっているので-1が必要なので-2。)       
            BanCnt2 = i + 1                         '表の左から何番目の箱か(箱連番)
            BanNo = P_sBanDat(i, pc_BanNoRow)       '箱番

            stat = DB_配列図箱別("insert")
            'stat = DB_配列図箱別("update")
        Next

        stat = DB_基礎図箱別("check")
        If Not rs.EOF Then
            stat = DB_基礎図箱別("delete")
            'stat = DB_基礎図箱別("select")
        End If
        For i = 0 To UBound(P_sBanDat, 1)    '箱の数だけループ(現在保存時にtxtファイル用に配列が1列多くなっているので-1が必要なので-2。)       
            BanCnt2 = i + 1                         '表の左から何番目の箱か(箱連番)
            BanNo = P_sBanDat(i, pc_BanNoRow)       '箱番

            stat = DB_基礎図箱別("insert")
            'stat = DB_基礎図箱別("update")
        Next

        '--------------------------------------------------------------------

    End Sub

    '
    '屋内外選択変更時
    '
    Private Sub cmbInOut_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbInOut.SelectedValueChanged
        If cmbInOut.SelectedItem = "屋内" Then  '屋内選択時
            'chkCaulk.Checked = False            'ｺｰｷﾝｸﾞ注意書きは記入しない
            'chkCaulk.Enabled = False            'ｺｰｷﾝｸﾞ注意書きを選択できないようにする
            'Okugai = False
            'IO = "屋内"
            txtBaseH.Text = H_Okunai
        Else                                    '屋内以外
            'chkCaulk.Enabled = True             'ｺｰｷﾝｸﾞ注意書きを選択できるようにする
            'Okugai = True
            'IO = "屋外"
            txtBaseH.Text = H_Okugai
        End If
    End Sub
    '
    '列入替時
    '
    Private Sub gridHairetuKiso_ColumnDisplayIndexChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewColumnEventArgs) Handles gridHairetuKiso.ColumnDisplayIndexChanged
        If Delflg = False Then
            Dim i As Integer, j As Integer, k As Integer, l As Integer, m As Integer, a As Integer, b As Integer
            Dim Colsoat(gridHairetuKiso.ColumnCount - 1) As Integer
            'ReDim Preserve P_sBanDatK(gridSyukairo.ColumnCount - 1, gridSyukairo.RowCount - 3)

            Call CopyModeClear()                            'セルコピー状態なら解除
            e.Column.HeaderText = e.Column.DisplayIndex + 1 '並び順振り直し
            'e.Column.Name = e.Column.DisplayIndex

            For a = 0 To gridHairetuKiso.ColumnCount - 1                    '1列(盤)目から順に処理
                For b = 0 To gridHairetuKiso.ColumnCount - 1                '
                    If gridHairetuKiso.Columns(a).DisplayIndex = b Then     '見た目の列の位置と一致したら
                        Colsoat(b) = gridHairetuKiso.Columns(a).Index             '見た目の行の位置と保存したい行の位置を一致させる
                        Exit For                                            '次の列へ
                    End If
                Next

            Next

            '基礎図表も連動して列を入れ替える(入替前の状態を保存した配列から、入替先にデータをもってくる)
            For i = 0 To gridHairetuKiso.ColumnCount - 1
                gridSyukairo.Rows(0).Cells(i).Value = gridHairetuKiso.Rows(0).Cells(Colsoat(i)).Value   '盤No(必ず決まる値なので先に変更し、次の処理で使用)
            Next
            For k = 0 To gridSyukairo.ColumnCount - 1                                   '基礎図表の行を左から順に
                For l = 0 To gridSyukairo.ColumnCount - 1                               '一時保存用配列も順に
                    If gridSyukairo.Rows(0).Cells(k).Value = P_sBanDatK(l, 0) Then      '盤Noと一時保存用配列の盤Noが一致したら
                        For m = 1 To gridSyukairo.RowCount - 3                          '盤Noとボタン行以外
                            gridSyukairo.Rows(m).Cells(k).Value = P_sBanDatK(l, m)      'データ書き換え
                        Next
                        Exit For
                    End If
                Next
            Next

            '補強枠の選択を表に反映させる処理
            If Delflg = False Then
                'For j = 0 To gridSyukairo.ColumnCount - 1
                For j = 0 To Colsoat.Length - 1
                    gridSyukairo.CurrentCell = gridSyukairo.Rows(1).Cells(Colsoat(j))    '補強枠選択行(コンボボックス行)
                    gridSyukairo.BeginEdit(True)            'コンボボックスの情報を得るために編集モードを開始する
                    Dim cb As DataGridViewComboBoxEditingControl = CType(gridSyukairo.EditingControl, DataGridViewComboBoxEditingControl)
                    cb.EditingControlDataGridView.NotifyCurrentCellDirty(True)  '1回目の選択の時に値が変わったという情報が伝わらないので伝える(一部セルの編集可否や色変更をするため)
                    cb.EditingControlDataGridView.EndEdit() '編集モードを終了する
                Next
            End If


            gridHairetuKiso.CurrentCell = Nothing
        End If

    End Sub

    '以下3つで入力可能なコンボボックスに
    Private Sub gridHairetuKiso_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles gridHairetuKiso.EditingControlShowing

        If TypeOf e.Control Is DataGridViewComboBoxEditingControl Then
            RemoveHandler e.Control.TextChanged, AddressOf EditCtrlTextChanged
            If TypeOf gridHairetuKiso.CurrentCell Is DataGridViewComboBoxCell Then          '選択したセルがコンボボックスセルだった場合
                '編集のために表示されているコントロールを取得
                Dim cb As DataGridViewComboBoxEditingControl = _
                    CType(e.Control, DataGridViewComboBoxEditingControl)

                cb.DropDownStyle = ComboBoxStyle.DropDown
                AddHandler e.Control.TextChanged, AddressOf EditCtrlTextChanged         'コンボボックスのリストの開閉制御(リストにない項目をコンボボックスセルに反映させるために必要)
            End If
        End If
    End Sub

    '
    'コンボボックスの値が変わったとき
    '
    Private Sub EditCtrlTextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim ctrl As ComboBox = sender
        Dim item = From r In ctrl.Items Where r.ToString().IndexOf(ctrl.Text) = 0 Select r

        If ctrl.SelectedItem <> Nothing Then
            If ctrl.SelectedItem.ToString().Equals(ctrl.Text) Then      '
                Return
            End If
        End If
        If item.Count() > 0 Then
            'If ctrl.DroppedDown <> True Then
            '    'ctrl.DroppedDown = True
            'End If
        Else
            If ctrl.DroppedDown = True Then
                'If gridHairetuKiso.CurrentCellAddress.Y <> UBound(P_sBanDat, 1) - 1 Then
                ctrl.DroppedDown = False
                'End If
            End If
        End If
    End Sub

    '
    'セルが入力フォーカスを失い、セルの値の検証が可能になったとき
    '(EndEditより早いタイミングで発生)
    '
    Private Sub gridHairetuKiso_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles gridHairetuKiso.CellValidating
        Dim dgv As DataGridView = CType(sender, DataGridView)
        Dim CmbV As String

        If TypeOf gridHairetuKiso.CurrentCell Is DataGridViewComboBoxCell Then          '選択したセルがコンボボックスセルだった場合
            Dim cbc As DataGridViewComboBoxCell = _
            CType(gridHairetuKiso.CurrentCell, DataGridViewComboBoxCell)
            CmbV = cbc.Value
            'コンボボックスの項目に追加する
            If Not cbc.Items.Contains(e.FormattedValue) Then
                cbc.Items.Add(e.FormattedValue)
            End If

            gridHairetuKiso.CommitEdit(DataGridViewDataErrorContexts.Commit)
            'セルの値を設定しないと、元に戻ってしまう
            dgv(e.ColumnIndex, e.RowIndex).Value = e.FormattedValue

            If cbc.RowIndex = pc_KikakuNoRow Then   '編集中のコンボボックスが「規格番号」行なら
                If cbc.Value <> Kikaku Then         'コンボボックスに入力、あるいは選択された規格番号が、セルの編集前から変更されていたら
                    Call sCrecmbBoxTyp(cbc.Value, cbc.RowIndex + 1, cbc.ColumnIndex)    '「形」行のコンボボックスセル再定義
                End If
            End If
        End If
    End Sub

    '
    '「保存」ボタンクリック時(基礎図表)
    '
    Private Sub btnHozon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHozon.Click
        'Dim i As Integer, j As Integer

        'ReDim Preserve Hokyoumu(1, gridSyukairo.ColumnCount - 1)
        '主回路ケーブル穴設定保存

        'For i = 0 To 7      '補強枠の部分
        '    For j = 0 To gridSyukairo.ColumnCount - 1
        '        SyukairoData(i, j) = gridSyukairo.Rows(i).Cells(j).Value
        '    Next

        'Next

        Call DataSave()     '配列基礎仕様表も保存

    End Sub

    '
    '配列基礎仕様表上でマウスのクリックがあったとき
    '
    Private Sub gridHairetuKiso_CellMouseClick(ByVal sender As Object, _
           ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) _
                        Handles gridHairetuKiso.CellMouseClick
        '左上端のヘッダーをクリックした時全て選択になるのを回避する
        Dim pos As System.Windows.Forms.DataGridView.HitTestInfo = gridHairetuKiso.HitTest(e.X, e.Y)
        If pos.ColumnIndex = -1 And pos.RowIndex = -1 Then
            gridHairetuKiso.MultiSelect = False
        Else
            gridHairetuKiso.MultiSelect = True
        End If
        Dim pos2 As System.Windows.Forms.DataGridView.HitTestInfo = gridSyukairo.HitTest(e.X, e.Y)
        If pos.ColumnIndex = -1 And pos.RowIndex = -1 Then
            gridSyukairo.MultiSelect = False
        Else
            gridSyukairo.MultiSelect = True
        End If
    End Sub

    'Private Sub lstHokyo_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstHokyo.MouseClick
    '    Dim i As Integer = lstHokyo.IndexFromPoint(e.Location)
    '    If i = -1 Then          'リストボックス内の空白(項目名の右側の空白は除く)
    '        '特に何もしない
    '    Else
    '        'txtHokyo.Text = lstHokyo.SelectedItem
    '    End If
    'End Sub

    Private Sub lstHokyo_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstHokyo.MouseMove
        Dim i As Integer = lstHokyo.IndexFromPoint(e.Location)
        Dim j As Integer
        'Dim bmp As Bitmap
        Dim myAssembly As System.Reflection.Assembly = _
            System.Reflection.Assembly.GetExecutingAssembly()

        If i = -1 Then          'リストボックス内の空白(項目名の右側の空白は除く)
            picHokyo.Image = Nothing
        Else
            For j = 0 To p_SelHokyoKata.Length - 2
                If Hpicname(i) = Hpicname(j) Then
                    picHokyo.Image = Hpics(j)
                End If
            Next
            'bmp = New Bitmap(myAssembly.GetManifestResourceStream("NPS承認図." & P_sHokyoDat(1, i)))
            'picHokyo.ImageLocation = BlockPath2 + picPath + P_sHokyoDat(1, i)
            'picHokyo.Image = bmp
        End If
    End Sub



    'Private Sub btnHokyoSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Dim i As Integer

    '    If IsNumeric(txtDNagasa.Text) = False Then
    '        MsgBox("長さが正しい値ではありません")
    '        MsgBox("保存に失敗しました", MsgBoxStyle.Critical)
    '        Exit Sub
    '    End If
    '    For i = 0 To gridSyukairo.ColumnCount - 1
    '        If cmbCubNo.SelectedItem = gridSyukairo.Rows(0).Cells(i).Value Then
    '            gridSyukairo.Rows(8).Cells(i).Value = txtHokyo.Text
    '            gridSyukairo.Rows(9).Cells(i).Value = txtDNagasa.Text
    '        End If
    '    Next
    'End Sub

    '
    '基礎図表上でマウスが動いたとき
    '
    Private Sub gridSyukairo_CellMouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles gridSyukairo.CellMouseMove
        '主回路ケーブル穴の表で、マウスカーソル位置によって表の下に表示するものを変える
        '(主回路ケーブル穴と補強枠)
        '主回路に関するグループと補強枠に関するグループで表示を切り替える

        If e.RowIndex >= 0 Then                 '行ヘッダーの行ではないなら
            If e.RowIndex > 5 Then             '主回路ケーブル穴関連の項目の行の場合
                tabctrlK.SelectedTab = tabHikiAna
            Else
                tabctrlK.SelectedTab = tabHokyo
            End If
        End If

    End Sub

    '
    '配列基礎仕様の表で、セルのコピーをする
    '(貼り付けはセルクリック時のイベントで行う)
    '(ペーストは同じ行でしかできない)
    '(ペーストするセルのクリックを待機している時に別の行を選択した場合は、そのセルをコピーし、ペーストするセルのクリックを待機する)
    '
    Private Sub btnCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopy.Click

        If Copyflg = True Then                          'セルコピー状態なら
            Call CopyModeClear()                        'セルコピーモード解除処理
            Exit Sub                                    '処理終了
        End If
        'セルコピー状態開始処理
        '行列ヘッダー、ボタンセル以外のセルが選択されているなら
        If 0 <= gridHairetuKiso.CurrentCellAddress.Y And gridHairetuKiso.CurrentCellAddress.Y < gridHairetuKiso.RowCount - 3 Then
            Select Case gridHairetuKiso.CurrentCellAddress.Y
                'Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow    'コンボボックスセル行の場合
                '↑ﾃﾞｰﾀ行追加に伴い↓のように修正 '16.12.1 松本
                Case pc_KikakuNoRow To pc_KankyouRow, pc_NoHairetuRow, pc_NoKisoRow, pc_KankiRow To pc_FTotteRow
                    befCell = gridHairetuKiso.CurrentCell                                           '現在のセルを変数に
                    befCell.FlatStyle = FlatStyle.Flat                                              'コピー元と分かるようにコンボボックススタイルを変更
                    befCellX = gridHairetuKiso.CurrentCellAddress.X
                    befCellY = gridHairetuKiso.CurrentCellAddress.Y                                 '現在のセルのY座標も記憶
                    btnCopy.ForeColor = Color.Cyan                                                  'セルコピー状態だと分かるように「セルコピー」ボタンの色を変更
                    Copyflg = True                                                                  'セルコピー状態開始
                Case Else                                                                           'テキストボックスセル行の場合
                    befCell2 = gridHairetuKiso.CurrentCell                                          '現在のセルを変数に
                    befCell2.Style.ForeColor = Color.Cyan                                           'コピー元と分かるようにセルの色の変更
                    befCellX = gridHairetuKiso.CurrentCellAddress.X
                    befCellY = gridHairetuKiso.CurrentCellAddress.Y                                 '現在のセルのY座標も記憶
                    btnCopy.ForeColor = Color.Cyan                                                  'セルコピー状態だと分かるように「セルコピー」ボタンの色を変更
                    Copyflg = True                                                                  'セルコピー状態開始
            End Select
            'gridHairetuKiso.CurrentCell.ReadOnly = True
            gridHairetuKiso.CurrentCell.Selected = False
            'gridHairetuKiso.CurrentCell = Nothing                                                  'コピー元のセルの値の色の変化がわかるようにカレントセルをなくす
        Else
            MsgBox("ボタンセルまたはヘッダーが選択されているか、" & vbCrLf & "セルが選択されていないためコピーできませんでした。")
        End If
    End Sub

    '
    '基礎図表のコンボボックスのコントロールに関する処理
    '
    Private Sub gridSyukairo_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles gridSyukairo.EditingControlShowing
        'Dim a As String, b As String

        If TypeOf e.Control Is DataGridViewComboBoxEditingControl Then
            If gridSyukairo.CurrentCellAddress.Y = 1 Then          '選択したセルが1行目(補強枠コンボボックス)だった場合
                '編集のために表示されているコントロールを取得
                Dim cb As DataGridViewComboBoxEditingControl = _
                    CType(e.Control, DataGridViewComboBoxEditingControl)    '編集中のコンボボックス取得

                RemoveHandler cb.DropDownClosed, AddressOf ValueChanged
                AddHandler cb.DropDownClosed, AddressOf ValueChanged

            End If
        End If
    End Sub

    '
    '基礎図表のコンボボックスの値が選択されたときの処理
    '
    Private Sub ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        'SendKeys.SendWait("ENTER")
        Dim cb As DataGridViewComboBoxEditingControl = _
                    CType(sender, DataGridViewComboBoxEditingControl)   '編集中のコンボボックス取得

        cb.EditingControlDataGridView.NotifyCurrentCellDirty(True)  '1回目の選択の時に値が変わったという情報が伝わらないので伝える
        cb.EditingControlDataGridView.EndEdit() 'コンボボックスの値を選択してすぐにサムネイルを表示するために編集モードを終了する
        cb.EditingControlDataGridView.BeginEdit(False)
    End Sub




    'Private Sub ListMouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lstHokyo.MouseMove
    '    Dim i As Integer = lstHokyo.IndexFromPoint(e.Location)
    '    Dim bmp As Bitmap
    '    Dim myAssembly As System.Reflection.Assembly = _
    '        System.Reflection.Assembly.GetExecutingAssembly()

    '    If i = -1 Then          'リストボックス内の空白(項目名の右側の空白は除く)
    '        picHokyo.Image = Nothing
    '    Else
    '        bmp = New Bitmap(myAssembly.GetManifestResourceStream("NPS承認図." & P_sHokyoDat(1, i)))
    '        'picHokyo.ImageLocation = BlockPath2 + picPath + P_sHokyoDat(1, i)
    '        picHokyo.Image = bmp
    '    End If
    'End Sub

    '
    '「引込穴追加」ボタンが押されたとき
    '
    Private Sub btnDataAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataAdd.Click
        'Dim i As Integer
        Dim iRowNo As Integer, iColNo As Integer
        'Dim SData() As String = {cmbK1.SelectedItem, txtK1A.Text, txtK1B.Text, txtK1X.Text, txtK1Y.Text}
        iColNo = gridSyukairo.CurrentCellAddress.X
        iRowNo = gridSyukairo.CurrentCellAddress.Y

        If iRowNo > 7 And txtBanNo.Text = gridSyukairo.Rows(0).Cells(iColNo).Value Then
            gridSyukairo.CurrentCell.Value = cmbK1.SelectedItem & "," & txtK1A.Text & "," & txtK1B.Text & "," & txtK1X.Text & "," & txtK1Y.Text

            'For i = 0 To 4
            '    '引込穴に関する情報を基礎図表用の配列に代入
            '    '基礎図表では1セルにまとめられた引込穴の情報を、データ保存先配列ではまとめずに保存するため、以下の式を用いつつ配列に保存
            '    'iRowNo+4(iRowNo-8)+i → 1つ目の形式(基礎図表の8行目)、形式2(9行目)、・・・の引込穴の型の、配列SyukairoData上の行を求める式
            '    '(iRowNo=8 → SyukairoData(8,iColNo), iRowNo=9 → SyukairoData(13,iColNo), iRowNo=10 → SyukairoData(18,iColNo)・・・)
            '    SyukairoData(iRowNo + 4 * (iRowNo - 8) + i, iColNo) = SData(i)
            'Next

        End If
    End Sub


    'Private Sub txtBanNo_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtBanNo.TextChangedLeave
    '    Dim i As Integer

    '    If txtKeisikiNo.Text <> "" Then
    '        For i = 0 To gridSyukairo.ColumnCount - 1
    '            If gridSyukairo.Rows(0).Cells(i).Value = txtBanNo.Text Then
    '                gridSyukairo.CurrentCell = gridSyukairo.Rows(txtKeisikiNo.Text).Cells(i)
    '            End If
    '        Next
    '    End If


    'End Sub

    'Private Sub txtKeisikiNo_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtKeisikiNo.TextChanged
    '    Dim i As Integer, k As Integer
    '    Dim BanNo As Integer

    '    If txtBanNo.Text <> "" Then
    '        For i = 0 To gridSyukairo.ColumnCount - 1
    '            If gridSyukairo.Rows(0).Cells(i).Value = txtBanNo.Text Then
    '                BanNo = gridSyukairo.Columns(i).HeaderText
    '                Exit For
    '            End If
    '        Next
    '        For k = 8 To 11
    '            If k = Val(txtKeisikiNo.Text) + 7 Then
    '                gridSyukairo.CurrentCell = gridSyukairo.Rows(k).Cells(BanNo)
    '            End If
    '        Next
    '    End If
    'End Sub

    '
    '引込穴タブの補強枠の型選択コンボボックスの値が変わった時の処理
    '
    Private Sub cmbK1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbK1.SelectedIndexChanged
        '
        Dim i As Integer
        Dim Selitem As String

        If cmbK1.SelectedItem = "1型500*250" Then
            txtK1A.Text = 500
            txtK1B.Text = 250
            txtK1A.Enabled = False
            txtK1B.Enabled = False
        ElseIf cmbK1.SelectedItem = "1型500*300" Then
            txtK1A.Text = 500
            txtK1B.Text = 300
            txtK1A.Enabled = False
            txtK1B.Enabled = False
        ElseIf cmbK1.SelectedItem = "1型600*250" Then
            txtK1A.Text = 600
            txtK1B.Text = 250
            txtK1A.Enabled = False
            txtK1B.Enabled = False
        ElseIf cmbK1.SelectedItem = "4型LS01" Then
            txtK1A.Text = 200
            txtK1B.Text = 400
            txtK1A.Enabled = False
            txtK1B.Enabled = False
        Else
            txtK1A.Enabled = True
            txtK1B.Enabled = True
            PicSyukairo.Image = Nothing
        End If
        Selitem = cmbK1.SelectedItem
        If 0 < Selitem.IndexOf("*") Then        '"*"が名前に含まれているなら
            Selitem = Selitem.Replace("*", ",") '"*"を","に変更(1型の既定の型のファイル名が「1型○○○,○○○」なので)
        End If

        For i = 0 To Kpics.Length - 1
            If Selitem = Kpicname(i) Then       '選択された型と一致する画像を配列から探す
                PicSyukairo.Image = Kpics(i)
                Exit For
            End If
        Next

    End Sub

    '
    '基礎図表のセルの編集が終わったとき
    '
    Private Sub gridSyukairo_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridSyukairo.CellEndEdit
        '補強枠の型によって入力可能セルを変える(入力の必要がないセルは入力不可に)
        Dim k As Integer, l As Integer

        If Lflg = True And gridSyukairo.CurrentCellAddress.Y = 1 Then
            Select Case gridSyukairo.CurrentCell.Value
                Case "Ⅰ字型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True   '編集不可に(読み取り専用にしている)
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"       '必要のない寸法は0に(エラーチェックがくるってしまうので)
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False  '編集可能に
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                Case "Ⅱ字型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                Case "一字型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                Case "二字型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                Case "Ｔ字型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                Case "逆Ｔ字型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                Case "Π型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                Case "逆Π型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                Case "井型"
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = False
                Case Else
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(2).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(3).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(4).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True
                    gridSyukairo.Rows(5).Cells(gridSyukairo.CurrentCellAddress.X).Value = "0"
            End Select
            For k = 2 To 5      '型の選択を受けて、編集ができるかどうかを見た目で判断できるようにする処理
                If gridSyukairo.Rows(k).Cells(gridSyukairo.CurrentCellAddress.X).ReadOnly = True Then   '編集不可のセルなら
                    '編集不可にしても見た目では判断できなかったので、分かるように灰色にする
                    gridSyukairo.Rows(k).Cells(gridSyukairo.CurrentCellAddress.X).Style.BackColor = Color.Gray
                Else
                    'セルの色を元に(デフォルト値)に戻す
                    gridSyukairo.Rows(k).Cells(gridSyukairo.CurrentCellAddress.X).Style.BackColor = Color.Empty
                End If
            Next
            For l = 0 To p_SelHokyoKata.Length - 2                      'コンボボックスの選択肢に"無"もあるため、長さ-2
                If gridSyukairo.CurrentCell.Value = Hpicname(l) Then    '選択された型の名前と一致する画像の名前を探す
                    picHokyo.Image = Hpics(l)                           'プレビュー表示
                End If
            Next
        End If
    End Sub


    '
    'タブが切り替わったとき
    '
    Private Sub TabHairetuKiso_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabHairetuKiso.SelectedIndexChanged
        Dim ColSoat(gridSyukairo.ColumnCount - 1) As Integer
        'ReDim Preserve P_sBanDatK(gridSyukairo.ColumnCount - 1, gridSyukairo.RowCount - 3)

        'セルコピー状態のままなら解除する
        If Copyflg = True Then
            Call CopyModeClear()
        End If

        '列入替時に、基礎図表の編集途中のデータも移動させるためにデータを一時保存する
        '列入替は配列基礎仕様側でのみ可能なので、このタイミングで基礎図表を仮保存する
        For a = 0 To gridHairetuKiso.ColumnCount - 1                    '1列(盤)目から順に処理
            For b = 0 To gridHairetuKiso.ColumnCount - 1                '
                If gridHairetuKiso.Columns(a).DisplayIndex = b Then     '見た目の列の位置と一致したら
                    ColSoat(b) = gridHairetuKiso.Columns(a).Index             '見た目の行の位置と保存したい行の位置を一致させる
                    Exit For                                            '次の列へ
                End If
            Next
        Next

        'For l = 0 To gridSyukairo.ColumnCount - 1
        '    For m = 0 To gridSyukairo.RowCount - 3
        '        gridSyukairo.Rows(m).Cells(l).Value = P_sBanDatK(Colsoat(l), m)
        '    Next
        'Next
        For l = 0 To gridSyukairo.ColumnCount - 1
            For m = 0 To gridSyukairo.RowCount - 3
                P_sBanDatK(l, m) = gridSyukairo.Rows(m).Cells(l).Value
            Next
        Next


    End Sub


    'Private Sub gridSyukairo_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles gridSyukairo.CellValidating
    '    '補強枠の型選択後、プレビューを切り替える
    '    If Lflg = True And gridSyukairo.CurrentCellAddress.Y = 1 Then   'フォーム読み込み時ではなく、且つ補強枠の型選択行なら
    '        For k = 0 To p_SelHokyoKata.Length - 2                      'コンボボックスの選択肢に"無"もあるため、長さ-2
    '            If gridSyukairo.CurrentCell.Value = Hpicname(k) Then    '選択された型の名前と一致する画像の名前を探す
    '                picHokyo.Image = Hpics(k)                           'プレビュー表示
    '            End If
    '        Next
    '    End If
    'End Sub

    Private Sub gridHairetuKiso_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridHairetuKiso.CellValueChanged
        If e.RowIndex = 6 And Lflg = True Then
            Call sCrecmbBoxTyp(gridHairetuKiso.Rows(e.RowIndex).Cells(e.ColumnIndex).Value, e.RowIndex + 1, e.ColumnIndex)
        End If
    End Sub

    Private Sub btnRyuyo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRyuyo.Click
        frmRyuyo.ShowDialog()
    End Sub

    Private Sub gridHairetuKiso_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridHairetuKiso.CellDoubleClick
        If e.RowIndex = pc_BlkSKRow Then
            SKX = e.ColumnIndex
            frmBlkSK.ShowDialog()
        End If



    End Sub
End Class

'Public Class myDataGridViewRowHeaderCell
'    Inherits DataGridViewRowHeaderCell
'    '行ヘッダーの三角マークを消す処理(三角マークが行き来すると見栄えが悪いと思ったため)
'    '(三角マークを隠さないとEnterキーとUPキーを使うため、行ヘッダーの三角マークが下、上と素早く移動する)
'    Protected Overrides Sub Paint(ByVal graphics As Graphics, _
'                                ByVal clipBounds As Rectangle, _
'                                ByVal cellBounds As Rectangle, _
'                                ByVal rowIndex As Integer, _
'                                ByVal cellState As DataGridViewElementStates, _
'                                ByVal value As Object, _
'                                ByVal formattedValue As Object, _
'                                ByVal errorText As String, _
'                                ByVal cellStyle As DataGridViewCellStyle, _
'                                ByVal advancedBorderStyle As DataGridViewAdvancedBorderStyle, _
'                                ByVal paintParts As DataGridViewPaintParts)

'        MyBase.Paint(graphics, clipBounds, cellBounds, _
'                    rowIndex, cellState, value, formattedValue, _
'                    errorText, cellStyle, advancedBorderStyle, _
'                    paintParts And Not DataGridViewPaintParts.ContentBackground)
'    End Sub

'End Class
