﻿Public Class frmErrorList

    'エラーの内容とそのエラーが発生している箇所
    'エラーがあった場合、上記の２つが表示される
    'フォームを閉じる場合は右上の×で
    Public lblEJBanNo As System.Windows.Forms.Label
    Public txtEJBanNo As System.Windows.Forms.TextBox
    Public lblENBanNo As System.Windows.Forms.Label
    Public txtENBanNo As System.Windows.Forms.TextBox

    Public lblEDoor As System.Windows.Forms.Label
    Public txtEDoor As System.Windows.Forms.TextBox
    Public lblEJuryo As System.Windows.Forms.Label
    Public txtEJuryo As System.Windows.Forms.TextBox
    Public lblENBanW As System.Windows.Forms.Label
    Public txtENBanW As System.Windows.Forms.TextBox
    Public lblENBanH As System.Windows.Forms.Label
    Public txtENBanH As System.Windows.Forms.TextBox
    Public lblENBanD As System.Windows.Forms.Label
    Public txtENBanD As System.Windows.Forms.TextBox
    Public lblBanW0 As System.Windows.Forms.Label
    Public txtBanW0 As System.Windows.Forms.TextBox
    Public lblBanH0 As System.Windows.Forms.Label
    Public txtBanH0 As System.Windows.Forms.TextBox
    Public lblBanD0 As System.Windows.Forms.Label
    Public txtBanD0 As System.Windows.Forms.TextBox

    Public lblHokyoWOvr As System.Windows.Forms.Label
    Public txtHokyoWOvr As System.Windows.Forms.TextBox
    Public lblHokyoUOvr As System.Windows.Forms.Label
    Public txtHokyoUOvr As System.Windows.Forms.TextBox
    Public lblHokyoTOvr As System.Windows.Forms.Label
    Public txtHokyoTOvr As System.Windows.Forms.TextBox

    Public lblHikiWOvr As System.Windows.Forms.Label
    Public txtHikiWOvr As System.Windows.Forms.TextBox
    Public lblHikiUOvr As System.Windows.Forms.Label
    Public txtHikiUOvr As System.Windows.Forms.TextBox
    Public lblHikiTOvr As System.Windows.Forms.Label
    Public txtHikiTOvr As System.Windows.Forms.TextBox

    Public lblEDoorPtn As System.Windows.Forms.Label
    Public txtEDoorPtn As System.Windows.Forms.TextBox

    Public lblEZentai As System.Windows.Forms.Label
    Public txtEZentai As System.Windows.Forms.TextBox

    Public lblEHokyoA As System.Windows.Forms.Label
    Public txtEHokyoA As System.Windows.Forms.TextBox
    Public lblEHokyoB As System.Windows.Forms.Label
    Public txtEHokyoB As System.Windows.Forms.TextBox
    Public lblEHokyoY As System.Windows.Forms.Label
    Public txtEHokyoY As System.Windows.Forms.TextBox

    Public lblEHikiA As System.Windows.Forms.Label
    Public txtEHikiA As System.Windows.Forms.TextBox
    Public lblEHikiB As System.Windows.Forms.Label
    Public txtEHikiB As System.Windows.Forms.TextBox
    Public lblEHikiY As System.Windows.Forms.Label
    Public txtEHikiY As System.Windows.Forms.TextBox




End Class