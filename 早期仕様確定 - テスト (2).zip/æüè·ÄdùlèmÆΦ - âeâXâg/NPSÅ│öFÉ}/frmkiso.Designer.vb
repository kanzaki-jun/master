﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmkiso
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSetubi = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblAllHako = New System.Windows.Forms.Label()
        Me.lblSegment = New System.Windows.Forms.Label()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtD = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtM = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtY = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtZbn = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtAllPage = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPage = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtSyubetu = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblGbn = New System.Windows.Forms.Label()
        Me.lblKbn = New System.Windows.Forms.Label()
        Me.btnkisoSave = New System.Windows.Forms.Button()
        Me.cmbsScale = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbNpsK = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'txtSetubi
        '
        Me.txtSetubi.Enabled = False
        Me.txtSetubi.Location = New System.Drawing.Point(85, 32)
        Me.txtSetubi.Name = "txtSetubi"
        Me.txtSetubi.Size = New System.Drawing.Size(171, 19)
        Me.txtSetubi.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(17, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(64, 18)
        Me.Label1.TabIndex = 51
        Me.Label1.Text = "設備名称："
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAllHako
        '
        Me.lblAllHako.AutoSize = True
        Me.lblAllHako.Location = New System.Drawing.Point(208, 9)
        Me.lblAllHako.Name = "lblAllHako"
        Me.lblAllHako.Size = New System.Drawing.Size(91, 12)
        Me.lblAllHako.TabIndex = 50
        Me.lblAllHako.Text = "全**箱　****mm"
        '
        'lblSegment
        '
        Me.lblSegment.AutoSize = True
        Me.lblSegment.Location = New System.Drawing.Point(125, 9)
        Me.lblSegment.Name = "lblSegment"
        Me.lblSegment.Size = New System.Drawing.Size(61, 12)
        Me.lblSegment.TabIndex = 49
        Me.lblSegment.Text = "**セグメント"
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(361, 113)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(73, 29)
        Me.cmdCancel.TabIndex = 40
        Me.cmdCancel.Text = "キャンセル"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(114, 113)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(73, 29)
        Me.cmdOK.TabIndex = 38
        Me.cmdOK.Text = "作成開始"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(406, 60)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(17, 12)
        Me.Label13.TabIndex = 48
        Me.Label13.Text = "1/"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(353, 58)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(47, 16)
        Me.Label12.TabIndex = 47
        Me.Label12.Text = "縮尺："
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(525, 35)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(17, 12)
        Me.Label11.TabIndex = 46
        Me.Label11.Text = "日"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtD
        '
        Me.txtD.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtD.Location = New System.Drawing.Point(497, 30)
        Me.txtD.Name = "txtD"
        Me.txtD.Size = New System.Drawing.Size(20, 19)
        Me.txtD.TabIndex = 35
        Me.txtD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(474, 35)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(17, 12)
        Me.Label10.TabIndex = 45
        Me.Label10.Text = "月"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtM
        '
        Me.txtM.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtM.Location = New System.Drawing.Point(448, 30)
        Me.txtM.Name = "txtM"
        Me.txtM.Size = New System.Drawing.Size(20, 19)
        Me.txtM.TabIndex = 34
        Me.txtM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(432, 35)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(17, 12)
        Me.Label9.TabIndex = 44
        Me.Label9.Text = "年"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtY
        '
        Me.txtY.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtY.Location = New System.Drawing.Point(406, 30)
        Me.txtY.Name = "txtY"
        Me.txtY.Size = New System.Drawing.Size(20, 19)
        Me.txtY.TabIndex = 32
        Me.txtY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(353, 33)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(47, 16)
        Me.Label8.TabIndex = 43
        Me.Label8.Text = "日付："
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtZbn
        '
        Me.txtZbn.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtZbn.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtZbn.Location = New System.Drawing.Point(85, 83)
        Me.txtZbn.Name = "txtZbn"
        Me.txtZbn.Size = New System.Drawing.Size(171, 19)
        Me.txtZbn.TabIndex = 30
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(32, 83)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(47, 16)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "図番："
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(344, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(11, 12)
        Me.Label6.TabIndex = 41
        Me.Label6.Text = "）"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtAllPage
        '
        Me.txtAllPage.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtAllPage.Location = New System.Drawing.Point(318, 56)
        Me.txtAllPage.Name = "txtAllPage"
        Me.txtAllPage.Size = New System.Drawing.Size(20, 19)
        Me.txtAllPage.TabIndex = 29
        Me.txtAllPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(303, 59)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(11, 12)
        Me.Label5.TabIndex = 39
        Me.Label5.Text = "/"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPage
        '
        Me.txtPage.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtPage.Location = New System.Drawing.Point(277, 56)
        Me.txtPage.Name = "txtPage"
        Me.txtPage.Size = New System.Drawing.Size(20, 19)
        Me.txtPage.TabIndex = 28
        Me.txtPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(260, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(11, 12)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "（"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtSyubetu
        '
        Me.txtSyubetu.Enabled = False
        Me.txtSyubetu.Location = New System.Drawing.Point(85, 57)
        Me.txtSyubetu.Name = "txtSyubetu"
        Me.txtSyubetu.Size = New System.Drawing.Size(171, 19)
        Me.txtSyubetu.TabIndex = 25
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(17, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(64, 18)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "製品種別："
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGbn
        '
        Me.lblGbn.AutoSize = True
        Me.lblGbn.Location = New System.Drawing.Point(94, 9)
        Me.lblGbn.Name = "lblGbn"
        Me.lblGbn.Size = New System.Drawing.Size(19, 12)
        Me.lblGbn.TabIndex = 31
        Me.lblGbn.Text = "B9"
        '
        'lblKbn
        '
        Me.lblKbn.AutoSize = True
        Me.lblKbn.Location = New System.Drawing.Point(15, 9)
        Me.lblKbn.Name = "lblKbn"
        Me.lblKbn.Size = New System.Drawing.Size(66, 12)
        Me.lblKbn.TabIndex = 27
        Me.lblKbn.Text = "99X99-9999"
        '
        'btnkisoSave
        '
        Me.btnkisoSave.Location = New System.Drawing.Point(237, 113)
        Me.btnkisoSave.Name = "btnkisoSave"
        Me.btnkisoSave.Size = New System.Drawing.Size(73, 29)
        Me.btnkisoSave.TabIndex = 61
        Me.btnkisoSave.Text = "保存"
        Me.btnkisoSave.UseVisualStyleBackColor = True
        Me.btnkisoSave.Visible = False
        '
        'cmbsScale
        '
        Me.cmbsScale.FormattingEnabled = True
        Me.cmbsScale.Items.AddRange(New Object() {"10", "15", "20", "25", "30"})
        Me.cmbsScale.Location = New System.Drawing.Point(429, 57)
        Me.cmbsScale.Name = "cmbsScale"
        Me.cmbsScale.Size = New System.Drawing.Size(39, 20)
        Me.cmbsScale.TabIndex = 62
        Me.cmbsScale.Text = "20"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(353, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(47, 16)
        Me.Label2.TabIndex = 63
        Me.Label2.Text = "図面："
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmbNpsK
        '
        Me.cmbNpsK.FormattingEnabled = True
        Me.cmbNpsK.Items.AddRange(New Object() {"通常", "NPS承認図"})
        Me.cmbNpsK.Location = New System.Drawing.Point(406, 83)
        Me.cmbNpsK.Name = "cmbNpsK"
        Me.cmbNpsK.Size = New System.Drawing.Size(85, 20)
        Me.cmbNpsK.TabIndex = 64
        Me.cmbNpsK.Text = "通常"
        '
        'frmkiso
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(550, 147)
        Me.Controls.Add(Me.cmbNpsK)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbsScale)
        Me.Controls.Add(Me.btnkisoSave)
        Me.Controls.Add(Me.txtSetubi)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblAllHako)
        Me.Controls.Add(Me.lblSegment)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtD)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtM)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtY)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtZbn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtAllPage)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtPage)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtSyubetu)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblGbn)
        Me.Controls.Add(Me.lblKbn)
        Me.Name = "frmkiso"
        Me.Text = "基礎図作成"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtSetubi As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblAllHako As System.Windows.Forms.Label
    Friend WithEvents lblSegment As System.Windows.Forms.Label
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtD As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtM As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtY As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtZbn As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtAllPage As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPage As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtSyubetu As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblGbn As System.Windows.Forms.Label
    Friend WithEvents lblKbn As System.Windows.Forms.Label
    Friend WithEvents btnkisoSave As System.Windows.Forms.Button
    Friend WithEvents cmbsScale As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbNpsK As System.Windows.Forms.ComboBox
End Class
