﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHokyoIta
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Pic1 = New System.Windows.Forms.PictureBox()
        Me.Pic4 = New System.Windows.Forms.PictureBox()
        Me.Pic3 = New System.Windows.Forms.PictureBox()
        Me.Pic2 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbHakoNo = New System.Windows.Forms.ComboBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.rbtnHokyo1 = New System.Windows.Forms.RadioButton()
        Me.rbtnHokyo2 = New System.Windows.Forms.RadioButton()
        Me.rbtnHokyo3 = New System.Windows.Forms.RadioButton()
        Me.rbtnHokyo4 = New System.Windows.Forms.RadioButton()
        Me.Pic5 = New System.Windows.Forms.PictureBox()
        Me.Pic8 = New System.Windows.Forms.PictureBox()
        Me.Pic7 = New System.Windows.Forms.PictureBox()
        Me.Pic6 = New System.Windows.Forms.PictureBox()
        Me.rbtnHokyo5 = New System.Windows.Forms.RadioButton()
        Me.rbtnHokyo6 = New System.Windows.Forms.RadioButton()
        Me.rbtnHokyo7 = New System.Windows.Forms.RadioButton()
        Me.rbtnHokyo8 = New System.Windows.Forms.RadioButton()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnAllDelete = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbKatati = New System.Windows.Forms.ComboBox()
        Me.pcbPic = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.gridHokyowaku = New System.Windows.Forms.DataGridView()
        Me.txtHokyoD = New System.Windows.Forms.TextBox()
        CType(Me.Pic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbPic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gridHokyowaku, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(468, 48)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "補強枠の設定をします。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "設定したい箱番号を選択後、使用する補強枠のパターンを選択してください。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "違うパターンを保存してしまった場合は、その箱の番号を選択し、「" & _
            "設定削除」ボタンを押して下さい。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "全箱の補強枠の設定を削除する場合は「一括削除」ボタンを押して下さい。"
        '
        'Pic1
        '
        Me.Pic1.Location = New System.Drawing.Point(26, 507)
        Me.Pic1.Name = "Pic1"
        Me.Pic1.Size = New System.Drawing.Size(132, 117)
        Me.Pic1.TabIndex = 1
        Me.Pic1.TabStop = False
        '
        'Pic4
        '
        Me.Pic4.Location = New System.Drawing.Point(484, 507)
        Me.Pic4.Name = "Pic4"
        Me.Pic4.Size = New System.Drawing.Size(132, 117)
        Me.Pic4.TabIndex = 2
        Me.Pic4.TabStop = False
        '
        'Pic3
        '
        Me.Pic3.Location = New System.Drawing.Point(332, 507)
        Me.Pic3.Name = "Pic3"
        Me.Pic3.Size = New System.Drawing.Size(132, 117)
        Me.Pic3.TabIndex = 3
        Me.Pic3.TabStop = False
        '
        'Pic2
        '
        Me.Pic2.Location = New System.Drawing.Point(179, 507)
        Me.Pic2.Name = "Pic2"
        Me.Pic2.Size = New System.Drawing.Size(132, 117)
        Me.Pic2.TabIndex = 4
        Me.Pic2.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(65, 90)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(94, 12)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "設定する箱の番号"
        '
        'cmbHakoNo
        '
        Me.cmbHakoNo.FormattingEnabled = True
        Me.cmbHakoNo.Location = New System.Drawing.Point(203, 87)
        Me.cmbHakoNo.Name = "cmbHakoNo"
        Me.cmbHakoNo.Size = New System.Drawing.Size(67, 20)
        Me.cmbHakoNo.TabIndex = 10
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(106, 787)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 11
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(461, 787)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 13
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'rbtnHokyo1
        '
        Me.rbtnHokyo1.AutoSize = True
        Me.rbtnHokyo1.Location = New System.Drawing.Point(16, 484)
        Me.rbtnHokyo1.Name = "rbtnHokyo1"
        Me.rbtnHokyo1.Size = New System.Drawing.Size(132, 16)
        Me.rbtnHokyo1.TabIndex = 14
        Me.rbtnHokyo1.TabStop = True
        Me.rbtnHokyo1.Text = "1.Π字型(背面から1m)"
        Me.rbtnHokyo1.UseVisualStyleBackColor = True
        '
        'rbtnHokyo2
        '
        Me.rbtnHokyo2.AutoSize = True
        Me.rbtnHokyo2.Location = New System.Drawing.Point(165, 484)
        Me.rbtnHokyo2.Name = "rbtnHokyo2"
        Me.rbtnHokyo2.Size = New System.Drawing.Size(140, 16)
        Me.rbtnHokyo2.TabIndex = 15
        Me.rbtnHokyo2.TabStop = True
        Me.rbtnHokyo2.Text = "2.Π字型(背面から0.5m)"
        Me.rbtnHokyo2.UseVisualStyleBackColor = True
        '
        'rbtnHokyo3
        '
        Me.rbtnHokyo3.AutoSize = True
        Me.rbtnHokyo3.Location = New System.Drawing.Point(323, 484)
        Me.rbtnHokyo3.Name = "rbtnHokyo3"
        Me.rbtnHokyo3.Size = New System.Drawing.Size(132, 16)
        Me.rbtnHokyo3.TabIndex = 16
        Me.rbtnHokyo3.TabStop = True
        Me.rbtnHokyo3.Text = "3.Π字型(正面から1m)"
        Me.rbtnHokyo3.UseVisualStyleBackColor = True
        '
        'rbtnHokyo4
        '
        Me.rbtnHokyo4.AutoSize = True
        Me.rbtnHokyo4.Location = New System.Drawing.Point(472, 484)
        Me.rbtnHokyo4.Name = "rbtnHokyo4"
        Me.rbtnHokyo4.Size = New System.Drawing.Size(140, 16)
        Me.rbtnHokyo4.TabIndex = 17
        Me.rbtnHokyo4.TabStop = True
        Me.rbtnHokyo4.Text = "4.Π字型(正面から0.5m)"
        Me.rbtnHokyo4.UseVisualStyleBackColor = True
        '
        'Pic5
        '
        Me.Pic5.Location = New System.Drawing.Point(26, 661)
        Me.Pic5.Name = "Pic5"
        Me.Pic5.Size = New System.Drawing.Size(132, 117)
        Me.Pic5.TabIndex = 18
        Me.Pic5.TabStop = False
        '
        'Pic8
        '
        Me.Pic8.Location = New System.Drawing.Point(484, 661)
        Me.Pic8.Name = "Pic8"
        Me.Pic8.Size = New System.Drawing.Size(132, 117)
        Me.Pic8.TabIndex = 19
        Me.Pic8.TabStop = False
        '
        'Pic7
        '
        Me.Pic7.Location = New System.Drawing.Point(332, 661)
        Me.Pic7.Name = "Pic7"
        Me.Pic7.Size = New System.Drawing.Size(132, 117)
        Me.Pic7.TabIndex = 20
        Me.Pic7.TabStop = False
        '
        'Pic6
        '
        Me.Pic6.Location = New System.Drawing.Point(179, 661)
        Me.Pic6.Name = "Pic6"
        Me.Pic6.Size = New System.Drawing.Size(132, 117)
        Me.Pic6.TabIndex = 21
        Me.Pic6.TabStop = False
        '
        'rbtnHokyo5
        '
        Me.rbtnHokyo5.AutoSize = True
        Me.rbtnHokyo5.Location = New System.Drawing.Point(16, 639)
        Me.rbtnHokyo5.Name = "rbtnHokyo5"
        Me.rbtnHokyo5.Size = New System.Drawing.Size(127, 16)
        Me.rbtnHokyo5.TabIndex = 26
        Me.rbtnHokyo5.TabStop = True
        Me.rbtnHokyo5.Text = "5.T字型(背面から1m)"
        Me.rbtnHokyo5.UseVisualStyleBackColor = True
        '
        'rbtnHokyo6
        '
        Me.rbtnHokyo6.AutoSize = True
        Me.rbtnHokyo6.Location = New System.Drawing.Point(165, 639)
        Me.rbtnHokyo6.Name = "rbtnHokyo6"
        Me.rbtnHokyo6.Size = New System.Drawing.Size(135, 16)
        Me.rbtnHokyo6.TabIndex = 27
        Me.rbtnHokyo6.TabStop = True
        Me.rbtnHokyo6.Text = "6.T字型(背面から0.5m)"
        Me.rbtnHokyo6.UseVisualStyleBackColor = True
        '
        'rbtnHokyo7
        '
        Me.rbtnHokyo7.AutoSize = True
        Me.rbtnHokyo7.Location = New System.Drawing.Point(323, 639)
        Me.rbtnHokyo7.Name = "rbtnHokyo7"
        Me.rbtnHokyo7.Size = New System.Drawing.Size(127, 16)
        Me.rbtnHokyo7.TabIndex = 28
        Me.rbtnHokyo7.TabStop = True
        Me.rbtnHokyo7.Text = "7.T字型(正面から1m)"
        Me.rbtnHokyo7.UseVisualStyleBackColor = True
        '
        'rbtnHokyo8
        '
        Me.rbtnHokyo8.AutoSize = True
        Me.rbtnHokyo8.Location = New System.Drawing.Point(472, 639)
        Me.rbtnHokyo8.Name = "rbtnHokyo8"
        Me.rbtnHokyo8.Size = New System.Drawing.Size(135, 16)
        Me.rbtnHokyo8.TabIndex = 29
        Me.rbtnHokyo8.TabStop = True
        Me.rbtnHokyo8.Text = "8.T字型(正面から0.5m)"
        Me.rbtnHokyo8.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(225, 787)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnDelete.TabIndex = 30
        Me.btnDelete.Text = "設定削除"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnAllDelete
        '
        Me.btnAllDelete.Location = New System.Drawing.Point(343, 787)
        Me.btnAllDelete.Name = "btnAllDelete"
        Me.btnAllDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnAllDelete.TabIndex = 31
        Me.btnAllDelete.Text = "一括削除"
        Me.btnAllDelete.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(66, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 12)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "補強枠の形"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(65, 142)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 12)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "補強枠の奥行方向の長さ"
        '
        'cmbKatati
        '
        Me.cmbKatati.FormattingEnabled = True
        Me.cmbKatati.Location = New System.Drawing.Point(203, 113)
        Me.cmbKatati.Name = "cmbKatati"
        Me.cmbKatati.Size = New System.Drawing.Size(67, 20)
        Me.cmbKatati.TabIndex = 34
        '
        'pcbPic
        '
        Me.pcbPic.Location = New System.Drawing.Point(350, 74)
        Me.pcbPic.Name = "pcbPic"
        Me.pcbPic.Size = New System.Drawing.Size(132, 117)
        Me.pcbPic.TabIndex = 36
        Me.pcbPic.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(385, 201)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 12)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "補強枠の形"
        '
        'gridHokyowaku
        '
        Me.gridHokyowaku.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridHokyowaku.Location = New System.Drawing.Point(12, 227)
        Me.gridHokyowaku.Name = "gridHokyowaku"
        Me.gridHokyowaku.RowTemplate.Height = 21
        Me.gridHokyowaku.Size = New System.Drawing.Size(664, 251)
        Me.gridHokyowaku.TabIndex = 38
        '
        'txtHokyoD
        '
        Me.txtHokyoD.Location = New System.Drawing.Point(203, 139)
        Me.txtHokyoD.Name = "txtHokyoD"
        Me.txtHokyoD.Size = New System.Drawing.Size(65, 19)
        Me.txtHokyoD.TabIndex = 39
        '
        'frmHokyoIta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(688, 810)
        Me.Controls.Add(Me.txtHokyoD)
        Me.Controls.Add(Me.gridHokyowaku)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.pcbPic)
        Me.Controls.Add(Me.cmbKatati)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnAllDelete)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.rbtnHokyo8)
        Me.Controls.Add(Me.rbtnHokyo7)
        Me.Controls.Add(Me.rbtnHokyo6)
        Me.Controls.Add(Me.rbtnHokyo5)
        Me.Controls.Add(Me.Pic6)
        Me.Controls.Add(Me.Pic7)
        Me.Controls.Add(Me.Pic8)
        Me.Controls.Add(Me.Pic5)
        Me.Controls.Add(Me.rbtnHokyo4)
        Me.Controls.Add(Me.rbtnHokyo3)
        Me.Controls.Add(Me.rbtnHokyo2)
        Me.Controls.Add(Me.rbtnHokyo1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.cmbHakoNo)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Pic2)
        Me.Controls.Add(Me.Pic3)
        Me.Controls.Add(Me.Pic4)
        Me.Controls.Add(Me.Pic1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmHokyoIta"
        Me.Text = "補強枠設定"
        CType(Me.Pic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbPic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gridHokyowaku, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pic1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pic4 As System.Windows.Forms.PictureBox
    Friend WithEvents Pic3 As System.Windows.Forms.PictureBox
    Friend WithEvents Pic2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmbHakoNo As System.Windows.Forms.ComboBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents rbtnHokyo1 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnHokyo2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnHokyo3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnHokyo4 As System.Windows.Forms.RadioButton
    Friend WithEvents Pic5 As System.Windows.Forms.PictureBox
    Friend WithEvents Pic8 As System.Windows.Forms.PictureBox
    Friend WithEvents Pic7 As System.Windows.Forms.PictureBox
    Friend WithEvents Pic6 As System.Windows.Forms.PictureBox
    Friend WithEvents rbtnHokyo5 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnHokyo6 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnHokyo7 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnHokyo8 As System.Windows.Forms.RadioButton
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnAllDelete As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbKatati As System.Windows.Forms.ComboBox
    Friend WithEvents pcbPic As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents gridHokyowaku As System.Windows.Forms.DataGridView
    Friend WithEvents txtHokyoD As System.Windows.Forms.TextBox
End Class
