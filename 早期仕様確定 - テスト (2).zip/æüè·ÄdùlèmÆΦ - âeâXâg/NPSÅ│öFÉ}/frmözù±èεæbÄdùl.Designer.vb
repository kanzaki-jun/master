﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm配列基礎仕様
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm配列基礎仕様))
        Me.chkNoWrtH = New System.Windows.Forms.CheckBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.cmbYoshiki = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtSyubetu = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtMeisyo = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnRyuyo = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmbSeikanTyp = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btnCopy = New System.Windows.Forms.Button()
        Me.cmbSeigyo = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtBaseH = New System.Windows.Forms.TextBox()
        Me.txtBckSunpo = New System.Windows.Forms.TextBox()
        Me.txtFntSunpo = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbKeshoTyp = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbInOut = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbDoorTyp = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnTuika = New System.Windows.Forms.Button()
        Me.btnGyakuten = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.gridHairetuKiso = New System.Windows.Forms.DataGridView()
        Me.TabHairetuKiso = New System.Windows.Forms.TabControl()
        Me.tabKiso = New System.Windows.Forms.TabPage()
        Me.cmbKumitate = New System.Windows.Forms.ComboBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtBunkatu = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.tabctrlK = New System.Windows.Forms.TabControl()
        Me.tabHokyo = New System.Windows.Forms.TabPage()
        Me.grbHokyo = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lstHokyo = New System.Windows.Forms.ListBox()
        Me.picHokyo = New System.Windows.Forms.PictureBox()
        Me.tabHikiAna = New System.Windows.Forms.TabPage()
        Me.grbSyukairo = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtKeisikiNo = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtBanNo = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btnDataAdd = New System.Windows.Forms.Button()
        Me.PicSyukairo = New System.Windows.Forms.PictureBox()
        Me.txtK1Y = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblK1 = New System.Windows.Forms.Label()
        Me.txtK1X = New System.Windows.Forms.TextBox()
        Me.lblK1A = New System.Windows.Forms.Label()
        Me.txtK1B = New System.Windows.Forms.TextBox()
        Me.lblK1B = New System.Windows.Forms.Label()
        Me.txtK1A = New System.Windows.Forms.TextBox()
        Me.lblK1X = New System.Windows.Forms.Label()
        Me.cmbK1 = New System.Windows.Forms.ComboBox()
        Me.lblK1Y = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnHozon = New System.Windows.Forms.Button()
        Me.gridSyukairo = New System.Windows.Forms.DataGridView()
        Me.TabPage1.SuspendLayout()
        CType(Me.gridHairetuKiso, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabHairetuKiso.SuspendLayout()
        Me.tabKiso.SuspendLayout()
        Me.tabctrlK.SuspendLayout()
        Me.tabHokyo.SuspendLayout()
        Me.grbHokyo.SuspendLayout()
        CType(Me.picHokyo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabHikiAna.SuspendLayout()
        Me.grbSyukairo.SuspendLayout()
        CType(Me.PicSyukairo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gridSyukairo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkNoWrtH
        '
        Me.chkNoWrtH.AutoSize = True
        Me.chkNoWrtH.Location = New System.Drawing.Point(16, 28)
        Me.chkNoWrtH.Name = "chkNoWrtH"
        Me.chkNoWrtH.Size = New System.Drawing.Size(123, 16)
        Me.chkNoWrtH.TabIndex = 1
        Me.chkNoWrtH.Text = "納入外は図示しない"
        Me.chkNoWrtH.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.cmbYoshiki)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Controls.Add(Me.txtSyubetu)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.txtMeisyo)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.btnRyuyo)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.cmbSeikanTyp)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.btnCopy)
        Me.TabPage1.Controls.Add(Me.cmbSeigyo)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.txtBaseH)
        Me.TabPage1.Controls.Add(Me.txtBckSunpo)
        Me.TabPage1.Controls.Add(Me.txtFntSunpo)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.cmbKeshoTyp)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.cmbInOut)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.cmbDoorTyp)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.btnTuika)
        Me.TabPage1.Controls.Add(Me.btnGyakuten)
        Me.TabPage1.Controls.Add(Me.cmdCancel)
        Me.TabPage1.Controls.Add(Me.cmdSave)
        Me.TabPage1.Controls.Add(Me.gridHairetuKiso)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(869, 822)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "盤情報一覧表"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(495, 96)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(375, 24)
        Me.Label26.TabIndex = 84
        Me.Label26.Text = "※ブロックSKコード行は、セルをダブルクリックすることで現れる別フォームで設定。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(仕様未確定につき、今後変更の可能性あり)"
        '
        'cmbYoshiki
        '
        Me.cmbYoshiki.FormattingEnabled = True
        Me.cmbYoshiki.Location = New System.Drawing.Point(407, 70)
        Me.cmbYoshiki.Name = "cmbYoshiki"
        Me.cmbYoshiki.Size = New System.Drawing.Size(121, 20)
        Me.cmbYoshiki.TabIndex = 83
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(348, 73)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(53, 12)
        Me.Label22.TabIndex = 82
        Me.Label22.Text = "図面様式"
        '
        'txtSyubetu
        '
        Me.txtSyubetu.Location = New System.Drawing.Point(269, 98)
        Me.txtSyubetu.Name = "txtSyubetu"
        Me.txtSyubetu.Size = New System.Drawing.Size(116, 19)
        Me.txtSyubetu.TabIndex = 81
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(210, 101)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(53, 12)
        Me.Label13.TabIndex = 80
        Me.Label13.Text = "製品種別"
        '
        'txtMeisyo
        '
        Me.txtMeisyo.Location = New System.Drawing.Point(72, 98)
        Me.txtMeisyo.Name = "txtMeisyo"
        Me.txtMeisyo.Size = New System.Drawing.Size(116, 19)
        Me.txtMeisyo.TabIndex = 79
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(13, 101)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 12)
        Me.Label12.TabIndex = 78
        Me.Label12.Text = "設備名称"
        '
        'btnRyuyo
        '
        Me.btnRyuyo.Location = New System.Drawing.Point(670, 38)
        Me.btnRyuyo.Name = "btnRyuyo"
        Me.btnRyuyo.Size = New System.Drawing.Size(81, 22)
        Me.btnRyuyo.TabIndex = 77
        Me.btnRyuyo.Text = "他工番流用"
        Me.btnRyuyo.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(542, 68)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(321, 24)
        Me.Label11.TabIndex = 76
        Me.Label11.Text = "※緑色のセルの行：配列図作成時、NPS承認図を選択した場合に" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "　　　　　　　　　　　　表示される表の項目"
        '
        'cmbSeikanTyp
        '
        Me.cmbSeikanTyp.FormattingEnabled = True
        Me.cmbSeikanTyp.Items.AddRange(New Object() {"無", "組立式", "ゲージ式"})
        Me.cmbSeikanTyp.Location = New System.Drawing.Point(462, 11)
        Me.cmbSeikanTyp.Name = "cmbSeikanTyp"
        Me.cmbSeikanTyp.Size = New System.Drawing.Size(69, 20)
        Me.cmbSeikanTyp.TabIndex = 75
        Me.cmbSeikanTyp.Text = "無"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(403, 14)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(53, 12)
        Me.Label17.TabIndex = 74
        Me.Label17.Text = "製缶方式"
        '
        'btnCopy
        '
        Me.btnCopy.Location = New System.Drawing.Point(670, 9)
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.Size = New System.Drawing.Size(81, 22)
        Me.btnCopy.TabIndex = 72
        Me.btnCopy.Text = "セルコピー"
        Me.btnCopy.UseVisualStyleBackColor = True
        '
        'cmbSeigyo
        '
        Me.cmbSeigyo.FormattingEnabled = True
        Me.cmbSeigyo.Items.AddRange(New Object() {"無"})
        Me.cmbSeigyo.Location = New System.Drawing.Point(109, 40)
        Me.cmbSeigyo.Name = "cmbSeigyo"
        Me.cmbSeigyo.Size = New System.Drawing.Size(185, 20)
        Me.cmbSeigyo.TabIndex = 71
        Me.cmbSeigyo.Text = "無"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 43)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 12)
        Me.Label7.TabIndex = 70
        Me.Label7.Text = "制御穴設定"
        '
        'txtBaseH
        '
        Me.txtBaseH.Location = New System.Drawing.Point(460, 40)
        Me.txtBaseH.Name = "txtBaseH"
        Me.txtBaseH.Size = New System.Drawing.Size(62, 19)
        Me.txtBaseH.TabIndex = 69
        Me.txtBaseH.Text = "0"
        '
        'txtBckSunpo
        '
        Me.txtBckSunpo.Location = New System.Drawing.Point(269, 70)
        Me.txtBckSunpo.Name = "txtBckSunpo"
        Me.txtBckSunpo.Size = New System.Drawing.Size(62, 19)
        Me.txtBckSunpo.TabIndex = 66
        Me.txtBckSunpo.Text = "0"
        '
        'txtFntSunpo
        '
        Me.txtFntSunpo.Location = New System.Drawing.Point(149, 70)
        Me.txtFntSunpo.Name = "txtFntSunpo"
        Me.txtFntSunpo.Size = New System.Drawing.Size(62, 19)
        Me.txtFntSunpo.TabIndex = 65
        Me.txtFntSunpo.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(348, 43)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(106, 12)
        Me.Label6.TabIndex = 68
        Me.Label6.Text = "基礎ベース突出寸法"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(226, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 12)
        Me.Label5.TabIndex = 67
        Me.Label5.Text = "－(背)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(133, 12)
        Me.Label4.TabIndex = 64
        Me.Label4.Text = "機器引出所要寸法－(前)"
        '
        'cmbKeshoTyp
        '
        Me.cmbKeshoTyp.FormattingEnabled = True
        Me.cmbKeshoTyp.Items.AddRange(New Object() {"無", "2.3T", "3.2T", "50W", "25W"})
        Me.cmbKeshoTyp.Location = New System.Drawing.Point(328, 11)
        Me.cmbKeshoTyp.Name = "cmbKeshoTyp"
        Me.cmbKeshoTyp.Size = New System.Drawing.Size(69, 20)
        Me.cmbKeshoTyp.TabIndex = 63
        Me.cmbKeshoTyp.Text = "無"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(257, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 12)
        Me.Label3.TabIndex = 62
        Me.Label3.Text = "側面化粧板"
        '
        'cmbInOut
        '
        Me.cmbInOut.DisplayMember = "屋内"
        Me.cmbInOut.FormattingEnabled = True
        Me.cmbInOut.Items.AddRange(New Object() {"屋内", "屋外"})
        Me.cmbInOut.Location = New System.Drawing.Point(60, 11)
        Me.cmbInOut.Name = "cmbInOut"
        Me.cmbInOut.Size = New System.Drawing.Size(69, 20)
        Me.cmbInOut.TabIndex = 61
        Me.cmbInOut.Text = "屋内"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 12)
        Me.Label2.TabIndex = 60
        Me.Label2.Text = "屋内外"
        '
        'cmbDoorTyp
        '
        Me.cmbDoorTyp.FormattingEnabled = True
        Me.cmbDoorTyp.Items.AddRange(New Object() {"無", "PKA", "PKB", "PKC", "PJA", "PJB", "PJC", "A", "B", "C"})
        Me.cmbDoorTyp.Location = New System.Drawing.Point(182, 11)
        Me.cmbDoorTyp.Name = "cmbDoorTyp"
        Me.cmbDoorTyp.Size = New System.Drawing.Size(69, 20)
        Me.cmbDoorTyp.TabIndex = 59
        Me.cmbDoorTyp.Text = "無"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(135, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 58
        Me.Label1.Text = "扉形番"
        '
        'btnTuika
        '
        Me.btnTuika.Location = New System.Drawing.Point(565, 9)
        Me.btnTuika.Name = "btnTuika"
        Me.btnTuika.Size = New System.Drawing.Size(81, 22)
        Me.btnTuika.TabIndex = 44
        Me.btnTuika.Text = "盤追加"
        Me.btnTuika.UseVisualStyleBackColor = True
        '
        'btnGyakuten
        '
        Me.btnGyakuten.Location = New System.Drawing.Point(565, 37)
        Me.btnGyakuten.Name = "btnGyakuten"
        Me.btnGyakuten.Size = New System.Drawing.Size(81, 22)
        Me.btnGyakuten.TabIndex = 43
        Me.btnGyakuten.Text = "配列逆転"
        Me.btnGyakuten.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(773, 37)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(81, 22)
        Me.cmdCancel.TabIndex = 40
        Me.cmdCancel.Text = "キャンセル"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(773, 9)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(81, 22)
        Me.cmdSave.TabIndex = 39
        Me.cmdSave.Text = "保存"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'gridHairetuKiso
        '
        Me.gridHairetuKiso.AllowDrop = True
        Me.gridHairetuKiso.AllowUserToOrderColumns = True
        Me.gridHairetuKiso.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gridHairetuKiso.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridHairetuKiso.EnableHeadersVisualStyles = False
        Me.gridHairetuKiso.Location = New System.Drawing.Point(6, 123)
        Me.gridHairetuKiso.Name = "gridHairetuKiso"
        Me.gridHairetuKiso.RowTemplate.Height = 21
        Me.gridHairetuKiso.Size = New System.Drawing.Size(857, 691)
        Me.gridHairetuKiso.TabIndex = 26
        '
        'TabHairetuKiso
        '
        Me.TabHairetuKiso.Controls.Add(Me.TabPage1)
        Me.TabHairetuKiso.Controls.Add(Me.tabKiso)
        Me.TabHairetuKiso.Location = New System.Drawing.Point(12, 12)
        Me.TabHairetuKiso.Name = "TabHairetuKiso"
        Me.TabHairetuKiso.SelectedIndex = 0
        Me.TabHairetuKiso.Size = New System.Drawing.Size(877, 848)
        Me.TabHairetuKiso.TabIndex = 26
        '
        'tabKiso
        '
        Me.tabKiso.Controls.Add(Me.cmbKumitate)
        Me.tabKiso.Controls.Add(Me.Label25)
        Me.tabKiso.Controls.Add(Me.Label14)
        Me.tabKiso.Controls.Add(Me.Label23)
        Me.tabKiso.Controls.Add(Me.txtBunkatu)
        Me.tabKiso.Controls.Add(Me.Label24)
        Me.tabKiso.Controls.Add(Me.Label21)
        Me.tabKiso.Controls.Add(Me.tabctrlK)
        Me.tabKiso.Controls.Add(Me.btnCancel)
        Me.tabKiso.Controls.Add(Me.btnHozon)
        Me.tabKiso.Controls.Add(Me.gridSyukairo)
        Me.tabKiso.Location = New System.Drawing.Point(4, 22)
        Me.tabKiso.Name = "tabKiso"
        Me.tabKiso.Padding = New System.Windows.Forms.Padding(3)
        Me.tabKiso.Size = New System.Drawing.Size(869, 822)
        Me.tabKiso.TabIndex = 2
        Me.tabKiso.Text = "基礎図設定"
        Me.tabKiso.UseVisualStyleBackColor = True
        '
        'cmbKumitate
        '
        Me.cmbKumitate.FormattingEnabled = True
        Me.cmbKumitate.Items.AddRange(New Object() {"組立式", "溶接式", "組立出荷"})
        Me.cmbKumitate.Location = New System.Drawing.Point(404, 13)
        Me.cmbKumitate.Name = "cmbKumitate"
        Me.cmbKumitate.Size = New System.Drawing.Size(171, 20)
        Me.cmbKumitate.TabIndex = 103
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(334, 13)
        Me.Label25.Name = "Label25"
        Me.Label25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label25.Size = New System.Drawing.Size(64, 18)
        Me.Label25.TabIndex = 102
        Me.Label25.Text = "組立方法："
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(87, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 12)
        Me.Label14.TabIndex = 101
        Me.Label14.Text = "箱幅合計"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(264, 16)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(47, 12)
        Me.Label23.TabIndex = 100
        Me.Label23.Text = "mm以下"
        '
        'txtBunkatu
        '
        Me.txtBunkatu.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtBunkatu.Location = New System.Drawing.Point(146, 13)
        Me.txtBunkatu.Name = "txtBunkatu"
        Me.txtBunkatu.Size = New System.Drawing.Size(112, 19)
        Me.txtBunkatu.TabIndex = 99
        Me.txtBunkatu.Text = "4000"
        Me.txtBunkatu.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(3, 13)
        Me.Label24.Name = "Label24"
        Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label24.Size = New System.Drawing.Size(87, 18)
        Me.Label24.TabIndex = 98
        Me.Label24.Text = "最長分割位置："
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(266, 747)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(296, 12)
        Me.Label21.TabIndex = 92
        Me.Label21.Text = "※作図場所、大きさによっては寸法線や寸法値が重なります。"
        '
        'tabctrlK
        '
        Me.tabctrlK.Controls.Add(Me.tabHokyo)
        Me.tabctrlK.Controls.Add(Me.tabHikiAna)
        Me.tabctrlK.Location = New System.Drawing.Point(8, 400)
        Me.tabctrlK.Name = "tabctrlK"
        Me.tabctrlK.SelectedIndex = 0
        Me.tabctrlK.Size = New System.Drawing.Size(734, 340)
        Me.tabctrlK.TabIndex = 97
        '
        'tabHokyo
        '
        Me.tabHokyo.Controls.Add(Me.grbHokyo)
        Me.tabHokyo.Location = New System.Drawing.Point(4, 22)
        Me.tabHokyo.Name = "tabHokyo"
        Me.tabHokyo.Padding = New System.Windows.Forms.Padding(3)
        Me.tabHokyo.Size = New System.Drawing.Size(726, 314)
        Me.tabHokyo.TabIndex = 0
        Me.tabHokyo.Text = "補強枠設定"
        Me.tabHokyo.UseVisualStyleBackColor = True
        '
        'grbHokyo
        '
        Me.grbHokyo.Controls.Add(Me.Label9)
        Me.grbHokyo.Controls.Add(Me.Label16)
        Me.grbHokyo.Controls.Add(Me.Label8)
        Me.grbHokyo.Controls.Add(Me.lstHokyo)
        Me.grbHokyo.Controls.Add(Me.picHokyo)
        Me.grbHokyo.Location = New System.Drawing.Point(12, 7)
        Me.grbHokyo.Name = "grbHokyo"
        Me.grbHokyo.Size = New System.Drawing.Size(818, 301)
        Me.grbHokyo.TabIndex = 94
        Me.grbHokyo.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(126, 252)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(65, 12)
        Me.Label9.TabIndex = 91
        Me.Label9.Text = "補強枠リスト"
        Me.Label9.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 13)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(397, 84)
        Me.Label16.TabIndex = 86
        Me.Label16.Text = "○補強枠設定(盤毎)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " ※入力はすべて表でできます。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  最初に型を選択してください。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  入力した寸法値がどこに反映されるかは右に図示されます。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  ※" & _
            "分割点の左右の奥行枠は、ここで""無""に設定しても必ず作図されます。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  設定が完了したら保存ボタンを押して下さい。(引込穴設定も同時に保存されます)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(570, 276)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 12)
        Me.Label8.TabIndex = 80
        Me.Label8.Text = "補強枠サムネイル"
        '
        'lstHokyo
        '
        Me.lstHokyo.FormattingEnabled = True
        Me.lstHokyo.ItemHeight = 12
        Me.lstHokyo.Location = New System.Drawing.Point(78, 115)
        Me.lstHokyo.Name = "lstHokyo"
        Me.lstHokyo.Size = New System.Drawing.Size(174, 124)
        Me.lstHokyo.TabIndex = 90
        Me.lstHokyo.Visible = False
        '
        'picHokyo
        '
        Me.picHokyo.Location = New System.Drawing.Point(540, 15)
        Me.picHokyo.Name = "picHokyo"
        Me.picHokyo.Size = New System.Drawing.Size(150, 250)
        Me.picHokyo.TabIndex = 79
        Me.picHokyo.TabStop = False
        '
        'tabHikiAna
        '
        Me.tabHikiAna.Controls.Add(Me.grbSyukairo)
        Me.tabHikiAna.Location = New System.Drawing.Point(4, 22)
        Me.tabHikiAna.Name = "tabHikiAna"
        Me.tabHikiAna.Padding = New System.Windows.Forms.Padding(3)
        Me.tabHikiAna.Size = New System.Drawing.Size(726, 314)
        Me.tabHikiAna.TabIndex = 1
        Me.tabHikiAna.Text = "引込穴設定"
        Me.tabHikiAna.UseVisualStyleBackColor = True
        '
        'grbSyukairo
        '
        Me.grbSyukairo.Controls.Add(Me.Label10)
        Me.grbSyukairo.Controls.Add(Me.txtKeisikiNo)
        Me.grbSyukairo.Controls.Add(Me.Label20)
        Me.grbSyukairo.Controls.Add(Me.Label19)
        Me.grbSyukairo.Controls.Add(Me.txtBanNo)
        Me.grbSyukairo.Controls.Add(Me.Label15)
        Me.grbSyukairo.Controls.Add(Me.btnDataAdd)
        Me.grbSyukairo.Controls.Add(Me.PicSyukairo)
        Me.grbSyukairo.Controls.Add(Me.txtK1Y)
        Me.grbSyukairo.Controls.Add(Me.Label18)
        Me.grbSyukairo.Controls.Add(Me.lblK1)
        Me.grbSyukairo.Controls.Add(Me.txtK1X)
        Me.grbSyukairo.Controls.Add(Me.lblK1A)
        Me.grbSyukairo.Controls.Add(Me.txtK1B)
        Me.grbSyukairo.Controls.Add(Me.lblK1B)
        Me.grbSyukairo.Controls.Add(Me.txtK1A)
        Me.grbSyukairo.Controls.Add(Me.lblK1X)
        Me.grbSyukairo.Controls.Add(Me.cmbK1)
        Me.grbSyukairo.Controls.Add(Me.lblK1Y)
        Me.grbSyukairo.Location = New System.Drawing.Point(12, 9)
        Me.grbSyukairo.Name = "grbSyukairo"
        Me.grbSyukairo.Size = New System.Drawing.Size(709, 304)
        Me.grbSyukairo.TabIndex = 93
        Me.grbSyukairo.TabStop = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(291, 175)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 12)
        Me.Label10.TabIndex = 155
        Me.Label10.Text = "番目の引込穴"
        '
        'txtKeisikiNo
        '
        Me.txtKeisikiNo.Location = New System.Drawing.Point(237, 172)
        Me.txtKeisikiNo.Name = "txtKeisikiNo"
        Me.txtKeisikiNo.Size = New System.Drawing.Size(48, 19)
        Me.txtKeisikiNo.TabIndex = 156
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(579, 277)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(90, 12)
        Me.Label20.TabIndex = 154
        Me.Label20.Text = "引込穴サムネイル"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(235, 156)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(71, 12)
        Me.Label19.TabIndex = 152
        Me.Label19.Text = "現在の盤No："
        '
        'txtBanNo
        '
        Me.txtBanNo.Location = New System.Drawing.Point(312, 153)
        Me.txtBanNo.Name = "txtBanNo"
        Me.txtBanNo.Size = New System.Drawing.Size(59, 19)
        Me.txtBanNo.TabIndex = 153
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(11, 13)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(151, 12)
        Me.Label15.TabIndex = 58
        Me.Label15.Text = "○箱別主回路ケーブル穴設定"
        '
        'btnDataAdd
        '
        Me.btnDataAdd.Location = New System.Drawing.Point(445, 170)
        Me.btnDataAdd.Name = "btnDataAdd"
        Me.btnDataAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnDataAdd.TabIndex = 150
        Me.btnDataAdd.Text = "引込穴追加"
        Me.btnDataAdd.UseVisualStyleBackColor = True
        '
        'PicSyukairo
        '
        Me.PicSyukairo.Location = New System.Drawing.Point(550, 15)
        Me.PicSyukairo.Name = "PicSyukairo"
        Me.PicSyukairo.Size = New System.Drawing.Size(150, 250)
        Me.PicSyukairo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicSyukairo.TabIndex = 60
        Me.PicSyukairo.TabStop = False
        '
        'txtK1Y
        '
        Me.txtK1Y.Location = New System.Drawing.Point(58, 217)
        Me.txtK1Y.Name = "txtK1Y"
        Me.txtK1Y.Size = New System.Drawing.Size(154, 19)
        Me.txtK1Y.TabIndex = 149
        Me.txtK1Y.Text = "0"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(16, 27)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(527, 84)
        Me.Label18.TabIndex = 139
        Me.Label18.Text = resources.GetString("Label18.Text")
        '
        'lblK1
        '
        Me.lblK1.AutoSize = True
        Me.lblK1.Location = New System.Drawing.Point(18, 132)
        Me.lblK1.Name = "lblK1"
        Me.lblK1.Size = New System.Drawing.Size(35, 12)
        Me.lblK1.TabIndex = 140
        Me.lblK1.Text = "形式："
        '
        'txtK1X
        '
        Me.txtK1X.Location = New System.Drawing.Point(58, 194)
        Me.txtK1X.Name = "txtK1X"
        Me.txtK1X.Size = New System.Drawing.Size(154, 19)
        Me.txtK1X.TabIndex = 148
        Me.txtK1X.Text = "0"
        '
        'lblK1A
        '
        Me.lblK1A.AutoSize = True
        Me.lblK1A.Location = New System.Drawing.Point(9, 153)
        Me.lblK1A.Name = "lblK1A"
        Me.lblK1A.Size = New System.Drawing.Size(44, 12)
        Me.lblK1A.TabIndex = 141
        Me.lblK1A.Text = "Ａ寸法："
        '
        'txtK1B
        '
        Me.txtK1B.Location = New System.Drawing.Point(59, 172)
        Me.txtK1B.Name = "txtK1B"
        Me.txtK1B.Size = New System.Drawing.Size(154, 19)
        Me.txtK1B.TabIndex = 147
        Me.txtK1B.Text = "0"
        '
        'lblK1B
        '
        Me.lblK1B.AutoSize = True
        Me.lblK1B.Location = New System.Drawing.Point(9, 175)
        Me.lblK1B.Name = "lblK1B"
        Me.lblK1B.Size = New System.Drawing.Size(44, 12)
        Me.lblK1B.TabIndex = 142
        Me.lblK1B.Text = "Ｂ寸法："
        '
        'txtK1A
        '
        Me.txtK1A.Location = New System.Drawing.Point(59, 150)
        Me.txtK1A.Name = "txtK1A"
        Me.txtK1A.Size = New System.Drawing.Size(154, 19)
        Me.txtK1A.TabIndex = 146
        Me.txtK1A.Text = "0"
        '
        'lblK1X
        '
        Me.lblK1X.AutoSize = True
        Me.lblK1X.Location = New System.Drawing.Point(9, 197)
        Me.lblK1X.Name = "lblK1X"
        Me.lblK1X.Size = New System.Drawing.Size(43, 12)
        Me.lblK1X.TabIndex = 143
        Me.lblK1X.Text = "Ｘ寸法："
        '
        'cmbK1
        '
        Me.cmbK1.FormattingEnabled = True
        Me.cmbK1.Location = New System.Drawing.Point(58, 127)
        Me.cmbK1.Name = "cmbK1"
        Me.cmbK1.Size = New System.Drawing.Size(154, 20)
        Me.cmbK1.TabIndex = 145
        '
        'lblK1Y
        '
        Me.lblK1Y.AutoSize = True
        Me.lblK1Y.Location = New System.Drawing.Point(9, 220)
        Me.lblK1Y.Name = "lblK1Y"
        Me.lblK1Y.Size = New System.Drawing.Size(43, 12)
        Me.lblK1Y.TabIndex = 144
        Me.lblK1Y.Text = "Ｙ寸法："
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(469, 764)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 89
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnHozon
        '
        Me.btnHozon.Location = New System.Drawing.Point(288, 764)
        Me.btnHozon.Name = "btnHozon"
        Me.btnHozon.Size = New System.Drawing.Size(75, 23)
        Me.btnHozon.TabIndex = 61
        Me.btnHozon.Text = "保存"
        Me.btnHozon.UseVisualStyleBackColor = True
        '
        'gridSyukairo
        '
        Me.gridSyukairo.AllowUserToAddRows = False
        Me.gridSyukairo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridSyukairo.Location = New System.Drawing.Point(6, 43)
        Me.gridSyukairo.Name = "gridSyukairo"
        Me.gridSyukairo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.gridSyukairo.RowTemplate.Height = 21
        Me.gridSyukairo.Size = New System.Drawing.Size(857, 348)
        Me.gridSyukairo.TabIndex = 57
        '
        'frm配列基礎仕様
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(900, 888)
        Me.Controls.Add(Me.TabHairetuKiso)
        Me.Name = "frm配列基礎仕様"
        Me.Text = "配列基礎仕様"
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.gridHairetuKiso, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabHairetuKiso.ResumeLayout(False)
        Me.tabKiso.ResumeLayout(False)
        Me.tabKiso.PerformLayout()
        Me.tabctrlK.ResumeLayout(False)
        Me.tabHokyo.ResumeLayout(False)
        Me.grbHokyo.ResumeLayout(False)
        Me.grbHokyo.PerformLayout()
        CType(Me.picHokyo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabHikiAna.ResumeLayout(False)
        Me.grbSyukairo.ResumeLayout(False)
        Me.grbSyukairo.PerformLayout()
        CType(Me.PicSyukairo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gridSyukairo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkCaulk As System.Windows.Forms.CheckBox
    Friend WithEvents chkNoWrtH As System.Windows.Forms.CheckBox
    Friend WithEvents chkHNoWrt As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents btnTuika As System.Windows.Forms.Button
    Friend WithEvents btnGyakuten As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents gridHairetuKiso As System.Windows.Forms.DataGridView
    Friend WithEvents TabHairetuKiso As System.Windows.Forms.TabControl
    Friend WithEvents tabKiso As System.Windows.Forms.TabPage
    Friend WithEvents gridSyukairo As System.Windows.Forms.DataGridView
    Friend WithEvents btnHozon As System.Windows.Forms.Button
    Friend WithEvents txtBaseH As System.Windows.Forms.TextBox
    Friend WithEvents txtBckSunpo As System.Windows.Forms.TextBox
    Friend WithEvents txtFntSunpo As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbKeshoTyp As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbInOut As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbDoorTyp As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbSeigyo As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents picHokyo As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lstHokyo As System.Windows.Forms.ListBox
    Friend WithEvents btnCopy As System.Windows.Forms.Button
    Friend WithEvents grbHokyo As System.Windows.Forms.GroupBox
    Friend WithEvents cmbSeikanTyp As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents grbSyukairo As System.Windows.Forms.GroupBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtBanNo As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents btnDataAdd As System.Windows.Forms.Button
    Friend WithEvents PicSyukairo As System.Windows.Forms.PictureBox
    Friend WithEvents txtK1Y As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lblK1 As System.Windows.Forms.Label
    Friend WithEvents txtK1X As System.Windows.Forms.TextBox
    Friend WithEvents lblK1A As System.Windows.Forms.Label
    Friend WithEvents txtK1B As System.Windows.Forms.TextBox
    Friend WithEvents lblK1B As System.Windows.Forms.Label
    Friend WithEvents txtK1A As System.Windows.Forms.TextBox
    Friend WithEvents lblK1X As System.Windows.Forms.Label
    Friend WithEvents cmbK1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblK1Y As System.Windows.Forms.Label
    Friend WithEvents tabctrlK As System.Windows.Forms.TabControl
    Friend WithEvents tabHokyo As System.Windows.Forms.TabPage
    Friend WithEvents tabHikiAna As System.Windows.Forms.TabPage
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtKeisikiNo As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnRyuyo As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtSyubetu As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtMeisyo As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cmbYoshiki As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtBunkatu As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents cmbKumitate As System.Windows.Forms.ComboBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
End Class
