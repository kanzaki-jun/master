﻿Imports System.IO
Imports System.Text

Module Main



#Region "メイン"


    '前提として
    'E3出力ファイル
    'エリアとインデックスの対応表
    '端点座標のCSVファイル
    '座標名、略称、形式、端子種類、器具番号を一行とするCSVファイル
    '以下4ファイルが存在するとする。

     Sub Main(ByVal CmdArg() As String)


        Dim tempArr() As String
        For Each s In CmdArg
            tempArr = s.Split(",")
            If (tempArr Is Nothing) = False Then
                Kouban = TrimOrder(tempArr(0))
                Gunban = tempArr(1)
                Job = tempArr(2)
            End If
        Next

        Dim Line As String
        Dim Header As String
        Dim Place As Integer
        Dim Max As Integer
        Dim ArrArea As New ArrayList
        Dim inputFile As String = ""               '入力用ファイル

        'E3データ出力先の工番と群番に一致したファイルのパスを複数取得
        Dim E3Files As String() = _
          System.IO.Directory.GetFiles(E3Path, "E3_" & Kouban & Gunban & "*" & ".*")

        Max = UBound(E3Files)

        '取得したファイルの分だけ繰り返す
        For i As Integer = 0 To Max
            '複数ファイルのデータを１つのListに纏める

            '複数取得したファイルパスのうちの一つを選択
            inputFile = E3Files(i)

            'パスのファイルを開く
            Using reader As New StreamReader(inputFile, Encoding.Default)
                While (reader.Peek() > -1)
                    '最終行まで一行ずつ読み込む
                    Line = reader.ReadLine()
                    '読み込んだ一行をPublic listのReadListに保存
                    ReadList.Add(Line)
                End While
                reader.Close()
            End Using
        Next

        'インデックスとエリアの対応表作成
        'ArrayListに読み込み結果を保存
        ArrArea = CType(ReadCSV(AreaCSVPath, False), System.Collections.ArrayList)
        For i = 1 To ArrArea.Count - 1
            Dim temp() As String = CType(ArrArea(i), String())
            'temp(0)=インデックス、temp(1)=エリア
            IndexToArea.Add(temp(0), temp(1))
        Next


        'ListをFor文でまわす
        For i = 0 To ReadList.Count - 1
            '1データの読み込み
            Line = ReadList(i)
            '左から2文字はHeader行
            Header = Left(Line, 2)
            '開始位置を初期値へ
            Place = 3

            '最終行の場合、最終行フラグを立てる
            If i <> 0 And i <> ReadList.Count - 1 Then
                If Left(ReadList(i + 1), 2) = "01" Then
                    LastFlg = True
                End If
            ElseIf i = ReadList.Count - 1 Then
                LastFlg = True
            End If


            Select Case Header
                Case "01"
                    'ヘッダ行の時

                    If i <> 0 Then
                        SortedRec3_4_Data = Sort_Dic(Rec3_4_Data)
                        SortedRec6_Data = Sort_Dic(Rec6_Data)
                        CreRec3()
                        CreRec4()
                        CreRec6()
                        CreRec7()
                        CreFLP()
                        OutPutDATFiles()
                    End If

                    FirstInFlg = True

                    'キーと値の削除
                    Dic1.Clear()

                    'ヘッダ行に関するDictionaryを作成
                    CreDic(Dic1, Area1, AreaName1, Line, Place)

                    '盤No.
                    BanNo = Dic1("盤No").Trim()
                    '前背
                    FB = IndexToArea(Dic1("インデックス").Trim)

                    '群番(Space付)
                    Dim temp As String() = SepaStr(Gunban)
                    Gun = temp(0) & " " & temp(1)

                    SelectCSVPath()

                    'CSVファイルを読み込み、座標名＋分割名をArrCoordに保存
                    CreCoord(CType(ReadCSV(CoordPath, True), System.Collections.ArrayList))
                    '座標名,分割名,略称,形式,端子種類,器具番号のCSVデータを読み込み
                    'キー:座標名+分割名
                    '値  :{略称,形式,端子種類,器具番号}
                    'CSVDataDicを作成
                    ParseCSVData(CType(ReadCSV(CSVDataPath, True), System.Collections.ArrayList))



                    'レコードNo.1　作成
                    CreRec1()

                    'レコードNo.2　作成
                    CreRec2()

                    'レコードNo.5　作成
                    CreRec5()

                    '
                    CreKIK()
                Case "02"

                    '布線行の時

                    'キーと値の削除
                    Dic2.Clear()

                    '布線行に関するDictionaryを作成
                    CreDic(Dic2, Area2, AreaName2, Line, Place)

                    SQ = Dic2("線サイズ")          '線サイズ(太さ)(空白付)
                    LnKnd = Dic2("線種")           '線種=電線種(空白付)
                    Color = Dic2("色")             'カラー=線色(空白付)

                    'Dim a As String = CStr(Val(SQ.Trim))



                    'レコードNo.3　作成
                    'CreRec3(job)

                    '非特殊電線ならレコードNo.4を、特殊電線ならレコードNo.6を作成
                    Select Case SPCCheck(SQ.Trim, LnKnd.Trim)

                        Case "非特殊電線"
                            'レコードNo.4　作成
                            'CreRec4(job)

                            CreRec3_4_Data()
                        Case "特殊電線"
                            'レコードNo.6　作成
                            CreRec6_Data()
                    End Select

                    CreRec7_Data()

                    'レコードNo.9作成
                    CreRec9()
                    CreHON()
            End Select
        Next

        SortedRec3_4_Data = Sort_Dic(Rec3_4_Data)
        SortedRec6_Data = Sort_Dic(Rec6_Data)
        CreRec3()
        CreRec4()
        CreRec6()
        CreRec7()
        CreFLP()
        SetTotalHON()
        OutPutDATFiles()
        OutPutZWDFiles()
    End Sub


#End Region

    Sub SelectCSVPath()
        Dim index As String = Dic1("インデックス").Trim

        CoordPath = CoordDPath & "\自動配線後_端点座標_" & BanNo & "_" & index & ".csv"
        CSVDataPath = CSVDataDPath & "\test" & BanNo & "_" & index & ".csv"
    End Sub
End Module
