﻿Imports System.IO
Imports System.Text

Module CreZWD

#Region "Create FLP"

    Sub CreFLP()

        Dim StrB As New StringBuilder

        If RecFLP.Count = 0 Then

            CreFLPHeader(StrB)

        End If

        StrB.Append(CreSpace(FLPDic("空白1"), " "))

        FLPCnt += 1
        'シリーズNo.
        StrB.Append("(")
        StrB.Append(CreSpace(FLPDic("シリーズNo") - LenB(CStr(FLPCnt)), "0"))
        StrB.Append(CStr(FLPCnt))
        StrB.Append(")")

        StrB.Append(CreSpace(FLPDic("空白2"), " "))

        '群番

        StrB.Append("GRP---")
        StrB.Append(Gun)
        StrB.Append(CreSpace(FLPDic("GRP---") - LenB(Gun), " "))

        '盤No.
        Dim Ban As String = BanNo.Trim()
        StrB.Append("BAN---")
        StrB.Append(Ban)
        StrB.Append(CreSpace(FLPDic("BAN---") - LenB(Ban), " "))

        '前背
        StrB.Append("FB---")
        StrB.Append(FB)
        StrB.Append(CreSpace(FLPDic("FB---") - LenB(FB), " "))

        StrB.Append("SCT---")
        StrB.Append(CreSpace(FLPDic("SCT---"), " "))

        StrB.Append("ZONE---")
        StrB.Append(CreSpace(FLPDic("ZONE---"), " "))

        StrB.Append("LOCATION---")
        StrB.Append(CreSpace(FLPDic("LOCATION---"), " "))


        StrB.Append(CreSpace(FLPDic("空白3"), " "))

        RecFLP.Add(StrB.ToString)
        StrB.Clear()
    End Sub

    Sub CreFLPHeader(ByRef StrB As StringBuilder)

        StrB.Append(FLP_Header)

        '工番名
        StrB.Append("KOOBAN=")
        StrB.Append(Kouban)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("KOOBAN=") - LenB(Kouban), " "))

        '客先名
        StrB.Append("KYAKU=")
        StrB.Append(CustomerName)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("KYAKU=") - LenB(CustomerName), " "))

        '日時
        StrB.Append("DATE:")
        StrB.Append(NowDate)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("DATE:") - LenB(NowDate), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(FLPDic("従番"), " "))
        StrB.Append(")")

        'ジョブNo.
        StrB.Append("JOB=")
        StrB.Append(Job)
        '空白詰め
        StrB.Append(CreSpace(FLPDic("JOB=") - LenB(Job), " "))

        RecFLP.Add(StrB.ToString)
        StrB.Clear()

        For Each s In Border
            RecFLP.Add(s)
        Next
    End Sub

    ''' <summary>
    ''' アルファべットと数字を分けた配列を返す
    ''' </summary>
    ''' <param name="str">対象文字列</param>
    ''' <returns>
    ''' (0):アルファべット,(1):数字　　
    ''' </returns>
    ''' <remarks></remarks>
    Function SepaStr(ByVal str As String) As String()
        Dim temp As String
        Dim ret(1) As String
        For i = 1 To str.Length
            temp = Mid(str, i, 1)
            Select Case temp
                Case "a" To "z", "A" To "Z"
                    ret(0) = ret(0) & temp
                Case "0" To "9"
                    ret(1) = ret(1) & temp
            End Select
        Next

        Return ret
    End Function
#End Region

#Region "Create HON"

    Sub CreHON()

        Dim StrB As New StringBuilder

        If LastFlg = True Then
            If RecHON.Count = 0 Then

                StrB.Append(HON_Header1)

                '工番名
                StrB.Append(Kouban)
                '空白詰め
                StrB.Append(CreSpace(HONDic("KOOBAN=") - LenB(Kouban), " "))

                StrB.Append(HON_Header2)
                StrB.Append(CreSpace(HONDic("空白1"), " "))

                '日時
                StrB.Append("DATE:")
                StrB.Append(NowDate)
                '空白詰め
                StrB.Append(CreSpace(HONDic("DATE:") - LenB(NowDate), " "))

                '従番
                StrB.Append("(")
                StrB.Append(CreSpace(HONDic("従番"), " "))
                StrB.Append(")")

                'ジョブNo.
                StrB.Append("JOB=")
                StrB.Append(Job)
                '空白詰め
                StrB.Append(CreSpace(HONDic("JOB=") - LenB(Job), " "))
                RecHON.Add(StrB.ToString)
                StrB.Clear()

                'ヘッダー二行目
                StrB.Append(HON_Header3)
                RecHON.Add(StrB.ToString)
                StrB.Clear()
            End If


            StrB.Append(CreSpace(HONDic("空白2"), " "))
            StrB.Append(Gun)
            StrB.Append(CreSpace(HONDic("GROUP") - LenB(Gun), " "))

            '盤No.
            Dim Ban As String = BanNo.Trim()
            StrB.Append(Ban)
            StrB.Append(CreSpace(HONDic("BAN") - LenB(Ban), " "))

            StrB.Append(FB)
            StrB.Append(CreSpace(HONDic("ZENHAI") - LenB(FB), " "))

            '0.3-付属線まで
            Dim Key As String
            For i = 0 To CountRec9.Keys.Count - 1
                key = CountRec9.Keys(i)

                '空白詰
                StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(CountRec9(Key))), " "))
                '0.3-TOBI
                StrB.Append(CountRec9(Key))

                'Part
                PartHON(Key) = PartHON(Key) + CountRec9(Key)
                'Total
                TotalHON(Key) = TotalHON(Key) + CountRec9(Key)
            Next

            RecHON.Add(StrB.ToString)
            StrB.Clear()

            LastFlg = False
            ClearRec9()                 'CountRec9の値の初期化

        End If
    End Sub

    Sub SetPartHON()
            Dim StrB As New StringBuilder

        StrB.Append("     ---------------    ")

        Dim Key As String
        Dim AllCnt As Integer
        For i = 0 To PartHON.Keys.Count - 1
            Key = PartHON.Keys(i)

            '空白詰
            StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(PartHON(Key))), " "))
            '0.3-TOBI
            StrB.Append(PartHON(Key))

            AllCnt += PartHON(Key)
            PartHON(Key) = 0
        Next i

        RecHON.Add(StrB.ToString)
        StrB.Clear()

    End Sub

    Sub SetTotalHON()
        Dim StrB As New StringBuilder

        SetPartHON()

        StrB.Append("     ** JOB TOTAL **    ")

        Dim Key As String
        Dim AllCnt As Integer
        For i = 0 To TotalHON.Keys.Count - 1
            Key = TotalHON.Keys(i)

            '空白詰
            StrB.Append(CreSpace(HONDic(Key) - LenB(CStr(TotalHON(Key))), " "))
            '0.3-TOBI
            StrB.Append(TotalHON(Key))

            AllCnt += TotalHON(Key)
        Next i

        RecHON.Add(StrB.ToString)
        StrB.Clear()
        StrB.Append("             (")
        StrB.Append(CreSpace(6 - LenB(CStr(AllCnt)), " "))
        StrB.Append(CStr(AllCnt))
        StrB.Append(")                                                                                                               ")
        RecHON.Add(StrB.ToString)
    End Sub


#End Region

#Region "KIK"

    Sub CreKIK()
        Dim StrB As New StringBuilder
        Dim key As String

        CreKIKHeader()



        For i = 0 To CSVDataDic.Keys.Count - 1

            StrB.Append(" ")
            key = CSVDataDic.Keys(i)
            '配列{略称,形式,端子種類,器具番号}
            Dim arr() As String = CSVDataDic(key)
            '0詰め
            StrB.Append(CreSpace(KIKDic("仮座標") - LenB(CStr(i + 1)), "0"))
            '仮座標
            StrB.Append(CStr(i + 1))
            '
            StrB.Append(CreSpace(KIKDic("空白2"), " "))

            '座標名
            Dim temp = Left(key, 6).Trim
            StrB.Append(temp)
            StrB.Append(CreSpace(KIKDic("座標名") - LenB(temp), " "))

            '分割名
            Dim str = Right(key, 1)
            StrB.Append(str)
            StrB.Append(CreSpace(KIKDic("分割名") - LenB(str), " "))

            '端子種類
            StrB.Append("(")
            StrB.Append(arr(2))
            StrB.Append(CreSpace(KIKDic("端子種類") - LenB(arr(2)), " "))
            StrB.Append(")")

            StrB.Append(CreSpace(KIKDic("空白3"), " "))

            '形式
            StrB.Append(arr(1))
            StrB.Append(CreSpace(KIKDic("形式") - LenB(arr(1)), " "))

            'フレーム
            StrB.Append(CreSpace(KIKDic("フレーム"), " "))

            '略称
            StrB.Append(arr(0))
            StrB.Append(CreSpace(KIKDic("略称") - LenB(arr(0)), " "))

            StrB.Append(CreSpace(KIKDic("No"), " "))

            If Left(temp, 2) = "YY" Then
                StrB.Append(NextBanDic(BanNo))
                StrB.Append(CreSpace(KIKDic("CHUKEI") - LenB(NextBanDic(BanNo)), " "))
            Else
                StrB.Append(CreSpace(KIKDic("CHUKEI"), " "))
            End If

            'KIGU_No
            StrB.Append(CreSpace(KIKDic("KIGU_No"), " "))

            'デバイス名
            StrB.Append(arr(3))
            StrB.Append(CreSpace(KIKDic("デバイス名") - LenB(arr(3)), " "))

            'SOU
            StrB.Append(CreSpace(KIKDic("SOU"), " "))

            '(T)
            StrB.Append(CreSpace(KIKDic("(T)"), " "))

            RecKIK.Add(StrB.ToString)
            StrB.Clear()
        Next i

    End Sub

#Region "Header"
    Sub CreKIKHeader()
        Dim StrB As New StringBuilder
        Dim jobs As String = "JOB=" & CreSpace(KIKHeaderDic("JOB=") - LenB(CStr(Job)), " ") & Job

        StrB.Append(KIKHeader1)

        '日時
        StrB.Append("DATE:")
        StrB.Append(NowDate)
        '空白詰め
        StrB.Append(CreSpace(KIKHeaderDic("DATE:") - LenB(NowDate), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(KIKHeaderDic("従番"), " "))
        StrB.Append(")")

        'ジョブNo.
        StrB.Append(jobs)

        RecKIK.Add(StrB.ToString)
        StrB.Clear()

        StrB.Append(" ")
        StrB.Append(jobs)
        StrB.Append(CreSpace(KIKHeaderDic("空白2"), " "))

        '工番
        StrB.Append("KOOBAN=")
        StrB.Append(Kouban)
        StrB.Append(CreSpace(KIKHeaderDic("KOOBAN=") - LenB(Kouban), " "))

        '群番

        StrB.Append("GRP=")
        StrB.Append(Gun)
        StrB.Append(CreSpace(KIKHeaderDic("GRP=") - LenB(Gun), " "))

        '盤No.

        StrB.Append("BAN=")
        StrB.Append(BanNo)
        StrB.Append(CreSpace(KIKHeaderDic("BAN=") - LenB(BanNo), " "))

        '前背
        StrB.Append("FB=")
        StrB.Append(FB)
        StrB.Append(CreSpace(KIKHeaderDic("FB=") - LenB(FB), " "))

        StrB.Append("SCT=")
        StrB.Append(CreSpace(KIKHeaderDic("SCT="), " "))

        StrB.Append("ZONE=")
        StrB.Append(CreSpace(KIKHeaderDic("ZONE="), " "))

        StrB.Append(CreSpace(KIKHeaderDic("空白3"), " "))

        RecKIK.Add(StrB.ToString)
        StrB.Clear()

        RecKIK.Add(CreSpace(KIKRecLen, " "))
        RecKIK.Add(KIKHeader2)
    End Sub

#End Region


#End Region


Public Root As New Dictionary(Of String, Dictionary(Of String, String()))

Public Sub CreRoot()

    Dim key As String = Dic2("FT機器座標").Trim
    Dim value As String = Dic2("TT機器座標").Trim

    'Toの仮座標
    Dim tem As String = SearchTemp(value, CSVDataDic)
    Dim temp As String = CreSpace(3 - LenB(tem), "0") & tem

    If Root.ContainsKey(key) = False Then
        Dim dic As New Dictionary(Of String, String()) _
         From {
                {temp, {value, "1"}}
              }
        Root.Add(key, dic)
    Else
        Dim tempdic As Dictionary(Of String, String()) = Root(key)

        If tempdic.ContainsKey(temp) = True Then

            '(0)=座標名、(1)=カウント、(2)=
            Dim arr As String() = tempdic(temp)
            arr(1) += 1

            tempdic(temp) = arr
        Else
            tempdic.Add(temp, {value, "1"})
        End If

        Sort_Dic_A(tempdic)
    End If

End Sub

    Public Const HeaderA As String = "*** TENKAIZU SETTKEI HONSU ***                                                  "
    Public Const HeaderB As String = "*** TENKAI HONSU HYO     ***(RETUBAKO CHUKEI)                                   "

    Public TEHeaderDic As New Dictionary(Of String, Integer) From
    {
        {"DATE:", 18},
        {"PAGE=", 3},
        {"空白1", 3},
        {"従番", 9},
        {"JOB=", 3},
        {"空白2", 3},
        {"空白3", 2},
        {"KOOBAN---", 13},
        {"GRP---", 9},
        {"BAN---", 9},
        {"FB---", 4},
        {"SCT---", 4},
        {"ZONE---", 4},
        {"空白4", 38}
    }

    Public Function CreHeaderAorB(ByVal AorBH As String, ByVal Page As String) As List(Of String)

        Dim StrB As New StringBuilder
        Dim jobs As String = "JOB=" & CreSpace(TEHeaderDic("JOB=") - LenB(CStr(Job)), " ") & CStr(Job)
        Dim ReList As New List(Of String)

        StrB.Append(AorBH)

        StrB.Append("DATE:")
        StrB.Append(NowDate)
        StrB.Append(CreSpace(TEHeaderDic("DATE:") - LenB(NowDate), " "))

        StrB.Append("PAGE=")
        StrB.Append(CreSpace(TEHeaderDic("PAGE=") - LenB(Page), "0"))
        StrB.Append(Page)

        StrB.Append(CreSpace(TEHeaderDic("空白1"), " "))

        '従番
        StrB.Append("(")
        StrB.Append(CreSpace(TEHeaderDic("従番"), " "))
        StrB.Append(")")

        StrB.Append(jobs)

        ReList.Add(StrB.ToString)
        StrB.Clear()

        StrB.Append(CreSpace(TEHeaderDic("空白2"), " "))

        'ジョブNo.
        StrB.Append(jobs)

        StrB.Append(CreSpace(TEHeaderDic("空白3"), " "))

        '工番
        StrB.Append("KOOBAN---")
        StrB.Append(Kouban)
        StrB.Append(CreSpace(TEHeaderDic("KOOBAN---") - LenB(Kouban), " "))

        '群番

        StrB.Append("GRP---")
        StrB.Append(Gun)
        StrB.Append(CreSpace(TEHeaderDic("GRP=") - LenB(Gun), " "))

        '盤No.
        Dim Ban As String = BanNo.Trim()
        StrB.Append("BAN---")
        StrB.Append(Ban)
        StrB.Append(CreSpace(TEHeaderDic("BAN---") - LenB(Ban), " "))

        '前背
        StrB.Append("FB---")
        StrB.Append(FB)
        StrB.Append(CreSpace(TEHeaderDic("FB---") - LenB(FB), " "))

        StrB.Append("SCT---")
        StrB.Append(CreSpace(TEHeaderDic("SCT---"), " "))

        StrB.Append("ZONE---")
        StrB.Append(CreSpace(TEHeaderDic("ZONE---"), " "))

        ReList.Add(StrB.ToString)

        Return ReList
    End Function



     Sub CreTEABWAT()
        Dim key As String   'From座標名
        Dim dic As Dictionary(Of String, String())
        Dim temp As String
        Dim arr As String()

        For i As Integer = 0 To Root.Count - 1
            '座標名の分だけ繰り返す
            key = Root.Keys(i)
            dic = Root(key)
            For j As Integer = 0 To dic.Count - 1
                '仮座標の分だけ繰り返す
                temp = dic.Keys(j)
                '(0)=座標名、(1)=カウント、(2)=
                arr = dic(temp)

                If Left(arr(0), 2) = "YY" Then

                Else

                End If
            Next
        Next i
     End Sub

End Module
